#ifndef UE4SS_SDK_BP_InputKeyState_HPP
#define UE4SS_SDK_BP_InputKeyState_HPP

class UBP_InputKeyState_C : public UObject
{
    bool IsPressed;                                                                   // 0x0028 (size: 0x1)
    FBP_InputKeyState_COnPressed OnPressed;                                           // 0x0030 (size: 0x10)
    void OnPressed();
    FBP_InputKeyState_COnReleased OnReleased;                                         // 0x0040 (size: 0x10)
    void OnReleased();
    bool IsPressedAlreadyBound;                                                       // 0x0050 (size: 0x1)
    bool IsReleasedAlreadyBound;                                                      // 0x0051 (size: 0x1)
    class UObject* Pressed_BoundObject;                                               // 0x0058 (size: 0x8)
    class UObject* Released_BoundObject;                                              // 0x0060 (size: 0x8)
    FName KeyName;                                                                    // 0x0068 (size: 0x8)
    int32 LayerIndex;                                                                 // 0x0070 (size: 0x4)
    double AxisValue;                                                                 // 0x0078 (size: 0x8)
    FBP_InputKeyState_COnAxisValue OnAxisValue;                                       // 0x0080 (size: 0x10)
    void OnAxisValue(double Value);
    FBP_InputKeyState_COnPressedKey OnPressedKey;                                     // 0x0090 (size: 0x10)
    void OnPressedKey(class UBP_InputKeyState_C* KeyState);

    void BindPressedKey(const FBindPressedKeyEvent& Event, class UObject* Pressed_BoundObject);
    void BindAxis(const FBindAxisEvent& Event, class UObject* Pressed_BoundObject);
    void UnbindReleasedByObject(class UObject* Object);
    void UnbindPressedByObject(class UObject* Object);
    void UnbindPressedByEvent(const FUnbindPressedByEventEvent& Event);
    void BindReleased(const FBindReleasedEvent& Event, class UObject* BoundObject);
    void BindPressed(const FBindPressedEvent& Event, class UObject* Pressed_BoundObject);
    void UpdateState(bool IsKeyDown, bool DisableEvents, double AxisValue, bool& WasConsumed);
    void Init(FName KeyName, int32 LayerIndex, bool IsPressed);
    void OnPressedKey__DelegateSignature(class UBP_InputKeyState_C* KeyState);
    void OnAxisValue__DelegateSignature(double Value);
    void OnReleased__DelegateSignature();
    void OnPressed__DelegateSignature();
}; // Size: 0xA0

#endif
