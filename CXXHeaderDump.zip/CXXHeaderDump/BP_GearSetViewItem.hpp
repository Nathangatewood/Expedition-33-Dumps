#ifndef UE4SS_SDK_BP_GearSetViewItem_HPP
#define UE4SS_SDK_BP_GearSetViewItem_HPP

class UBP_GearSetViewItem_C : public UObject
{
    class UBP_GearSetManager_C* OwnerGearSetManager;                                  // 0x0028 (size: 0x8)
    FString GearSetID;                                                                // 0x0030 (size: 0x10)

    void GetGearSetID(FString& GearSetID);
    void GetGearSetManager(class UBP_GearSetManager_C*& GearSetManager);
    void InitializeViewItem(FString GearSetID);
}; // Size: 0x40

#endif
