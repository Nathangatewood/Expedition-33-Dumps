#ifndef UE4SS_SDK_BP_GroupInstance_UniqueMechanic_Masks_HPP
#define UE4SS_SDK_BP_GroupInstance_UniqueMechanic_Masks_HPP

class UBP_GroupInstance_UniqueMechanic_Masks_C : public UBP_GroupInstance_Skill_Base_C
{
    TEnumAsByte<E_Transform_Masks_Mechanic::Type> MatchingMask;                       // 0x0038 (size: 0x1)
    bool OnlyExotic;                                                                  // 0x0039 (size: 0x1)
    bool UnsetOnly;                                                                   // 0x003A (size: 0x1)

    FText GetGroupDisplayName();
    void DoesSkillMatch(class UBP_DataAsset_Skill_C* SkillData, bool& MatchesGroup);
}; // Size: 0x3B

#endif
