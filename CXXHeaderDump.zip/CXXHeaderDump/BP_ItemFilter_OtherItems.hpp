#ifndef UE4SS_SDK_BP_ItemFilter_OtherItems_HPP
#define UE4SS_SDK_BP_ItemFilter_OtherItems_HPP

class UBP_ItemFilter_OtherItems_C : public UBP_ItemFilterAbstract_ItemType_C
{

    void GetFilteredTypes(TArray<TEnumAsByte<E_jRPG_ItemType::Type>>& FilteredType);
    void GetDisplayName(FText& DisplayName);
}; // Size: 0x28

#endif
