#ifndef UE4SS_SDK_BP_jRPG_GM_World_HPP
#define UE4SS_SDK_BP_jRPG_GM_World_HPP

class ABP_jRPG_GM_World_C : public ASandfallGameMode
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0348 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0350 (size: 0x8)
    class UBP_WorldInfoComponent_C* BP_WorldInfoComponent;                            // 0x0358 (size: 0x8)
    class UBP_GameFlowTransitionSystem_C* BP_GameFlowTransitionSystem;                // 0x0360 (size: 0x8)
    class USceneComponent* DefaultSceneRoot2;                                         // 0x0368 (size: 0x8)
    TSoftObjectPtr<class ABP_LightingScenarioReference_C> StartLevelLightingScenario; // 0x0370 (size: 0x28)
    FS_AreaAudioParameters StartLevelAudioParam;                                      // 0x0398 (size: 0x38)
    FTransform SpawnTransform;                                                        // 0x03D0 (size: 0x60)

    void GetSpawnTransform(FTransform& SpawnTransform);
    void ReceiveBeginPlay();
    void HandleStartingNewPlayer(class APlayerController* NewPlayer);
    void K2_OnRestartPlayer(class AController* NewPlayer);
    void OnPreStartPlay();
    void OnGraphicSettingsApplied(class UConfigurableGameUserSettings* Settings);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_jRPG_GM_World(int32 EntryPoint);
}; // Size: 0x430

#endif
