#ifndef UE4SS_SDK_BP_GameActionInstance_ReplaceCharacter_HPP
#define UE4SS_SDK_BP_GameActionInstance_ReplaceCharacter_HPP

class UBP_GameActionInstance_ReplaceCharacter_C : public UGameActionInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0040 (size: 0x8)
    class UBP_CharacterData_C* OldCharacterData;                                      // 0x0048 (size: 0x8)
    class UBP_CharacterData_C* NewCharacterData;                                      // 0x0050 (size: 0x8)
    FS_jRPG_CharacterSaveState OldCharacterSaveState;                                 // 0x0058 (size: 0x1C0)
    FS_jRPG_CharacterSaveState NewCharacterSaveState;                                 // 0x0218 (size: 0x1C0)

    bool ShouldTriggerAutoSaveAfterExecution();
    void ReplaceEquippedItemsFromOldToNew(TEnumAsByte<E_jRPG_ItemType::Type> ItemType);
    void RemoveOldCharacterFromCollection();
    void AddNewCharacterToPartyIfNeeded();
    void AddNewCharacterToCollection();
    void ComputeNewCharacterSaveState();
    void GetCharacterIDs(FName& OldCharacter, FName& NewCharacter);
    void GetReplaceCharacterParameters(FS_ReplaceCharacterParameters& ReplaceCharacterParameters);
    FString GetDebugString();
    void ExecuteGameAction(const class APlayerController* Controller);
    void ExecuteUbergraph_BP_GameActionInstance_ReplaceCharacter(int32 EntryPoint);
}; // Size: 0x3D8

#endif
