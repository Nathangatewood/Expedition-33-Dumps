#ifndef UE4SS_SDK_BP_GradientGaugeSystem_HPP
#define UE4SS_SDK_BP_GradientGaugeSystem_HPP

class UBP_GradientGaugeSystem_C : public UExtendedObject
{
    double CurrentProgress;                                                           // 0x0028 (size: 0x8)
    int32 AvailableCharges;                                                           // 0x0030 (size: 0x4)
    TArray<UAC_jRPG_CharacterBattleStats_C*> SourceCharacters;                        // 0x0038 (size: 0x10)
    float ProgressPerAPSpent;                                                         // 0x0048 (size: 0x4)
    int32 MaxCharges;                                                                 // 0x004C (size: 0x4)
    FBP_GradientGaugeSystem_COnGradientGaugeChanged OnGradientGaugeChanged;           // 0x0050 (size: 0x10)
    void OnGradientGaugeChanged(double PreviousProgress, int32 PreviousCharges);

    void SetCurrentGradientGauge(int32 NewCharges, double NewProgress, FString Reason);
    bool CanAffordCharges(int32 Amount);
    void ConsumeCharge(int32 Amount);
    int32 GetAvailableCharges();
    double GetCurrentProgress();
    void ApplyGaugeChangeFromEvent(class UBP_GradientGaugeChangeEvent_C* Event);
    void ChangeGradientGauge(double Delta, FString Reason);
    void OnCharacterAPChangedInternal(int32 NewAP, int32 PreviousAP, class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterAPChangedEvent(class UBP_BattleEvent_APChange_C* APChange);
    void RegisterSourceCharacter(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnGradientGaugeChanged__DelegateSignature(double PreviousProgress, int32 PreviousCharges);
}; // Size: 0x60

#endif
