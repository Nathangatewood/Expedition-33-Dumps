#ifndef UE4SS_SDK_BP_ItemUpgradeSystem_HPP
#define UE4SS_SDK_BP_ItemUpgradeSystem_HPP

class UBP_ItemUpgradeSystem_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    FBP_ItemUpgradeSystem_COnWeaponReplaced OnWeaponReplaced;                         // 0x0030 (size: 0x10)
    void OnWeaponReplaced(FS_WeaponInstanceData ReplacedWeaponInstance);
    TArray<FS_WeaponInstanceData> OwnedWeaponInstances;                               // 0x0040 (size: 0x10)
    FBP_ItemUpgradeSystem_COnWeaponModified OnWeaponModified;                         // 0x0050 (size: 0x10)
    void OnWeaponModified();
    TMap<TEnumAsByte<EWeaponQuality::Type>, FS_ItemQuantityList> UpgradeCostTable;    // 0x0060 (size: 0x50)
    TMap<FName, FName> ConsumableShardUpgradeTable;                                   // 0x00B0 (size: 0x50)
    TMap<FName, UBP_DataAsset_Item_Shard_C*> ShardDataCache;                          // 0x0100 (size: 0x50)
    TMap<FName, FName> UpgradeItemToShard;                                            // 0x0150 (size: 0x50)
    TMap<FName, int32> UpgradeLevelsByShard;                                          // 0x01A0 (size: 0x50)
    TMap<FName, FName> ConsumableItemToShard;                                         // 0x01F0 (size: 0x50)
    TMap<FName, UBP_ItemInstance_Base_C*> ItemInstances;                              // 0x0240 (size: 0x50)
    TMap<int32, FS_ItemQuantityList> UpgradeCostTable_V2;                             // 0x0290 (size: 0x50)

    void ResetUpgradeSystemForNewGamePlus();
    void IsShardUpgradable(FName ShardName, bool& IsShardUpgradable);
    void UpgradeShardToNextLevel(FName ShardName, bool& bIsUpgradeSuccessful);
    void UpgradeWeaponFromInstance(class UBP_ItemInstance_Gear_C* ItemInstance, FString DebugReason);
    void GetItemInstanceUpgradeCost(class UBP_ItemInstance_Gear_C* GearItemInstance, TArray<FS_ItemQuantity>& ItemQuantities);
    TArray<UBP_ItemInstance_Base_C*> GetAllItemInstances();
    TSubclassOf<class UBP_ItemInstance_Base_C> GetItemInstanceClassFromData(FS_jRPG_Item_StaticData ItemStaticData);
    void FindItemInstanceByID(FName ItemDefinitionID, class UBP_ItemInstance_Base_C*& ItemInstance);
    void CreateItemInstanceInternal(const FS_jRPG_Item_StaticData& ItemStaticData, int32 Quantity, class UBP_ItemInstance_Base_C*& ItemInstance);
    void CreateItemInstanceTransient(const FS_jRPG_Item_StaticData& ItemStaticData, int32 Quantity, class UBP_ItemInstance_Base_C*& ItemInstance);
    void GetOrCreateItemInstance(const FS_jRPG_Item_StaticData& ItemStaticData, int32 Quantity, class UBP_ItemInstance_Base_C*& ItemInstance);
    void OnItemRemovedFromInventory(const FS_jRPG_Item_StaticData& ItemStaticData, int32 Amount, int32& RemainingQuantity);
    void GetShardForConsumable(const FName& ConsumableID, FName& ShardID);
    FDataTableRowHandle GetUpgradedConsumableItemFromShard(FName ShardStaticDataID);
    bool IsItemConsumableUpgrade(FName ItemId);
    void OnItemAddedToInventory(const FS_jRPG_Item_StaticData& ItemStaticData, int32 Quantity, FS_LootContext LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItemInfo);
    void GetShardItemUpgradeItemRow(class UBP_DataAsset_Item_Shard_C* ShardItem, FDataTableRowHandle& UpgradeItemRow);
    void LoadShardDefinition(FS_jRPG_Item_StaticData ShardItemDefinition);
    void GetWeaponQualityLevel(FName WeaponDefinitionID, TEnumAsByte<EWeaponQuality::Type>& Quality);
    void ComputeWeaponUnlockedPassivesFromID(FName WeaponID, TArray<FName>& ActivePassiveEffectIDs);
    void GetItemUpgradeCost(FName WeaponDefinitionID, TArray<FS_ItemQuantity>& ItemQuantities);
    void GetUpgradeResourceList(TArray<FDataTableRowHandle>& UpgradeResourcesList);
    void GetWeaponQualityForUpgradeLevel(int32 UpgradeLevel, TEnumAsByte<EWeaponQuality::Type>& Quality);
    void UpgradeWeaponFromHandle(FS_WeaponInstanceHandle WeaponHandle, FS_WeaponInstanceData& UpgradedWeaponData);
    void CreateInventorySaveState(TArray<FS_WeaponInstanceHandle>& WeaponHandles);
    void LoadInventoryState(TArray<FS_WeaponInstanceHandle>& WeaponHandles);
    void ComputeWeaponInstanceData(FS_WeaponInstanceHandle WeaponHandle, FS_WeaponInstanceData& WeaponInstanceData);
    void UpdateWeaponInstance(FS_WeaponInstanceData WeaponInstanceData);
    void FindWeaponInstanceByWeaponID(FName WeaponDefinitionID, bool& Found, int32& WeaponIndex, FS_WeaponInstanceData& WeaponInstanceData);
    void AddWeaponToInventory(const FS_WeaponInstanceHandle& WeaponInstanceHandle, int32& PreviousLevel);
    void ResetState();
    void Initialize();
    void Sandfall_Debug_UpgradeWeapon(FName WeaponID);
    void Sandfall_Debug_SetGearLevel(FName WeaponID, int32 NewLevel);
    void ExecuteUbergraph_BP_ItemUpgradeSystem(int32 EntryPoint);
    void OnWeaponModified__DelegateSignature();
    void OnWeaponReplaced__DelegateSignature(FS_WeaponInstanceData ReplacedWeaponInstance);
}; // Size: 0x2E0

#endif
