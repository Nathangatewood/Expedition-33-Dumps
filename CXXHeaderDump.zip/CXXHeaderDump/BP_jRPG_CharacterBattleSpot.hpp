#ifndef UE4SS_SDK_BP_jRPG_CharacterBattleSpot_HPP
#define UE4SS_SDK_BP_jRPG_CharacterBattleSpot_HPP

class ABP_jRPG_CharacterBattleSpot_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* SpawnPosition;                                             // 0x0298 (size: 0x8)
    class USkeletalMeshComponent* PreviewMesh;                                        // 0x02A0 (size: 0x8)
    class UTextRenderComponent* BacklineText;                                         // 0x02A8 (size: 0x8)
    class UArrowComponent* BacklineArrow;                                             // 0x02B0 (size: 0x8)
    class UCapsuleComponent* BacklineCapsule;                                         // 0x02B8 (size: 0x8)
    class UTextRenderComponent* FrontlineText;                                        // 0x02C0 (size: 0x8)
    class UArrowComponent* FrontlineArrow;                                            // 0x02C8 (size: 0x8)
    class UCapsuleComponent* FrontlineCapsule;                                        // 0x02D0 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02D8 (size: 0x8)
    int32 SlotIndex;                                                                  // 0x02E0 (size: 0x4)

    void UserConstructionScript();
    void ReceiveBeginPlay();
    void DEBUG_CVarChange_ShowBattleDebug(bool NewValue);
    void ExecuteUbergraph_BP_jRPG_CharacterBattleSpot(int32 EntryPoint);
}; // Size: 0x2E4

#endif
