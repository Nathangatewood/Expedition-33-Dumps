#ifndef UE4SS_SDK_BP_GameAction_WritePersistentFlag_HPP
#define UE4SS_SDK_BP_GameAction_WritePersistentFlag_HPP

class UBP_GameAction_WritePersistentFlag_C : public UBP_PDT_GameAction_C
{
    class UNamedID* NamedID;                                                          // 0x0030 (size: 0x8)
    bool Value;                                                                       // 0x0038 (size: 0x1)

    void ValidateGameAction(TArray<FText>& ErrorMessages, FString& PropertyPath, bool& ExploreAssetChildren);
    TSubclassOf<class UGameActionInstance> GetInstanceClass();
}; // Size: 0x39

#endif
