#ifndef UE4SS_SDK_BP_GameDirectorComponent_HPP
#define UE4SS_SDK_BP_GameDirectorComponent_HPP

class UBP_GameDirectorComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class ALevelSequenceActor* CurrentBattleTurnSequence;                             // 0x00A8 (size: 0x8)
    TMap<ULevelSequence*, ALevelSequenceActor*> PreloadedLevelSequenceActors;         // 0x00B0 (size: 0x50)
    class ALevelSequenceActor* PreviousBattleTurnSequenceActor;                       // 0x0100 (size: 0x8)
    TEnumAsByte<EGameDirectorTargetType::Type> CurrentTarget;                         // 0x0108 (size: 0x1)
    bool IsDynamicCamDirty;                                                           // 0x0109 (size: 0x1)
    class ALevelSequenceActor* NextBattleTurnSequenceActor;                           // 0x0110 (size: 0x8)
    class AActor* NextBattleTurnSequenceCharacter;                                    // 0x0118 (size: 0x8)
    FString DEBUG_LogIndent;                                                          // 0x0120 (size: 0x10)
    int32 DEBUG_LogIndentCount;                                                       // 0x0130 (size: 0x4)
    bool DEBUG_VerboseIndent;                                                         // 0x0134 (size: 0x1)
    bool CanBeInterrupted;                                                            // 0x0135 (size: 0x1)

    void SetBattleTurnSequencePaused(bool Paused);
    void PrintText(const FText InText);
    void OnWorldSkillEnd();
    void OnFreeAimCancelled();
    void OnWorldSkillStart();
    void Unload Sequence(class ALevelSequenceActor* LevelSequenceActor);
    void PreloadLevelSequence(class ULevelSequence* LevelSequence, class ALevelSequenceActor*& OutActor);
    void PlayBattleTurnSequence(class ALevelSequenceActor* BattleTurnSequence, class AActor* Character);
    void OnBattleTurnSequenceStop();
    void OnBattleTurnSequencePaused();
    void StartPreloadingLevelSequence();
    void StopAnyBattleTurnSequence();
    void OnEpicBattleSequencePlay();
    void ReceiveTick(float DeltaSeconds);
    void OnDynamicCameraActivatedInternal();
    void OnDynamicCameraActivated(FString DEBUG_CameraType);
    void ActivateTargetingCamera(class UCameraComponent* TargetingCamera, class AActor* ViewTarget);
    void InterruptDynamicCameraChange();
    void OnBattleEnd();
    void OnEpicBattleSequenceEnds();
    void DisableTargetingCamera(class UActorComponent* TargetingCamera);
    void ExecuteUbergraph_BP_GameDirectorComponent(int32 EntryPoint);
}; // Size: 0x136

#endif
