#ifndef UE4SS_SDK_BP_GameMenu_Verso_HPP
#define UE4SS_SDK_BP_GameMenu_Verso_HPP

class ABP_GameMenu_Verso_C : public ABP_Cine_Verso_C
{
    class UBP_CharacterVisualAlterationsComponent_C* BP_CharacterVisualAlterationsComponent; // 0x06D8 (size: 0x8)

}; // Size: 0x6E0

#endif
