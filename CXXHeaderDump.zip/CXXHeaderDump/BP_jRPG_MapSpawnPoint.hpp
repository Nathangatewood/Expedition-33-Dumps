#ifndef UE4SS_SDK_BP_jRPG_MapSpawnPoint_HPP
#define UE4SS_SDK_BP_jRPG_MapSpawnPoint_HPP

class ABP_jRPG_MapSpawnPoint_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UArrowComponent* Arrow;                                                     // 0x0298 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02A0 (size: 0x8)
    class UTextRenderComponent* TextRender;                                           // 0x02A8 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x02B0 (size: 0x8)
    FName SpawnPointName;                                                             // 0x02B8 (size: 0x8)
    FGameplayTag SpawnPointTag;                                                       // 0x02C0 (size: 0x8)
    FS_AreaAudioParameters SpawnPointMusic;                                           // 0x02C8 (size: 0x38)
    TSoftObjectPtr<class ABP_LightingScenarioReference_C> LightingScenario;           // 0x0300 (size: 0x28)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    FString GetDebugString();
    void GetSpawnTransfrom(FTransform& SpawnTransform);
    void UserConstructionScript();
    void PrevizLightingScenario();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_jRPG_MapSpawnPoint(int32 EntryPoint);
}; // Size: 0x328

#endif
