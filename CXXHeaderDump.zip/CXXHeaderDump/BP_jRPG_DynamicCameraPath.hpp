#ifndef UE4SS_SDK_BP_jRPG_DynamicCameraPath_HPP
#define UE4SS_SDK_BP_jRPG_DynamicCameraPath_HPP

class ABP_jRPG_DynamicCameraPath_C : public AActor
{
    class USplineComponent* Spline;                                                   // 0x0290 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x0298 (size: 0x8)
    class UCameraComponent* PreviewCamera;                                            // 0x02A0 (size: 0x8)
    FName PathID;                                                                     // 0x02A8 (size: 0x8)
    TEnumAsByte<E_jRPG_CameraPathType::Type> PathType;                                // 0x02B0 (size: 0x1)
    int32 PointsAmount;                                                               // 0x02B4 (size: 0x4)
    double LoopRadius;                                                                // 0x02B8 (size: 0x8)
    bool LoopClosed;                                                                  // 0x02C0 (size: 0x1)
    double SpiralRadius;                                                              // 0x02C8 (size: 0x8)
    double SpiralLength;                                                              // 0x02D0 (size: 0x8)
    double SpiralOffset;                                                              // 0x02D8 (size: 0x8)
    double PreviewTime;                                                               // 0x02E0 (size: 0x8)
    FVector CameraFocusPoint;                                                         // 0x02E8 (size: 0x18)
    FRotator PathInitialRotation;                                                     // 0x0300 (size: 0x18)
    bool UseFocusPoint;                                                               // 0x0318 (size: 0x1)

    void SetCameraFocusPoint(FVector WorldLocation);
    void GetCameraFocusPoint(FVector& FocusLocation);
    void GetPathLocationAtDistance(double Time, FVector& WorldLocation);
    void UserConstructionScript();
}; // Size: 0x319

#endif
