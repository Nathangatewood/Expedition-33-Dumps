#ifndef UE4SS_SDK_BP_jRPG_Character_World_HPP
#define UE4SS_SDK_BP_jRPG_Character_World_HPP

class ABP_jRPG_Character_World_C : public AALS_CharacterBP_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0A38 (size: 0x8)
    class UCameraShakeSourceComponent* CameraShakeSource_Moving;                      // 0x0A40 (size: 0x8)
    class UCharacterSpringArmComponent* CharacterSpringArm;                           // 0x0A48 (size: 0x8)
    class UCineCameraComponent* Main_CineCamera;                                      // 0x0A50 (size: 0x8)
    class UChildActorComponent* Camera_PreCinematic;                                  // 0x0A58 (size: 0x8)
    class USceneComponent* LookAtTarget;                                              // 0x0A60 (size: 0x8)
    class UCameraComponent* MainCamera;                                               // 0x0A68 (size: 0x8)
    class USmartSpringArmComponent* SmartSpringArm_MainCamera;                        // 0x0A70 (size: 0x8)
    class UCapsuleComponent* CompanionAvoidanceCapsule;                               // 0x0A78 (size: 0x8)
    class UBP_CharacterSkinComponent_C* BP_CharacterSkinComponent;                    // 0x0A80 (size: 0x8)
    class UBP_CharacterVisualAlterationsComponent_C* BP_CharacterVisualAlterationsComponent; // 0x0A88 (size: 0x8)
    class UAudioComponent* AC_Vocals_01;                                              // 0x0A90 (size: 0x8)
    class UAudioComponent* AC_Vocals_02;                                              // 0x0A98 (size: 0x8)
    class UAudioComponent* AC_Hand_R_01;                                              // 0x0AA0 (size: 0x8)
    class UAudioComponent* AC_Weapon_R_01;                                            // 0x0AA8 (size: 0x8)
    class UAudioComponent* AC_Weapon_L_01;                                            // 0x0AB0 (size: 0x8)
    class UAudioComponent* AC_Hand_L_01;                                              // 0x0AB8 (size: 0x8)
    class UAudioComponent* AC_Weapon_L_02;                                            // 0x0AC0 (size: 0x8)
    class UAudioComponent* AC_FT_R;                                                   // 0x0AC8 (size: 0x8)
    class UAudioComponent* AC_FT_L;                                                   // 0x0AD0 (size: 0x8)
    class UWorldPartitionStreamingSourceComponent* WorldPartitionStreamingSource;     // 0x0AD8 (size: 0x8)
    class UAudioComponent* Audio_Dialogue;                                            // 0x0AE0 (size: 0x8)
    class UBP_DialogueCameraControllerComponent_C* BP_DialogueCameraControllerComponent; // 0x0AE8 (size: 0x8)
    class USpotLightComponent* SpotLight_Dialogue_RimLeft;                            // 0x0AF0 (size: 0x8)
    class USpotLightComponent* SpotLight_Dialogue_FrontRight;                         // 0x0AF8 (size: 0x8)
    class USpotLightComponent* SpotLight_Dialogue_RimRight;                           // 0x0B00 (size: 0x8)
    class USpotLightComponent* SpotLight_Dialogue_FrontLeft;                          // 0x0B08 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue6;                                 // 0x0B10 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue9;                                 // 0x0B18 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue8;                                 // 0x0B20 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue7;                                 // 0x0B28 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue4;                                 // 0x0B30 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue2;                                 // 0x0B38 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue3;                                 // 0x0B40 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue10;                                // 0x0B48 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue5;                                 // 0x0B50 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue1;                                 // 0x0B58 (size: 0x8)
    class USceneComponent* FocusPoint_Dialogue;                                       // 0x0B60 (size: 0x8)
    class UCineCameraComponent* CineCamera_Dialogue_Main;                             // 0x0B68 (size: 0x8)
    class UBP_NPCAnimationComponent_C* BP_NPCAnimationComponent;                      // 0x0B70 (size: 0x8)
    class UBP_EyeEffectsControllerComponent_C* BP_EyeEffectsControllerComponent;      // 0x0B78 (size: 0x8)
    class UBP_ExplorationCapacityComponent_Rope_C* BP_ExplorationCapacityComponent_Rope; // 0x0B80 (size: 0x8)
    class UBP_ClimbingComponent_C* BP_ClimbingComponent;                              // 0x0B88 (size: 0x8)
    class UBP_CameraControllerComponent_C* BP_CameraControllerComponent;              // 0x0B90 (size: 0x8)
    class UBP_CameraLookAtControllerComponent_C* BP_CameraLookAtControllerComponent;  // 0x0B98 (size: 0x8)
    class UBP_AICompanion_CompanionManager_C* BP_AICompanion_CompanionManager;        // 0x0BA0 (size: 0x8)
    class UBP_AICompanion_TargetPointsComponent_C* BP_AICompanion_TargetPointsComponent; // 0x0BA8 (size: 0x8)
    class UChildActorComponent* ChildActorAimCamera;                                  // 0x0BB0 (size: 0x8)
    class USpringArmComponent* SpringArm_FreeAim;                                     // 0x0BB8 (size: 0x8)
    class UBP_VelocityControllerComponent_C* BP_VelocityControllerComponent;          // 0x0BC0 (size: 0x8)
    class UBP_Component_WorldAnimationProfile_C* BP_Component_WorldAnimationProfile;  // 0x0BC8 (size: 0x8)
    class UBP_FacialAnimationComponent_C* BP_FacialAnimationComponent;                // 0x0BD0 (size: 0x8)
    class USpringArmComponent* Torch_SpringArm;                                       // 0x0BD8 (size: 0x8)
    class UBP_TrailSource_Component_C* BP_TrailSource_Component_r;                    // 0x0BE0 (size: 0x8)
    class UBP_TrailSource_Component_C* BP_TrailSource_Component_l;                    // 0x0BE8 (size: 0x8)
    class UBP_ExplorationCapacityComponent_GrappleHook_C* BP_ExplorationCapacityComponent_GrappleHook; // 0x0BF0 (size: 0x8)
    class UMotionWarpingComponent* MotionWarping;                                     // 0x0BF8 (size: 0x8)
    class UBPC_LightAreaMecanic_C* BPC_LightAreaMecanic;                              // 0x0C00 (size: 0x8)
    class UBP_ExplorationCapacityComponent_FreeAimTeleport_C* BP_ExplorationCapacityComponent_FreeAimTeleport; // 0x0C08 (size: 0x8)
    class UBP_ExplorationCapacityComponent_FreeAimDamage_C* BP_ExplorationCapacityComponent_FreeAimDamage; // 0x0C10 (size: 0x8)
    class UAudioComponent* AC_Idle;                                                   // 0x0C18 (size: 0x8)
    class UAudioComponent* AC_SFX_02;                                                 // 0x0C20 (size: 0x8)
    class UAudioComponent* AC_Foleys_02;                                              // 0x0C28 (size: 0x8)
    class UAudioComponent* AC_Foleys_01;                                              // 0x0C30 (size: 0x8)
    class UAudioComponent* AC_SFX_01;                                                 // 0x0C38 (size: 0x8)
    class UBP_AudioCharacter_Manager_C* BP_AudioCharacter_Manager;                    // 0x0C40 (size: 0x8)
    class USpotLightComponent* SpotLight1;                                            // 0x0C48 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0C50 (size: 0x8)
    class USceneComponent* ProjectileSpawnLocation;                                   // 0x0C58 (size: 0x8)
    class UChildActorComponent* ChildActor_Skin;                                      // 0x0C60 (size: 0x8)
    class UArrowComponent* Arrow2;                                                    // 0x0C68 (size: 0x8)
    class UChildActorComponent* SneakActorCamera;                                     // 0x0C70 (size: 0x8)
    class UArrowComponent* EndSneakCamArrow;                                          // 0x0C78 (size: 0x8)
    class UArrowComponent* StartSneakCamArrow;                                        // 0x0C80 (size: 0x8)
    class URectLightComponent* RectLight;                                             // 0x0C88 (size: 0x8)
    class UArrowComponent* DashFxLoc1;                                                // 0x0C90 (size: 0x8)
    class UBP_FreeAim_C* BP_FreeAimControlComponent;                                  // 0x0C98 (size: 0x8)
    class UCameraComponent* ShoulderCam;                                              // 0x0CA0 (size: 0x8)
    class USpringArmComponent* ShoulderSpringArm;                                     // 0x0CA8 (size: 0x8)
    class UArrowComponent* ExploAtkArrow;                                             // 0x0CB0 (size: 0x8)
    class UArrowComponent* DashFxLoc;                                                 // 0x0CB8 (size: 0x8)
    class UStaticMeshComponent* NinjaTraceMesh;                                       // 0x0CC0 (size: 0x8)
    class USpotLightComponent* CharaxcterLightBack;                                   // 0x0CC8 (size: 0x8)
    class USpotLightComponent* CharacterLightFront;                                   // 0x0CD0 (size: 0x8)
    class UBoxComponent* WorldStrikeCollision;                                        // 0x0CD8 (size: 0x8)
    class UBoxComponent* DialogBox;                                                   // 0x0CE0 (size: 0x8)
    float Timeline_ExplorationAttack_HitBoxTrack_F552019B465836AC171344A345E24AF5;    // 0x0CE8 (size: 0x4)
    float Timeline_ExplorationAttack_StepForwardTrack_F552019B465836AC171344A345E24AF5; // 0x0CEC (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_ExplorationAttack__Direction_F552019B465836AC171344A345E24AF5; // 0x0CF0 (size: 0x1)
    class UTimelineComponent* Timeline_ExplorationAttack;                             // 0x0CF8 (size: 0x8)
    float Timeline_1_DistanceMultiplier_530E22E44FEF074B39B902B36F8EE6E0;             // 0x0D00 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_530E22E44FEF074B39B902B36F8EE6E0; // 0x0D04 (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x0D08 (size: 0x8)
    float EnableIKTimeline_IKAlpha_DDD7A86D4122DF4EACB63E877B021AFE;                  // 0x0D10 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> EnableIKTimeline__Direction_DDD7A86D4122DF4EACB63E877B021AFE; // 0x0D14 (size: 0x1)
    class UTimelineComponent* EnableIKTimeline;                                       // 0x0D18 (size: 0x8)
    float Timeline_0_SpringArmMovement_E5045E2A45345B73800A59A639C19BD6;              // 0x0D20 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_E5045E2A45345B73800A59A639C19BD6; // 0x0D24 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0D28 (size: 0x8)
    float FoV_Control_Timeline_SpringArmMovement_9901529640326D15C1E16593984FA550;    // 0x0D30 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> FoV_Control_Timeline__Direction_9901529640326D15C1E16593984FA550; // 0x0D34 (size: 0x1)
    class UTimelineComponent* FoV_Control_Timeline;                                   // 0x0D38 (size: 0x8)
    float SpringArmReset_Timeline_SpringArmMovement_97E0D35D46F19FBD762F89AA85055A4E; // 0x0D40 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> SpringArmReset_Timeline__Direction_97E0D35D46F19FBD762F89AA85055A4E; // 0x0D44 (size: 0x1)
    class UTimelineComponent* SpringArmReset_Timeline;                                // 0x0D48 (size: 0x8)
    float SpringArmControl_Timeline_SpringArmMovement_50E9683048EA6E7F81BD9E94476B74B7; // 0x0D50 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> SpringArmControl_Timeline__Direction_50E9683048EA6E7F81BD9E94476B74B7; // 0x0D54 (size: 0x1)
    class UTimelineComponent* SpringArmControl_Timeline;                              // 0x0D58 (size: 0x8)
    float FX_ArmRingColor_0to1_9F591E5949084DB1308311B637BE9513;                      // 0x0D60 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> FX_ArmRingColor__Direction_9F591E5949084DB1308311B637BE9513; // 0x0D64 (size: 0x1)
    class UTimelineComponent* FX_ArmRingColor;                                        // 0x0D68 (size: 0x8)
    float Timeline_GrappeCamera_FieldOfView_CA80C41844AFE0A643BF3BA198223DE5;         // 0x0D70 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_GrappeCamera__Direction_CA80C41844AFE0A643BF3BA198223DE5; // 0x0D74 (size: 0x1)
    class UTimelineComponent* Timeline_GrappeCamera;                                  // 0x0D78 (size: 0x8)
    TArray<AActor*> ActorInInteractionRange;                                          // 0x0D80 (size: 0x10)
    class AActor* ActorToInteract;                                                    // 0x0D90 (size: 0x8)
    class ABP_jRPG_Controller_World_C* PlayerController;                              // 0x0D98 (size: 0x8)
    class UW_UseWidget_C* UseWidget;                                                  // 0x0DA0 (size: 0x8)
    class UBP_DialogSystem_C* DialogSystemReference;                                  // 0x0DA8 (size: 0x8)
    class AActor* HitActor;                                                           // 0x0DB0 (size: 0x8)
    bool IsInDialogue;                                                                // 0x0DB8 (size: 0x1)
    double DeltaTime;                                                                 // 0x0DC0 (size: 0x8)
    bool IsTeleporting?;                                                              // 0x0DC8 (size: 0x1)
    class UMaterialInstanceDynamic* SpeedLinesBlendable;                              // 0x0DD0 (size: 0x8)
    TArray<UObject*> reversibleActors;                                                // 0x0DD8 (size: 0x10)
    TArray<UObject*> reversibleCharacters;                                            // 0x0DE8 (size: 0x10)
    class UParticleSystemComponent* Particles;                                        // 0x0DF8 (size: 0x8)
    TArray<UMaterialInterface*> AllMeshMaterials;                                     // 0x0E00 (size: 0x10)
    int32 JumpCounter;                                                                // 0x0E10 (size: 0x4)
    FDataTableRowHandle MovementStruct;                                               // 0x0E18 (size: 0x10)
    class ABP_jRPG_Enemy_World_Base_Seamless_C* EnemyHit;                             // 0x0E28 (size: 0x8)
    bool DashCooldownActive;                                                          // 0x0E30 (size: 0x1)
    double DashDuration;                                                              // 0x0E38 (size: 0x8)
    class UAnimMontage* DashAnimMontage;                                              // 0x0E40 (size: 0x8)
    double DashForce;                                                                 // 0x0E48 (size: 0x8)
    class UParticleSystem* DashVfx;                                                   // 0x0E50 (size: 0x8)
    class UParticleSystemComponent* TrailFx;                                          // 0x0E58 (size: 0x8)
    double DashZHeight;                                                               // 0x0E60 (size: 0x8)
    bool ShouldAdapteDashMovementToGround;                                            // 0x0E68 (size: 0x1)
    int32 DashCount;                                                                  // 0x0E6C (size: 0x4)
    int32 MaxDashCount;                                                               // 0x0E70 (size: 0x4)
    double AdaptativeDashGroundCheck;                                                 // 0x0E78 (size: 0x8)
    FVector DashInputVectorCache;                                                     // 0x0E80 (size: 0x18)
    FVector DashCamForwardVectorCache;                                                // 0x0E98 (size: 0x18)
    bool DashInterupted;                                                              // 0x0EB0 (size: 0x1)
    FVector PreventingLocationCache;                                                  // 0x0EB8 (size: 0x18)
    bool bIsDashing;                                                                  // 0x0ED0 (size: 0x1)
    bool DashUseInputVector;                                                          // 0x0ED1 (size: 0x1)
    bool ShouldNotUseAdaptiveDash;                                                    // 0x0ED2 (size: 0x1)
    double DashForwardChekDistance;                                                   // 0x0ED8 (size: 0x8)
    double AdaptativeDashRoofCheck;                                                   // 0x0EE0 (size: 0x8)
    double DashCoolDownAerial;                                                        // 0x0EE8 (size: 0x8)
    double DashCoolDownGround;                                                        // 0x0EF0 (size: 0x8)
    bool bIsWorldMapPawn;                                                             // 0x0EF8 (size: 0x1)
    double DashAtkForce;                                                              // 0x0F00 (size: 0x8)
    double DashAtkHeight;                                                             // 0x0F08 (size: 0x8)
    FVector DashAtkInputVector;                                                       // 0x0F10 (size: 0x18)
    FVector DashAtkCamForwardVector;                                                  // 0x0F28 (size: 0x18)
    class UParticleSystemComponent* DashAtkTrailFX;                                   // 0x0F40 (size: 0x8)
    double AtkCoolDown;                                                               // 0x0F48 (size: 0x8)
    double DashAtkHitBoxSize;                                                         // 0x0F50 (size: 0x8)
    FVector DashAttackHitBoxHalf Size;                                                // 0x0F58 (size: 0x18)
    bool CanDamageLevelElementsLv1;                                                   // 0x0F70 (size: 0x1)
    class UAnimMontage* AM_ExplorationAtk;                                            // 0x0F78 (size: 0x8)
    double ExplorationAttackStepForwardForce;                                         // 0x0F80 (size: 0x8)
    bool CanDamageLevelElementsLv2;                                                   // 0x0F88 (size: 0x1)
    bool ExploAtkHitSomething;                                                        // 0x0F89 (size: 0x1)
    bool CanDamageLevelElementsLv3;                                                   // 0x0F8A (size: 0x1)
    class UParticleSystem* DashAttackImpactFX;                                        // 0x0F90 (size: 0x8)
    double DashAtkRecover;                                                            // 0x0F98 (size: 0x8)
    class UAnimMontage* AmExploAtkInterupted;                                         // 0x0FA0 (size: 0x8)
    FDataTableRowHandle FreeAimMovementModel;                                         // 0x0FA8 (size: 0x10)
    FDataTableRowHandle WalkingMovementModel;                                         // 0x0FB8 (size: 0x10)
    bool DEBUG_IsInvisible;                                                           // 0x0FC8 (size: 0x1)
    double InvisibilityEffectDuration;                                                // 0x0FD0 (size: 0x8)
    FVector CheckpointLocation;                                                       // 0x0FD8 (size: 0x18)
    FRotator CheckPointRotation;                                                      // 0x0FF0 (size: 0x18)
    bool IsInDebugFlyMode;                                                            // 0x1008 (size: 0x1)
    double DebugFlyingGravityScale;                                                   // 0x1010 (size: 0x8)
    FDataTableRowHandle DebugFlyingMovementModel;                                     // 0x1018 (size: 0x10)
    FDataTableRowHandle DebugWalkingMovementModel;                                    // 0x1028 (size: 0x10)
    double DebugGravityScaleCache;                                                    // 0x1038 (size: 0x8)
    bool IsSneaking;                                                                  // 0x1040 (size: 0x1)
    FRotator StartSneakActorRotCache;                                                 // 0x1048 (size: 0x18)
    FVector StartSneakActorLocCache;                                                  // 0x1060 (size: 0x18)
    FVector EndSneakArrowLoc;                                                         // 0x1078 (size: 0x18)
    FRotator EndSneakArrowRot;                                                        // 0x1090 (size: 0x18)
    bool StartSneaking;                                                               // 0x10A8 (size: 0x1)
    FRotator SneakCamRelativeRotCache;                                                // 0x10B0 (size: 0x18)
    FVector SneakCameraLocCache;                                                      // 0x10C8 (size: 0x18)
    FRotator SneakCameraRotCache;                                                     // 0x10E0 (size: 0x18)
    FVector SneakCamRelativeLocCache;                                                 // 0x10F8 (size: 0x18)
    FVector EndSneakCamLocCache;                                                      // 0x1110 (size: 0x18)
    FRotator EndSneakCamRotCache;                                                     // 0x1128 (size: 0x18)
    bool IsClimbing;                                                                  // 0x1140 (size: 0x1)
    class USplineComponent* Sneak Spline to Follow;                                   // 0x1148 (size: 0x8)
    double SneakDistanceValue;                                                        // 0x1150 (size: 0x8)
    double DistanceOnSpline;                                                          // 0x1158 (size: 0x8)
    bool StartSneakFromSplineEnd;                                                     // 0x1160 (size: 0x1)
    double InputForwardBackwardValue;                                                 // 0x1168 (size: 0x8)
    FVector EndSneakCamWorldLoc;                                                      // 0x1170 (size: 0x18)
    FRotator EndSneakCamWorldRot;                                                     // 0x1188 (size: 0x18)
    class UArrowComponent* SneakEntryArrow;                                           // 0x11A0 (size: 0x8)
    class ABP_SneakCam_C* SneakCam;                                                   // 0x11A8 (size: 0x8)
    class UAnimMontage* SneakExitAtSplineEnd;                                         // 0x11B0 (size: 0x8)
    class UAnimMontage* SneakExitAtSplineStart;                                       // 0x11B8 (size: 0x8)
    FFluidForceDynamic FluidForceDynamic Settings;                                    // 0x11C0 (size: 0x70)
    bool TutoGameIsPaused;                                                            // 0x1230 (size: 0x1)
    class UWBP_TutoPanel_C* CurrentTutoPanel;                                         // 0x1238 (size: 0x8)
    class UWBP_DialogNotifBox_C* CurrentDialogUI;                                     // 0x1240 (size: 0x8)
    double EndCombatTransitionDuration;                                               // 0x1248 (size: 0x8)
    bool LightingActiveWhenStartPlaying;                                              // 0x1250 (size: 0x1)
    class UObject* NearestLightingScenario;                                           // 0x1258 (size: 0x8)
    double ClosestDistance;                                                           // 0x1260 (size: 0x8)
    double Min Distance;                                                              // 0x1268 (size: 0x8)
    TSoftClassPtr<UObject> Asset Class;                                               // 0x1270 (size: 0x28)
    TMap<FName, TSubclassOf<class AActor>> PreloadedHeads;                            // 0x1298 (size: 0x50)
    class ABP_Arm_Ring_V2_C* As BP Arm Ring V2;                                       // 0x12E8 (size: 0x8)
    bool Starting from Spline Start;                                                  // 0x12F0 (size: 0x1)
    FTransform SneakCamTransformCache;                                                // 0x1300 (size: 0x60)
    FTransform SneakCamTransformInverseCache;                                         // 0x1360 (size: 0x60)
    bool ExitFromStartBox;                                                            // 0x13C0 (size: 0x1)
    class UArrowComponent* Exit from Entry Arrow;                                     // 0x13C8 (size: 0x8)
    class UArrowComponent* Exit from Exit Arrow;                                      // 0x13D0 (size: 0x8)
    bool Sneak Custom Look At;                                                        // 0x13D8 (size: 0x1)
    double BrakingDecelerationFlyingCache;                                            // 0x13E0 (size: 0x8)
    class UWBP_FlyMode_C* FlyModeWidget;                                              // 0x13E8 (size: 0x8)
    double DeadZoneCameraLagSpeedCache;                                               // 0x13F0 (size: 0x8)
    double DeadZoneCamera Lag Speed;                                                  // 0x13F8 (size: 0x8)
    FMovementSettings CurrentMovementSettingsCache;                                   // 0x1400 (size: 0x20)
    double BrakingDecelerationFallingDeadZoneCache;                                   // 0x1420 (size: 0x8)
    FFSoundEvent Sound Event;                                                         // 0x1428 (size: 0x8)
    FSoundEventDataTableRowHandle Sound Event_0;                                      // 0x1430 (size: 0x10)
    class AWaterBody* WaterBody;                                                      // 0x1440 (size: 0x8)
    double DEBUG_DashTraceTime;                                                       // 0x1448 (size: 0x8)
    TEnumAsByte<EDrawDebugTrace::Type> DEBUG_DashTraceVisibility;                     // 0x1450 (size: 0x1)
    FVector Relative LocationSpringArmCache;                                          // 0x1458 (size: 0x18)
    FVector  CameraCacheRelativeLocation;                                             // 0x1470 (size: 0x18)
    bool CharacterLocationResetInProgress;                                            // 0x1488 (size: 0x1)
    bool IsManorCharacter;                                                            // 0x1489 (size: 0x1)
    FFSoundEvent SD_CharacterWorld_CharaSwitch;                                       // 0x1490 (size: 0x8)
    FFSoundEvent SD_CharacterWorld_DoubleJump;                                        // 0x1498 (size: 0x8)
    FFSoundEvent SD_CharacterWorld_Jump;                                              // 0x14A0 (size: 0x8)
    FFSoundEvent SD_CharacterWorld_WorldStrike;                                       // 0x14A8 (size: 0x8)
    FFSoundEvent SD_CharacterWorld_Dash;                                              // 0x14B0 (size: 0x8)
    FFSoundEvent SD_CharacterWorld_Landed;                                            // 0x14B8 (size: 0x8)
    FFSoundEvent SD_CharacterWorld_MantleReachTop;                                    // 0x14C0 (size: 0x8)
    bool CanHeadRotate;                                                               // 0x14C8 (size: 0x1)
    bool IsUsingDebugTp;                                                              // 0x14C9 (size: 0x1)
    bool CanClimb;                                                                    // 0x14CA (size: 0x1)
    double FieldOfViewCache;                                                          // 0x14D0 (size: 0x8)
    double CameraLagSpeedCache;                                                       // 0x14D8 (size: 0x8)
    double TargetArmLengthCache;                                                      // 0x14E0 (size: 0x8)
    FVector SocketOffsetCache;                                                        // 0x14E8 (size: 0x18)
    FVector TargetOffsetCache;                                                        // 0x1500 (size: 0x18)
    FVector PreviousLocation;                                                         // 0x1518 (size: 0x18)
    double DistanceTraveled;                                                          // 0x1530 (size: 0x8)
    double FreeAimShootingCooldown;                                                   // 0x1538 (size: 0x8)
    FVector OriginalCameraLocation;                                                   // 0x1540 (size: 0x18)
    FFCharacterExplorationAudioProfile CharacterExplorationAudioProfile;              // 0x1558 (size: 0x8)
    int32 DebugFlySpeedIndex;                                                         // 0x1560 (size: 0x4)
    class ABP_SpawnPointLevelProto_C* SpawnPointCache;                                // 0x1568 (size: 0x8)
    bool IsUsingShortJump;                                                            // 0x1570 (size: 0x1)
    class ABP_ShortJumper_C* CurrentShortJump;                                        // 0x1578 (size: 0x8)
    FName ActiveCharacterAtPreload;                                                   // 0x1580 (size: 0x8)
    class UBP_DataAsset_CharacterExplorationAudioProfile_C* DataAsset_ExplorationAudioProfile; // 0x1588 (size: 0x8)
    TArray<ABP_GameplayRoom_C*> ActiveRooms;                                          // 0x1590 (size: 0x10)
    FBP_jRPG_Character_World_COnActiveRoomsChanged OnActiveRoomsChanged;              // 0x15A0 (size: 0x10)
    void OnActiveRoomsChanged(class ABP_jRPG_Character_World_C* Character);
    double LookUp/DownRate;                                                           // 0x15B0 (size: 0x8)
    double GamepadCameraSpeedUpDown;                                                  // 0x15B8 (size: 0x8)
    double GamepadCameraSpeedLeftRight;                                               // 0x15C0 (size: 0x8)
    FTransform TransformBeforeTPMenu;                                                 // 0x15D0 (size: 0x60)
    TArray<AExponentialHeightFog*> FogsActivatedBeforeOpeningMenu;                    // 0x1630 (size: 0x10)
    bool IsInExplorationAttack;                                                       // 0x1640 (size: 0x1)
    class UMaterialInstanceDynamic* FXArmRingMaterial;                                // 0x1648 (size: 0x8)
    TEnumAsByte<EFreeAimFeedbackType::Type> CurrentFreeaimFeedback;                   // 0x1650 (size: 0x1)
    float SpringArmLengthBeforeMovement;                                              // 0x1654 (size: 0x4)
    float MaxWalkSpeedCache;                                                          // 0x1658 (size: 0x4)
    float FovBeforeMovement;                                                          // 0x165C (size: 0x4)
    float CameraLagMaxDistanceBeforeMovement;                                         // 0x1660 (size: 0x4)
    float CameraLagMaxDistanceCache;                                                  // 0x1664 (size: 0x4)
    EALSOverlayState ChangeOverlay;                                                   // 0x1668 (size: 0x1)
    TMap<TEnumAsByte<E_jRPG_CharacterWorldCapability::Type>, int32> CharacterCapabilities; // 0x1670 (size: 0x50)
    FS_jRPG_Character_World_Capabilities Override Character Capabilites;              // 0x16C0 (size: 0x50)
    bool UseOverrideCharacterCapabilities;                                            // 0x1710 (size: 0x1)
    double IKAlpha;                                                                   // 0x1718 (size: 0x8)
    bool IsSprintRequested;                                                           // 0x1720 (size: 0x1)
    TArray<FS_jRPG_Character_World_Movement_Data> CharacterMovementDataQueue;         // 0x1728 (size: 0x10)
    class ABP_ExplorationCapacity_TorchObject_C* TorchActor;                          // 0x1738 (size: 0x8)
    int32 Editor_ChestsRemainingInTheLevel;                                           // 0x1740 (size: 0x4)
    bool UseCachedAimingRotationForInputs;                                            // 0x1744 (size: 0x1)
    bool IsInPostBattleAggroDelay;                                                    // 0x1745 (size: 0x1)
    FBP_jRPG_Character_World_COnCharacterCapabilitiesInitialized OnCharacterCapabilitiesInitialized; // 0x1748 (size: 0x10)
    void OnCharacterCapabilitiesInitialized();
    FRotator CachedAimingRotation;                                                    // 0x1758 (size: 0x18)
    float PreCinematicCameraBlendTime;                                                // 0x1770 (size: 0x4)
    TMap<UCineCameraComponent*, FTransform> OriginalCamerasTransform;                 // 0x1778 (size: 0x50)
    TMap<UCineCameraComponent*, FTransform> OnDialogueStartCamerasTransform;          // 0x17C8 (size: 0x50)
    double CurrentHeartRate;                                                          // 0x1818 (size: 0x8)
    bool IsAttachedToMovingPlatform;                                                  // 0x1820 (size: 0x1)
    FSF_ReferenceCounterHandle CheckpointInputLockBlocker;                            // 0x1828 (size: 0x20)
    FSF_ReferenceCounterHandle CinematicInputLockBlocker;                             // 0x1848 (size: 0x20)
    FSF_ReferenceCounterHandle CinematicInteractionLockBlocker;                       // 0x1868 (size: 0x20)
    TSubclassOf<class UCameraModifier> DefaultCameraModifierRotationLimiterClass;     // 0x1888 (size: 0x8)
    double MouseCameraSpeedUpDown;                                                    // 0x1890 (size: 0x8)
    double MouseCameraSpeedLeftRight;                                                 // 0x1898 (size: 0x8)
    FBP_jRPG_Character_World_COnCharacterCapabilitiesChanged OnCharacterCapabilitiesChanged; // 0x18A0 (size: 0x10)
    void OnCharacterCapabilitiesChanged();

    void BPI_GetDialogueAudioComponent(class UAudioComponent*& AudioComponent);
    void BPI_GetDialogueCameraByType(TEnumAsByte<EDialogueCameraType::Type> CameraType, class UCameraComponent*& CameraComponent);
    bool BPI_HasLightingAuthority();
    bool BPI_ShouldMoveCameraPresetsToOtherSide();
    TScriptInterface<class IBPI_DialogueCharacter_C> BPI_GetInteractingCharacter();
    FVector BPI_GetDialogueCameraOffset();
    TScriptInterface<class IBPI_DialogueCharacter_C> BPI_GetReverseSpotlightReceiver();
    TEnumAsByte<E_NPC_SpolightTypes::Type> BPI_GetLightDirection();
    void BPI_GetLightingSet(TEnumAsByte<E_NPC_SpolightTypes::Type> LightDirection, class ULightComponent*& FrontLight, class ULightComponent*& RimLight);
    void BPI_GetAllDialogueCameras(TArray<UCineCameraComponent*>& CineCameraComponents);
    void BPI_GetDialogueFocusPoint(class USceneComponent*& SceneComponent);
    void BPI_GetSpotlightsToActivateDuringDialogue(TArray<TSoftObjectPtr<class ASpotLight>>& SpotLightActors);
    TScriptInterface<class IBPI_DialogueCharacter_C> GetDialogueCharacterInterface();
    void AreDependenciesLoaded(bool& AreLoaded);
    void GetCharacterActor(class AActor*& Character);
    void GetCameraComponent(class UCameraComponent*& Camera);
    void GetAssetDialogueCharacter(class UBP_DataAsset_DialogueCharacter_C*& DialogueCharacter);
    void IsFreeAimTargetDisabled(bool& IsDisabled);
    void GetAllAudioComponents(TArray<UAudioComponent*>& AudioComponents);
    void GetAudioComponentByType(const TEnumAsByte<EInWorldAudioContainerComponents::Type> Type, class UAudioComponent*& AudioComponent);
    void GetAudioCharacterManager(class UActorComponent*& AudioCharacterManager);
    void GetAudioComponents(class UAudioComponent*& AC_SFX_01, class UAudioComponent*& AC_Foleys_01, class UAudioComponent*& AC_FT_L, class UAudioComponent*& AC_Vocals_01, class UAudioComponent*& AC_SFX_02, class UAudioComponent*& AC_Foleys_02, class UAudioComponent*& AC_FT_R, class UAudioComponent*& AC_Vocals_02, class UAudioComponent*& AC_Idle, class UAudioComponent*& AC_Weapon_L_01, class UAudioComponent*& AC_Weapon_L_02, class UAudioComponent*& AC_Weapon_R_01, class UAudioComponent*& AC_Hand_L_01, class UAudioComponent*& AC_Hand_R_01);
    void GetCurrentInputDevice(TEnumAsByte<EInputDevices::Type>& InputDevice);
    void GetClosestInteractable(class AActor*& Interactable);
    void PerformMantleIfPossible();
    void SetIsInDialogue(bool IsInDialogue);
    bool GetIsInDialogue();
    void AdjustCharacterSpringArm(bool IsCrouching, double ScaledHalfHeightAdjust);
    void Force LOD();
    bool GetIsAttachedToMovingPlatform();
    void SetIsAttachedToMovingPlatform(bool IsAttachedToMovingPlatform, bool UseSmartLineTrace);
    void UpdateSpringArmLength();
    bool CanAddMovementInput();
    void DEBUG_PrintCharacterCapabilities();
    void OnCharacterCapabilitiesUpdated();
    void InterruptExplorationAttackTimeline();
    void UpdateCharacterVisualAlterations();
    EALSGait GetAllowedGait();
    void OnGameUserSettingsApplied(const class UConfigurableGameUserSettings* UserConfig);
    void ToggleGaitIfPossible();
    void SetGaitToRunningIfPossible();
    void SetGaitToSprintIfPossible();
    void OnBattleDependenciesLoaded();
    void GenerateExplorationAttack(double A);
    void StopCustomMovement();
    bool IsInCustomMovement();
    void ForceRefreshCharacterAndCompanions();
    void GetAllDialogueCameras(TArray<UCineCameraComponent*>& AllCameras);
    void Cinematic_ActivatePlayerCamera();
    void Cinematic_GetPreCinematicBlendTime(float& PreCinematicCameraBlendTime);
    void Cinematic_ActivatePreCameraCinematic();
    void OnCharacterCollectionChanged();
    void BindEventsToController();
    void PlayAnimMontageOnCharacterWorld(class UAnimMontage* MontageToPlay);
    void ComputeActorRotationDuringAttack(FRotator& Rotation);
    void OnTargetViewAboutToChanged(class AActor* PreviousViewTarget, class AActor* CurrentViewTarget);
    void HasCameraOverride(bool& HasOverride);
    void GetSpringArmFreeAimCamera(class USpringArmComponent*& SpringArm);
    void GetFreeAimCamera(class UCameraComponent*& Camera);
    void OnRollAnimationStopped(bool IsInterrupted);
    void OnRollAnimationStarted();
    void ExitCinematicMode();
    void EnterCinematicMode();
    void IsAnyInputUsable(bool& Usable);
    void InitCharacterCapabilities();
    void RemoveCharacterCapabilitiesOverride();
    void SetCharacterCapabilitiesOverride(FS_jRPG_Character_World_Capabilities Capabilities);
    void ResetCharacterCapabilitiesAndMovementData();
    void IsCapabilityAllowed(TEnumAsByte<E_jRPG_CharacterWorldCapability::Type> Capability, bool& isAllowed);
    void UpdateCharacterCapabilities(TMap<TEnumAsByte<E_jRPG_CharacterWorldCapability::Type>, bool> Capabilities, FString Reason);
    void OnCharacterMovementDataQueueUpdated();
    void RemoveCharacterMovementData(FS_jRPG_Character_World_Movement_Data MovementData);
    void AddCharacterMovementData(FS_jRPG_Character_World_Movement_Data Movement Data, bool IsHighPriority);
    void CharacterTalking(bool Talking);
    void ArmRingChangeFeedbackType(TEnumAsByte<EFreeAimFeedbackType::Type> NewFeedbackType);
    void ArmRingDisableFeedbackType(TEnumAsByte<EFreeAimFeedbackType::Type> CurrentFeedbackType);
    void ArmRingEnableFeedbackType(TEnumAsByte<EFreeAimFeedbackType::Type> CurrentFeedbackType, FLinearColor& CurrentColor, double& RotationRate, double& glow);
    void GetALSAnimBP(class UALS_UE5_AnimBP_C*& AsALS UE5 Anim BP);
    void ApplyDefaultInputContext(bool SetDefaultRunningGait);
    void GetSpringArmMainCamera(class USpringArmComponent*& SpringArm_MainCamera);
    void GetMainCamera(class UCameraComponent*& MainCamera);
    bool IsInAnyRoom(TArray<ABP_GameplayRoom_C*>& Rooms);
    bool CanBeDetectedByEnemies();
    void Despawn();
    void OnBattleEnds();
    void OnBattleStarts();
    void ResetCamValuesToCache();
    void SaveCamValuesInCache();
    void CanSwitchCharacter(bool& CharacterSwitchFromButtonPress);
    bool CanEnterFreeAimCheck();
    bool CanPerformExplorationAttack();
    bool CanDash();
    void SetLastCheckpoint(FVector Location, FRotator Rotation, class AActor* SourceObject);
    void GetWorldCharacterByName(FName RowName, bool& Found, FS_jRPG_WorldCharacters& WorldCharacter);
    void GetNextWorldCharacterName(FName& CharacterName);
    void GetCurrentWorldCharacter(bool& Found, FS_jRPG_WorldCharacters& WorldCharacter);
    void ComputeActiveCharacter();
    void SetCharacterCustomization(FS_CharacterCustomization CharacterCustomization, FName Character Name);
    void FindNearestActorOfClass(TSubclassOf<class AActor> Class, FVector TargetLocation, class AActor*& NearestActor, double& NearestDistance);
    void DEBUG_TeleportEnviro(int32 TPNumber);
    void UserConstructionScript();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void Timeline_ExplorationAttack__FinishedFunc();
    void Timeline_ExplorationAttack__UpdateFunc();
    void Timeline_GrappeCamera__FinishedFunc();
    void Timeline_GrappeCamera__UpdateFunc();
    void FX_ArmRingColor__FinishedFunc();
    void FX_ArmRingColor__UpdateFunc();
    void SpringArmControl_Timeline__FinishedFunc();
    void SpringArmControl_Timeline__UpdateFunc();
    void SpringArmReset_Timeline__FinishedFunc();
    void SpringArmReset_Timeline__UpdateFunc();
    void FoV_Control_Timeline__FinishedFunc();
    void FoV_Control_Timeline__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void EnableIKTimeline__FinishedFunc();
    void EnableIKTimeline__UpdateFunc();
    void InpActEvt_I_K2Node_InputDebugKeyEvent_6(FKey Key, FInputActionValue ActionValue);
    void InpActEvt_U_K2Node_InputDebugKeyEvent_5(FKey Key, FInputActionValue ActionValue);
    void InpActEvt_T_K2Node_InputDebugKeyEvent_4(FKey Key, FInputActionValue ActionValue);
    void InpActEvt_Y_K2Node_InputDebugKeyEvent_3(FKey Key, FInputActionValue ActionValue);
    void InpActEvt_V_K2Node_InputDebugKeyEvent_2(FKey Key, FInputActionValue ActionValue);
    void InpActEvt_ZoomOut_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_ZoomIn_K2Node_InputActionEvent_0(FKey Key);
    void InpActEvt_IA_CameraUpAction_Gamepad_K2Node_EnhancedInputActionEvent_30(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraUpAction_Keyboard_K2Node_EnhancedInputActionEvent_29(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraRightAction_Gamepad_K2Node_EnhancedInputActionEvent_28(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraRightAction_Keyboard_K2Node_EnhancedInputActionEvent_27(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_AimAction_K2Node_EnhancedInputActionEvent_26(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_AimAction_K2Node_EnhancedInputActionEvent_25(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_AimAction_K2Node_EnhancedInputActionEvent_24(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_FreeAimExplo_Shoot_K2Node_EnhancedInputActionEvent_23(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_SprintAction_K2Node_EnhancedInputActionEvent_22(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_SprintAction_K2Node_EnhancedInputActionEvent_21(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_SprintAction_K2Node_EnhancedInputActionEvent_20(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_CharacterSwitchAction_K2Node_EnhancedInputActionEvent_19(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_417717A14648999DF1C834AF8E5C7DD4(FName NotifyName);
    void OnNotifyBegin_417717A14648999DF1C834AF8E5C7DD4(FName NotifyName);
    void OnInterrupted_417717A14648999DF1C834AF8E5C7DD4(FName NotifyName);
    void OnBlendOut_417717A14648999DF1C834AF8E5C7DD4(FName NotifyName);
    void OnCompleted_417717A14648999DF1C834AF8E5C7DD4(FName NotifyName);
    void InpActEvt_HitInWorldAction_K2Node_EnhancedInputActionEvent_18(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_NumPadNine_K2Node_InputKeyEvent_2(FKey Key);
    void InpActEvt_Gamepad_RightThumbstick_K2Node_InputDebugKeyEvent_1(FKey Key, FInputActionValue ActionValue);
    void InpActEvt_Gamepad_LeftThumbstick_K2Node_InputDebugKeyEvent_0(FKey Key, FInputActionValue ActionValue);
    void InpActEvt_CameraTapAction_K2Node_EnhancedInputActionEvent_17(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugForceLoadLastSave_K2Node_EnhancedInputActionEvent_16(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugRequestAutoSave_K2Node_EnhancedInputActionEvent_15(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugFlyMode_K2Node_EnhancedInputActionEvent_14(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugIncreaseCinematicSpeed_K2Node_EnhancedInputActionEvent_13(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugIncreaseCinematicSpeed_K2Node_EnhancedInputActionEvent_12(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugIncreaseCinematicSpeed_K2Node_EnhancedInputActionEvent_11(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport1_K2Node_EnhancedInputActionEvent_10(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport2_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport3_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport4_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport5_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport6_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport7_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport8_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport9_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_DebugTeleport10_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_JumpAction_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_E_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_Gamepad_FaceButton_Bottom_K2Node_InputKeyEvent_0(FKey Key);
    void LoadDependencies();
    void UnloadDependencies();
    void FreeAimHit(class ABP_jRPG_Character_World_C* PlayerCharacterWorld, FVector HitLocation, bool IsDisabled);
    void ExplorationAttacked(class ABP_jRPG_Character_World_C* PlayerCharacter, FVector ImpactPoint);
    void LiveActivation(FName ParamName, double FadeTimeOfBrush, double FadeTimeOfCanvas);
    void LiveFluidParams(double BrushSize);
    void UpdateInteractables();
    void RemoveInteractable(class AActor* Interactable);
    void AddInteractable(class AActor* Interactable);
    void GetTest();
    void ZoomInEvent();
    void ZoomOutEvent();
    void InpAxisEvt_DebugFlyingUpDown_K2Node_InputAxisEvent_1(float AxisValue);
    void SprintAction(bool bValue);
    void InterruptExplorationAttack();
    void ForwardMovementAction(float Value);
    void RightMovementAction(float Value);
    void JumpAction(bool bValue);
    void StanceAction();
    void UpdateDebugFlyModeSpeed();
    void AimAction(bool bValue);
    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ReceiveTick(float DeltaSeconds);
    void OnLanded(const FHitResult& Hit);
    void CharacterSwitch();
    void SetAbpBattleForAiming(bool Aiming);
    void ResetLocationToCheckPoint();
    void Enter Debug Fly Mode();
    void Exit Debug Fly Mode();
    void InteractWithReader();
    void LoadAndActivateCharacter(FName CharacterName, bool HasSwitchCharacter);
    void ReceivePossessed(class AController* NewController);
    void TeleportCharacter(FTransform DestinationTransform, FRotator CameraRotation);
    void WaterFXDelay();
    void SetSpawnLocationFromWorldMap();
    void SpawnAICompanions();
    void ReceiveActorEndOverlap(class AActor* OtherActor);
    void K2_OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
    void K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
    void GrappleCameraMovement();
    void FXArmRingActivate(bool AddTrail);
    void FXArmRingDeactivate();
    void FXArmRingChangeColor(FLinearColor CurrentColor, double RotationRate, double glow);
    void CameraToBasePosition(float OverTime);
    void CameraToPosition(FVector TargetRelativeLocation, float OverTime);
    void SpringArmControl(float Target Arm Length, double CameraLagMaxDistance);
    void SpringArmReset();
    void FovControl(double TargetFov);
    void FovReset();
    void AttachTorch();
    void UnattachTorch();
    void LimitCharacterWorldMovement(TMap<TEnumAsByte<E_jRPG_CharacterWorldCapability::Type>, bool> Capabilities, FS_jRPG_Character_World_Movement_Data Movement Data, FString Reason);
    void ResetCharacterWorldMovement();
    void EnableIK(bool EnableIK);
    void OnGaitChanged(EALSGait previousGait, EALSGait nextGait);
    void SetCharacterSpotLightsEnabled(bool Visible);
    void ReceiveUnpossessed(class AController* OldController);
    void PostBattleAggroDelay();
    void UnspawnAICompanions();
    void BndEvt__BP_jRPG_Character_World_BP_FallDetectorComponent_K2Node_ComponentBoundEvent_2_OnKillByFallDetected__DelegateSignature();
    void ApplyCustomizationOnAICompanions();
    void BndEvt__BP_jRPG_Character_World_BP_ClimbingComponent_K2Node_ComponentBoundEvent_3_OnStartClimbing__DelegateSignature();
    void BndEvt__BP_jRPG_Character_World_BP_ClimbingComponent_K2Node_ComponentBoundEvent_8_OnEndClimbing__DelegateSignature();
    void ReceiveBeginPlay();
    void BndEvt__BP_jRPG_Character_World_MantleComponent_K2Node_ComponentBoundEvent_1_MantleStateChangedSignature__DelegateSignature(bool State);
    void TeleportCharacterToArea(FTransform DestinationTransform, FRotator CameraRotation, class ABP_LightingScenarioReference_C* LightingScenario, const FS_AreaAudioParameters AreaAudioParameters, FS_ChangeLevelParameters ChangeLevelParameters);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void LoadCharacter();
    void OnSaveLoaded();
    void BndEvt__BP_jRPG_Character_World_BP_CharacterSkinComponent_K2Node_ComponentBoundEvent_4_OnCharacterSkinChanged__DelegateSignature(class UBP_CharacterSkinComponent_C* SkinComponent);
    void DEBUG_CVarChange_DisableCompanions(bool NewValue);
    void DEBUG_CVarChange_DisableAggro(bool NewValue);
    void ExecuteUbergraph_BP_jRPG_Character_World(int32 EntryPoint);
    void OnCharacterCapabilitiesChanged__DelegateSignature();
    void OnCharacterCapabilitiesInitialized__DelegateSignature();
    void OnActiveRoomsChanged__DelegateSignature(class ABP_jRPG_Character_World_C* Character);
}; // Size: 0x18B0

#endif
