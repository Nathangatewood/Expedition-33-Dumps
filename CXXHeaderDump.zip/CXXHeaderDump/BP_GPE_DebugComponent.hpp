#ifndef UE4SS_SDK_BP_GPE_DebugComponent_HPP
#define UE4SS_SDK_BP_GPE_DebugComponent_HPP

class UBP_GPE_DebugComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool GPETriggerIsActive;                                                          // 0x00A8 (size: 0x1)
    TMap<AActor*, double> GPEActivatedByImpulse;                                      // 0x00B0 (size: 0x50)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    bool Editor_DrawDebugShapes();
    bool Editor_GetDebugShapes(TArray<FEditorDebugShape_Arrow>& Arrows, TArray<FEditorDebugShape_Arrow>& Lines);
    void InverseGPETriggerIsActive();
    void SelectDebugColor(class AActor* GPE, FLinearColor& Color);
    void AddImpulseActivation(class AActor* GPE);
    void ReceiveBeginPlay();
    void OnDebugInPlayModeChanged(bool NewValue);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_GPE_DebugComponent(int32 EntryPoint);
}; // Size: 0x100

#endif
