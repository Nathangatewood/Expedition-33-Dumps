#ifndef UE4SS_SDK_BP_GameMenu_Monoco_HPP
#define UE4SS_SDK_BP_GameMenu_Monoco_HPP

class ABP_GameMenu_Monoco_C : public ABP_Cine_Monoco_C
{
    class UBP_CharacterVisualAlterationsComponent_C* BP_CharacterVisualAlterationsComponent; // 0x06A0 (size: 0x8)

}; // Size: 0x6A8

#endif
