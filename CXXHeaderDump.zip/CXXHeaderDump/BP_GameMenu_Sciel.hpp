#ifndef UE4SS_SDK_BP_GameMenu_Sciel_HPP
#define UE4SS_SDK_BP_GameMenu_Sciel_HPP

class ABP_GameMenu_Sciel_C : public ABP_Cine_Sciel_C
{
    class UBP_CharacterVisualAlterationsComponent_C* BP_CharacterVisualAlterationsComponent; // 0x0698 (size: 0x8)

}; // Size: 0x6A0

#endif
