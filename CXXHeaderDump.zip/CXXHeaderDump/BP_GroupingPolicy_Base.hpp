#ifndef UE4SS_SDK_BP_GroupingPolicy_Base_HPP
#define UE4SS_SDK_BP_GroupingPolicy_Base_HPP

class UBP_GroupingPolicy_Base_C : public UExtendedObject
{
    TArray<UBP_GroupInstance_Base_C*> GroupInstances;                                 // 0x0028 (size: 0x10)
    UClass* ExpectedClass;                                                            // 0x0038 (size: 0x8)
    FText PolicyDisplayName;                                                          // 0x0040 (size: 0x10)
    bool IsMultiMatchAllowed;                                                         // 0x0050 (size: 0x1)

    void SetMultiMatchAllowed(bool Allowed);
    void SetPolicyDisplayName(FText Value);
    void GetPolicyDisplayName(FText& PolicyDisplayName);
    void InitGroupPolicy();
    TArray<UBP_GroupInstance_Base_C*> GetGroupInstances();
    void RegisterGroupInstance(const class UBP_GroupInstance_Base_C*& GroupInstance);
    void PopulateGroupsWithObjects(TArray<UObject*>& Objects);
}; // Size: 0x51

#endif
