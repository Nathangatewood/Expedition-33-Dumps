#ifndef UE4SS_SDK_BP_GrapplePoint_HPP
#define UE4SS_SDK_BP_GrapplePoint_HPP

class ABP_GrapplePoint_C : public ABP_jRPG_InteractionObject_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02F0 (size: 0x8)
    class UTextRenderComponent* TextRender_EditorHelp;                                // 0x02F8 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh_EditorHelp;                            // 0x0300 (size: 0x8)
    class USceneComponent* FX_Anchor;                                                 // 0x0308 (size: 0x8)
    class UForceFeedbackComponent* ForceFeedback;                                     // 0x0310 (size: 0x8)
    class UBP_GPE_InternalActivationComponent_C* BP_GPE_InternalActivationComponent;  // 0x0318 (size: 0x8)
    class UStaticMeshComponent* Grapple;                                              // 0x0320 (size: 0x8)
    class UBoxComponent* DeactivationZone;                                            // 0x0328 (size: 0x8)
    class UArrowComponent* LandingSpot;                                               // 0x0330 (size: 0x8)
    class UBP_ExplorationCapacityComponent_GrappleHook_C* GrappleComponentReference;  // 0x0338 (size: 0x8)
    bool Activated;                                                                   // 0x0340 (size: 0x1)
    bool CanBeActivated;                                                              // 0x0341 (size: 0x1)
    FGPEInterfacesReferences GPEInterface;                                            // 0x0348 (size: 0x10)
    TArray<FGameAction_Wrapper> GameActionsOnMidAir;                                  // 0x0358 (size: 0x10)
    class UAudioComponent* AC Hand R 01;                                              // 0x0368 (size: 0x8)
    float FFBIntensityMultiplier;                                                     // 0x0370 (size: 0x4)
    bool IsInRange;                                                                   // 0x0374 (size: 0x1)

    void DEBUG_ValidateInteractionRadius();
    void GetInteractionLocation(FVector& Location);
    void Stop  Sound Gapplin Available(class UAudioComponent* AC Hand R 01);
    void Play Sound Gapplin Available(class UAudioComponent* AC Hand R 01);
    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    void Deactivate();
    void Activate();
    void OnInteractionEnabled();
    void OnInteractionDisabled();
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void BndEvt__BP_GrapplePoint_DeactivationZone_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_GrapplePoint_DeactivationZone_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void BndEvt__BP_GrapplePoint_InteractionRange_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_GrapplePoint_InteractionRange_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ReceiveBeginPlay();
    void UpdateForceFeedbackIntensity();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_GrapplePoint(int32 EntryPoint);
}; // Size: 0x375

#endif
