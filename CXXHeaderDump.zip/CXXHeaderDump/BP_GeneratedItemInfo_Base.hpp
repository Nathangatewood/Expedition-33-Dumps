#ifndef UE4SS_SDK_BP_GeneratedItemInfo_Base_HPP
#define UE4SS_SDK_BP_GeneratedItemInfo_Base_HPP

class UBP_GeneratedItemInfo_Base_C : public UExtendedObject
{
    int32 Quantity;                                                                   // 0x0028 (size: 0x4)

    void SetItemQuantity(int32 Quantity);
    void GetItemQuantity(int32& Quantity);
    bool ShouldShowQuantity();
    TSoftObjectPtr<class UTexture2D> GetItemIcon();
    TEnumAsByte<E_jRPG_ItemType::Type> GetItemType();
    FText GetItemDisplayText();
    void Init();
}; // Size: 0x2C

#endif
