#ifndef UE4SS_SDK_BP_GestralVariationComponent_HPP
#define UE4SS_SDK_BP_GestralVariationComponent_HPP

class UBP_GestralVariationComponent_C : public UActorComponent
{
    FS_GestralRandomScaleVariation GestralRandomVariationStructure;                   // 0x00A0 (size: 0x88)
    TArray<TSoftObjectPtr<class UStaticMesh>> GestralHairCutList;                     // 0x0128 (size: 0x10)
    double ScaleMin;                                                                  // 0x0138 (size: 0x8)
    double ScaleMax;                                                                  // 0x0140 (size: 0x8)
    double UVMaskScale;                                                               // 0x0148 (size: 0x8)
    TArray<TSoftObjectPtr<class UTexture2D>> GestralMaslAlphaList;                    // 0x0150 (size: 0x10)

    void RefreshABP();
    void RandomizeHaircut();
    void RandomizeScales(double ScaleMin, double ScaleMax, FS_GestralRandomScaleVariation& Output_Get);
    void GiveMeAWTFGestral(FS_GestralRandomScaleVariation& ScaleVariationStruct);
    void GiveMeARandomGestral(double ScaleMin, double ScaleMax, FS_GestralRandomScaleVariation& ScaleVariationStruct);
}; // Size: 0x160

#endif
