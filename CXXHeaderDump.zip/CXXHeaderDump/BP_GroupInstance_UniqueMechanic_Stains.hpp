#ifndef UE4SS_SDK_BP_GroupInstance_UniqueMechanic_Stains_HPP
#define UE4SS_SDK_BP_GroupInstance_UniqueMechanic_Stains_HPP

class UBP_GroupInstance_UniqueMechanic_Stains_C : public UBP_GroupInstance_Skill_Base_C
{
    bool ProducesStains;                                                              // 0x0038 (size: 0x1)
    bool ConsumesStains;                                                              // 0x0039 (size: 0x1)
    bool OnlyExotic;                                                                  // 0x003A (size: 0x1)
    bool UnsetOnly;                                                                   // 0x003B (size: 0x1)

    FText GetGroupDisplayName();
    void DoesSkillMatch(class UBP_DataAsset_Skill_C* SkillData, bool& MatchesGroup);
}; // Size: 0x3C

#endif
