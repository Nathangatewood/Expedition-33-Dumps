#ifndef UE4SS_SDK_BP_GPE_Controller_HPP
#define UE4SS_SDK_BP_GPE_Controller_HPP

class ABP_GPE_Controller_C : public AActor
{
    class UBP_GPE_InternalActivationComponent_C* BP_GPEInternalActivationComponent;   // 0x0290 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x0298 (size: 0x8)
    class UBP_GPE_DebugComponent_C* BP_GPEDebugComponent;                             // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)

    void GPETrigger_GetGameplayElementsToActivate(FGPEInterfacesReferences& GameplayElementsToActivate);
    void GPE_GetActivationComponent(class UBP_GPE_InternalActivationComponent_C*& ActivationComponent);
}; // Size: 0x2B0

#endif
