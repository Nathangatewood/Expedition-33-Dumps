#ifndef UE4SS_SDK_BP_jRPG_InteractionObject_Base_HPP
#define UE4SS_SDK_BP_jRPG_InteractionObject_Base_HPP

class ABP_jRPG_InteractionObject_Base_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* InteractionPromptLocation;                                 // 0x0298 (size: 0x8)
    class UArrowComponent* Arrow;                                                     // 0x02A0 (size: 0x8)
    class USphereComponent* InteractionRange;                                         // 0x02A8 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02B0 (size: 0x8)
    double InteractionRadius;                                                         // 0x02B8 (size: 0x8)
    FName ObjectGlobalID;                                                             // 0x02C0 (size: 0x8)
    bool DoesntRespawnIfInteracted;                                                   // 0x02C8 (size: 0x1)
    class ABP_jRPG_Character_World_C* As BP J RPG Character World;                    // 0x02D0 (size: 0x8)
    FText PromptText;                                                                 // 0x02D8 (size: 0x10)
    bool InteractionEnabled;                                                          // 0x02E8 (size: 0x1)
    bool IsInteractionStatePersistent;                                                // 0x02E9 (size: 0x1)
    bool ShouldDisplayDistantFeedback;                                                // 0x02EA (size: 0x1)

    bool Editor_DrawDebugShapes();
    bool Editor_GetDebugShapes(TArray<FEditorDebugShape_Arrow>& Arrows, TArray<FEditorDebugShape_Arrow>& Lines);
    bool CheckForErrors(TArray<FText>& ErrorMessages);
    bool ShouldHideDistantInteraction();
    void CanInteractWithMount(bool& CanInteract);
    void IsInteractionDone(bool& Done);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    void IsInteractionAvailable(bool& Available);
    void GetInteractionFeedbackLocation(FVector& Location);
    void GetInteractionLocation(FVector& Location);
    void UpdateInteractionState();
    void SetInteractionEnabled(bool InteractionEnabled);
    void GetObjectInteractionState(bool& InteractionState);
    void SetObjectInteractionState(bool InteractionState);
    void UserConstructionScript();
    void BndEvt__InteractionRange_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void OnInteractionDisabled();
    void BndEvt__InteractionRange_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ReceiveBeginPlay();
    void OnOverlapEvent();
    void OnInteractionEnabled();
    void OnEndOverlapEvent();
    void OnEnemyBattleStateLoaded(bool BattleState);
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void ExecuteUbergraph_BP_jRPG_InteractionObject_Base(int32 EntryPoint);
}; // Size: 0x2EB

#endif
