#ifndef UE4SS_SDK_BP_GeneratedItemInfo_Chroma_HPP
#define UE4SS_SDK_BP_GeneratedItemInfo_Chroma_HPP

class UBP_GeneratedItemInfo_Chroma_C : public UBP_GeneratedItemInfo_Base_C
{
    int32 GeneratedAmount;                                                            // 0x002C (size: 0x4)

    void GetItemQuantity(int32& Quantity);
    TSoftObjectPtr<class UTexture2D> GetItemIcon();
    TEnumAsByte<E_jRPG_ItemType::Type> GetItemType();
    FText GetItemDisplayText();
}; // Size: 0x30

#endif
