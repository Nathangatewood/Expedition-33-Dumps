#ifndef UE4SS_SDK_BP_GlobalVariablesFunctionLibrary_HPP
#define UE4SS_SDK_BP_GlobalVariablesFunctionLibrary_HPP

class UBP_GlobalVariablesFunctionLibrary_C : public UBlueprintFunctionLibrary
{

    void HasEncounteredEnemy(FName& EnemyGlobalID, class UObject* __WorldContext, bool& Result);
    void HasExplorationCapacity(TEnumAsByte<E_ExplorationCapacity::Type> Capacity, class UObject* __WorldContext, bool& Result);
    bool HasUnlockedGradientParry(class UObject* __WorldContext);
    bool HasUnlockedJump(class UObject* __WorldContext);
    void HasPlayedTutorial(FName& TutorialID, class UObject* __WorldContext, bool& Result);
    void GetPlayedTime(class UObject* __WorldContext, double& PlayedTime);
    void GetFinishedGameCount(class UObject* __WorldContext, int32& FinishedGameCount);
    void HasAlreadyFinishedGame(class UObject* __WorldContext, bool& Result);
    void HasPlayedDialogueStage(FGuid& DialogueGUID, int32 Stage, class UObject* __WorldContext, bool& Result);
    void HasAtLeastGoldAmount(int32 GoldAmount, class UObject* __WorldContext, bool& Result);
    void GetGoldAmount(class UObject* __WorldContext, int32& GoldAmount);
    void HasCharacterInParty(TEnumAsByte<E_CharacterList::Type> Character, class UObject* __WorldContext, bool& Result);
    void HasCharacterInPartyByHardcodedName(FName HardcodedName, class UObject* __WorldContext, bool& Result);
    void HasCharacterInCollection(TEnumAsByte<E_CharacterList::Type> Character, bool CheckExcludedCharacters, class UObject* __WorldContext, bool& Result);
    void HasCharacterInCollectionByHardcodedName(FName HardcodedName, bool CheckExcludedCharacters, class UObject* __WorldContext, bool& Result);
    void HasAtLeastRelationshipLevel(TEnumAsByte<E_CharacterList::Type> Character, int32 Level, class UObject* __WorldContext, bool& Result);
    void GetRelationshipLevel(TEnumAsByte<E_CharacterList::Type> Character, class UObject* __WorldContext, int32& Level);
    void HasWorldMapCapacity(TEnumAsByte<E_WorldMapExplorationCapacity::Type> Capacity, class UObject* __WorldContext, bool& Result);
    void HasPlayedCinematic(FName& CinematicID, class UObject* __WorldContext, bool& Result);
    void HasBattledEnemy(FName& EnemyGlobalID, class UObject* __WorldContext, bool& Result);
    void HasPlayedDialogue(FGuid& DialogueGUID, class UObject* __WorldContext, bool& Result);
    void HasPersistentFlag(class UNamedID* Flag, class UObject* __WorldContext, bool& Result);
    void HasAtLeastAmountOfItemInInventory(FS_jRPG_Item_StaticData& Item, int32 Amount, class UObject* __WorldContext, bool& Result);
    void HasItemInInventory(FS_jRPG_Item_StaticData& Item, class UObject* __WorldContext, bool& Result);
    void GetAmountOfItemTypeInInventory(TEnumAsByte<E_jRPG_ItemType::Type> ItemType, TEnumAsByte<E_jRPG_ItemSubtype::Type> ItemSubtype, class UObject* __WorldContext, int32& ItemAmount);
    void GetAmountOfItemInInventory(FS_jRPG_Item_StaticData& Item, class UObject* __WorldContext, int32& ItemAmount);
    void ObjectiveHasStatus(FQuestObjectiveIdentifier& Objective, TEnumAsByte<E_QuestStatus::Type> Status, class UObject* __WorldContext, bool& Result);
    void QuestHasStatus(FName& QuestName, TEnumAsByte<E_QuestStatus::Type> Status, class UObject* __WorldContext, bool& Result);
}; // Size: 0x28

#endif
