#ifndef UE4SS_SDK_BP_ItemFilter_Weapons_HPP
#define UE4SS_SDK_BP_ItemFilter_Weapons_HPP

class UBP_ItemFilter_Weapons_C : public UBP_ItemFilterAbstract_ItemType_C
{

    void GetCompatibleItemSorters(TArray<TSubclassOf<class UBP_ItemSorterAbstract_C>>& ItemSorters);
    void GetFilteredTypes(TArray<TEnumAsByte<E_jRPG_ItemType::Type>>& FilteredType);
    void GetDisplayName(FText& DisplayName);
}; // Size: 0x28

#endif
