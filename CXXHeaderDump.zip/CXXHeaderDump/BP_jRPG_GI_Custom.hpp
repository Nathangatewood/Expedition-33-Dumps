#ifndef UE4SS_SDK_BP_jRPG_GI_Custom_HPP
#define UE4SS_SDK_BP_jRPG_GI_Custom_HPP

class UBP_jRPG_GI_Custom_C : public UExtendedGameInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x01C0 (size: 0x8)
    class UBP_SpawnPointManager_C* SpawnPointManager;                                 // 0x01C8 (size: 0x8)
    bool IsChangingMap;                                                               // 0x01D0 (size: 0x1)
    FName WorldMapName;                                                               // 0x01D4 (size: 0x8)
    class UBP_SaveManager_C* SaveManager;                                             // 0x01E0 (size: 0x8)
    class UBP_EntitlementManager_C* EntitlementManager;                               // 0x01E8 (size: 0x8)
    double TimePlayed;                                                                // 0x01F0 (size: 0x8)
    FName LevelDestinationAssetName;                                                  // 0x01F8 (size: 0x8)
    FName LastSavedLevelName;                                                         // 0x0200 (size: 0x8)
    FTransform LastSavedTransform;                                                    // 0x0210 (size: 0x60)
    FName PreviousLevelRowName;                                                       // 0x0270 (size: 0x8)
    FGameplayTag SpawnPointTag;                                                       // 0x0278 (size: 0x8)
    FTransform LastWorldMapTransform;                                                 // 0x0280 (size: 0x60)
    FGameplayTag ReturnSpawnPointTag;                                                 // 0x02E0 (size: 0x8)
    FText AreaName;                                                                   // 0x02E8 (size: 0x10)
    TArray<FS_jRPG_PartySlot> CurrentParty;                                           // 0x02F8 (size: 0x10)
    TMap<FName, FS_jRPG_CharacterSaveState> CharactersCollection_Legacy;              // 0x0308 (size: 0x50)
    TArray<FS_jRPG_Item_DynamicData> Inventory;                                       // 0x0358 (size: 0x10)
    int32 Gold;                                                                       // 0x0368 (size: 0x4)
    bool SpawningAfterBattle?;                                                        // 0x036C (size: 0x1)
    FTransform WorldTransformBeforeBattle;                                            // 0x0370 (size: 0x60)
    FRotator CameraWorldRotationBeforeBattle;                                         // 0x03D0 (size: 0x18)
    TMap<FName, FTransform> WorldEnemiesTransformsBeforeBattle;                       // 0x03E8 (size: 0x50)
    TArray<FName> PossibleEncounters;                                                 // 0x0438 (size: 0x10)
    TArray<FName> PossibleBattleMaps;                                                 // 0x0448 (size: 0x10)
    TMap<FName, bool> GPE_States;                                                     // 0x0458 (size: 0x50)
    TMap<FName, TEnumAsByte<E_GPE_MovingAlongSplineDestination::Type>> MovingPlatformsStates; // 0x04A8 (size: 0x50)
    TMap<FName, bool> TransientInteractedObjects;                                     // 0x04F8 (size: 0x50)
    TMap<FName, bool> InteractedObjects;                                              // 0x0548 (size: 0x50)
    TMap<FName, bool> TransientBattledEnemies;                                        // 0x0598 (size: 0x50)
    TMap<FName, FTransform> TransientEnemyTransforms;                                 // 0x05E8 (size: 0x50)
    TMap<FName, int32> TransientEnemyRoamingPointIndexes;                             // 0x0638 (size: 0x50)
    TMap<FName, TSoftObjectPtr<class ABP_FleePoint_C>> TransientEnemyLastFleePoints;  // 0x0688 (size: 0x50)
    TMap<FName, bool> BattledEnemies;                                                 // 0x06D8 (size: 0x50)
    bool RandomEncountersEnabled;                                                     // 0x0728 (size: 0x1)
    class USoundWave* FightTransitionSound;                                           // 0x0730 (size: 0x8)
    bool CinematicAfterBattle;                                                        // 0x0738 (size: 0x1)
    FName Charactertoaddafterbattle;                                                  // 0x073C (size: 0x8)
    TMap<FName, bool> InteractedCinematics;                                           // 0x0748 (size: 0x50)
    TMap<FName, bool> InteractedSoundNotif;                                           // 0x0798 (size: 0x50)
    TMap<FName, bool> InteractedTutorials;                                            // 0x07E8 (size: 0x50)
    class UBP_InteractiveMusicSystem_C* InteractiveMusicSystem;                       // 0x0838 (size: 0x8)
    class UBP_AudioControlSystem_C* AudioControlSystem;                               // 0x0840 (size: 0x8)
    class UBP_DataAsset_Ambience_C* LastAmbience;                                     // 0x0848 (size: 0x8)
    class UAudioComponent* AmbienceComponent;                                         // 0x0850 (size: 0x8)
    FFSoundEvent CurrentMusicSoundEvent;                                              // 0x0858 (size: 0x8)
    bool 1stCinematicSeen;                                                            // 0x0860 (size: 0x1)
    bool LearnSkillAfterBattle;                                                       // 0x0861 (size: 0x1)
    bool AddCharacterAfterBattle;                                                     // 0x0862 (size: 0x1)
    TMap<FName, bool> InteractedDialogs;                                              // 0x0868 (size: 0x50)
    TMap<FName, bool> DEPRECATED_GlobalVariable;                                      // 0x08B8 (size: 0x50)
    class ACameraActor* BattleCameraActor;                                            // 0x0908 (size: 0x8)
    FName CurrentCharacterWorld;                                                      // 0x0910 (size: 0x8)
    class USoundBase* CurrentVoiceName;                                               // 0x0918 (size: 0x8)
    class UAudioComponent* VoicePersistentComponent;                                  // 0x0920 (size: 0x8)
    TMap<FName, UBP_CharacterData_C*> CharactersCollection;                           // 0x0928 (size: 0x50)
    TMap<FName, FName> SkinCollection;                                                // 0x0978 (size: 0x50)
    TMap<FName, TSoftClassPtr<ABP_CharacterSkinBase_C>> ActiveSkins;                  // 0x09C8 (size: 0x50)
    TMap<FName, bool> UnlockedManorGestrals;                                          // 0x0A18 (size: 0x50)
    FBP_jRPG_GI_Custom_COnGameLoaded OnGameLoaded;                                    // 0x0A68 (size: 0x10)
    void OnGameLoaded();
    bool SaveLoaded;                                                                  // 0x0A78 (size: 0x1)
    TArray<FName> ActiveInteractiveObjects;                                           // 0x0A80 (size: 0x10)
    TArray<FString> AlreadyRegisteredActors_0;                                        // 0x0A90 (size: 0x10)
    TArray<FName> DestroyableObjects;                                                 // 0x0AA0 (size: 0x10)
    FFSoundEvent SD_StopMusic;                                                        // 0x0AB0 (size: 0x8)
    TMap<FName, FName> ActiveSkins_Default;                                           // 0x0AB8 (size: 0x50)
    class UWBP_LoadingScreen_C* LoadingScreenWidget;                                  // 0x0B08 (size: 0x8)
    FName PROTO_WorldmapSpawnName;                                                    // 0x0B10 (size: 0x8)
    FName PROTO_LevelSpawnName;                                                       // 0x0B18 (size: 0x8)
    TEnumAsByte<E_WorldMap_Camps::Type> WorldMapCamp;                                 // 0x0B20 (size: 0x1)
    class UBP_ExplorationProgressionSystem_C* ExplorationProgressionState;            // 0x0B28 (size: 0x8)
    class UWBP_FullScreenNotificationContainer_C* WBP_FullScreenNotificationContainer; // 0x0B30 (size: 0x8)
    TMap<UNamedID*, bool> NamedIDsStates;                                             // 0x0B38 (size: 0x50)
    TArray<UNamedID*> AllNamedIDs;                                                    // 0x0B88 (size: 0x10)
    FBP_jRPG_GI_Custom_COnPersistentFlagSet OnPersistentFlagSet;                      // 0x0B98 (size: 0x10)
    void OnPersistentFlagSet(class UNamedID* NamedID);
    FString LastRelevantSaveName;                                                     // 0x0BA8 (size: 0x10)
    FDateTime LastSaveDateTime;                                                       // 0x0BB8 (size: 0x8)
    TEnumAsByte<E_CharacterList::Type> CurrentCharacterWorldEnum;                     // 0x0BC0 (size: 0x1)
    class UBP_BattleTowerSystem_C* BattleTowerSystem;                                 // 0x0BC8 (size: 0x8)
    FS_CleasTowerBattle CurrentTowerBattle;                                           // 0x0BD0 (size: 0x1C)
    bool ShouldTriggerTowerBattle;                                                    // 0x0BEC (size: 0x1)
    bool ShouldTalkToNPCAfterCleasTowerBattle;                                        // 0x0BED (size: 0x1)
    int32 CleasTowerCurrentAccessibleStage;                                           // 0x0BF0 (size: 0x4)
    int32 CleasTowerBattleIndex;                                                      // 0x0BF4 (size: 0x4)
    TArray<FName> EquippedConsumableShards;                                           // 0x0BF8 (size: 0x10)
    float AmbiencePlaybackPercent;                                                    // 0x0C08 (size: 0x4)
    TMap<FName, FFVendorState> VendorsStates;                                         // 0x0C10 (size: 0x50)
    bool ComeToWorldMapFromCamp;                                                      // 0x0C60 (size: 0x1)
    class UBP_DataAsset_GameCredits_C* CreditsToShow;                                 // 0x0C68 (size: 0x8)
    TMap<FName, int32> Lifts_CurrentFloor;                                            // 0x0C70 (size: 0x50)
    class UBP_QuestSystem_C* QuestSystem;                                             // 0x0CC0 (size: 0x8)
    bool IsSoundPausedByCinematic;                                                    // 0x0CC8 (size: 0x1)
    bool IsLoadingMapFromLoadGame;                                                    // 0x0CC9 (size: 0x1)
    FS_ManorDoors PreviousManorDoorInfo;                                              // 0x0CCC (size: 0x10)
    class UBP_ItemUpgradeSystem_C* InventorySystem;                                   // 0x0CE0 (size: 0x8)
    FBP_jRPG_GI_Custom_COnAnyPersistentFlagSet OnAnyPersistentFlagSet;                // 0x0CE8 (size: 0x10)
    void OnAnyPersistentFlagSet();
    FBP_jRPG_GI_Custom_COnEnemyBattled OnEnemyBattled;                                // 0x0CF8 (size: 0x10)
    void OnEnemyBattled(FName EnemyID);
    FBP_jRPG_GI_Custom_COnAnyEnemyBattled OnAnyEnemyBattled;                          // 0x0D08 (size: 0x10)
    void OnAnyEnemyBattled();
    FBP_jRPG_GI_Custom_COnAnyDialoguePlayed OnAnyDialoguePlayed;                      // 0x0D18 (size: 0x10)
    void OnAnyDialoguePlayed();
    FBP_jRPG_GI_Custom_COnAnyCinematicPlayed OnAnyCinematicPlayed;                    // 0x0D28 (size: 0x10)
    void OnAnyCinematicPlayed();
    FDataTableRowHandle PartyHealShard;                                               // 0x0D38 (size: 0x10)
    TMap<FGuid, int32> InteractedDialogues;                                           // 0x0D48 (size: 0x50)
    class UBP_RelationshipSystem_C* RelationshipSystem;                               // 0x0D98 (size: 0x8)
    FName LevelDestinationNameAfterCamp;                                              // 0x0DA0 (size: 0x8)
    class USoundBase* LastMusicBeforeBattle;                                          // 0x0DA8 (size: 0x8)
    class USoundBase* LastMusicBeforeCinematic;                                       // 0x0DB0 (size: 0x8)
    class UWBP_CreditOverlay_C* CurrentCreditsOverlay;                                // 0x0DB8 (size: 0x8)
    TArray<UAudioComponent*> AudioComponentsToUnspawn;                                // 0x0DC0 (size: 0x10)
    bool IsStillOnVictoryScreen;                                                      // 0x0DD0 (size: 0x1)
    class UBP_DataAsset_ProjectConfiguration_C* ProjectConfiguration;                 // 0x0DD8 (size: 0x8)
    TSoftObjectPtr<class ABP_LightingScenarioReference_C> LastSavedLightingScenario;  // 0x0DE0 (size: 0x28)
    FS_AreaAudioParameters LastSavedAudioParameters;                                  // 0x0E08 (size: 0x38)
    class UBP_GameDifficultyManager_C* DifficultyManager;                             // 0x0E40 (size: 0x8)
    bool ShouldDispatchModifications;                                                 // 0x0E48 (size: 0x1)
    int32 FinishedGameCount;                                                          // 0x0E4C (size: 0x4)
    FBP_jRPG_GI_Custom_COnFinishedGameCounterChanged OnFinishedGameCounterChanged;    // 0x0E50 (size: 0x10)
    void OnFinishedGameCounterChanged();
    FBP_jRPG_GI_Custom_COnChangeMapProcessStarted OnChangeMapProcessStarted;          // 0x0E60 (size: 0x10)
    void OnChangeMapProcessStarted(FName LevelDestination);
    FBP_jRPG_GI_Custom_COnChangeMapProcessFinished OnChangeMapProcessFinished;        // 0x0E70 (size: 0x10)
    void OnChangeMapProcessFinished(FName LevelDestination);
    TMap<FName, FS_MerchantSaveData> MerchantStates;                                  // 0x0E80 (size: 0x50)
    FBP_jRPG_GI_Custom_COnAnyTutorialCompleted OnAnyTutorialCompleted;                // 0x0ED0 (size: 0x10)
    void OnAnyTutorialCompleted();
    TEnumAsByte<E_InteractiveMusicContext::Type> CurrentExplorationContext;           // 0x0EE0 (size: 0x1)
    TMap<FName, FFPassiveEffectProgression> SharedPassiveEffectProgression;           // 0x0EE8 (size: 0x50)
    TArray<FName> ExternalCompanions;                                                 // 0x0F38 (size: 0x10)
    TMap<FName, FS_LevelSpawnPointsData> UnlockedSpawnPoints;                         // 0x0F48 (size: 0x50)
    TArray<uint8> UnlockedMapSections;                                                // 0x0F98 (size: 0x10)
    bool IsMountInUse;                                                                // 0x0FA8 (size: 0x1)
    FGameplayTag CurrentSettingsContext;                                              // 0x0FAC (size: 0x8)
    FBP_jRPG_GI_Custom_COnSettingsPageContextChanged OnSettingsPageContextChanged;    // 0x0FB8 (size: 0x10)
    void OnSettingsPageContextChanged(FGameplayTag NewContext);
    TMap<FName, bool> EncounteredEnemies;                                             // 0x0FC8 (size: 0x50)
    FBP_jRPG_GI_Custom_COnEnemyEncountered OnEnemyEncountered;                        // 0x1018 (size: 0x10)
    void OnEnemyEncountered(FName EnemyID);
    FBP_jRPG_GI_Custom_COnAnyEnemyEncountered OnAnyEnemyEncountered;                  // 0x1028 (size: 0x10)
    void OnAnyEnemyEncountered();
    TMap<FGameplayTag, FS_UINotificationPool> NotificationPools;                      // 0x1038 (size: 0x50)
    FBP_jRPG_GI_Custom_COnObjectMarkedAsRead OnObjectMarkedAsRead;                    // 0x1088 (size: 0x10)
    void OnObjectMarkedAsRead(FGameplayTag PoolTag, FName ObjectName, class UUserWidget* Mark Caller);
    TMap<FGameplayTag, FS_UIFavoritePool> FavoritePools;                              // 0x1098 (size: 0x50)
    FBP_jRPG_GI_Custom_COnFavoriteObjectChanged OnFavoriteObjectChanged;              // 0x10E8 (size: 0x10)
    void OnFavoriteObjectChanged(FGameplayTag PoolTag, FName ObjectId, bool IsFavorite);
    FBP_jRPG_GI_Custom_COnPassiveEffectLearned OnPassiveEffectLearned;                // 0x10F8 (size: 0x10)
    void OnPassiveEffectLearned(FName PassiveEffectName);
    FS_LevelSpawnPointData LastUsedSavePoint;                                         // 0x1108 (size: 0x10)
    TArray<FName> VisitedLevelRowNames;                                               // 0x1118 (size: 0x10)
    TArray<UNamedID*> NamedIDsStatesToKeepInNewGamePlus;                              // 0x1128 (size: 0x10)
    TMap<FName, UCharacterStats*> TempCharacterStats;                                 // 0x1138 (size: 0x50)
    FBP_jRPG_GI_Custom_COnAnyCharacterLevelChanged OnAnyCharacterLevelChanged;        // 0x1188 (size: 0x10)
    void OnAnyCharacterLevelChanged();
    TArray<FS_GameActionTriggerZoneParameters> GameActionTriggerZoneParameters;       // 0x1198 (size: 0x10)
    class ABP_PhotoModePawn_C* PhotoModePawn;                                         // 0x11A8 (size: 0x8)
    class ABP_PhotoModeController_C* PhotoModeController;                             // 0x11B0 (size: 0x8)
    class APlayerController* PreviousControllerBeforePhotoMode;                       // 0x11B8 (size: 0x8)
    FBP_jRPG_GI_Custom_COnEnterPhotoMode OnEnterPhotoMode;                            // 0x11C0 (size: 0x10)
    void OnEnterPhotoMode();
    FBP_jRPG_GI_Custom_COnExitPhotoMode OnExitPhotoMode;                              // 0x11D0 (size: 0x10)
    void OnExitPhotoMode();
    FS_UITransientData UITransientData;                                               // 0x11E0 (size: 0xF0)
    class UBP_PassiveEffectsSetManager_C* PassiveEffectsSetManager;                   // 0x12D0 (size: 0x8)
    class AActor* PreviousViewTargetBeforePhotoMode;                                  // 0x12D8 (size: 0x8)

    void RestorePreviousViewTarget(class ABP_jRPG_Controller_World_C* ControllerWorld);
    class UBP_PassiveEffectsSetManager_C* GetPassiveEffectsSetManager();
    void SetGlobalPostProcessEnabled(bool Enabled);
    void SetUIIsFilterActive(TEnumAsByte<E_SortDropdownIdentifier::Type> DropdownIdentifier, bool IsFilterActive);
    void SetUIActiveFilters(TEnumAsByte<E_SortDropdownIdentifier::Type> DropdownIdentifier, const TArray<FName>& ActiveFilters);
    void SetUIActiveSortDirection(const TEnumAsByte<E_SortDropdownIdentifier::Type>& DropdownIdentifier, const ESortDirection& ActiveSortDirection);
    void SetUIActiveSortEntry(const TEnumAsByte<E_SortDropdownIdentifier::Type>& DropdownIdentifier, const FName& ActiveEntryIdentifier);
    void GetUITransientData(FS_UITransientData& UITransientData);
    bool IsInPhotoMode();
    void ExitPhotoMode();
    void EnterPhotoMode();
    bool HasGameActionTriggerZoneParameters(class ABP_GameActionTriggerZone_C* GameActionTriggerZone, TEnumAsByte<E_GameActionTriggerZoneExecutionMode::Type> ExecutionMode);
    TArray<FS_GameActionTriggerZoneParameters> PopAllGameActionTriggerZoneParameters();
    void PushGameActionTriggerZoneParameters(FS_GameActionTriggerZoneParameters GameActionTriggerZoneParameters);
    void OnCharacterLevelChanged(FName CharacterNameID, int32 OldLevel, int32 NewLevel);
    bool CanUseStats();
    void InitCharStats();
    void OnGameUserSettingsApplied(class UConfigurableGameUserSettings* UserConfig);
    void AddVisitedLevel(FName VisitedLevel);
    bool HasVisitedLevel(const FName& LevelName);
    void LoadFavoritePools(TMap<FGameplayTag, FS_UIFavoritePool> FavoritePools);
    void GetFavoritePools(TMap<FGameplayTag, FS_UIFavoritePool>& FavoritePools);
    void IsObjectFavorite(FGameplayTag PoolTag, FName FavoriteObjectName, bool& IsFavorite);
    void ToggleObjectAsFavorite(FGameplayTag PoolTag, FName FavoriteObjectName);
    void ResetDataOnChangeMapIfNeeded(const FFLevelDataEntry& DestinationLevelData);
    void LoadNotificationPools(TMap<FGameplayTag, FS_UINotificationPool> NotificationPools);
    void GetNotificationPools(TMap<FGameplayTag, FS_UINotificationPool>& NotificationPools);
    void IsThereAnyObjectNotifiedInPool(FGameplayTag PoolTag, bool& IsFound);
    void ShouldObjectBeNotified(FGameplayTag PoolTag, FName NotifiedObjectName, bool& IsNotified);
    void MarkObjectAsRead(FGameplayTag PoolTag, FName NotifiedObjectName, class UUserWidget* MarkCaller);
    void NotifyObject(FGameplayTag PoolTag, FName NotifiedObjectName);
    void GetIsSaveLoaded(bool& ReturnNode);
    void GetCharacterCollectionLeftToRight(bool With Excluded Characters, TArray<UBP_CharacterData_C*>& Characters);
    double GetFadeOutDurationFromAmbience(class UBP_DataAsset_Ambience_C* Ambience);
    void AdjustAmbienceColume(float AdjustVolumeDuration, float AdjustVolumeLevel, const EAudioFaderCurve FadeCurve);
    void GetSettingsPageContext(FGameplayTag& CurrentContext);
    void SetSettingsPageContext(FGameplayTag NewContext);
    void GetUnlockedMapSectionsNormalized(TArray<double>& NormalizedUnlockedMapSections);
    bool HasUnlockedAnySpawnPointInLevel(const FName& LevelName);
    void AddToUnlockedMapSections(uint8 SectionGrayscale, int32& AddedIndex);
    void DoesUnlockedMapSectionsContains(uint8 SectionGrayscale, bool& IsContained);
    void GetUnlockedMapSections(TArray<uint8>& UnlockedMapSections);
    void LoadUnlockSpawnPoints(TArray<FS_LevelSpawnPointsData>& SpawnPointList);
    bool HasUnlockedSpawnPointInCurrentLevel(const FGameplayTag& SpawnPointTag);
    void UnlockSpawnPointForCurrentLevel(const FGameplayTag& SpawnPointTag);
    void LoadSharedPassiveEffectProgression(TArray<FFPassiveEffectProgression>& PassiveEffectProgression);
    void GetAllSharedPassiveEffectProgressions(TArray<FFPassiveEffectProgression>& PassiveEffectProgressions);
    void UpdateSharedPassiveEffectProgression(FFPassiveEffectProgression DirtyProgression, FFPassiveEffectProgression& UpdatedProgression);
    void GetOrCreateSharedPassiveEffectProgression(const FName& PassiveEffectID, FFPassiveEffectProgression& Progression);
    void GetAudioControlSystem(class UBP_AudioControlSystem_C*& AudioControlSystem);
    void SetTutorialCompleted(const FName& TutorialRowName, bool Completed);
    void ApplyAccessibilitySettings();
    void OnControllerEndPlay();
    void OnControllerBeginPlay();
    void IncreaseFinishedGameCount();
    void CreateNotificationWidget();
    void LoadPersistentFlags(const TMap<FGuid, bool>& FlagStates);
    void OnAudioPlayStateChanged(EAudioComponentPlayState PlayState);
    void MarkAudioComponentForUnspawn(class UAudioComponent* AudioComponent, double FadeOutDuration);
    void ComputeAudioParametersForSave(FS_AreaAudioParameters& AudioParameters);
    void DestroyAllSounds();
    void ProcessAudioParameters(FS_AudioLevelParameters AudioPrameters);
    void GetPreviousLevelData(bool& Found, FFLevelDataEntry& LevelData);
    void OnCreditsFinished();
    void IsMapChangeInProgress(bool& InProgress);
    void PlayCredits(class UBP_DataAsset_GameCredits_C* Credits, class USF_BlueprintLatentAction* LatentAction);
    void PrepareToChangeMap();
    void GetInteractedDialogues(TMap<FGuid, int32>& InteractedDialogues);
    void AddInteractedDialogues(const FGuid& DialogueGUID, const int32& DialogueStage);
    void SetPlayedCinematic(const FName& Cinematic);
    void SetEnemyLastFleePoint(const FName& EnemyID, TSoftObjectPtr<class ABP_FleePoint_C> RoamingPointIndex);
    void SetEnemyRoamingPointIndex(const FName& EnemyID, int32 RoamingPointIndex);
    void SetEncounteredEnemy(const FName& EnemyID);
    void SetBattledEnemy(const FName& EnemyID);
    void SetEnemyTransform(const FName& EnemyID, FTransform Transform);
    void OnWeaponChange();
    FName GetSpawnPointAsName();
    void AreAllCharactersDead(bool& AllDead);
    void GetCurrentCharacterWorld(TEnumAsByte<E_CharacterList::Type>& CurrentCharacterWorldEnum);
    bool HasCharacterInCollectionByID(FName CharacterId);
    void GetCharacterByID(FName CharacterId, class UBP_CharacterData_C*& CharacterData);
    void GetCharacterNameCollection(bool With Excluded Characters, TArray<FName>& Characters);
    void GetCharacterCollection(bool With Excluded Characters, TArray<UBP_CharacterData_C*>& Characters);
    bool IsSoundPausedForCinematics();
    void OnCharacterExplorationDeath(class UBP_CharacterData_C* CharacterData);
    void UpdateVendorState(FName VendorID, FFVendorState VendorState);
    void GetOrCreateVendorState(FName VendorID, FFVendorState& Value);
    void todelete(const class USoundWave* PlayingSoundWave, const float PlaybackPercent);
    void ResumeAmbience(float FadeInDuration);
    void StopAmbience(float FadeOutDuration);
    void HandleNextAmbience(class UBP_DataAsset_Ambience_C* NextAmb, float StartTime);
    void WritePersistentFlag(class UNamedID* NamedID, bool Value);
    void GetPersistentFlagValue(class UNamedID* NamedID, bool& Value);
    void GetPersistentFlags(TArray<UNamedID*>& Keys);
    class UNamedID* FindNamedIDByGuid(FGuid Guid);
    void GetAllNamedIDs(TArray<UNamedID*>& AllNamedIDs);
    void DEBUG_RegisterCVars();
    void GoBackToMainMenu();
    void CheckDestroyable(const FName& ItemToFind, bool& CanDestroy);
    int32 GetItemQuantityInInventory(FName ItemId);
    void ValidateGameData();
    void UpdateCurrentCharacterWorld();
    bool IsCharacterInParty(FName CharacterId);
    void CheckInteractiveObjectUnicity(FName InteractiveObjectGlobalID, const class AActor*& Actor);
    void SetBattleParty(TArray<FName>& CharacterHardcodedName);
    void OnSaveLoaded();
    void BindOnSaveLoaded(const FBindOnSaveLoadedEvent& Event, bool& AlreadyLoaded);
    void CheckDialogueIsAtLeastAtStage(const FGuid& DialogueGUID, int32 Stage, bool& IsAtLeastAtStage);
    void CheckHasPlayedTutorial(const FName& TutorialRowName, bool& HasPlayed);
    void SetNewActiveSkin(FName CharacterName, TSoftClassPtr<ABP_CharacterSkinBase_C> NewActiveSkin, TSoftClassPtr<ABP_CharacterSkinBase_C>& ActiveSkin);
    void AddSkinToCollection(FName Character, FName SkinToAdd);
    void CheckInteractionDone(TArray<FName>& Interaction, bool& AllCheckTrue);
    void InitializeSystemsAndManagers();
    void ResetNamedIDsStatesForNewGamePlus();
    void ResetStateByRestPointUsed();
    void ResetStateForNewGamePlus();
    void ResetState();
    void PersistentGruntSound(class USoundBase* SoundPersistent);
    void PlayBattleTransition();
    class ABP_jRPG_Controller_World_C* GetControllerWorld();
    void PersistentVoice(class USoundBase* VoicePersistent, FVector Location, double PitchMultiplier, double FadeOutTime, class UAudioComponent*& CurrentVoiceName);
    void PersistentSoundEffect(class USoundBase* SoundPersistent, double Volume, double Pitch, double tartTime);
    void SpawnNewSound(class USoundBase* SoundToPlay, float StartTime, class UAudioComponent*& SpawnedComponent);
    void ApplyPostProcessSettings();
    void ApplyAllUserSettings();
    void OnLoaded_6940291243D1FB3D1A33C5BD82FB6BD8(UClass* Loaded);
    void DEBUG_RegisterCvarCallbacks();
    void DEBUG_CVarChanged_MuteMusic(bool NewValue);
    void DEBUG_CVarChanged_MuteSFX(bool NewValue);
    void DEBUG_CVarChanged_MuteVO(bool NewValue);
    void DEBUG_CVarChanged_MuteAMB(bool NewValue);
    void DEBUG_CVarChanged_OnUnlockAllCleasTowerBattles(bool NewValue);
    void DEBUG_CVarChanged_OnShowColorVisionDeficiencyChanged(bool NewValue);
    void GameInstance_StartPerformanceMeasures(double Delay);
    void DEBUG_ResetCinematics();
    void ReceiveInit();
    void ChangeMap();
    void OnInitialCinematicCompleted();
    void SetGameplayPaused(bool Paused);
    void ProcessLevelParameters(FFLevelDataEntry LevelData);
    void OnCvarChanged_ScreenPercentage(int32 NewValue);
    void ShowCreditsIfNeeded();
    void ReceivePostInitSubsystemCollection();
    void TickStats();
    void QueueStatUpdate();
    void OnStatUpdateReady();
    void Test_Event1();
    void ProcessCharacterStat_Step1(int32 StatId, int32 StatValue);
    void ProcessCharacterStat_Final();
    void ProcessCharacterStat_Step2();
    void ExecuteUbergraph_BP_jRPG_GI_Custom(int32 EntryPoint);
    void OnExitPhotoMode__DelegateSignature();
    void OnEnterPhotoMode__DelegateSignature();
    void OnAnyCharacterLevelChanged__DelegateSignature();
    void OnPassiveEffectLearned__DelegateSignature(FName PassiveEffectName);
    void OnFavoriteObjectChanged__DelegateSignature(FGameplayTag PoolTag, FName ObjectId, bool IsFavorite);
    void OnObjectMarkedAsRead__DelegateSignature(FGameplayTag PoolTag, FName ObjectName, class UUserWidget* Mark Caller);
    void OnAnyEnemyEncountered__DelegateSignature();
    void OnEnemyEncountered__DelegateSignature(FName EnemyID);
    void OnSettingsPageContextChanged__DelegateSignature(FGameplayTag NewContext);
    void OnEnemyBattled__DelegateSignature(FName EnemyID);
    void OnAnyTutorialCompleted__DelegateSignature();
    void OnChangeMapProcessFinished__DelegateSignature(FName LevelDestination);
    void OnChangeMapProcessStarted__DelegateSignature(FName LevelDestination);
    void OnFinishedGameCounterChanged__DelegateSignature();
    void OnAnyPersistentFlagSet__DelegateSignature();
    void OnAnyCinematicPlayed__DelegateSignature();
    void OnAnyDialoguePlayed__DelegateSignature();
    void OnAnyEnemyBattled__DelegateSignature();
    void OnPersistentFlagSet__DelegateSignature(class UNamedID* NamedID);
    void OnGameLoaded__DelegateSignature();
}; // Size: 0x12E0

#endif
