#ifndef UE4SS_SDK_BP_GameMenuScene_HPP
#define UE4SS_SDK_BP_GameMenuScene_HPP

class ABP_GameMenuScene_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USpotLightComponent* SpotLight_Gustave_Skills;                              // 0x0298 (size: 0x8)
    class USpotLightComponent* SpotLight_Verso_Skills;                                // 0x02A0 (size: 0x8)
    class USpotLightComponent* SpotLight_Verso_Stats;                                 // 0x02A8 (size: 0x8)
    class USpotLightComponent* SpotLight_Lune_Stats;                                  // 0x02B0 (size: 0x8)
    class USpotLightComponent* SpotLight_Maelle_Stats;                                // 0x02B8 (size: 0x8)
    class USkyLightComponent* SkyLight;                                               // 0x02C0 (size: 0x8)
    class UDirectionalLightComponent* DirectionalLight;                               // 0x02C8 (size: 0x8)
    class URectLightComponent* RectLight_Gustave_1;                                   // 0x02D0 (size: 0x8)
    class URectLightComponent* RectLight_Gustave_2;                                   // 0x02D8 (size: 0x8)
    class USpotLightComponent* SpotLight_Gustave_5_Wardrobe;                          // 0x02E0 (size: 0x8)
    class USpotLightComponent* SpotLight_Gustave_4_WardrobeWeapon;                    // 0x02E8 (size: 0x8)
    class USpotLightComponent* SpotLight_Gustave_2;                                   // 0x02F0 (size: 0x8)
    class USpotLightComponent* SpotLight_Gustave_3;                                   // 0x02F8 (size: 0x8)
    class USpotLightComponent* SpotLight_Monoco_3_Wardrobe;                           // 0x0300 (size: 0x8)
    class USpotLightComponent* SpotLight_Monoco_2;                                    // 0x0308 (size: 0x8)
    class USpotLightComponent* SpotLight_Monoco_1_Weapon;                             // 0x0310 (size: 0x8)
    class URectLightComponent* RectLight_Monoco2;                                     // 0x0318 (size: 0x8)
    class URectLightComponent* RectLight_Monoco1;                                     // 0x0320 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_5;                                     // 0x0328 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_4;                                     // 0x0330 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_7_Wardrobe;                            // 0x0338 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_6_Wardrobe;                            // 0x0340 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_5_Weapon;                              // 0x0348 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_4_Weapon;                              // 0x0350 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_1;                                     // 0x0358 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_2;                                     // 0x0360 (size: 0x8)
    class USpotLightComponent* SpotLight_Sciel_3;                                     // 0x0368 (size: 0x8)
    class URectLightComponent* RectLight_Sciel_2;                                     // 0x0370 (size: 0x8)
    class USpotLightComponent* SpotLight_Lune_Wardrobe_1;                             // 0x0378 (size: 0x8)
    class USpotLightComponent* SpotLight_Lune_3;                                      // 0x0380 (size: 0x8)
    class USpotLightComponent* SpotLight_Lune_2;                                      // 0x0388 (size: 0x8)
    class USpotLightComponent* SpotLight_Lune_1;                                      // 0x0390 (size: 0x8)
    class URectLightComponent* RectLight_Lune_1;                                      // 0x0398 (size: 0x8)
    class URectLightComponent* RectLight_Lune_2;                                      // 0x03A0 (size: 0x8)
    class USpotLightComponent* SpotLight_Verso_6_WardrobeWeapon_Backlight;            // 0x03A8 (size: 0x8)
    class USpotLightComponent* SpotLight_Verso_5_Wardrobe;                            // 0x03B0 (size: 0x8)
    class USpotLightComponent* SpotLight_Verso_4_WardrobeWeapon;                      // 0x03B8 (size: 0x8)
    class URectLightComponent* RectLight_Verso_1;                                     // 0x03C0 (size: 0x8)
    class URectLightComponent* RectLight_Verso_2;                                     // 0x03C8 (size: 0x8)
    class URectLightComponent* RectLight_Maelle1;                                     // 0x03D0 (size: 0x8)
    class USpotLightComponent* SpotLight_Maelle_3;                                    // 0x03D8 (size: 0x8)
    class USpotLightComponent* SpotLight_Maelle_Backlight_Custo_5;                    // 0x03E0 (size: 0x8)
    class USpotLightComponent* SpotLight_Maelle__Custo_4;                             // 0x03E8 (size: 0x8)
    class USpotLightComponent* SpotLight_Maelle__Custo_3;                             // 0x03F0 (size: 0x8)
    class URectLightComponent* RectLight_Maelle2;                                     // 0x03F8 (size: 0x8)
    class USpotLightComponent* SpotLight_Maelle_2;                                    // 0x0400 (size: 0x8)
    class USpotLightComponent* SpotLight_Verso_3;                                     // 0x0408 (size: 0x8)
    class USpotLightComponent* SpotLight_Gustave_1;                                   // 0x0410 (size: 0x8)
    class USpotLightComponent* SpotLight_Verso_2;                                     // 0x0418 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_Pictos;                             // 0x0420 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_Lumina;                              // 0x0428 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_Skills;                              // 0x0430 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_CharacterOverview;                  // 0x0438 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_CharacterOverview;                 // 0x0440 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_Pictos;                            // 0x0448 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_SkillTree;                         // 0x0450 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_Wardrobe;                          // 0x0458 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_Lumina;                            // 0x0460 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_Skills;                            // 0x0468 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_Stats;                             // 0x0470 (size: 0x8)
    class UCineCameraComponent* CineCamera_Gustave_Weapon;                            // 0x0478 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_Weapon;                               // 0x0480 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_Skills;                               // 0x0488 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_Lumina;                               // 0x0490 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_Wardrobe;                             // 0x0498 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_SkillTree;                            // 0x04A0 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_Stats;                                // 0x04A8 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_Pictos;                               // 0x04B0 (size: 0x8)
    class UCineCameraComponent* CineCamera_Lune_CharacterOverview;                    // 0x04B8 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_Stats;                               // 0x04C0 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_CharacterOverview;                   // 0x04C8 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_Weapon;                              // 0x04D0 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_Skills;                              // 0x04D8 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_Lumina;                              // 0x04E0 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_Wardrobe;                            // 0x04E8 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_Pictos;                              // 0x04F0 (size: 0x8)
    class UCineCameraComponent* CineCamera_Verso_SkillTree;                           // 0x04F8 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_Wardrobe;                           // 0x0500 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_SkillTree;                          // 0x0508 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_Stats;                              // 0x0510 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_Pictos;                             // 0x0518 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_Weapon;                             // 0x0520 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_Skills;                             // 0x0528 (size: 0x8)
    class UCineCameraComponent* CineCamera_Monoco_Lumina;                             // 0x0530 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_SkillTree;                           // 0x0538 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_Wardrobe;                            // 0x0540 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_Weapon;                              // 0x0548 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_CharacterOverview;                   // 0x0550 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_Pictos;                              // 0x0558 (size: 0x8)
    class UCineCameraComponent* CineCamera_Sciel_Stats;                               // 0x0560 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_Skills;                             // 0x0568 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_Stats;                              // 0x0570 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_SkillTree;                          // 0x0578 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_Weapon;                             // 0x0580 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_CharacterOverview;                  // 0x0588 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_Wardrobe;                           // 0x0590 (size: 0x8)
    class UCineCameraComponent* CineCamera_Maelle_Lumina;                             // 0x0598 (size: 0x8)
    class USpotLightComponent* SpotLight_Base5;                                       // 0x05A0 (size: 0x8)
    class UChildActorComponent* ChildActor_PostProcessVolume;                         // 0x05A8 (size: 0x8)
    class UNiagaraComponent* FX_Falling_Leaves;                                       // 0x05B0 (size: 0x8)
    class UExponentialHeightFogComponent* ExponentialHeightFog;                       // 0x05B8 (size: 0x8)
    class UCineCameraComponent* CineCamera_TeamOverview;                              // 0x05C0 (size: 0x8)
    class USpotLightComponent* SpotLight_Base_4;                                      // 0x05C8 (size: 0x8)
    class USpotLightComponent* SpotLight5;                                            // 0x05D0 (size: 0x8)
    class USpotLightComponent* SpotLight4;                                            // 0x05D8 (size: 0x8)
    class USpotLightComponent* SpotLight3;                                            // 0x05E0 (size: 0x8)
    class UPointLightComponent* PointLight1;                                          // 0x05E8 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x05F0 (size: 0x8)
    class USceneComponent* Scene_EsquieCarLocation;                                   // 0x05F8 (size: 0x8)
    class USpotLightComponent* SpotLight_Base_3;                                      // 0x0600 (size: 0x8)
    class UChildActorComponent* ChildActor_Esquie;                                    // 0x0608 (size: 0x8)
    class UChildActorComponent* ChildActor_Verso;                                     // 0x0610 (size: 0x8)
    class UChildActorComponent* ChildActor_Monoco;                                    // 0x0618 (size: 0x8)
    class UChildActorComponent* ChildActor_Sciel;                                     // 0x0620 (size: 0x8)
    class UStaticMeshComponent* ArtDeco1;                                             // 0x0628 (size: 0x8)
    class UChildActorComponent* ChildActor_Maelle;                                    // 0x0630 (size: 0x8)
    class USpotLightComponent* SpotLight_Base_1;                                      // 0x0638 (size: 0x8)
    class USpotLightComponent* SpotLight_Base_2;                                      // 0x0640 (size: 0x8)
    class UStaticMeshComponent* Sphere;                                               // 0x0648 (size: 0x8)
    class UCineCameraComponent* CineCamera_Reference;                                 // 0x0650 (size: 0x8)
    class UChildActorComponent* ChildActor_Lune;                                      // 0x0658 (size: 0x8)
    class UChildActorComponent* ChildActor_Gustave;                                   // 0x0660 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0668 (size: 0x8)
    float CameraFocalLengthTimeline_LerpTrack_F13C3E8448E1A2954C204DA3E9DDA0BF;       // 0x0670 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> CameraFocalLengthTimeline__Direction_F13C3E8448E1A2954C204DA3E9DDA0BF; // 0x0674 (size: 0x1)
    class UTimelineComponent* CameraFocalLengthTimeline;                              // 0x0678 (size: 0x8)
    float MovingCameraTimeline_LerpTrack_A622A368444C69C7860F29982FD6291A;            // 0x0680 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> MovingCameraTimeline__Direction_A622A368444C69C7860F29982FD6291A; // 0x0684 (size: 0x1)
    class UTimelineComponent* MovingCameraTimeline;                                   // 0x0688 (size: 0x8)
    TMap<FName, UChildActorComponent*> CharacterChildActorMapping;                    // 0x0690 (size: 0x50)
    TMap<UChildActorComponent*, UBP_CharacterData_C*> ActorToData;                    // 0x06E0 (size: 0x50)
    class ALevelSequenceActor* CurrentSequence;                                       // 0x0730 (size: 0x8)
    FMovieSceneSequencePlaybackSettings PlaybackSettings;                             // 0x0738 (size: 0x28)
    class UWBP_GameMenu_v3_C* MainMenuUI;                                             // 0x0760 (size: 0x8)
    TArray<UBP_CharacterSkinComponent_C*> CharacterSkinsToLoad;                       // 0x0768 (size: 0x10)
    FBP_GameMenuScene_COnMenuUIReady OnMenuUIReady;                                   // 0x0778 (size: 0x10)
    void OnMenuUIReady();
    FName PreSelectedPage;                                                            // 0x0788 (size: 0x8)
    TEnumAsByte<E_Characters::Type> FocusedCharacter;                                 // 0x0790 (size: 0x1)
    FTransform CamRefTransformBeforeMovement;                                         // 0x07A0 (size: 0x60)
    float CamRefFocalBeforeMovement;                                                  // 0x0800 (size: 0x4)
    TEnumAsByte<E_Characters::Type> PreviousCharacter;                                // 0x0804 (size: 0x1)
    TEnumAsByte<E_GameMenuPage::Type> CurrentGameMenuPage;                            // 0x0805 (size: 0x1)
    TEnumAsByte<E_Characters::Type> CurrentCharacter;                                 // 0x0806 (size: 0x1)
    bool DEBUG_InstantCamTP;                                                          // 0x0807 (size: 0x1)
    class UChildActorComponent* CurrentChildActorToFocus;                             // 0x0808 (size: 0x8)
    FRotator BaseOverViewCamRotation;                                                 // 0x0810 (size: 0x18)
    bool PreviewSpotDisabled;                                                         // 0x0828 (size: 0x1)
    bool PreviewSpotCharacterEnabled;                                                 // 0x0829 (size: 0x1)
    FName Debug_Spotlight_TagName;                                                    // 0x082C (size: 0x8)
    bool UseCustomSpotlightPerCharacter;                                              // 0x0834 (size: 0x1)

    void SetSceneTickEnabled(bool Enabled);
    void PlayAnimationOnMenuOpened();
    void UpdateCharactersVisualAlterations();
    void EnableGameMenuLighting(bool bNewVisibility);
    void DEBUG_SpotlightCharacterVisibility();
    void UpdateCharacterClassPreload(TArray<UBP_CharacterData_C*>& CharacterData);
    void UpdateWeaponSkin(TSubclassOf<class ABP_WeaponSkin_C> WeaponSkinClass, class UBP_CharacterData_C* CurrentCharacterData);
    void GetCharacterClassByChildComponent(class UChildActorComponent* ChildActor, TSoftClassPtr<ABP_CineCharacter_Main_C>& ActorClass);
    void UpdateCameraOverviewLookAt();
    void MoveCameraToCorrespondingCharacter(TEnumAsByte<E_GameMenuPage::Type> GameMenuPage, TEnumAsByte<E_Characters::Type> Character);
    void ApplyCustomization(class UBP_CharacterData_C* CharacterData);
    void TriggerCustomizationChangedAnimation(bool HasHaircutChanged, bool HasCostumeChanged);
    void SetActivePageAndCharacterAnimState(TEnumAsByte<E_GameMenuPage::Type> InPage, class UBP_CharacterData_C* InCharacterData);
    void SuspendClothOnCharacters();
    void ResumeClothOnCharacters();
    void OnSkinLoaded(class UBP_CharacterSkinComponent_C* SkinComponent);
    void GetCharactersClassByChildComponent(TMap<UChildActorComponent*, TSoftClassPtr<ABP_CineCharacter_Main_C>>& Map);
    void LoadAnimations();
    void CreateUIMenu(FS_GameMenuParameters GameMenuParameters);
    void LoadEsquieState(TArray<TEnumAsByte<E_WorldMapExplorationCapacity::Type>>& WorldMapExplorationCapacities);
    void SetGameMenuSceneEnabled(bool Enabled);
    void CleanPreviousSequence();
    void GetCharactersDataLeftToRight(TArray<UBP_CharacterData_C*>& OrderedCharacters);
    void LoadCharacters(TArray<UBP_CharacterData_C*>& CharacterCollection);
    void LoadAnimInstanceOnChildActor(class UChildActorComponent* ChildActor, UClass* AnimBP);
    void GetActorForCharacter(class UBP_CharacterData_C* CharacterData, class AActor*& Actor);
    void GetChildActorComponentForCharacter(class UBP_CharacterData_C* CharacterData, class UChildActorComponent*& Value);
    void UserConstructionScript();
    void MovingCameraTimeline__FinishedFunc();
    void MovingCameraTimeline__UpdateFunc();
    void CameraFocalLengthTimeline__FinishedFunc();
    void CameraFocalLengthTimeline__UpdateFunc();
    void OnLoaded_7B74164F4C8789B779DF569C565E2059(UClass* Loaded);
    void ApplyCharacterCustomization(class UBP_CharacterData_C* Character);
    void OnCharacterCollectionChanged();
    void OnActivePageAndCharacterChanged(TEnumAsByte<E_GameMenuPage::Type> MenuPage, class UBP_CharacterData_C* CurrentCharacter);
    void MoveReferenceCamera(class UCineCameraComponent* CameraToMoveTo);
    void DisableGameMenuScene();
    void TEST_SpawnCharactersToSetup();
    void MoveCameraToOverview();
    void PerformCharacterCloseup(class UBP_CharacterData_C* Character);
    void EnableGameMenuScene(TArray<UBP_CharacterData_C*>& CharacterCollection, const TArray<TEnumAsByte<E_WorldMapExplorationCapacity::Type>>& UnlockedWorldMapCapacities, FS_GameMenuParameters GameMenuParameters);
    void ReceiveBeginPlay();
    void EDITORSETUP_DisableGlobalSpot();
    void DEBUG_ActivateSpotlights_Verso();
    void DEBUG_ActivateSpotlights_Maelle();
    void DEBUG_ActivateSpotlights_Lune();
    void DEBUG_ActivateSpotlights_Sciel();
    void DEBUG_ActivateSpotlights_Monoco();
    void DEBUG_ActivateSpotlights_Gustave();
    void UpdateWeaponOnPageOpen(const FS_jRPG_Item_StaticData& S_jRPG_Item_StaticData, class UBP_CharacterData_C* CurrentCharacterData);
    void OpenPreSelectedPage(FName InPageName);
    void ExecuteUbergraph_BP_GameMenuScene(int32 EntryPoint);
    void OnMenuUIReady__DelegateSignature();
}; // Size: 0x835

#endif
