#ifndef UE4SS_SDK_BP_GameActionInstance_RequestSaveGame_HPP
#define UE4SS_SDK_BP_GameActionInstance_RequestSaveGame_HPP

class UBP_GameActionInstance_RequestSaveGame_C : public UGameActionInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0040 (size: 0x8)

    FString GetDebugString();
    bool ShouldTriggerAutoSaveAfterExecution();
    void ExecuteGameAction(const class APlayerController* Controller);
    void ExecuteUbergraph_BP_GameActionInstance_RequestSaveGame(int32 EntryPoint);
}; // Size: 0x48

#endif
