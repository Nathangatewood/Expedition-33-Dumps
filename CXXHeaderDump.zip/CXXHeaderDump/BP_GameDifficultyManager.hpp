#ifndef UE4SS_SDK_BP_GameDifficultyManager_HPP
#define UE4SS_SDK_BP_GameDifficultyManager_HPP

class UBP_GameDifficultyManager_C : public UExtendedObject
{
    TEnumAsByte<E_GameDifficulty::Type> SelectedDifficulty;                           // 0x0028 (size: 0x1)
    TEnumAsByte<E_GameDifficulty::Type> CurrentDifficulty;                            // 0x0029 (size: 0x1)
    TEnumAsByte<E_GameDifficulty::Type> LowestDifficulty;                             // 0x002A (size: 0x1)
    FBP_GameDifficultyManager_COnGameDifficultyChanged OnGameDifficultyChanged;       // 0x0030 (size: 0x10)
    void OnGameDifficultyChanged();
    TMap<FName, FName> ActivatedChallengeOptionIDs;                                   // 0x0040 (size: 0x50)
    TArray<UBP_DataAsset_BattleChallenge_C*> ChallengeAssets;                         // 0x0090 (size: 0x10)

    void ResetState();
    void FindChallengeDefinitions(TArray<FName>& ChallengeIDs, TMap<FName, UBP_DataAsset_BattleChallenge_C*>& ChallengeAsset);
    void FindChallengeDefinition(FName InputPin, class UBP_DataAsset_BattleChallenge_C*& ChallengeAsset);
    void DisableChallenge(const FName& ChallengeID);
    void SetSelectedChallengeOption(const FName& ChallengeID, const FName& OptionID);
    void GetSelectedChallengeOption(const FName& ChallengeID, bool& Found, FName& OptionID);
    TArray<FName> GetActiveChallengeIDs();
    void GetCurrentSelectedDifficulty(TEnumAsByte<E_GameDifficulty::Type>& SelectedDifficulty);
    void SetToDefaultSelectedGameDifficulty();
    bool IsChallengeActivated(FName ChallengeID);
    void RevertSelectedGameDiffculty();
    void IsCurrentDifficultyDirty(bool& IsDirty);
    void ApplySelectedGameDifficulty(bool DispatchChanges);
    void SelectGameDifficulty(TEnumAsByte<E_GameDifficulty::Type> Difficulty);
    void SetCurrentDifficulty(TEnumAsByte<E_GameDifficulty::Type> Difficulty);
    TEnumAsByte<E_GameDifficulty::Type> GetCurrentDifficulty();
    void LoadState(FS_GameDifficultySaveData SaveData);
    void SaveState(FS_GameDifficultySaveData& SaveData);
    void OnGameDifficultyChanged__DelegateSignature();
}; // Size: 0xA0

#endif
