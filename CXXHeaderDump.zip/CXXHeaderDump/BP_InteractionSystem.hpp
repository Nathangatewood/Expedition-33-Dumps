#ifndef UE4SS_SDK_BP_InteractionSystem_HPP
#define UE4SS_SDK_BP_InteractionSystem_HPP

class UBP_InteractionSystem_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<TScriptInterface<class IBPI_Interaction_C>> InteractiveObjects;            // 0x00A8 (size: 0x10)
    TArray<TScriptInterface<class IBPI_Interaction_C>> DistantInteractiveObjects;     // 0x00B8 (size: 0x10)
    TScriptInterface<class IBPI_Interaction_C> ActiveInteraction;                     // 0x00C8 (size: 0x10)
    FFPromptID CurrentPromptID;                                                       // 0x00D8 (size: 0x10)
    TScriptInterface<class IBPI_Interaction_C> 2DInteraction;                         // 0x00E8 (size: 0x10)
    class UWBP_PromptContainer_C* PromptContainerRef;                                 // 0x00F8 (size: 0x8)
    FSF_ReferenceCounter EnableInteractionsReferenceCounter;                          // 0x0100 (size: 0x20)
    FBP_InteractionSystem_COnInteracted OnInteracted;                                 // 0x0120 (size: 0x10)
    void OnInteracted();
    TMap<FFPromptID, TScriptInterface<class IBPI_Interaction_C>> DisplayedDistantInteractiveObjects; // 0x0130 (size: 0x50)
    int32 CurrentSliceIndex;                                                          // 0x0180 (size: 0x4)
    double DistantInteractionThresholdSquared;                                        // 0x0188 (size: 0x8)
    double DistantInteractionThresholdHysteresisSquared;                              // 0x0190 (size: 0x8)
    int32 InteractionsToProcessPerSlice;                                              // 0x0198 (size: 0x4)
    class ABP_jRPG_Controller_World_C* ParentControllerWorld;                         // 0x01A0 (size: 0x8)
    bool IsInteracting;                                                               // 0x01A8 (size: 0x1)

    void ShowExplorationPromptAtWorldLocation(FVector Location, FFPromptParams PromptParams, FFPromptID& OutPromptID);
    void GetIsInteracting(bool& IsInteracting);
    void OnInteractEnd();
    void HideExplorationPrompt(FFPromptID& PromptID);
    void AutoUnregisterDistantActor(class AActor* Actor, TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void RemoveDistantPromptWidget(TScriptInterface<class IBPI_Interaction_C> Interaction);
    void CreateDistantPromptWidget(TScriptInterface<class IBPI_Interaction_C> InputPin);
    bool ShouldDisplayDistantInteraction(TScriptInterface<class IBPI_Interaction_C> Interaction, bool UseHysteresis);
    void GetInteractionIndexToProcess(int32 LoopIndex, int32& NextIndex);
    void UpdateDistantInteractiveObjects();
    void UnregisterDistantInteractiveObject(TScriptInterface<class IBPI_Interaction_C> InteractiveObject);
    void RegisterDistantInteractiveObject(TScriptInterface<class IBPI_Interaction_C> InteractiveObject);
    bool IsInteraction3D(const TScriptInterface<class IBPI_Interaction_C>& Interaction);
    void OnInteracted_2D();
    void OnInteract();
    void UpdateActiveInteraction();
    void UpdateInteractionPrompt(TScriptInterface<class IBPI_Interaction_C> Interaction);
    bool CanPlayerProcessInteraction();
    void CanPlayerInteract(bool& Result);
    void SetInteractionsEnabled(bool Enabled, FSF_ReferenceCounterHandle& BlockerReferenceHandle, FString DebugName);
    void AreInteractionsEnabled(bool& Result);
    void SetUIReference(class UWBP_PromptContainer_C* PromptContainer);
    void DisableInteractionPrompt(TScriptInterface<class IBPI_Interaction_C> Interaction);
    void EnableInteractionPrompt(TScriptInterface<class IBPI_Interaction_C> Interaction, const FEnableInteractionPromptEvent& Event);
    void ComputeBestInteraction(TScriptInterface<class IBPI_Interaction_C>& BestInteraction);
    void UnregisterInteractiveObject(TScriptInterface<class IBPI_Interaction_C> InteractiveObject);
    void RegisterInteractiveObject2D(TScriptInterface<class IBPI_Interaction_C> InteractiveObject);
    void RegisterInteractiveObject(TScriptInterface<class IBPI_Interaction_C> InteractiveObject);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_InteractionSystem(int32 EntryPoint);
    void OnInteracted__DelegateSignature();
}; // Size: 0x1A9

#endif
