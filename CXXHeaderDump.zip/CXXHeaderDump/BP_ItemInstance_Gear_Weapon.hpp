#ifndef UE4SS_SDK_BP_ItemInstance_Gear_Weapon_HPP
#define UE4SS_SDK_BP_ItemInstance_Gear_Weapon_HPP

class UBP_ItemInstance_Gear_Weapon_C : public UBP_ItemInstance_Gear_C
{
    FS_WeaponInstanceData CurrentWeaponInstanceData;                                  // 0x0220 (size: 0x110)
    TMap<TEnumAsByte<ECharacterAttribute::Type>, TEnumAsByte<EAttributeScalingGrade::Type>> CurrentAttributeScaling; // 0x0330 (size: 0x50)
    FS_WeaponDefinition WeaponDefinition;                                             // 0x0380 (size: 0xF0)

    void GetUnlockedPassiveEffectsIDs(TArray<FName>& PassiveEffectIDs);
    void LoadItemDefinition();
    void GetWeaponDefinition(FS_WeaponDefinition& WeaponDefinition);
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> GetBaseStatsMultipliers();
    TMap<TEnumAsByte<ECharacterAttribute::Type>, TEnumAsByte<EAttributeScalingGrade::Type>> GetCurrentAttributeScaling();
    int32 ComputeUnlockedAttributeUpgradeCount();
    TArray<TEnumAsByte<EWeaponQuality::Type>> GetAttributeUpgradeRanks();
    class UDataTable* GetScalingDataTable();
    FS_WeaponInstanceHandle LEGACY_GetWeaponInstanceHandle();
    FS_WeaponInstanceData GetWeaponInstanceData();
    void RefreshCurrentGearStats();
}; // Size: 0x470

#endif
