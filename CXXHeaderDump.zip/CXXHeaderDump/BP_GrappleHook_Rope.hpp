#ifndef UE4SS_SDK_BP_GrappleHook_Rope_HPP
#define UE4SS_SDK_BP_GrappleHook_Rope_HPP

class ABP_GrappleHook_Rope_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UNiagaraComponent* FX_GrappleRope03;                                        // 0x0298 (size: 0x8)
    class UNiagaraComponent* FX_GrappleRope02;                                        // 0x02A0 (size: 0x8)
    class UNiagaraComponent* FX_GrappleRope01;                                        // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* RopeEnd;                                              // 0x02B0 (size: 0x8)
    class UCableComponent* RopeCable;                                                 // 0x02B8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02C0 (size: 0x8)
    FVector GrappleLocation;                                                          // 0x02C8 (size: 0x18)

    void ReceiveBeginPlay();
    void DestroyRopeFX();
    void ExecuteUbergraph_BP_GrappleHook_Rope(int32 EntryPoint);
}; // Size: 0x2E0

#endif
