#ifndef UE4SS_SDK_BP_ItemInstance_Base_HPP
#define UE4SS_SDK_BP_ItemInstance_Base_HPP

class UBP_ItemInstance_Base_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    FName ItemDefinitionID;                                                           // 0x0030 (size: 0x8)
    FS_jRPG_Item_StaticData ItemStaticData;                                           // 0x0038 (size: 0x130)
    int32 Quantity;                                                                   // 0x0168 (size: 0x4)
    double AcquiredPlayTime;                                                          // 0x0170 (size: 0x8)

    void BPI_ShouldShowNotification(bool& bShouldShow);
    void SetQuantity(int32 Quantity);
    double GetAcquiredPlayTime();
    void GetItemType(TEnumAsByte<E_jRPG_ItemType::Type>& Item_Type);
    void GetItemStaticData(FS_jRPG_Item_StaticData& ItemStaticData);
    void LoadItemDefinition();
    int32 GetChromaValue();
    void MergeItem(class UBP_ItemInstance_Base_C* OtherItemInstance);
    void GenerateItem(FS_jRPG_Item_StaticData& ItemStaticItem, FS_LootContext& LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItemInfo);
    void Initialize();
    int32 GetQuantity();
    FName GetItemDefinitionID();
    void BPI_OnMarkNotificationAsRead(class UUserWidget* MarkCaller);
    void ExecuteUbergraph_BP_ItemInstance_Base(int32 EntryPoint);
}; // Size: 0x178

#endif
