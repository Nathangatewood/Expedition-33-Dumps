#ifndef UE4SS_SDK_BP_GeneratedItemInfo_UpgradableItem_HPP
#define UE4SS_SDK_BP_GeneratedItemInfo_UpgradableItem_HPP

class UBP_GeneratedItemInfo_UpgradableItem_C : public UBP_GeneratedItemInfo_Item_C
{
    int32 PreviousLevel;                                                              // 0x0168 (size: 0x4)
    int32 CurrentLevel;                                                               // 0x016C (size: 0x4)
    int32 ConvertedChromaValue;                                                       // 0x0170 (size: 0x4)

    void GetConvertedChromaValue(int32& BonusChroma);
    void IsConvertedToChroma(bool& bIsConvertedToChroma);
    bool ShouldShowQuantity();
    void GetPreviousLevel(int32& CurrentLevel);
    void GetCurrentLevel(int32& CurrentLevel);
    void SetUpgradeInfo(int32 CurrentLevel, int32 PreviousLevel, class UBP_GeneratedItemInfo_UpgradableItem_C*& SelfRef);
    bool IsUpgrade();
}; // Size: 0x174

#endif
