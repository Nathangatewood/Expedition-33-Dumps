#ifndef UE4SS_SDK_BP_GameAction_ReplaceCharacter_HPP
#define UE4SS_SDK_BP_GameAction_ReplaceCharacter_HPP

class UBP_GameAction_ReplaceCharacter_C : public UBP_PDT_GameAction_C
{
    FS_ReplaceCharacterParameters ReplaceCharacterParameters;                         // 0x0030 (size: 0x9)

    TSubclassOf<class UGameActionInstance> GetInstanceClass();
    void ValidateGameAction(TArray<FText>& ErrorMessages, FString& PropertyPath, bool& ExploreAssetChildren);
}; // Size: 0x39

#endif
