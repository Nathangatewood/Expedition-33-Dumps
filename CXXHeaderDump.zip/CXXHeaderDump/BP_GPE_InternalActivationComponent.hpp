#ifndef UE4SS_SDK_BP_GPE_InternalActivationComponent_HPP
#define UE4SS_SDK_BP_GPE_InternalActivationComponent_HPP

class UBP_GPE_InternalActivationComponent_C : public UActorComponent
{
    FBP_GPE_InternalActivationComponent_COnActivationChanged OnActivationChanged;     // 0x00A0 (size: 0x10)
    void OnActivationChanged(bool Activated);
    TArray<UObject*> ActivatorList;                                                   // 0x00B0 (size: 0x10)
    TArray<UObject*> DeactivatorList;                                                 // 0x00C0 (size: 0x10)
    FBP_GPE_InternalActivationComponent_COnInstantActivationChanged OnInstantActivationChanged; // 0x00D0 (size: 0x10)
    void OnInstantActivationChanged(bool Activated);
    FBP_GPE_InternalActivationComponent_COnActivatorsChanged OnActivatorsChanged;     // 0x00E0 (size: 0x10)
    void OnActivatorsChanged(bool Instant);
    FBP_GPE_InternalActivationComponent_COnDeactivatorsChanged OnDeactivatorsChanged; // 0x00F0 (size: 0x10)
    void OnDeactivatorsChanged(bool Instant);
    FBP_GPE_InternalActivationComponent_COnBehaviorExecuted OnBehaviorExecuted;       // 0x0100 (size: 0x10)
    void OnBehaviorExecuted();

    void OnActivationChangedInternal(bool Instant);
    void GetDeactivatorList(TArray<UObject*>& Deactivators);
    void GetActivatorList(TArray<UObject*>& Activators);
    bool IsDeactivated();
    bool IsActivated();
    void RemoveCustomActivation(class AActor* Activator, bool Instant);
    void AddCustomActivation(class UObject* Activator, bool Instant, FString DebugName);
    void RemoveActivationInternal(class UObject* Activator, bool Instant, bool& HasActivationChanged);
    void AddActivationInternal(class UObject* Activator, bool Instant, FString DebugName, bool& HasActivationChanged);
    void SendImpulse(class AActor* Activator);
    void RemoveActivation(class UObject* Activator, bool Instant);
    void AddActivation(class UObject* Activator, bool Instant, FString DebugName);
    void OnBehaviorExecuted__DelegateSignature();
    void OnInstantActivationChanged__DelegateSignature(bool Activated);
    void OnDeactivatorsChanged__DelegateSignature(bool Instant);
    void OnActivatorsChanged__DelegateSignature(bool Instant);
    void OnActivationChanged__DelegateSignature(bool Activated);
}; // Size: 0x110

#endif
