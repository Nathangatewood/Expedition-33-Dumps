#ifndef UE4SS_SDK_BP_GradientGaugeChangeEvent_HPP
#define UE4SS_SDK_BP_GradientGaugeChangeEvent_HPP

class UBP_GradientGaugeChangeEvent_C : public UObject
{
    TEnumAsByte<EGradientChangeReason::Type> Reason;                                  // 0x0028 (size: 0x1)
    double ChangeAmount;                                                              // 0x0030 (size: 0x8)

    void ModifyAmount(double NewValue, FString Reason);
    void GetChangeAmount(double& ChangeAmount);
    TEnumAsByte<EGradientChangeReason::Type> GetReason();
}; // Size: 0x38

#endif
