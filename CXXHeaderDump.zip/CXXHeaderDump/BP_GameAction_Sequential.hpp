#ifndef UE4SS_SDK_BP_GameAction_Sequential_HPP
#define UE4SS_SDK_BP_GameAction_Sequential_HPP

class UBP_GameAction_Sequential_C : public UBP_PDT_GameAction_C
{
    TArray<FGameAction_Wrapper> GameActionsToExecute;                                 // 0x0030 (size: 0x10)

    TSubclassOf<class UGameActionInstance> GetInstanceClass();
    void ValidateGameAction(TArray<FText>& ErrorMessages, FString& PropertyPath, bool& ExploreAssetChildren);
}; // Size: 0x40

#endif
