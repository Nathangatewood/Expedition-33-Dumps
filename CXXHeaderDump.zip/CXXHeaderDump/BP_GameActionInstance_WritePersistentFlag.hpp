#ifndef UE4SS_SDK_BP_GameActionInstance_WritePersistentFlag_HPP
#define UE4SS_SDK_BP_GameActionInstance_WritePersistentFlag_HPP

class UBP_GameActionInstance_WritePersistentFlag_C : public UGameActionInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0040 (size: 0x8)

    FString GetDebugString();
    void ExecuteGameAction(const class APlayerController* Controller);
    void ExecuteUbergraph_BP_GameActionInstance_WritePersistentFlag(int32 EntryPoint);
}; // Size: 0x48

#endif
