#ifndef UE4SS_SDK_BP_InputContextComponent_HPP
#define UE4SS_SDK_BP_InputContextComponent_HPP

class UBP_InputContextComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<UInputMappingContext*> PushedInputMappings;                                // 0x00A8 (size: 0x10)
    class UInputMappingContext* DefaultMovementInputMapping;                          // 0x00B8 (size: 0x8)
    class UInputMappingContext* DefaultCameraInputMapping;                            // 0x00C0 (size: 0x8)
    class UInputMappingContext* DefaultUIInputMapping;                                // 0x00C8 (size: 0x8)
    class UInputMappingContext* DefaultDebugMapping;                                  // 0x00D0 (size: 0x8)
    FS_InputContextParameters CurrentParameters;                                      // 0x00D8 (size: 0x10)
    bool IgnoreMovementInputLockForUI;                                                // 0x00E8 (size: 0x1)

    void SetIgnoreMovementInputLockForUI(bool Ignore);
    void GetCurrentInputMappingNames(FString& MovementInputMapping, FString& CameraInputMapping);
    void RemovePushedInputContexts();
    void UpdateInputContexts(FS_InputContextParameters Parameters);
    void SetInputContext(FS_InputContextParameters Parameters);
    void ApplyDefaultInputContext();
    void RefreshCurrentInputContexts();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_InputContextComponent(int32 EntryPoint);
}; // Size: 0xE9

#endif
