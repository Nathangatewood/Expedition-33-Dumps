#ifndef UE4SS_SDK_BP_GPE_Rope_HPP
#define UE4SS_SDK_BP_GPE_Rope_HPP

class ABP_GPE_Rope_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USphereComponent* TopTriggerSphereBig;                                      // 0x0298 (size: 0x8)
    class USphereComponent* BottomTriggerSphereBig;                                   // 0x02A0 (size: 0x8)
    class UAudioComponent* AC_Loop;                                                   // 0x02A8 (size: 0x8)
    class UNiagaraComponent* FX_GPE_Rope;                                             // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* TopPlayerStartPosition;                               // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Bottom_PlayerStartPosition;                           // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* DragAndDropPoint;                                     // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* TopCapsulePoint;                                      // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* BottomCapsulePoint;                                   // 0x02D8 (size: 0x8)
    class UBP_GPE_SerializableComponent_C* BP_GPE_SerializableComponent;              // 0x02E0 (size: 0x8)
    class UCapsuleComponent* TopCapsule;                                              // 0x02E8 (size: 0x8)
    class UCapsuleComponent* BottomCapsule;                                           // 0x02F0 (size: 0x8)
    class UArrowComponent* TopArrow;                                                  // 0x02F8 (size: 0x8)
    class UArrowComponent* BottomArrow;                                               // 0x0300 (size: 0x8)
    class USceneComponent* TopInteractionPromptLocation;                              // 0x0308 (size: 0x8)
    class USphereComponent* TopTriggerSphere;                                         // 0x0310 (size: 0x8)
    class USceneComponent* BottomInteractionPromptLocation;                           // 0x0318 (size: 0x8)
    class USphereComponent* BottomTriggerSphere;                                      // 0x0320 (size: 0x8)
    class UBP_GPE_InternalActivationComponent_C* BP_GPE_InternalActivationComponent;  // 0x0328 (size: 0x8)
    class UStaticMeshComponent* PivotPointSphere;                                     // 0x0330 (size: 0x8)
    class USplineComponent* CharacterTrajectorySpline;                                // 0x0338 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0340 (size: 0x8)
    float SetFXHeight_0_to_1_18FEACBC46C3B0C41BA7B58769DE6C50;                        // 0x0348 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> SetFXHeight__Direction_18FEACBC46C3B0C41BA7B58769DE6C50; // 0x034C (size: 0x1)
    class UTimelineComponent* SetFXHeight;                                            // 0x0350 (size: 0x8)
    bool IsActivatedByDefault;                                                        // 0x0358 (size: 0x1)
    FS_Interaction_Parameters InteractionParameters;                                  // 0x0360 (size: 0x20)
    TEnumAsByte<E_RopeMovementDirection::Type> CurrentDirection;                      // 0x0380 (size: 0x1)
    double CurveRadius;                                                               // 0x0388 (size: 0x8)
    class UStaticMesh* SplineMesh;                                                    // 0x0390 (size: 0x8)
    double SectionLength;                                                             // 0x0398 (size: 0x8)
    TEnumAsByte<ESplineMeshAxis::Type> ForwardAxis;                                   // 0x03A0 (size: 0x1)
    FS_Interaction_Parameters ActivationParameters;                                   // 0x03A8 (size: 0x20)
    bool CanBeActivatedFromBottom;                                                    // 0x03C8 (size: 0x1)
    bool CanBeActivatedFromTop;                                                       // 0x03C9 (size: 0x1)
    bool InteractionRegistered;                                                       // 0x03CA (size: 0x1)
    class ABP_jRPG_Character_World_C* CurrentUser;                                    // 0x03D0 (size: 0x8)
    bool WasActivatedByBeginPlay;                                                     // 0x03D8 (size: 0x1)

    bool ShouldHideDistantInteraction();
    void CanInteractWithMount(bool& CanInteract);
    void GetInteractionLocation(FVector& Location);
    void GetInteractionFeedbackLocation(FVector& Location);
    void IsInteractionAvailable(bool& Available);
    void IsInteractionDone(bool& Done);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    void GPE_GetActivationComponent(class UBP_GPE_InternalActivationComponent_C*& ActivationComponent);
    void SpawnActivationExplosionFX(FVector Location);
    double GetRopeFXHeight();
    void UpdateArrowsColor();
    void UpdateSplineMeshesVisibility();
    void UpdateStateInstant();
    void UpdateState(bool Instant);
    void UnregisterInteractionIfNeeded();
    void RegisterInteractionIfPossible();
    void SetCurrentUser(class ABP_jRPG_Character_World_C* Character);
    void SetupFXParameters();
    void GetEndPositionAndTangent(int32 Index, FVector& position, FVector& Tangent);
    void GetStartPositionAndTangent(int32 Index, FVector& position, FVector& Tangent);
    void CreateSplineMesh();
    void ApplySplineRadius();
    void UpdateEntryPointsLocation();
    void UpdateSplinePointLocationAtIndex3();
    void UpdateSplinePointLocationAtIndex2();
    void UpdateSplinePointLocationAtIndex1();
    void UpdateSplinePointLocationAtIndex0();
    void UpdateSplinePointLocationAtIndex(int32 Index);
    void UserConstructionScript();
    void SetFXHeight__FinishedFunc();
    void SetFXHeight__UpdateFunc();
    void OnInteractionEnabled();
    void OnInteractionDisabled();
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void OnEnemyBattleStateLoaded(bool BattleState);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void BndEvt__BP_GPE_Rope_EntryTriggerSphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_GPE_Rope_EntryTriggerSphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void BndEvt__BP_GPE_Rope_TopTriggerSphere_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_GPE_Rope_TopTriggerSphere_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void BndEvt__BP_GPE_Rope_BP_GPE_InternalActivationComponent_K2Node_ComponentBoundEvent_6_OnActivationChanged__DelegateSignature(bool Activated);
    void BndEvt__BP_GPE_Rope_BP_GPE_InternalActivationComponent_K2Node_ComponentBoundEvent_7_OnInstantActivationChanged__DelegateSignature(bool Activated);
    void UpdateFXRope(bool Instant);
    void BndEvt__BP_GPE_Rope_BottomTriggerSphereBig_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_GPE_Rope_TopTriggerSphereBig_K2Node_ComponentBoundEvent_5_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ExecuteUbergraph_BP_GPE_Rope(int32 EntryPoint);
}; // Size: 0x3D9

#endif
