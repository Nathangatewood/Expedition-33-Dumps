#ifndef UE4SS_SDK_BP_jRPG_Character_Battle_Base_HPP
#define UE4SS_SDK_BP_jRPG_Character_Battle_Base_HPP

class ABP_jRPG_Character_Battle_Base_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class ULODSyncComponent* LODSyncCharacters;                                       // 0x0678 (size: 0x8)
    class ULODSyncComponent* LODSyncEnemies;                                          // 0x0680 (size: 0x8)
    class UBP_CharacterVisualAlterationsComponent_C* BPC_CharacterVisualAlterations;  // 0x0688 (size: 0x8)
    class UChildActorComponent* ChildActor_PreviewWeapon;                             // 0x0690 (size: 0x8)
    class USceneComponent* TargetingCameraFocusPoint;                                 // 0x0698 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_foot_right; // 0x06A0 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_foot_left; // 0x06A8 (size: 0x8)
    class UNiagaraComponent* Niagara_3D_UI_BackgroundGold;                            // 0x06B0 (size: 0x8)
    class UNiagaraComponent* Niagara_3D_UI_Background;                                // 0x06B8 (size: 0x8)
    class UBP_CharacterSkinComponent_C* BP_CharacterSkinComponent;                    // 0x06C0 (size: 0x8)
    class UBP_EventRoutingSystemComponent_C* BP_EventRoutingSystemComponent_AISkills; // 0x06C8 (size: 0x8)
    class USceneComponent* LookAtLocation_FreeAim;                                    // 0x06D0 (size: 0x8)
    class USceneComponent* LookAtLocation;                                            // 0x06D8 (size: 0x8)
    class UArrowComponent* DebugArrow_FreeAim_L;                                      // 0x06E0 (size: 0x8)
    class USceneComponent* FreeAimRotationComponent_L;                                // 0x06E8 (size: 0x8)
    class USceneComponent* FreeAimSpawnLocation_L;                                    // 0x06F0 (size: 0x8)
    class USceneComponent* AttackedLocation;                                          // 0x06F8 (size: 0x8)
    class UAudioComponent* AC_Idle;                                                   // 0x0700 (size: 0x8)
    class UAudioComponent* AC_Placeholder_02;                                         // 0x0708 (size: 0x8)
    class UAudioComponent* AC_Placeholder_01;                                         // 0x0710 (size: 0x8)
    class UAudioComponent* AC_Foley_02;                                               // 0x0718 (size: 0x8)
    class UAudioComponent* AC_Foley_01;                                               // 0x0720 (size: 0x8)
    class UAudioComponent* AC_Footstep_L;                                             // 0x0728 (size: 0x8)
    class UAudioComponent* AC_Footstep_R;                                             // 0x0730 (size: 0x8)
    class UAudioComponent* AC_Weapon_L_02;                                            // 0x0738 (size: 0x8)
    class UAudioComponent* AC_Weapon_R_02;                                            // 0x0740 (size: 0x8)
    class UAudioComponent* AC_Vocal_02;                                               // 0x0748 (size: 0x8)
    class UAudioComponent* AC_HitBy_02;                                               // 0x0750 (size: 0x8)
    class UAudioComponent* AC_SFX_02;                                                 // 0x0758 (size: 0x8)
    class UAudioComponent* AC_HitBy_01;                                               // 0x0760 (size: 0x8)
    class UAudioComponent* AC_SFX_01;                                                 // 0x0768 (size: 0x8)
    class UAudioComponent* AC_Vocal_01;                                               // 0x0770 (size: 0x8)
    class UAudioComponent* AC_Weapon_L_01;                                            // 0x0778 (size: 0x8)
    class UAudioComponent* AC_Weapon_R_01;                                            // 0x0780 (size: 0x8)
    class UBP_AudioCharacter_BattleManager_C* BP_AudioCharacter_BattleManager;        // 0x0788 (size: 0x8)
    class UArrowComponent* FrontLocation;                                             // 0x0790 (size: 0x8)
    class USceneComponent* DamagePosition;                                            // 0x0798 (size: 0x8)
    class USceneComponent* Attachment_FootR;                                          // 0x07A0 (size: 0x8)
    class USceneComponent* Attachment_FootL;                                          // 0x07A8 (size: 0x8)
    class USceneComponent* Attachment_Spine03;                                        // 0x07B0 (size: 0x8)
    class USceneComponent* Attachment_Spine01;                                        // 0x07B8 (size: 0x8)
    class USceneComponent* Attachment_Root;                                           // 0x07C0 (size: 0x8)
    class USceneComponent* Attachment_Head;                                           // 0x07C8 (size: 0x8)
    class USceneComponent* Attachment_Hand_R;                                         // 0x07D0 (size: 0x8)
    class USceneComponent* Attachment_Hand_L;                                         // 0x07D8 (size: 0x8)
    class USceneComponent* Attachment_AboveBody;                                      // 0x07E0 (size: 0x8)
    class USceneComponent* FrontVFXSpawn;                                             // 0x07E8 (size: 0x8)
    class USceneComponent* FreeAimRotationComponent_R;                                // 0x07F0 (size: 0x8)
    class UArrowComponent* DebugArrow_FreeAim_R;                                      // 0x07F8 (size: 0x8)
    class USceneComponent* FreeAimSpawnLocation_R;                                    // 0x0800 (size: 0x8)
    class USceneComponent* HealthBar_CloseLocation;                                   // 0x0808 (size: 0x8)
    class UWidgetComponent* HealthBar;                                                // 0x0810 (size: 0x8)
    class USceneComponent* Head_R;                                                    // 0x0818 (size: 0x8)
    class USceneComponent* Head_L;                                                    // 0x0820 (size: 0x8)
    class USceneComponent* thigh_r;                                                   // 0x0828 (size: 0x8)
    class USceneComponent* thigh_l;                                                   // 0x0830 (size: 0x8)
    class USceneComponent* lowerarm_r;                                                // 0x0838 (size: 0x8)
    class USceneComponent* lowerarm_l;                                                // 0x0840 (size: 0x8)
    class USceneComponent* upperarm_r;                                                // 0x0848 (size: 0x8)
    class USceneComponent* upperarm_l;                                                // 0x0850 (size: 0x8)
    class USceneComponent* Side_R;                                                    // 0x0858 (size: 0x8)
    class USceneComponent* Side_L;                                                    // 0x0860 (size: 0x8)
    class UTextRenderComponent* DebugText_CharacterInfos;                             // 0x0868 (size: 0x8)
    class USceneComponent* CameraTargetingTarget;                                     // 0x0870 (size: 0x8)
    class UChildActorComponent* ChildActor_TargetingCamera;                           // 0x0878 (size: 0x8)
    class UCineCameraComponent* TargetingCamera;                                      // 0x0880 (size: 0x8)
    class UArrowComponent* Arrow1;                                                    // 0x0888 (size: 0x8)
    class UBP_FreeAimShooterBattleComponent_C* BP_FreeAimShooterBattleComponent;      // 0x0890 (size: 0x8)
    class UCapsuleComponent* TargetingCapsule;                                        // 0x0898 (size: 0x8)
    class UTextRenderComponent* DebugText_PreviousPosition;                           // 0x08A0 (size: 0x8)
    class UCameraComponent* Camera_Shoulder;                                          // 0x08A8 (size: 0x8)
    class USpringArmComponent* SpringArm_Shoulder;                                    // 0x08B0 (size: 0x8)
    class UStaticMeshComponent* Sphere_Head;                                          // 0x08B8 (size: 0x8)
    class UStaticMeshComponent* Sphere_Hand_R;                                        // 0x08C0 (size: 0x8)
    class UStaticMeshComponent* Sphere_Hand_L;                                        // 0x08C8 (size: 0x8)
    class USceneComponent* Attachments;                                               // 0x08D0 (size: 0x8)
    class UWidgetComponent* TargetWidget;                                             // 0x08D8 (size: 0x8)
    class UAC_jRPG_CombatMovement_C* AC_jRPG_CombatMovement;                          // 0x08E0 (size: 0x8)
    class UBillboardComponent* TargetPointer;                                         // 0x08E8 (size: 0x8)
    class UAC_jRPG_CharacterBattleStats_C* AC_jRPG_CharacterStats;                    // 0x08F0 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x08F8 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0900 (size: 0x8)
    float LateralOffsetUIFX_0to1_5196A039410C8DC3D94C10B3DAF53447;                    // 0x0908 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> LateralOffsetUIFX__Direction_5196A039410C8DC3D94C10B3DAF53447; // 0x090C (size: 0x1)
    class UTimelineComponent* LateralOffsetUIFX;                                      // 0x0910 (size: 0x8)
    float ChangeSizeTimeline_0to1_FEFB868E4BAD591F95B10BA3ADE10F40;                   // 0x0918 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> ChangeSizeTimeline__Direction_FEFB868E4BAD591F95B10BA3ADE10F40; // 0x091C (size: 0x1)
    class UTimelineComponent* ChangeSizeTimeline;                                     // 0x0920 (size: 0x8)
    float Timeline_FreeaimRecoil_RecoilTimeline_1AFEEEE64C939F0FE67404B5B1F4ABE1;     // 0x0928 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_FreeaimRecoil__Direction_1AFEEEE64C939F0FE67404B5B1F4ABE1; // 0x092C (size: 0x1)
    class UTimelineComponent* Timeline_FreeaimRecoil;                                 // 0x0930 (size: 0x8)
    float GradientCounterRadius_0to1_AB8F890F4FB1CBA3A26D6084F926BCCC;                // 0x0938 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> GradientCounterRadius__Direction_AB8F890F4FB1CBA3A26D6084F926BCCC; // 0x093C (size: 0x1)
    class UTimelineComponent* GradientCounterRadius;                                  // 0x0940 (size: 0x8)
    float Timeline_Targeting_NewTrack_0_EB09F8A344E5CF553AEF4B84CD1DA71B;             // 0x0948 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_Targeting__Direction_EB09F8A344E5CF553AEF4B84CD1DA71B; // 0x094C (size: 0x1)
    class UTimelineComponent* Timeline_Targeting;                                     // 0x0950 (size: 0x8)
    float Timeline_GradientAttackPostProcess_0to1_1CFBE67A4635212B1C24BF9F8B70EEF3;   // 0x0958 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_GradientAttackPostProcess__Direction_1CFBE67A4635212B1C24BF9F8B70EEF3; // 0x095C (size: 0x1)
    class UTimelineComponent* Timeline_GradientAttackPostProcess;                     // 0x0960 (size: 0x8)
    float AppearDisappearTimeline_0To1_64AB1CEA4A58B3518DA3F59F51F1CBD1;              // 0x0968 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> AppearDisappearTimeline__Direction_64AB1CEA4A58B3518DA3F59F51F1CBD1; // 0x096C (size: 0x1)
    class UTimelineComponent* AppearDisappearTimeline;                                // 0x0970 (size: 0x8)
    bool ControlledByBattleAI?;                                                       // 0x0978 (size: 0x1)
    class UAC_jRPG_BattleManager_C* BattleManagerReference;                           // 0x0980 (size: 0x8)
    bool Enemy?;                                                                      // 0x0988 (size: 0x1)
    class UAC_jRPG_TargetingManager_C* TargetingManagerReference;                     // 0x0990 (size: 0x8)
    TEnumAsByte<E_jRPG_FormationType::Type> FormationType;                            // 0x0998 (size: 0x1)
    bool Dead?;                                                                       // 0x0999 (size: 0x1)
    TEnumAsByte<E_jRPG_CombatStyle::Type> CombatStyle_DEPRECATED;                     // 0x099A (size: 0x1)
    class UBP_jRPG_GI_Custom_C* GameInstanceReference;                                // 0x09A0 (size: 0x8)
    class USoundBase* SoundToPlayWhenTargetHovered;                                   // 0x09A8 (size: 0x8)
    class USoundBase* SoundToPlayWhenTargetDecided;                                   // 0x09B0 (size: 0x8)
    FVector OriginalLocation;                                                         // 0x09B8 (size: 0x18)
    FRotator OriginalRotation;                                                        // 0x09D0 (size: 0x18)
    class ABP_jRPG_Character_Battle_Base_C* TargetedCharacter;                        // 0x09E8 (size: 0x8)
    FName CameraName;                                                                 // 0x09F0 (size: 0x8)
    TArray<UAnimMontage*> AnimDodge;                                                  // 0x09F8 (size: 0x10)
    class UAnimMontage* AnimJump;                                                     // 0x0A08 (size: 0x8)
    class UAnimMontage* AnimJumpCounter;                                              // 0x0A10 (size: 0x8)
    class UAnimMontage* AnimParry;                                                    // 0x0A18 (size: 0x8)
    TMap<TEnumAsByte<E_jRPG_CharacterAttachmentSlot::Type>, FName> SocketNames;       // 0x0A20 (size: 0x50)
    TMap<TEnumAsByte<E_jRPG_CharacterAttachmentSlot::Type>, USceneComponent*> AttachmentComponents; // 0x0A70 (size: 0x50)
    class UParticleSystemComponent* SpawnedParticleSystem;                            // 0x0AC0 (size: 0x8)
    FVector SingleTargetLocation;                                                     // 0x0AC8 (size: 0x18)
    TArray<FName> BattleActionQueue;                                                  // 0x0AE0 (size: 0x10)
    class UAnimMontage* AnimGradientParry;                                            // 0x0AF0 (size: 0x8)
    double DefensiveMoveLockEndTime;                                                  // 0x0AF8 (size: 0x8)
    FTimerHandle DefensiveMoveLockTimer;                                              // 0x0B00 (size: 0x8)
    double DefensiveMoveImmunityEndTime;                                              // 0x0B08 (size: 0x8)
    bool IsParrying;                                                                  // 0x0B10 (size: 0x1)
    bool IsDodging;                                                                   // 0x0B11 (size: 0x1)
    bool IsJumping;                                                                   // 0x0B12 (size: 0x1)
    bool IsStunLocked;                                                                // 0x0B13 (size: 0x1)
    double DodgeLockDuration;                                                         // 0x0B18 (size: 0x8)
    double DodgeSuccessLockDuration;                                                  // 0x0B20 (size: 0x8)
    double DodgeImmuneDuration;                                                       // 0x0B28 (size: 0x8)
    double ParryLockDuration;                                                         // 0x0B30 (size: 0x8)
    double ParryImmuneDuration;                                                       // 0x0B38 (size: 0x8)
    FName CurrentSkillNextComboAction;                                                // 0x0B40 (size: 0x8)
    bool IsLastSkillComboSuccessful;                                                  // 0x0B48 (size: 0x1)
    QTEKeyframeType QTE_Keyframes;                                                    // 0x0B49 (size: 0x1)
    BattleSequenceKeyframeType BattleKeyframes;                                       // 0x0B4A (size: 0x1)
    BattleSequenceKeyframeType BattleKeyframes_Track2;                                // 0x0B4B (size: 0x1)
    BattleSequenceKeyframeType BattleKeyframes_Track3;                                // 0x0B4C (size: 0x1)
    BattleSequenceCameraType BattleCameraKeyframes;                                   // 0x0B4D (size: 0x1)
    BattleSequenceKeyframeType BattleKeyframes_Diegetic;                              // 0x0B4E (size: 0x1)
    TArray<TEnumAsByte<EBattleTurnState::Type>> BattleStateStack;                     // 0x0B50 (size: 0x10)
    TMap<TEnumAsByte<EBattleTurnState::Type>, UAnimSequenceBase*> CurrentBattlePostureAnimations; // 0x0B60 (size: 0x50)
    bool UseFullComboSequence;                                                        // 0x0BB0 (size: 0x1)
    class ABP_EpicBattleSequenceActor_C* CurrentComboSequence;                        // 0x0BB8 (size: 0x8)
    double NextBattleSequenceActionTime;                                              // 0x0BC0 (size: 0x8)
    int32 DEBUG_CurrentComboAutoSuccess;                                              // 0x0BC8 (size: 0x4)
    TEnumAsByte<EBattleActionEvent::Type> LastBattleSequenceAction;                   // 0x0BCC (size: 0x1)
    TArray<bool> ComboSuccessHistory;                                                 // 0x0BD0 (size: 0x10)
    TArray<bool> ComboPerfectHistory;                                                 // 0x0BE0 (size: 0x10)
    bool IsComboWaitingForActionEffect;                                               // 0x0BF0 (size: 0x1)
    bool HasAimingSkill;                                                              // 0x0BF1 (size: 0x1)
    bool CHECK_wasBaseBeginPlayCalled;                                                // 0x0BF2 (size: 0x1)
    double Anim_DefaultSlotAlpha;                                                     // 0x0BF8 (size: 0x8)
    FFBattleTurnSequence_CharacterData BattleSequenceData;                            // 0x0C00 (size: 0x20)
    FFBattleTurnSequence_CharacterData BattleSequenceData_Static;                     // 0x0C20 (size: 0x20)
    bool IsBattleStateDirty;                                                          // 0x0C40 (size: 0x1)
    TMap<int32, UBP_BattleSequenceTimeline_C*> BattleSequenceTimelines;               // 0x0C48 (size: 0x50)
    int32 CurrentActionEffectNumber;                                                  // 0x0C98 (size: 0x4)
    bool IsPerformingCounterAttack;                                                   // 0x0C9C (size: 0x1)
    bool IsCurrentCounterAttackGradient;                                              // 0x0C9D (size: 0x1)
    class ABP_jRPG_Character_Battle_Base_C* CurrentCounterAttackTarget;               // 0x0CA0 (size: 0x8)
    class ABP_jRPG_Character_Battle_Base_C* CurrentCounterAttackSource;               // 0x0CA8 (size: 0x8)
    bool CanBeCountered;                                                              // 0x0CB0 (size: 0x1)
    bool IsBeingCountered;                                                            // 0x0CB1 (size: 0x1)
    bool CounterAttackRequiresPerfect;                                                // 0x0CB2 (size: 0x1)
    bool ShouldPlayHitAnimationOnNextDamage?;                                         // 0x0CB3 (size: 0x1)
    bool CHECK_ParentCall;                                                            // 0x0CB4 (size: 0x1)
    bool CHECK_PublicCall;                                                            // 0x0CB5 (size: 0x1)
    FString CHECK_CallContext;                                                        // 0x0CB8 (size: 0x10)
    FRotator OriginalSpringArmRelativeRotation;                                       // 0x0CC8 (size: 0x18)
    FRotator OriginalActorWorldRotation;                                              // 0x0CE0 (size: 0x18)
    bool DEBUG_IgnoreDamages;                                                         // 0x0CF8 (size: 0x1)
    class UWBP_HUD_AimTarget_C* Crosshair;                                            // 0x0D00 (size: 0x8)
    bool RandomIntroPlayRate?;                                                        // 0x0D08 (size: 0x1)
    FBP_jRPG_Character_Battle_Base_COnFreeAimCancelInput OnFreeAimCancelInput;        // 0x0D10 (size: 0x10)
    void OnFreeAimCancelInput();
    int32 BattleSpotIndex;                                                            // 0x0D20 (size: 0x4)
    FSoundEventDataTableRowHandle SoundEvent_FreeAimStart;                            // 0x0D28 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_FreeAimCancel;                           // 0x0D38 (size: 0x10)
    FVector OriginalWidgetRelativeLocation;                                           // 0x0D48 (size: 0x18)
    double StunLockDuration;                                                          // 0x0D60 (size: 0x8)
    double HealthBarScale_Close;                                                      // 0x0D68 (size: 0x8)
    double HealthBarScale_Far;                                                        // 0x0D70 (size: 0x8)
    FBP_jRPG_Character_Battle_Base_COnResetBattleActionValidation OnResetBattleActionValidation; // 0x0D78 (size: 0x10)
    void OnResetBattleActionValidation();
    FBP_jRPG_Character_Battle_Base_COnSelfTurnStart OnSelfTurnStart;                  // 0x0D88 (size: 0x10)
    void OnSelfTurnStart();
    FBP_jRPG_Character_Battle_Base_COnSelfTurnEnd OnSelfTurnEnd;                      // 0x0D98 (size: 0x10)
    void OnSelfTurnEnd();
    FBP_jRPG_Character_Battle_Base_COnDefenseStateChange OnDefenseStateChange;        // 0x0DA8 (size: 0x10)
    void OnDefenseStateChange(bool IsActive);
    FBP_jRPG_Character_Battle_Base_COnParryStart OnParryStart;                        // 0x0DB8 (size: 0x10)
    void OnParryStart();
    FBP_jRPG_Character_Battle_Base_COnGradientParryStart OnGradientParryStart;        // 0x0DC8 (size: 0x10)
    void OnGradientParryStart();
    FBP_jRPG_Character_Battle_Base_COnDefensiveMoveEnd OnDefensiveMoveEnd;            // 0x0DD8 (size: 0x10)
    void OnDefensiveMoveEnd();
    FBP_jRPG_Character_Battle_Base_COnDodgeStart OnDodgeStart;                        // 0x0DE8 (size: 0x10)
    void OnDodgeStart();
    FBP_jRPG_Character_Battle_Base_COnDefenseLockEnd OnDefenseLockEnd;                // 0x0DF8 (size: 0x10)
    void OnDefenseLockEnd();
    FBP_jRPG_Character_Battle_Base_COnDefenseLockStart OnDefenseLockStart;            // 0x0E08 (size: 0x10)
    void OnDefenseLockStart();
    bool DEBUG_CVar_ShowBattleDebug;                                                  // 0x0E18 (size: 0x1)
    bool DEBUG_CVar_ShowFreeAimBodyParts;                                             // 0x0E19 (size: 0x1)
    TMap<TEnumAsByte<EAttackType::Type>, TEnumAsByte<EElementalAffinity::Type>> ElementalAffinitiesCurrent; // 0x0E20 (size: 0x50)
    TMap<TEnumAsByte<EAttackType::Type>, FFElementalAffinityList> ElementalAffinitiesOverrides; // 0x0E70 (size: 0x50)
    TMap<TEnumAsByte<EAttackType::Type>, TEnumAsByte<EElementalAffinity::Type>> ElementalAffinitiesBase; // 0x0EC0 (size: 0x50)
    TMap<TEnumAsByte<EAttackType::Type>, TEnumAsByte<EElementalAffinity::Type>> ElementalAffinitiesInitial; // 0x0F10 (size: 0x50)
    int32 BaseAttackNumber;                                                           // 0x0F60 (size: 0x4)
    int32 DodgeAnimIndex;                                                             // 0x0F64 (size: 0x4)
    double FreeAimLookSpeed;                                                          // 0x0F68 (size: 0x8)
    bool CanBeTargeted;                                                               // 0x0F70 (size: 0x1)
    BattleSequenceKeyframeType BattleKeyframes_Diegetic2;                             // 0x0F71 (size: 0x1)
    BattleSequenceKeyframeType BattleKeyframes_Diegetic3;                             // 0x0F72 (size: 0x1)
    FFCharacterBattleAudioProfile CharacterAudioProfile;                              // 0x0F78 (size: 0xD0)
    TEnumAsByte<E_EnemyIdleState::Type> CurrentIdleState;                             // 0x1048 (size: 0x1)
    class UABP_Battle_Global_C* As ABP Battle Global;                                 // 0x1050 (size: 0x8)
    TEnumAsByte<E_HitReact_Anim_Type::Type> E_HitReactAnimType;                       // 0x1058 (size: 0x1)
    double MoveToControlForSequence;                                                  // 0x1060 (size: 0x8)
    FVector MoveTo_Start;                                                             // 0x1068 (size: 0x18)
    FVector MoveTo_Target;                                                            // 0x1080 (size: 0x18)
    FVector MoveTo_Offset;                                                            // 0x1098 (size: 0x18)
    bool MoveTo_IsActive;                                                             // 0x10B0 (size: 0x1)
    class ABP_Battle_SkillScript_C* CurrentBattleSkill;                               // 0x10B8 (size: 0x8)
    class UBP_DataAsset_CharacterBattleAudioProfile_C* DataAsset_BattleAudioProfile;  // 0x10C0 (size: 0x8)
    class UWBP_Battle_Boss_OverheadState_C* BossUI;                                   // 0x10C8 (size: 0x8)
    class USkeletalMeshComponent* Weapon Mesh L;                                      // 0x10D0 (size: 0x8)
    class USkeletalMeshComponent* Weapon Mesh R;                                      // 0x10D8 (size: 0x8)
    FDataTableRowHandle SD_Hit_Critical;                                              // 0x10E0 (size: 0x10)
    FDataTableRowHandle SD_HitAffinity_Resistant;                                     // 0x10F0 (size: 0x10)
    FDataTableRowHandle SD_HitAffinity_Weak;                                          // 0x1100 (size: 0x10)
    FDataTableRowHandle SD_HitIntensity_Light;                                        // 0x1110 (size: 0x10)
    FDataTableRowHandle SD_HitIntensity_Medium;                                       // 0x1120 (size: 0x10)
    FDataTableRowHandle SD_HitIntensity_Strong;                                       // 0x1130 (size: 0x10)
    TArray<UBP_FreeAimTargetPart_C*> FreeAimTargetParts;                              // 0x1140 (size: 0x10)
    double GradientParryLockDuration;                                                 // 0x1150 (size: 0x8)
    double GradientParryImmuneDuration;                                               // 0x1158 (size: 0x8)
    bool IsGradientParrying;                                                          // 0x1160 (size: 0x1)
    FBP_jRPG_Character_Battle_Base_COnMoveToCompleted OnMoveToCompleted;              // 0x1168 (size: 0x10)
    void OnMoveToCompleted(class ABP_jRPG_Character_Battle_Base_C* CharacterBase);
    class UAnimMontage* AM_DashBack;                                                  // 0x1178 (size: 0x8)
    TEnumAsByte<EAttackType::Type> LastFeedbackedPermeateElement;                     // 0x1180 (size: 0x1)
    bool IsPlayerControlledCharacter;                                                 // 0x1181 (size: 0x1)
    class ABP_WeaponSkin_C* Weapons;                                                  // 0x1188 (size: 0x8)
    TSubclassOf<class AActor> BaseWeaponSkinIfNoWeaponEquipped;                       // 0x1190 (size: 0x8)
    FName Weapon_R_SocketName;                                                        // 0x1198 (size: 0x8)
    FName Weapon_L_Socket Name;                                                       // 0x11A0 (size: 0x8)
    TSubclassOf<class ABP_WeaponSkin_C> WeaponClass;                                  // 0x11A8 (size: 0x8)
    class UAnimMontage* AM_DashIn;                                                    // 0x11B0 (size: 0x8)
    TArray<FFEnemyDataRow> PossibleMinions;                                           // 0x11B8 (size: 0x10)
    bool CanDoJumpCounterAttack;                                                      // 0x11C8 (size: 0x1)
    class UAnimMontage* ResurectAnimation;                                            // 0x11D0 (size: 0x8)
    TSubclassOf<class ABP_FreeAimProjectile_Base_C> FreeAimProjectileClass;           // 0x11D8 (size: 0x8)
    class UAnimMontage* FreeAimShootAnim;                                             // 0x11E0 (size: 0x8)
    double AOEDamageMultiplier;                                                       // 0x11E8 (size: 0x8)
    double JumpLockDuration;                                                          // 0x11F0 (size: 0x8)
    double JumpWarmUpDuration;                                                        // 0x11F8 (size: 0x8)
    double JumpImmuneDuration;                                                        // 0x1200 (size: 0x8)
    double DefensiveMoveImmunityStartTime;                                            // 0x1208 (size: 0x8)
    FBP_jRPG_Character_Battle_Base_COnJumpStart OnJumpStart;                          // 0x1210 (size: 0x10)
    void OnJumpStart(class ABP_jRPG_Character_Battle_Base_C* Character);
    double JumpCounterAttackWindowDuration;                                           // 0x1220 (size: 0x8)
    double JumpCounterAttackWindowStartDelay;                                         // 0x1228 (size: 0x8)
    double JumpCounterAttackWindowSlomo;                                              // 0x1230 (size: 0x8)
    class ABP_jRPG_Character_Battle_Base_C* JumpAttacker;                             // 0x1238 (size: 0x8)
    FSF_ReferenceCounterHandle LastStandReference;                                    // 0x1240 (size: 0x20)
    bool DisableLastStandOnCounterAttackDamages;                                      // 0x1260 (size: 0x1)
    bool DEBUG_DrawDebugMoveToOnNextFrame;                                            // 0x1261 (size: 0x1)
    bool InitFreeAimWithRightHand;                                                    // 0x1262 (size: 0x1)
    FName InitFreeAimWithBoneOverride;                                                // 0x1264 (size: 0x8)
    TEnumAsByte<EPermeateIntensity::Type> LastFeedbackedPermeateIntensity;            // 0x126C (size: 0x1)
    class UAnimMontage* FleeIntroAnimation;                                           // 0x1270 (size: 0x8)
    TArray<ULevelSequence*> Attackx1Sequence;                                         // 0x1278 (size: 0x10)
    class ULevelSequence* Attackx2Sequence;                                           // 0x1288 (size: 0x8)
    class ULevelSequence* Attackx3Sequence;                                           // 0x1290 (size: 0x8)
    class ULevelSequence* Attackx4Sequence;                                           // 0x1298 (size: 0x8)
    bool BaseAttack_ShouldDashBefore;                                                 // 0x12A0 (size: 0x1)
    double BaseAttack_DistanceToEnemyAfterDash;                                       // 0x12A8 (size: 0x8)
    class UAnimMontage* FleeActivationAnimation;                                      // 0x12B0 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> TargetsAcquisitionOverride;             // 0x12B8 (size: 0x10)
    FBP_jRPG_Character_Battle_Base_COnPuppetTurnEnded OnPuppetTurnEnded;              // 0x12C8 (size: 0x10)
    void OnPuppetTurnEnded();
    class ULevelSequence* GradientCounterSequence;                                    // 0x12D8 (size: 0x8)
    TArray<ULevelSequence*> CounterSequence;                                          // 0x12E0 (size: 0x10)
    class UNiagaraSystem* FX_ParrySuccess;                                            // 0x12F0 (size: 0x8)
    class UAnimMontage* AM_ItemUse;                                                   // 0x12F8 (size: 0x8)
    bool CurrentBattleSequenceActionEffectCount;                                      // 0x1300 (size: 0x1)
    int32 CurrentSkillActionEffectCount;                                              // 0x1304 (size: 0x4)
    TArray<ABP_jRPG_Character_Battle_Base_C*> AcquiredHeroTargets;                    // 0x1308 (size: 0x10)
    FVector PPGradientCenter;                                                         // 0x1318 (size: 0x18)
    class UWBP_HUD_DamageFeedback_C* CurrentDamagePopupWidget;                        // 0x1330 (size: 0x8)
    FBP_jRPG_Character_Battle_Base_COnBattleSequenceActionEffect OnBattleSequenceActionEffect; // 0x1338 (size: 0x10)
    void OnBattleSequenceActionEffect(int32 ActionEffectIndex);
    double LookX;                                                                     // 0x1348 (size: 0x8)
    double LookY;                                                                     // 0x1350 (size: 0x8)
    float CurrentRecoilValue;                                                         // 0x1358 (size: 0x4)
    bool IsTurnActive;                                                                // 0x135C (size: 0x1)
    FFRoutedEventHandle DEBUG_OverrideSkillRouting;                                   // 0x1360 (size: 0x20)
    TArray<ULevelSequence*> RangeCounterSequence;                                     // 0x1380 (size: 0x10)
    TEnumAsByte<ECounterType::Type> CurrentCounterType;                               // 0x1390 (size: 0x1)
    TArray<UAnimMontage*> AnimAOECounter;                                             // 0x1398 (size: 0x10)
    class UAnimMontage* AM_InterceptDashTo;                                           // 0x13A8 (size: 0x8)
    class UAnimMontage* AM_InterceptDashBack;                                         // 0x13B0 (size: 0x8)
    FBP_jRPG_Character_Battle_Base_COnJumpCounter OnJumpCounter;                      // 0x13B8 (size: 0x10)
    void OnJumpCounter();
    double AimingBreathingMultiplier;                                                 // 0x13C8 (size: 0x8)
    class UAnimMontage* IdleToFreeAim_Transition_Montage;                             // 0x13D0 (size: 0x8)
    FDataTableRowHandle SD_StanceBreak;                                               // 0x13D8 (size: 0x10)
    FDataTableRowHandle SD_JumpStart;                                                 // 0x13E8 (size: 0x10)
    FDataTableRowHandle SD_JumpSuccess;                                               // 0x13F8 (size: 0x10)
    int32 NextDamagePopupPositionIndex;                                               // 0x1408 (size: 0x4)
    FMargin DamageNumberPositionOffset;                                               // 0x140C (size: 0x10)
    bool NiagaraTurnSystemEnabled;                                                    // 0x141C (size: 0x1)
    class UObject* DefaultHitSound;                                                   // 0x1420 (size: 0x8)
    TArray<TSoftObjectPtr<class AActor>> InstigatedActors;                            // 0x1428 (size: 0x10)
    TArray<FString> InstigatedActorNames;                                             // 0x1438 (size: 0x10)
    TArray<TSoftObjectPtr<class AActor>> RegisteredInstigatedActors;                  // 0x1448 (size: 0x10)
    TArray<TSoftObjectPtr<class AActor>> HiddenExternalActors;                        // 0x1458 (size: 0x10)
    FName BoneToAttachGradientFX;                                                     // 0x1468 (size: 0x8)
    class ULODSyncComponent* LODSyncToChange;                                         // 0x1470 (size: 0x8)
    class ULODSyncComponent* LODSync Characters;                                      // 0x1478 (size: 0x8)
    int32 LODBias;                                                                    // 0x1480 (size: 0x4)
    double MinimumDodgeLockDiff;                                                      // 0x1488 (size: 0x8)
    TSoftObjectPtr<class ULevelSequence> FinisherSequence;                            // 0x1490 (size: 0x28)
    FSF_ReferenceCounterHandle FinisherDeathPreventHandle;                            // 0x14B8 (size: 0x20)
    bool ShouldPlayFinisherWhenTurnEnd;                                               // 0x14D8 (size: 0x1)
    bool HasPlayedFinisher;                                                           // 0x14D9 (size: 0x1)
    class ABP_EpicBattleSequenceActor_C* ActiveCounterSequence;                       // 0x14E0 (size: 0x8)
    FBP_jRPG_Character_Battle_Base_COnCounterAttacked OnCounterAttacked;              // 0x14E8 (size: 0x10)
    void OnCounterAttacked(class ABP_jRPG_Character_Battle_Base_C* CounteredCharacter);
    bool CurrentOverpoweredFeedbackState;                                             // 0x14F8 (size: 0x1)
    FDataTableRowHandle SD_JumpCounter;                                               // 0x1500 (size: 0x10)
    FBP_jRPG_Character_Battle_Base_COnStartedAllowQTE OnStartedAllowQTE;              // 0x1510 (size: 0x10)
    void OnStartedAllowQTE(class ABP_jRPG_Character_Battle_Base_C* CharacterActor);
    FName BoneNameToAttachGradientFX;                                                 // 0x1520 (size: 0x8)
    FBP_jRPG_Character_Battle_Base_COnReadyForBattle OnReadyForBattle;                // 0x1528 (size: 0x10)
    void OnReadyForBattle();
    TArray<ABP_jRPG_Character_Battle_Base_C*> LifeLinkedCharacters;                   // 0x1538 (size: 0x10)
    bool bIsLifeLinkMaster;                                                           // 0x1548 (size: 0x1)
    TArray<AActor*> ExternalFreeAimTargetActors;                                      // 0x1550 (size: 0x10)
    bool AdditionalTurnEndEventRequested;                                             // 0x1560 (size: 0x1)
    bool IsCurrentlyPlayingFinisher;                                                  // 0x1561 (size: 0x1)

    bool OnInstigatedActorSpawned(class AActor* SpawnedActor);
    void BPI_GetDependencies(TArray<TSoftClassPtr<UObject>>& Classes, TArray<TSoftObjectPtr<class UObject>>& Assets, TArray<TScriptInterface<class IBPI_LoadingDependenciesSource_C>>& ExternalDependencies);
    void GetBattleAudioProfile(class UBP_DataAsset_CharacterBattleAudioProfile_C*& AudioProfile);
    void GetBattleAudioContainerComponents(class USceneComponent*& SFX, class USceneComponent*& weapon_l, class USceneComponent*& weapon_r, class USceneComponent*& Foley, class USceneComponent*& Vocal, class USceneComponent*& foot_l, class USceneComponent*& Foot_R, class USceneComponent*& HitBy);
    void GetBattleAudioCharacterManager(class UBP_AudioCharacter_BattleManager_C*& AudioCharacterBattleManager);
    void GetTiedObject(class UObject*& Object);
    void GetCurrentBattlePosture(TEnumAsByte<EBattleTurnState::Type>& CurrentBattlePosture);
    void GetBattlePostureAnimations(TMap<TEnumAsByte<EBattleTurnState::Type>, UAnimSequenceBase*>& BattlePostureAnimations);
    void GetIsDead(bool& Dead);
    void GetIsDefending(bool& Defending);
    void GetCharacterCombatStyle(TEnumAsByte<E_jRPG_CombatStyle::Type>& CombatStyle);
    bool IsPlayingFinisher();
    void UpdateWeaponsVisibility();
    void RunDataCheck();
    void SetActorsHiddenInGame(bool HiddenInGame, TArray<TSoftObjectPtr<class AActor>>& Actors, TArray<TSoftObjectPtr<class AActor>>& UpdatedActors);
    double ClampAngleForLookUpDown(double AngleDegrees);
    double ClampAngleForLookLeftRight(double AngleDegrees);
    void FlushAdditionalTurnEndEvent(bool& Value);
    void RequestAdditionalTurnEnd();
    bool HasFinisherSequence();
    FTransform GetTransformForBattleSequenceSnapping();
    void InitializeLifeLinkedCharacters();
    void AddLifeLinkedCharacter(class ABP_jRPG_Character_Battle_Base_C* LifeLinkedCharacter);
    bool IsLifeLinkedMaster();
    bool IsLifeLinked();
    void GetLocationForSequenceSnapping(FVector& InitialLocation);
    double GetCounterDamageLevelMultiplier();
    void PlayBattleDialogueLine(class USoundBase* SoundAsset);
    void PlaySkillBattleLine(class USoundBase* SoundAsset);
    class UBP_BattleLinesModel_Base_C* GetBattleLineModel();
    void ApplyDifficultySettings();
    void Internal_SetUniqueMechanicOverpoweredState(bool Enabled);
    double GetParryImmuneDuration();
    double GetDodgeImmuneDuration();
    void GetIsBeingCountered(bool& IsBeingCountered);
    void GetBattleSpotIndex(int32& BattleSpotIndex);
    void GetAcquiredTargets(TArray<ABP_jRPG_Character_Battle_Base_C*>& Characters);
    void ClearAcquiredTargets();
    void TryStopParryAnim();
    void OnGroupCounterAttackBegin(class ABP_jRPG_Character_Battle_Base_C* CounterAttackTarget);
    void OnCounteredStart();
    void GetHasAimingSkill(bool& HasAimingSkill);
    class ABP_EpicBattleSequenceActor_C* GetActiveCounterSequence();
    bool CanCounterAttackCurrentEnemy();
    bool HasUnlockedJump();
    void ActivateLightingScenarioWithTag(FName LightingScenarioTag, const float ChangeSpeedMultiplier);
    void GetBattleWheel2DOffsetForPage(FGameplayTag WheelPageTag, FVector2D& 2DOffset);
    void SetBattleCharacterVisible(bool Visible);
    void SetShouldPlayFinisherAtTurnEnd(bool ShouldPlayFinisherWhenTurnEnd);
    void GetShouldPlayFinisher(bool& ShouldPlayFinisherWhenTurnEnd);
    void GetBattleMap(class ABP_BattleMap_C*& BattleMap);
    class UBP_AudioCharacter_BattleManager_C* GetCharacterAudioManager();
    void InitializeLODSync();
    void LODSyncBattle();
    void LODSyncApplyParameter(class UConfigurableGameUserSettings* UserSettings);
    void SummonSingleMinion(FDataTableRowHandle EnemyRow, int32 BattleSpotIndex, bool NotifyBattleStart, class ABP_jRPG_Character_Battle_Base_C*& SpawnedCharacter, FVector& SpawnLocation);
    void CleanInstigatedActors();
    void RegisterExternalActor(class AActor* Actor);
    void ProcessDamageReceivedSound(class UBP_BattleDamages_C* BattleDamage);
    void SpawnDamagePopupFromDamages(class UBP_BattleDamages_C* BattleDamages, class UWBP_HUD_DamageFeedback_C*& DamageWidget);
    void ResolveHitSound();
    void Attach Weapons to Hands(class ABP_WeaponSkin_C* WeaponActor);
    void InitializeCameraFocus();
    FVector GetDamagePopupWorldLocation();
    void ExecuteSkillAction(FName SkillID);
    void ClearActionEffectNumber(FString Reason);
    FVector GetAttackedLocation();
    bool HasReceivedBattleStart();
    ABP_WeaponSkin_C* GetWeaponActor();
    void StartCounterableMove(TEnumAsByte<ECounterType::Type> CounterType);
    void PerformActionByAI_Internal();
    void ExecuteSkillEvent(FFRoutedEventHandle& SkillHandle);
    void DeclareSkillEvent(FFRoutedEventHandle& SkillHandle, const FDeclareSkillEventEvent& Event, FString DebugName);
    void DeclareCharacterSkillEvents();
    void ExecuteSkillScript(class ABP_Battle_SkillScript_C* SkillScriptInstance);
    void OnBattleEnded();
    void ShouldDoLastStand(bool& DoLastStand);
    void AdjustDefensiveMoveLockTimer(double NewDuration, FString Reason);
    void OnDefenseLockTimerExpired();
    void Acquire Targets(TArray<ABP_jRPG_Character_Battle_Base_C*>& Targets, TArray<ABP_jRPG_Character_Battle_Base_C*>& AcquiredTargets);
    bool IsLastActionEffectOfSkill();
    void ApplyStandardStatusEffectOnTarget(TEnumAsByte<E_StatusEffects::Type> StatusEffect, int32 TurnDuration, TEnumAsByte<EBuffApplicationProbability::Type> StatusEffectProbability, bool Condition, class ABP_jRPG_Character_Battle_Base_C* TargetCharacter, bool& Success);
    void ApplyStandardStatusEffect(TEnumAsByte<E_StatusEffects::Type> StatusEffect, int32 TurnDuration, TEnumAsByte<EBuffApplicationProbability::Type> StatusEffectProbability, bool Condition, bool& Success);
    void GetOwnerCharacter(class ABP_jRPG_Character_Battle_Base_C*& Character);
    void PerformStandardHit(bool CanBeCountered, bool CanBeJumped, bool RequiresGradientCounter, double DamageMultiplier, TEnumAsByte<EAttackType::Type> DamageElement, bool& HasHit, TArray<UBP_BattleDamages_C*>& BattleDamages);
    void PerformStandardHitOnCharacter(class ABP_jRPG_Character_Battle_Base_C* TargetCharacter, bool CanBeCountered, bool CanBeJumped, bool RequiresGradientCounter, double DamageMultiplier, TEnumAsByte<EAttackType::Type> DamageElement, bool& HasHit, class UBP_BattleDamages_C*& BattleDamages);
    void SetActiveFreeAimHand(bool UseRightHand, FName BoneOverride);
    void TryPerformLastStand(class UBP_LastStandRequest_C* LastStandRequest);
    void EndLastStandMove();
    void StartLastStandMove(FString DebugName);
    void StartGradientAttack();
    bool IsInImmunityPhase();
    void ResetMoveToStartLocation();
    void TryStartJump(bool& Success);
    void ResetCurrentSkill();
    void ExecuteSkillScriptFromState(class UBP_SkillState_C* SkillState);
    void OnCharacterReintegratesBattle();
    void KickCharacterFromBattle(FGuid& KickedCharacterHandle);
    void RegisterExternalFreeAimTarget(class AActor* Actor);
    void UpdatePermeateFeedback();
    void GetAllEnemiesExceptSelf(TArray<ABP_jRPG_Character_Battle_Base_C*>& EnemiesExceptSelf);
    void TryStartGradientParry(bool& Success);
    void StartUnblockableAttack();
    void StartUndodgeableAttack();
    TArray<UBP_FreeAimTargetPart_C*> GetFreeAimTargetPartsComponents();
    void SpawnWeaponAndSetSkin();
    void GetDynamicMaterialInstance(int32 Material Index, class UMeshComponent* Mesh, class UMaterialInstanceDynamic*& Dynamic Material Instance);
    void StartMoveToControlledBySequence(class ABP_jRPG_Character_Battle_Base_C* TargetCharacter, double Distance);
    void SetMoveToControlForSequence(double MoveToControlForSequence);
    void SetCurrentIdleState(TEnumAsByte<E_EnemyIdleState::Type> CurrentIdleState, class UAnimMontage* Idle Transition AnimMontage, float& AnimMontageDuration);
    void SummonMinions(FDataTableRowHandle EncounterRow, bool NotifyBattleStart, TArray<ABP_jRPG_Character_Battle_Base_C*>& SpawnedCharacters, TArray<FVector>& SpawnLocations);
    void OnSkipTurnChosen();
    void ReactToBattleEnd();
    void ReactToCharacterThatWasAttacked(class UAC_jRPG_CharacterBattleStats_C* OtherCharacter);
    void ReactToRevivingOther(class UAC_jRPG_CharacterBattleStats_C* RevivedCharacterStats);
    void ReactToBeingRevived(class UAC_jRPG_CharacterBattleStats_C* ReviverCharacterStats);
    void ReactToGivingBuff(class UAC_jRPG_CharacterBattleStats_C* TargetCharacterStats, class UBP_BattleBuffInstance_C* GivenBuffInstance);
    void ReactToBuffReceived(class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStats, class UBP_BattleBuffInstance_C* BuffInstance);
    void OnTriedForbiddenAction(TEnumAsByte<EBattleForbiddenActionReason::Type> ForbiddenActionReason);
    void UI_AppearOnDamagePosition(class UUserWidget* UIElement);
    void UpdateDamageSkin(class USkeletalMeshComponent* FaceMesh);
    void OnStartAllowQTE();
    void SetBaseElementalAffinities(TMap<TEnumAsByte<EAttackType::Type>, TEnumAsByte<EElementalAffinity::Type>> ElementalAffinities);
    void RemoveElementalAllAffinityOverridesFromSource(class UObject* Source);
    void AddElementalAffinityOverride(class UObject* Source, TEnumAsByte<EAttackType::Type> Element, TEnumAsByte<EElementalAffinity::Type> Affinity);
    void GetElementalAffinity(TEnumAsByte<EAttackType::Type> AttackType, TEnumAsByte<EElementalAffinity::Type>& Value);
    void UpdateElementalAffinities();
    void Shield_Explosion();
    void RegisterSkillChecks(FName ActionName);
    void Feedback_APLostUI(int32 LostAP, TEnumAsByte<EAPChangeReason::Type> ChangeReason);
    void GetOverheadStateWidget(class UWBP_Battle_CharacterOverheadState_Base_C*& WBPOverheadState);
    void StartDefenseLock(double Duration, FString Reason);
    void UpdateFreeAimOnAPChanged(int32 NewAP, int32 PreviousAP, class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void MakeBoneMap(const TMap<USceneComponent*, double>& Map);
    int32 GetBattleSpotIndexLeftToRight_(WhenFacingCharacters)();
    void Feedback_APRecoverUI(double RecoveredAP, bool IsFromTurnStart);
    void UseDynamicCameraSystem();
    void IsDataValid(TArray<FText>& ValidationErrors, EDataValidationResult& Result);
    void StartFreeAim_Regular();
    void OnBattleReset();
    void OnDeathPublic(bool DeathCounter);
    void OnResurrectedPublic(double HealAmount);
    void OnInitiativeReducedPublic(double ReductionAmount);
    void OnHealedPublic(double HealAmount, bool RestoredMP?);
    void CheckPublicCall();
    void CheckParentCall();
    void StartPublicCall(FString CallContext);
    void ActivateCharacterDynamicCamera(TEnumAsByte<EBattleTurnState::Type> BattleTurnState);
    void OnCounterAttackFinished();
    void SetIsCounterAttacking(class ABP_jRPG_Character_Battle_Base_C* CounteredCharacter, bool IsGradient);
    void On Action Finished(bool& HasMoreActions);
    void ActivateActionEffect();
    void PrintDebugText();
    void GetBattleTimelineExpiringSoonest(TArray<UBP_BattleSequenceTimeline_C*>& SortedBattleSequenceTimelines);
    void GetCurrentBattleSequenceTime(double& Time);
    TEnumAsByte<EBattleTurnState::Type> GetCurrentBattleTurnState();
    void UpdateBattleTurnState();
    void OnBattleTurnStateChanged();
    void PopAllBattleTurnStates();
    void PopBattleTurnStates(TArray<TEnumAsByte<EBattleTurnState::Type>>& CurrentState);
    void PopBattleTurnState(TEnumAsByte<EBattleTurnState::Type> CurrentState);
    void PushBattleTurnState(TEnumAsByte<EBattleTurnState::Type> TurnState);
    void GetDebugText(FText& Result);
    void SetAnim_DefaultSlotAlpha(double Anim_DefaultSlotAlpha);
    class UAC_jRPG_ActionsManager_C* GetActionManager();
    void TryCancelFreeAim();
    void EnableFreeAim(TEnumAsByte<EFreeAimType::Type> FreeAimType, int32 AmmoCount, double TimeLimit, TSubclassOf<class ABP_FreeAimProjectile_Base_C> ProjectileClass);
    void OnStopTargeting();
    void OnStartTargeting();
    void ExternalTickCurrentBattleSequenceActionTimeline();
    void DeclareBattleSequenceTimingsAsList(class ABP_EpicBattleSequenceActor_C* BattleSequence, TArray<FBattleSequenceKeyframe>& BattleSequenceKeyframes, TMap<double, BattleSequenceCameraType> CameraKeyframes, int32 TrackIndex);
    void OnSkillComboFailed();
    void OnBattleSequenceFinished(class ABP_EpicBattleSequenceActor_C* ComboSequence);
    void OnBattleSequenceStarts(class ABP_EpicBattleSequenceActor_C* BattleSequence);
    void OnStopChoosingItem();
    void OnStartChoosingItem();
    void OnStopChoosingUltimate();
    void OnStartChoosingUltimate();
    void OnStopChoosingMagic();
    void OnStartChoosingSkill();
    void IsPlayerTeamCharacter(bool& IsPlayerTeam);
    void AssertIsCurrentTurn();
    void IsCurrentTurn(bool& IsCurrentTurn);
    void GetLastSkillComboInfo(bool& OnlySuccess, bool& OnlyFail, bool& OnlyPerfect, int32& SuccessCount, int32& FailCount, int32& PerfectCount);
    void Try Activate Skill Combo();
    void OnDefendSuccess(class ABP_jRPG_Character_Battle_Base_C* DefendedEnemy);
    void OnParrySuccess(class ABP_jRPG_Character_Battle_Base_C* ParriedEnemy);
    void OnDodgeSuccess(class ABP_jRPG_Character_Battle_Base_C* DodgedEnemy, bool IsPerfectDodge);
    void ClearDefensiveMoveLock(FString Reason);
    void TryStartParry(bool& Success);
    void TryStartDodge(bool& Success);
    void EndDefensiveMove();
    void StartDefensiveMove(double LockDuration, double ImmuneDuration, double WarmUpDuration, FString Reason);
    void IsImmunityByDefensiveMoveFinished(bool& IsFinished);
    void IsLockedByDefensiveMoveTimer(bool& IsLocked);
    void CanDoDefensiveMove(bool& CanDoDefensiveMove);
    void OverrideWithShoulderCamera(bool Enabled);
    void OnTurnEnded();
    void OnTurnStart();
    void QTEFailFXAndSound(FVector FXScale, class USoundBase* SoundBase, class UParticleSystem* ParticleSystem, FVector FX Position Offset);
    void GetRootLocation(FVector& Location, FVector& Scale, FRotator& Rotation);
    void GetSingleTargetLocation(FVector& TargetLocation);
    void GetTargetHeadLocation(TArray<FVector>& TargetsLocation, TArray<FVector>& TargetScaleList, TArray<FRotator>& TargetRotationList);
    void GetTargetMiddleLocation(TArray<FVector>& TargetsLocation, TArray<FVector>& TargetScaleList, TArray<FRotator>& TargetRotationList);
    void GetTargetRootLocation(TArray<FVector>& TargetsLocation, TArray<FVector>& TargetScaleList, TArray<FRotator>& TargetRotationList);
    class UParticleSystemComponent* SpawnFXOnSelectedTargets(class UNiagaraSystem* VFXNiagara, FVector LocationModif, FRotator RotationModif, FVector ScaleModif, TEnumAsByte<E_JRPG_VFXSpawnSpots::Type> WhereToSpawn, class USoundBase* VFXSound, class UParticleSystem* OLDCASCADE_ParticleSystem, TArray<UParticleSystemComponent*>& SpawnedParticleSystems);
    void AddCharacterParticleSystem(TEnumAsByte<E_jRPG_CharacterAttachmentSlot::Type> AttachmentSlot, class UParticleSystem* ParticleSystemCascade, FRotator ParticleSystemRotation, class UNiagaraSystem* SystemNiagara, FVector PositionOffset, class UParticleSystemComponent*& ParticleSystemComponent_Cascade, class UNiagaraComponent*& NiagaraSystem);
    void FillTargetsWithOtherHeroes(TArray<ABP_jRPG_Character_Battle_Base_C*>& OriginalTargets, TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetList);
    void GetAllEnemies(TArray<ABP_jRPG_Character_Battle_Base_C*>& Output);
    void GetMiddleEnemy(class ABP_jRPG_Character_Battle_Base_C*& Output);
    void CameraShakePlay(TSubclassOf<class UCameraShakeBase> CameraShake, double Scale);
    void ChangeCamera(FName CameraName);
    void PerformActionByAI();
    void UserConstructionScript();
    void Timeline_Targeting__FinishedFunc();
    void Timeline_Targeting__UpdateFunc();
    void Timeline_FreeaimRecoil__FinishedFunc();
    void Timeline_FreeaimRecoil__UpdateFunc();
    void ChangeSizeTimeline__FinishedFunc();
    void ChangeSizeTimeline__UpdateFunc();
    void AppearDisappearTimeline__FinishedFunc();
    void AppearDisappearTimeline__UpdateFunc();
    void Timeline_GradientAttackPostProcess__FinishedFunc();
    void Timeline_GradientAttackPostProcess__UpdateFunc();
    void GradientCounterRadius__FinishedFunc();
    void GradientCounterRadius__UpdateFunc();
    void LateralOffsetUIFX__FinishedFunc();
    void LateralOffsetUIFX__UpdateFunc();
    void OnFinished_282BA5C34080385E2DB4D1849738C470();
    void OnFinished_77F23D7F4DB17AAB78B820BB808011AB();
    void InpActEvt_IA_Battle_FreeAim_Shoot_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Battle_FreeAim_Cancel_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraRightAction_Keyboard_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraUpAction_Keyboard_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraRightAction_Gamepad_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraUpAction_Gamepad_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UI_Menu_Pause_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnLoaded_F2DB9C784493F242341D828551987DA8(class UObject* Loaded);
    void OnFinished_B66BF519426C66C6C8336A86B3DB3006();
    void OnUIAction();
    void OnInitiativeReduced(double ReductionAmount);
    void OnPowerDebuff(double Debuff Power);
    void StartAttackInterceptionAnim(class ABP_jRPG_Character_Battle_Base_C* CharacterToProtect);
    void Internal_StartDashBackForInterception();
    void ResetInterceptionMovement(class USF_BlueprintLatentAction* LatentAction);
    void ReceiveTick(float DeltaSeconds);
    void OnBeginCursorOver_Trace(class AActor* TouchedActor);
    void OnEndCursorOver_Trace(class AActor* TouchedActor);
    void OnClicked_Trace();
    void OnTargetingHoverStart();
    void OnTargetingHoverEnd();
    void OnUINavigationFocusLost();
    void OnUINavigationFocus(const class UBP_UINavigationFocusEvent_C* FocusEventBP);
    void ShootFreeAimProjectile();
    void BndEvt__BP_jRPG_Character_Battle_Base_BP_FreeAimShooterBattleComponent_K2Node_ComponentBoundEvent_0_ShootFreeAimProjectile__DelegateSignature();
    void OnBeginFreeAimHover();
    void OnEndFreeAimHover();
    void ExecuteAction(TEnumAsByte<E_jRPG_ActionType::Type> ActionType, FName SecondaryActionName);
    void ExecuteAttackAction();
    void ExecuteDefendAction();
    void ExecuteItemAction(FName ItemName);
    void ExecuteFleeAction();
    void ExecuteMagicAction(FName MagicName);
    void ExecuteMoveAction(FName MoveName);
    void ExecuteSoloCounterAttack(bool IsGradientCounter, class USF_BlueprintLatentAction* LatentAction);
    void CounterAttackActionEffect();
    void OnDeathDamagePrevented();
    void ExecuteGradientCounterAttack(class ABP_jRPG_Character_Battle_Base_C* CounteredCharacter);
    void GradientCounterAttackActionEffect();
    void DisableGradientPPFromCounterAttack(FVector GradientCenterLocation);
    void PlayFreezeFrameInternal(class USF_BlueprintLatentAction* LatentAction);
    void ChangeSize(double ScaleMultiplier, double Duration, class UCurveFloat* CurveOverride);
    void Feedback_OnAccuracyDodge();
    void LeadGroupCounter(class USF_BlueprintLatentAction* LatentAction);
    void CleanPost();
    void Feedback_OnUniqueMechanicOverpowerEnable();
    void Feedback_OnUniqueMechanicOverpowerDisable();
    void OnDeath(bool DeathByCounter);
    void OnHealed(double HealAmount, bool RestoredMP?, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, TEnumAsByte<EHealReason::Type> Reason);
    void OnResurrected(double HealAmount);
    void OnDamageReceivedPublic(class UBP_BattleDamages_C* BattleDamages, TScriptInterface<class IIBattleDamageSource_C> DamageSourceCharacter);
    void OnAPRecovered(int32 Amount, bool IsFromTurnStart);
    void ShieldAdded();
    void OnStanceBroken();
    void MakeDead_Internal();
    void BPI_SetExternalActorHiddenInGame(bool HiddenInGame);
    void ReceiveBeginPlay();
    void OnBattleStart();
    void StartDodgeFeedback();
    void StartParry();
    void StartDefend();
    void StopDefend();
    void FeedbackSuccessfulDodge();
    void FeedbackSuccessfulParry();
    void FeedbackSuccessfulDefend();
    void OnDamageReceived(double Damage, bool Critical?, bool Weakness?, bool Resistant?, TEnumAsByte<EAttackType::Type> Element, TEnumAsByte<EDamageReason::Type> Reason, class ABP_jRPG_Character_Battle_Base_C* DamageCharacterSource);
    void BeginRotationOverride();
    void ClearRotationOverride();
    void OnFreeAimHit(TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, class ABP_FreeAimProjectile_Base_C* Projectile);
    void BndEvt__BP_jRPG_Character_Battle_Base_BP_FreeAimShooterBattleComponent_K2Node_ComponentBoundEvent_2_OnFreeAimHit_Character_Regular__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, FHitResult HitResult, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
    void HitFeedback(class ABP_jRPG_Character_Battle_Base_C* OverrideTarget, bool HasHit, TSubclassOf<class UCameraShakeBase> CameraShake, double ShakeScale, class UNiagaraSystem* VFX1, class UNiagaraSystem* VFX2, const class USoundBase* Sound, class UObject* SoundWwise, double VolumeMultiplier, TEnumAsByte<E_FreezeFrame::Type> FreezeFrame, bool SpawnIfCharacterIsDead);
    void DEBUG_CVarChange_ShowBattleDebug(bool NewValue);
    void DEBUG_CVarChange_ShowFreeAimBodyParts(bool NewValue);
    void ResetDefensiveLockAfterTime(double Duration);
    void TriggerABPHitAnimation();
    void BndEvt__BP_jRPG_Character_Battle_Base_AC_jRPG_CharacterStats_K2Node_ComponentBoundEvent_0_OnCharacterInitialized__DelegateSignature();
    void DEBUG_SpawnWeapon();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void StartGradientParryFeedback();
    void MoveToInitialLocation2(class USF_BlueprintLatentAction* CompletedLatentAction, FString DebugReason);
    void TEMP_TriggerCounterAttack(class UAC_jRPG_CharacterBattleStats_C* TargetCharacterStats);
    void FeedbackPermeateChange(TEnumAsByte<EAttackType::Type> NewPermeateElement, TEnumAsByte<EPermeateIntensity::Type> NewPermeateIntensity);
    void DashBack(class UAnimMontage* DashBackAnimMontage, class USF_BlueprintLatentAction* CompletedLatentAction);
    void MakeCharacterDisappear();
    void MakeCharacterAppear();
    void StartPPGradientAttack();
    void EndPPGradientAttack();
    void StartJumpFeedback();
    void BeginJumpCounterAttackWindow(class ABP_jRPG_Character_Battle_Base_C* Attacker);
    void TryTriggerJumpCounterAttack();
    void PerformBattleStartEvent(class UBP_DependencyRefCounter_C* RefCounter);
    void EndPPGradientAttackCounter(FVector GradientCenterLocation);
    void PrepareForBattleInternal();
    void Init(FS_CharacterCustomization CharacterCustomization);
    void PerformDelayedBattleStart();
    void A/DTrailsBasedOnVelocity();
    void HitFeedbackOnSelf(bool HasHit, TSubclassOf<class UCameraShakeBase> CameraShake, double ShakeScale, class UNiagaraSystem* VFX1, class UNiagaraSystem* VFX2, const class USoundBase* Sound, class UObject* SoundWwise, double VolumeMultiplier, TEnumAsByte<E_FreezeFrame::Type> FreezeFrame, bool SpawnIfCharacterIsDead);
    void HitFeedbackOnCurrentTarget(class ABP_jRPG_Character_Battle_Base_C* OverrideTarget, bool HasHit, TSubclassOf<class UCameraShakeBase> CameraShake, double ShakeScale, class UNiagaraSystem* VFX1, class UNiagaraSystem* VFX2, const class USoundBase* Sound, class UObject* SoundWwise, double VolumeMultiplier, TEnumAsByte<E_FreezeFrame::Type> FreezeFrame, bool SpawnIfCharacterIsDead);
    void HitFeedbackInternal(class ABP_jRPG_Character_Battle_Base_C* OverrideTarget, bool HasHit, TSubclassOf<class UCameraShakeBase> CameraShake, double ShakeScale, class UNiagaraSystem* VFX1, class UNiagaraSystem* VFX2, const class USoundBase* Sound, class UObject* SoundWwise, double VolumeMultiplier, TEnumAsByte<E_FreezeFrame::Type> FreezeFrame, bool SpawnIfCharacterIsDead);
    void SetNiagaraUIEnabled(bool Enabled);
    void OrientNiagaraUIFromCamera();
    void DEBUG_OnCvarChanged_HideUI(bool NewValue);
    void OnCharacterTurnEnd(class ABP_jRPG_Character_Battle_Base_C* Character);
    void OffsetFX_UISkillPanel();
    void PlayFinisherAtTurnEnd(class UObject* CharacterStats);
    void PlayFinisherSequence();
    void Action Effect_Finisher(int32 ActionEffectIndex);
    void ActivateFinisherPossible();
    void BeginStaggerOnCountered();
    void EndStaggerOnCountered();
    void OnBattlePreIntro();
    void FreeAimEndTurnInternal(TEnumAsByte<EFreeAimType::Type> FreeAimType);
    void OnFreeAimCancelled();
    void OnFreeAimEnded(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllHitCharacters, TEnumAsByte<EFreeAimType::Type> FreeAimType);
    void OnFreeAimEnabled();
    void ExecuteUbergraph_BP_jRPG_Character_Battle_Base(int32 EntryPoint);
    void OnReadyForBattle__DelegateSignature();
    void OnStartedAllowQTE__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* CharacterActor);
    void OnCounterAttacked__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* CounteredCharacter);
    void OnJumpCounter__DelegateSignature();
    void OnBattleSequenceActionEffect__DelegateSignature(int32 ActionEffectIndex);
    void OnPuppetTurnEnded__DelegateSignature();
    void OnJumpStart__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character);
    void OnMoveToCompleted__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* CharacterBase);
    void OnGradientParryStart__DelegateSignature();
    void OnDefenseLockStart__DelegateSignature();
    void OnDefenseLockEnd__DelegateSignature();
    void OnDodgeStart__DelegateSignature();
    void OnDefensiveMoveEnd__DelegateSignature();
    void OnParryStart__DelegateSignature();
    void OnDefenseStateChange__DelegateSignature(bool IsActive);
    void OnSelfTurnEnd__DelegateSignature();
    void OnSelfTurnStart__DelegateSignature();
    void OnResetBattleActionValidation__DelegateSignature();
    void OnFreeAimCancelInput__DelegateSignature();
}; // Size: 0x1562

#endif
