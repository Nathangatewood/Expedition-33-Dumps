#ifndef UE4SS_SDK_BP_InputManager_HPP
#define UE4SS_SDK_BP_InputManager_HPP

class UBP_InputManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TMap<FName, UBP_InputKeyState_C*> KeyStates;                                      // 0x00A8 (size: 0x50)
    TEnumAsByte<EInputType::Type> CurrentInputType;                                   // 0x00F8 (size: 0x1)
    bool AutoSwitchInputType;                                                         // 0x00F9 (size: 0x1)
    TArray<FFInputLayer> InputLayersStack;                                            // 0x0100 (size: 0x10)
    TArray<TEnumAsByte<EInputAction::Type>> AllowedInputActions;                      // 0x0110 (size: 0x10)
    bool bLocked;                                                                     // 0x0120 (size: 0x1)
    TSet<FKey> ConsumedInputKeys;                                                     // 0x0128 (size: 0x50)
    FBP_InputManager_COnInputTypeChanged OnInputTypeChanged;                          // 0x0178 (size: 0x10)
    void OnInputTypeChanged(TEnumAsByte<EInputType::Type> NewInputType);
    TArray<FInputActionKeyMapping> ActionMappingsByName;                              // 0x0188 (size: 0x10)
    FGuid UINavigationLayerID;                                                        // 0x0198 (size: 0x10)
    bool RegisterInUINavigationLayer;                                                 // 0x01A8 (size: 0x1)
    int32 UINavigationLayerIndex;                                                     // 0x01AC (size: 0x4)
    bool DEBUG_LogEnabled;                                                            // 0x01B0 (size: 0x1)

    void DEBUG_SetVerboseEnabled(bool Enabled);
    void BindToActionPressedKey(TEnumAsByte<EInputAction::Type> Action, class UObject* Object, const FBindToActionPressedKeyEvent& Event);
    void UpdateLayerForKey(TEnumAsByte<EInputAction::Type> InputAction, bool IsKeyDown, double AxisValue, FKey Key, FFInputLayer Layer);
    void SetAllInputBlocked(bool bLocked);
    void ResetInputActionRestriction();
    void SetInputActionsRestriction_NavigationOnly(bool AllowConfirm);
    void SetInputActionsRestriction(TArray<TEnumAsByte<EInputAction::Type>>& InputActions, bool AllowNavigation);
    void GetAllActionNamesFromEnum(TArray<FName>& ActionNames);
    void GetAllActionNames(TArray<FName>& ActionNames);
    void BindToActionAxis(TEnumAsByte<EInputAction::Type> Action, const FBindToActionAxisEvent& Event, class UObject* Object);
    void BindToActionPressedReleased(TEnumAsByte<EInputAction::Type> Action, const FBindToActionPressedReleasedPressedEvent& PressedEvent, const FBindToActionPressedReleasedReleased& Released, class UObject* Object);
    void UpdateLayersForKey(TEnumAsByte<EInputAction::Type> InputAction, bool IsKeyDown, double AxisValue, FKey Key);
    void DeleteInputLayerByGUID(FGuid& Guid);
    void FindLayerByGUID(FGuid& Guid, FFInputLayer& Output, int32& Array Index);
    void GetCurrentLayer(FFInputLayer& Output);
    void CreateInputLayer(bool IsModal, FGuid& Guid);
    void DisplayTutoPanel(FName RowName);
    void ProcessTextForInlineInputTag(FText Input, FText& Output);
    void GetBaseBindingKeyVisualInfo(TEnumAsByte<EInputAction::Type> GameAction, FFKeyVisualInfo& KeyVisualInfo);
    void GetKeyVisualInfo(FKey Key, FFKeyVisualInfo& KeyVisualInfo);
    void GetBaseBindingKeyByName(FString InputActionName, FKey& Key);
    void GetBaseBindingKey(TEnumAsByte<EInputAction::Type> GameAction, FKey& Key);
    void UnbindToActionReleasedByEvent(TEnumAsByte<EInputAction::Type> Action, const FUnbindToActionReleasedByEventEvent& Event);
    void UnbindToActionReleasedByObjectReal(TEnumAsByte<EInputAction::Type> Action, class UObject* Object);
    void UnbindToActionPressedByObject(TEnumAsByte<EInputAction::Type> Action, class UObject* Object);
    void UnbindToActionPressed(TEnumAsByte<EInputAction::Type> Action, const FUnbindToActionPressedEvent& Event, class UObject* Object);
    void BindToActionReleased(TEnumAsByte<EInputAction::Type> Action, const FBindToActionReleasedEvent& Event, class UObject* BoundObject);
    void BindToActionPressed(TEnumAsByte<EInputAction::Type> Action, const FBindToActionPressedEvent& Event, class UObject* Object);
    void GetActionStateObject_FromLayer(TEnumAsByte<EInputAction::Type> ActionName, FFInputLayer& InputLayer, class UBP_InputKeyState_C*& Value);
    void GetActionStateObject(TEnumAsByte<EInputAction::Type> ActionName, class UBP_InputKeyState_C*& Value);
    void GetActionStateObjectByName(FName ActionName, class UBP_InputKeyState_C*& Value);
    void GetActionKeyState(const FName& ActionName, bool& IsKeyDown, TEnumAsByte<EInputType::Type>& InputType, double& AxisValue, FKey& Key);
    void CustomEvent_0(TEnumAsByte<EInputType::Type> InputType);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_InputManager(int32 EntryPoint);
    void OnInputTypeChanged__DelegateSignature(TEnumAsByte<EInputType::Type> NewInputType);
}; // Size: 0x1B1

#endif
