#ifndef UE4SS_SDK_BP_Holds_HPP
#define UE4SS_SDK_BP_Holds_HPP

class ABP_Holds_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* CharacterLocation;                                         // 0x0298 (size: 0x8)
    class USphereComponent* InteractionTrigger_Sphere;                                // 0x02A0 (size: 0x8)
    class UArrowComponent* Arrow;                                                     // 0x02A8 (size: 0x8)
    class USceneComponent* EnterExitLocation;                                         // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Mesh_Climb;                                           // 0x02B8 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02C0 (size: 0x8)
    TArray<ABP_Holds_C*> LinkedHolds;                                                 // 0x02C8 (size: 0x10)
    bool IsTopHold;                                                                   // 0x02D8 (size: 0x1)
    bool IsBottomHold;                                                                // 0x02D9 (size: 0x1)
    TArray<USceneComponent*> DebugComponents;                                         // 0x02E0 (size: 0x10)
    TArray<UStaticMesh*> PossibleMeshes;                                              // 0x02F0 (size: 0x10)
    bool RandomlyRotateHolds;                                                         // 0x0300 (size: 0x1)
    FVector Meshscale;                                                                // 0x0308 (size: 0x18)
    int32 Seed;                                                                       // 0x0320 (size: 0x4)
    FFPromptParams InteractionPromptParams;                                           // 0x0328 (size: 0x18)
    class AActor* InteractorActor;                                                    // 0x0340 (size: 0x8)
    double MinimumDistanceBetweenHolds;                                               // 0x0348 (size: 0x8)
    double MaximumDistanceBetweenHolds;                                               // 0x0350 (size: 0x8)

    bool ShouldHideDistantInteraction();
    void CanInteractWithMount(bool& CanInteract);
    void GetInteractionLocation(FVector& Location);
    void GetInteractionFeedbackLocation(FVector& Location);
    void IsInteractionAvailable(bool& Available);
    void IsInteractionDone(bool& Done);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    void GetClimbingElementLocation(FVector& Location);
    void GetClimbingElementRotation(FRotator& Rotation);
    void CheckMoveToNextClimbingElement(FVector InputDirectionHorizontal, FVector InputDirectionVertical, double InputScale, FVector CameraForward, FVector CameraLocation, bool& CanMove, TScriptInterface<class IBPI_ClimbingElement_C>& NextHold);
    void CheckCanExitToTop(FVector InputDirectionVertical, double InputScale, bool& CanExit, FVector& Location, FRotator& Rotation);
    void CheckCanExitToBottom(FVector InputDirectionVertical, double InputScale, bool& CanExit, FVector& Location, FRotator& Rotation);
    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void ProjectLocationsOnCameraPlane(class AActor* HoldToEvaluate, FVector CameraForward, FVector CameraLocation, FVector& HoldToEvaluateLocation, FVector& CurrentLocation);
    void SortClimbingElementByDistance(class ABP_Holds_C* Hold, TArray<ABP_Holds_C*>& Array, TArray<ABP_Holds_C*>& SortedArray);
    void UpdateEntryExitDefaultLocation();
    void LinkToFirstClimbingElementAndRemoveIt(TArray<ABP_Holds_C*>& Holds, class ABP_Holds_C*& LinkedHold);
    void GetClimbingElementInRange(class ABP_Holds_C* ClimbingElement, TArray<ABP_Holds_C*>& ClimbingElements);
    void AutoLinkAllHoldsInRangeWithIgnoreList(TArray<ABP_Holds_C*>& ClimbingElementsToIgnore);
    void AutoLinkAllHoldsInRange();
    void AutoLinkHold();
    void EvaluatePossibleHold(class AActor* HoldToEvaluate, FVector InputDirection, FVector CameraForward, FVector CameraLocation, double& ComputedDot);
    void OnTriggerEndOverlap(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void OnTriggerBeginOverlap(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    bool IsEntryOrExit();
    void ConstructObject();
    void UpdateDebugDisplay();
    void UserConstructionScript();
    void OnInteractionEnabled();
    void OnInteractionDisabled();
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void OnEnemyBattleStateLoaded(bool BattleState);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void ExecuteUbergraph_BP_Holds(int32 EntryPoint);
}; // Size: 0x358

#endif
