#ifndef UE4SS_SDK_BP_GPE_SerializableComponent_HPP
#define UE4SS_SDK_BP_GPE_SerializableComponent_HPP

class UBP_GPE_SerializableComponent_C : public UBP_SerializableActorComponent_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void ReadState(bool& State);
    void SaveState();
    void ReceiveBeginPlay();
    void OnPreSave();
    void ExecuteUbergraph_BP_GPE_SerializableComponent(int32 EntryPoint);
}; // Size: 0xB8

#endif
