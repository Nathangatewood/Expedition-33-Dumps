#ifndef UE4SS_SDK_BP_GameActionInstance_ShowCredits_HPP
#define UE4SS_SDK_BP_GameActionInstance_ShowCredits_HPP

class UBP_GameActionInstance_ShowCredits_C : public UGameActionInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0040 (size: 0x8)

    bool ShouldTriggerAutoSaveAfterExecution();
    FString GetDebugString();
    void ExecuteGameAction(const class APlayerController* Controller);
    void ExecuteUbergraph_BP_GameActionInstance_ShowCredits(int32 EntryPoint);
}; // Size: 0x48

#endif
