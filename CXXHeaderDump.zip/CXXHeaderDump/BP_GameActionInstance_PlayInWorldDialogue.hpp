#ifndef UE4SS_SDK_BP_GameActionInstance_PlayInWorldDialogue_HPP
#define UE4SS_SDK_BP_GameActionInstance_PlayInWorldDialogue_HPP

class UBP_GameActionInstance_PlayInWorldDialogue_C : public UGameActionInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0040 (size: 0x8)

    bool ShouldBlockAutoSaveDuringExecution();
    bool ShouldTriggerAutoSaveAfterExecution();
    FString GetDebugString();
    void ExecuteGameAction(const class APlayerController* Controller);
    void OnInWorldDialogueCompleted();
    void ExecuteUbergraph_BP_GameActionInstance_PlayInWorldDialogue(int32 EntryPoint);
}; // Size: 0x48

#endif
