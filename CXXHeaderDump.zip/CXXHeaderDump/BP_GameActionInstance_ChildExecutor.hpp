#ifndef UE4SS_SDK_BP_GameActionInstance_ChildExecutor_HPP
#define UE4SS_SDK_BP_GameActionInstance_ChildExecutor_HPP

class UBP_GameActionInstance_ChildExecutor_C : public UGameActionInstance
{
    class UGameActionInstance* ChildGameActionInstance;                               // 0x0040 (size: 0x8)

    FString GetDebugString();
    void OnChildGameActionFinished(class UGameActionInstance* GameActionInstance);
    void ExecuteChildGameAction(FGameAction_Wrapper GameActionWrapper);
    void TryExecuteChildGameAction(FGameAction_Wrapper GameActionWrapper);
}; // Size: 0x48

#endif
