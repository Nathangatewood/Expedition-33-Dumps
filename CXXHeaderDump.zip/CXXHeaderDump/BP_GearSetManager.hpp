#ifndef UE4SS_SDK_BP_GearSetManager_HPP
#define UE4SS_SDK_BP_GearSetManager_HPP

class UBP_GearSetManager_C : public UExtendedObject
{
    FS_GearSetCollection GearSetCollection;                                           // 0x0028 (size: 0x50)
    class UBP_CharacterData_C* CharacterOwner;                                        // 0x0078 (size: 0x8)
    int32 GearSetMaxCount;                                                            // 0x0080 (size: 0x4)
    FBP_GearSetManager_COnGearSetUpdated OnGearSetUpdated;                            // 0x0088 (size: 0x10)
    void OnGearSetUpdated();
    FBP_GearSetManager_COnGearSetApplied OnGearSetApplied;                            // 0x0098 (size: 0x10)
    void OnGearSetApplied();
    FBP_GearSetManager_COnGearSetCreated OnGearSetCreated;                            // 0x00A8 (size: 0x10)
    void OnGearSetCreated();
    FBP_GearSetManager_COnGearSetDeleted OnGearSetDeleted;                            // 0x00B8 (size: 0x10)
    void OnGearSetDeleted();

    void GetCharacterOwner(class UBP_CharacterData_C*& CharacterOwner);
    void GetGearSetData(FString InGearSetID, FS_GearSetData& Value, bool& IsFound);
    void GetGearSetMaxCount(int32& GearSetMaxCount);
    void GetGearSets(TMap<FString, FS_GearSetData>& GearSets);
    void ApplyGearSet(FString GearSetID, FS_GearSetManagerParameters GearSetManagerParameters);
    void DeleteGearSet(FString GearSetID);
    void UpdateOrCreateGearSet(FString GearSetID, FS_GearSetManagerParameters Parameters);
    void Initialize(class UBP_CharacterData_C* CharacterOwner);
    void OnGearSetDeleted__DelegateSignature();
    void OnGearSetCreated__DelegateSignature();
    void OnGearSetApplied__DelegateSignature();
    void OnGearSetUpdated__DelegateSignature();
}; // Size: 0xC8

#endif
