#ifndef UE4SS_SDK_BP_JournalViewItem_HPP
#define UE4SS_SDK_BP_JournalViewItem_HPP

class UBP_JournalViewItem_C : public UObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    FS_jRPG_Item_StaticData JournalItemData;                                          // 0x0030 (size: 0x130)
    class UAC_jRPG_InventoryManager_C* InventoryManager;                              // 0x0160 (size: 0x8)
    FBP_JournalViewItem_COnUnlockJournal OnUnlockJournal;                             // 0x0168 (size: 0x10)
    void OnUnlockJournal();
    bool IsUnlocked;                                                                  // 0x0178 (size: 0x1)
    FBP_JournalViewItem_COnVoiceOverFinished OnVoiceOverFinished;                     // 0x0180 (size: 0x10)
    void OnVoiceOverFinished();
    bool bIsPlaying;                                                                  // 0x0190 (size: 0x1)
    TMap<FString, int32> UnknownCutMap;                                               // 0x0198 (size: 0x50)
    TMap<FString, int32> SurvivorCutMap;                                              // 0x01E8 (size: 0x50)
    TMap<FString, int32> VersoCutMap;                                                 // 0x0238 (size: 0x50)
    TMap<FString, int32> RenoirCutMap;                                                // 0x0288 (size: 0x50)
    TMap<FString, int32> AlineCutMap;                                                 // 0x02D8 (size: 0x50)

    void SetIsPlaying(bool bIsPlaying);
    void IsPlaying(bool& bIsPlaying);
    void GetJournalHardcodedName(FName& Item_HardcodedName);
    void GetJournalLevelName(FName& AssociatedLevel);
    void GetJournalShortTitle(FText& ShortText, bool& IsNumber);
    void GetJournalVoiceOver(TSoftObjectPtr<class USoundBase>& VoiceOver);
    void ShouldBeAddedToList(bool& bAddToList);
    void GetJournalContentText(FText& ContentText);
    void GetJournalTitleText(FText& TitleText);
    void IsOwned(bool& IsOwned);
    void TriggerUnlockJournal();
    void Call();
    void ExecuteUbergraph_BP_JournalViewItem(int32 EntryPoint);
    void OnVoiceOverFinished__DelegateSignature();
    void OnUnlockJournal__DelegateSignature();
}; // Size: 0x328

#endif
