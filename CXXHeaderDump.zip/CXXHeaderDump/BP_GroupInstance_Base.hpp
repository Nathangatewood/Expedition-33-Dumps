#ifndef UE4SS_SDK_BP_GroupInstance_Base_HPP
#define UE4SS_SDK_BP_GroupInstance_Base_HPP

class UBP_GroupInstance_Base_C : public UExtendedObject
{
    TArray<UObject*> MatchingObjects;                                                 // 0x0028 (size: 0x10)

    void ResetContents();
    FText GetGroupDisplayName();
    void DoesObjectMatch(class UObject* Object, bool& MatchesGroup);
    TArray<UObject*> GetMatchingObjects();
    void AddMatchingObject(const class UObject*& NewItem);
}; // Size: 0x38

#endif
