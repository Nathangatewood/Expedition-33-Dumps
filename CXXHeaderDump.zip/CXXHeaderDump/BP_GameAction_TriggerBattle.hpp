#ifndef UE4SS_SDK_BP_GameAction_TriggerBattle_HPP
#define UE4SS_SDK_BP_GameAction_TriggerBattle_HPP

class UBP_GameAction_TriggerBattle_C : public UBP_PDT_GameAction_C
{
    FFBattleStartParams Battle Start Params;                                          // 0x0030 (size: 0x158)

    TSubclassOf<class UGameActionInstance> GetInstanceClass();
    void ValidateGameAction(TArray<FText>& ErrorMessages, FString& PropertyPath, bool& ExploreAssetChildren);
}; // Size: 0x188

#endif
