#ifndef UE4SS_SDK_BP_InteractionObjectBase_HPP
#define UE4SS_SDK_BP_InteractionObjectBase_HPP

class ABP_InteractionObjectBase_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBP_GPE_InternalActivationComponent_C* BP_GPE_InternalActivationComponent;  // 0x0298 (size: 0x8)
    class UBP_GPE_DebugComponent_C* BP_GPE_DebugComponent;                            // 0x02A0 (size: 0x8)
    class USceneComponent* InteractionPromptLocation;                                 // 0x02A8 (size: 0x8)
    class UArrowComponent* InteractionPoint;                                          // 0x02B0 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x02B8 (size: 0x8)
    class USphereComponent* InteractionRange;                                         // 0x02C0 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02C8 (size: 0x8)
    bool IsActivatedByDefault;                                                        // 0x02D0 (size: 0x1)
    FS_Interaction_Parameters Parameters;                                             // 0x02D8 (size: 0x20)
    FGPEInterfacesReferences GameplayElementsToActivate;                              // 0x02F8 (size: 0x10)
    FGPEInterfacesReferences GameplayElementsToDeactivate;                            // 0x0308 (size: 0x10)
    bool ShouldDisableInteractionAfterUse;                                            // 0x0318 (size: 0x1)
    bool HasActivatedGPEs;                                                            // 0x0319 (size: 0x1)
    FGPEInterfacesReferences AllGPEInterfaces;                                        // 0x0320 (size: 0x10)
    bool ShouldDisplayDistantFeedback;                                                // 0x0330 (size: 0x1)

    bool ShouldHideDistantInteraction();
    void CanInteractWithMount(bool& CanInteract);
    void IsInteractionDone(bool& Done);
    void GetInteractionLocation(FVector& Location);
    void GetInteractionFeedbackLocation(FVector& Location);
    void IsInteractionAvailable(bool& Available);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    void GPETrigger_GetGameplayElementsToActivate(FGPEInterfacesReferences& GameplayElementsToActivate);
    void GPE_GetActivationComponent(class UBP_GPE_InternalActivationComponent_C*& ActivationComponent);
    void UserConstructionScript();
    void OnInteractionEnabled();
    void OnInteractionDisabled();
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void OnEnemyBattleStateLoaded(bool BattleState);
    void BndEvt__BP_jRPG_InteractionObject_InteractionRange_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_jRPG_InteractionObject_InteractionRange_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_InteractionObjectBase(int32 EntryPoint);
}; // Size: 0x331

#endif
