#ifndef UE4SS_SDK_BP_InteractiveMusicSystem_HPP
#define UE4SS_SDK_BP_InteractiveMusicSystem_HPP

class UBP_InteractiveMusicSystem_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    TMap<TEnumAsByte<E_InteractiveMusicContext::Type>, FS_InteractiveMusic> InteractiveMusicByContext; // 0x0030 (size: 0x50)
    TEnumAsByte<E_InteractiveMusicContext::Type> CurrentContext;                      // 0x0080 (size: 0x1)
    TArray<UAudioComponent*> AudioComponentsToUnspawn;                                // 0x0088 (size: 0x10)
    bool IsStopped;                                                                   // 0x0098 (size: 0x1)
    TArray<TEnumAsByte<E_InteractiveMusicContext::Type>> InteractiveContextsToPause;  // 0x00A0 (size: 0x10)
    FS_InteractiveMusicParameters PreviousInteractiveMusicParameters;                 // 0x00B0 (size: 0x18)
    TEnumAsByte<E_InteractiveMusicContext::Type> PreviousExplorationInteractiveMusicContext; // 0x00C8 (size: 0x1)

    void RestoreExplorationCurrentInteractiveMusicContext();
    void SaveExplorationCurrentInteractiveMusicContext();
    void ComputeCurrentInteractiveMusicParameters(FS_InteractiveMusicParameters& InteractiveMusicParameters);
    void RestorePreviousInteractiveMusicParameters();
    void SaveCurrentInteractiveMusicParameters();
    bool ShouldPauseMusic(const TEnumAsByte<E_InteractiveMusicContext::Type>& NewContext);
    void SetFloatParameterByContext(const TEnumAsByte<E_InteractiveMusicContext::Type> Context, FName ParameterName, float Value);
    void GetCurrentContext(TEnumAsByte<E_InteractiveMusicContext::Type>& Context);
    void PrintInteractiveMusicParameters(FS_InteractiveMusicParameters Parameters);
    void PrintAudioTriggerName(TEnumAsByte<E_InteractiveMusicContext::Type> Context, FName AudioTriggerName);
    void PrintInteractiveMusicStringInLog(FString String);
    FString GetInteractiveMusicParametersDebugString(FS_InteractiveMusicParameters InteractiveMusicParameters);
    FString GetInteractiveMusicDebugString(TEnumAsByte<E_InteractiveMusicContext::Type> InteractiveMusicContext, const FS_InteractiveMusic& InteractiveMusic);
    FString GetAudioComponentDebugString(class UAudioComponent* AudioComponent);
    void GetAudioTriggerNameWhenInterrupted(TEnumAsByte<E_InteractiveMusicContext::Type> NewContext, FName& AudioTriggerName);
    void GetAudioTriggerNameWhenInterrupting(TEnumAsByte<E_InteractiveMusicContext::Type> CurrentContext, FName& AudioTriggerName);
    void GetAudioTriggerNameForContextAndTable(class UDataTable* DataTable, TEnumAsByte<E_InteractiveMusicContext::Type> Context, FName& AudioTriggerName);
    void SetInteractiveMusicPaused(TEnumAsByte<E_InteractiveMusicContext::Type> Context, bool bPause);
    void ProcessMusicInterruption(TEnumAsByte<E_InteractiveMusicContext::Type> NewContext);
    void Initialize();
    void AdjustVolumeByContext(float AdjustVolumeDuration, float AdjustVolumeLevel, TEnumAsByte<E_InteractiveMusicContext::Type> Context);
    void GetDebugString(FString& String);
    void AdjustVolumeCurrentContext(float AdjustVolumeDuration, float AdjustVolumeLevel);
    void UnpauseInteractiveMusicCurrentContext();
    void ApplyInteractiveMusicParameters(FS_InteractiveMusicParameters Parameters);
    void ReplaceInteractiveMusicContext(FS_InteractiveMusicParameters Parameters);
    void SwitchInteractiveMusicContext(FS_InteractiveMusicParameters Parameters);
    void InterruptInteractiveMusic(const TEnumAsByte<E_InteractiveMusicContext::Type>& NewContext);
    void GetCurrentSoundData(TEnumAsByte<E_InteractiveMusicContext::Type>& Context, class USoundBase*& Sound, FName& LastAudioTrigger);
    void GetSoundByContext(const TEnumAsByte<E_InteractiveMusicContext::Type>& Context, class USoundBase*& Sound, FName& LastAudioTrigger);
    void GetCurrentInteractiveMusic(FS_InteractiveMusic& InteractiveMusic);
    void GetInteractiveMusicByContext(const TEnumAsByte<E_InteractiveMusicContext::Type>& Context, FS_InteractiveMusic& InteractiveMusic);
    void OnAudioPlayStateChanged(EAudioComponentPlayState PlayState);
    void MarkAudioComponentForUnspawn(class UAudioComponent* AudioComponent);
    void CreateInteractiveMusicWithContextIfNeeded(TEnumAsByte<E_InteractiveMusicContext::Type> Context, class USoundBase* Sound, FS_InteractiveMusic& InteractiveMusic);
    void ExecuteAudioTriggerByContext(const TEnumAsByte<E_InteractiveMusicContext::Type>& Context, FName AudioTrigger, bool IsInterruption);
    void FadeOutInteractiveMusicByContext(const TEnumAsByte<E_InteractiveMusicContext::Type>& Context, float AdjustVolumeDuration);
    void AdjustVolumeInteractiveMusicByContext(const TEnumAsByte<E_InteractiveMusicContext::Type>& Context, float AdjustVolumeDuration, float AdjustVolumeLevel);
    void Create New Audio Component(class USoundBase* Sound, class UAudioComponent*& SpawnedComponent);
    void PauseInteractiveMusicCurrentContext();
    void ResumeInteractiveMusicSystemWithContext(TEnumAsByte<E_InteractiveMusicContext::Type> Context);
    void StopInteractiveMusicSystem(float FadeOutDuration);
    void DestroyAllInteractiveMusicContexts();
    void PlayInteractiveMusicContext(TEnumAsByte<E_InteractiveMusicContext::Type> Context);
    void PushInteractiveMusicContext(FS_InteractiveMusicParameters InteractiveMusicParameters);
    void SetDebugDrawEnabled(bool Enable);
    void ExecuteUbergraph_BP_InteractiveMusicSystem(int32 EntryPoint);
}; // Size: 0xC9

#endif
