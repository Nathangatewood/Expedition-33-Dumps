#ifndef UE4SS_SDK_BP_GameActionExecutorComponent_HPP
#define UE4SS_SDK_BP_GameActionExecutorComponent_HPP

class UBP_GameActionExecutorComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<UGameActionInstance*> GameActionInstancesInExecution;                      // 0x00A8 (size: 0x10)
    FBP_GameActionExecutorComponent_COnGameActionExecuted OnGameActionExecuted;       // 0x00B8 (size: 0x10)
    void OnGameActionExecuted(class UGameAction* GameAction);
    FSF_ReferenceCounterHandle SaveBlockerReferenceHandle;                            // 0x00C8 (size: 0x20)
    TArray<UAudioComponent*> SpawnedAudioComponents;                                  // 0x00E8 (size: 0x10)
    bool DebugDrawEnabled;                                                            // 0x00F8 (size: 0x1)
    TMap<UGameActionInstance*, FS_GameActionTriggerZoneParameters> GameActionTriggerZoneParameters; // 0x0100 (size: 0x50)
    class UBP_SaveGameData_C* LastGameStateSnapshot;                                  // 0x0150 (size: 0x8)

    class UBP_SaveGameData_C* GetLastSavedGameData();
    void CreateSaveGameDataIfNeeded();
    void SaveGameActionTriggerZoneParameters();
    void DrawDebug();
    void OnAudioComponentStateChanged(EAudioComponentPlayState PlayState);
    void RegisterSpawnedAudioComponent(const class UAudioComponent*& AudioComponent);
    void RequestAutoSaveIfNeeded(class UGameActionInstance* GameActionInstance);
    bool ShouldBlockAutoSave();
    void SetDebugDrawEnable(bool Enable);
    void GetDebugString(FString& String);
    void OnGameActionExecutionFinished(class UGameActionInstance* GameActionInstance);
    void ConstructAndBindGameActionInstance(class UGameAction* GameAction, class UGameActionInstance*& GameActionInstance);
    bool HasAnyGameActionInExecutionFromTriggerZones();
    bool HasAnyGameActionInExecution();
    void ExecuteGameActionInternal(class UGameActionInstance* GameActionInstance);
    void ExecuteGameAction(class UGameAction* GameAction);
    void ExecuteGameActionWrapperFromTriggerZone(FGameAction_Wrapper GameActrionWrapper, FS_GameActionTriggerZoneParameters TriggerZoneParameters);
    void ExecuteGameActionWrapper(FGameAction_Wrapper GameActrionWrapper);
    void OnLoaded_F41409DF48962A8613AC8491DEFFE562(class UObject* Loaded);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void SetGameplayPaused(bool Paused);
    void ReceiveBeginPlay();
    void RestoreGameActionTriggerZoneParameters();
    void ExecuteUbergraph_BP_GameActionExecutorComponent(int32 EntryPoint);
    void OnGameActionExecuted__DelegateSignature(class UGameAction* GameAction);
}; // Size: 0x158

#endif
