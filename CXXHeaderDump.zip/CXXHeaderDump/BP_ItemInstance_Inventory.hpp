#ifndef UE4SS_SDK_BP_ItemInstance_Inventory_HPP
#define UE4SS_SDK_BP_ItemInstance_Inventory_HPP

class UBP_ItemInstance_Inventory_C : public UBP_ItemInstance_Base_C
{

    void GenerateItem(FS_jRPG_Item_StaticData& ItemStaticItem, FS_LootContext& LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItemInfo);
}; // Size: 0x178

#endif
