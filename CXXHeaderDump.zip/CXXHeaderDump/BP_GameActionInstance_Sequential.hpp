#ifndef UE4SS_SDK_BP_GameActionInstance_Sequential_HPP
#define UE4SS_SDK_BP_GameActionInstance_Sequential_HPP

class UBP_GameActionInstance_Sequential_C : public UBP_GameActionInstance_ChildExecutor_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0048 (size: 0x8)
    int32 NextIndex;                                                                  // 0x0050 (size: 0x4)
    class UBP_GameAction_Sequential_C* GameActionSequential;                          // 0x0058 (size: 0x8)
    class APlayerController* PlayerController;                                        // 0x0060 (size: 0x8)
    bool ShouldTriggerAutoSave;                                                       // 0x0068 (size: 0x1)

    bool ShouldBlockAutoSaveDuringExecution();
    bool ShouldTriggerAutoSaveAfterExecution();
    FString GetDebugString();
    void OnChildGameActionFinished(class UGameActionInstance* GameActionInstance);
    void GetNextGameActionToExecuteAndUpdateIndex(FGameAction_Wrapper& GameActionWrapper);
    bool HasAnyGameActionToExecute();
    void TryExecuteNextGameAction();
    void ExecuteGameAction(const class APlayerController* Controller);
    void ExecuteUbergraph_BP_GameActionInstance_Sequential(int32 EntryPoint);
}; // Size: 0x69

#endif
