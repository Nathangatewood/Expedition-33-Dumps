#ifndef UE4SS_SDK_BP_GeneratedItemInfo_Item_HPP
#define UE4SS_SDK_BP_GeneratedItemInfo_Item_HPP

class UBP_GeneratedItemInfo_Item_C : public UBP_GeneratedItemInfo_Base_C
{
    FName ItemId;                                                                     // 0x002C (size: 0x8)
    FS_jRPG_Item_StaticData ItemStaticData;                                           // 0x0038 (size: 0x130)

    TSoftObjectPtr<class UTexture2D> GetItemIcon();
    TEnumAsByte<E_jRPG_ItemType::Type> GetItemType();
    void Init();
    FText GetItemDisplayText();
}; // Size: 0x168

#endif
