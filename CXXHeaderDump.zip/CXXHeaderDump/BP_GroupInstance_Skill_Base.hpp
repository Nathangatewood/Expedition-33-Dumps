#ifndef UE4SS_SDK_BP_GroupInstance_Skill_Base_HPP
#define UE4SS_SDK_BP_GroupInstance_Skill_Base_HPP

class UBP_GroupInstance_Skill_Base_C : public UBP_GroupInstance_Base_C
{

    void DoesSkillMatch(class UBP_DataAsset_Skill_C* SkillData, bool& MatchesGroup);
    void DoesObjectMatch(class UObject* Object, bool& MatchesGroup);
}; // Size: 0x38

#endif
