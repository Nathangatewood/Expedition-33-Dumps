#ifndef UE4SS_SDK_BP_GroupingPolicy_UniqueMechanic_Masks_HPP
#define UE4SS_SDK_BP_GroupingPolicy_UniqueMechanic_Masks_HPP

class UBP_GroupingPolicy_UniqueMechanic_Masks_C : public UBP_GroupingPolicy_Base_C
{

    void InitGroupPolicy();
}; // Size: 0x51

#endif
