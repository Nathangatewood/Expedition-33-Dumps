#ifndef UE4SS_SDK_BP_GPE_IndexSelectorComponent_HPP
#define UE4SS_SDK_BP_GPE_IndexSelectorComponent_HPP

class UBP_GPE_IndexSelectorComponent_C : public UActorComponent
{
    TEnumAsByte<E_GPE_OrchestratorMode::Type> Mode;                                   // 0x00A0 (size: 0x1)
    int32 CurrentIndex;                                                               // 0x00A4 (size: 0x4)
    TArray<int32> ShuffledIndexes;                                                    // 0x00A8 (size: 0x10)
    int32 PreviousArrayLength;                                                        // 0x00B8 (size: 0x4)
    TArray<int32> UsedIndexes;                                                        // 0x00C0 (size: 0x10)

    void InitShuffeIndexesIfNeeded(int32 ArrayLength);
    void GetUsedIndexes(TArray<int32>& Indexes);
    void ResetIndexes(bool ResetCurrentIndex);
    void GetNextIndex(int32 ArrayLength, int32& Index);
}; // Size: 0xD0

#endif
