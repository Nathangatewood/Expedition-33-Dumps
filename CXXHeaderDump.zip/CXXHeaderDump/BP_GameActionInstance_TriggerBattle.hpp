#ifndef UE4SS_SDK_BP_GameActionInstance_TriggerBattle_HPP
#define UE4SS_SDK_BP_GameActionInstance_TriggerBattle_HPP

class UBP_GameActionInstance_TriggerBattle_C : public UGameActionInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0040 (size: 0x8)

    FString GetDebugString();
    void OnBattleFinished(bool Victory);
    void ExecuteGameAction(const class APlayerController* Controller);
    void ExecuteUbergraph_BP_GameActionInstance_TriggerBattle(int32 EntryPoint);
}; // Size: 0x48

#endif
