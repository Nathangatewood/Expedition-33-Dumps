#ifndef UE4SS_SDK_BP_GameActionTriggerZone_AutoSaveRequest_HPP
#define UE4SS_SDK_BP_GameActionTriggerZone_AutoSaveRequest_HPP

class ABP_GameActionTriggerZone_AutoSaveRequest_C : public ABP_GameActionTriggerZone_C
{
}; // Size: 0x330

#endif
