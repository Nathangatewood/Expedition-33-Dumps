#ifndef UE4SS_SDK_BP_jRPG_EnemyBattleSpot_HPP
#define UE4SS_SDK_BP_jRPG_EnemyBattleSpot_HPP

class ABP_jRPG_EnemyBattleSpot_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* SpawnPosition;                                             // 0x0298 (size: 0x8)
    class USkeletalMeshComponent* PreviewMesh;                                        // 0x02A0 (size: 0x8)
    class UTextRenderComponent* Text;                                                 // 0x02A8 (size: 0x8)
    class UArrowComponent* Arrow;                                                     // 0x02B0 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x02B8 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02C0 (size: 0x8)
    int32 SlotIndex;                                                                  // 0x02C8 (size: 0x4)
    TEnumAsByte<E_jRPG_FormationType::Type> Formation;                                // 0x02CC (size: 0x1)

    void UserConstructionScript();
    void ReceiveBeginPlay();
    void DEBUG_CVarChange_ShowBattleDebug(bool NewValue);
    void ExecuteUbergraph_BP_jRPG_EnemyBattleSpot(int32 EntryPoint);
}; // Size: 0x2CD

#endif
