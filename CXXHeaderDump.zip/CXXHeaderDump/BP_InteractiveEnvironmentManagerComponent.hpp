#ifndef UE4SS_SDK_BP_InteractiveEnvironmentManagerComponent_HPP
#define UE4SS_SDK_BP_InteractiveEnvironmentManagerComponent_HPP

class UBP_InteractiveEnvironmentManagerComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool IsEnabled;                                                                   // 0x00A8 (size: 0x1)
    TArray<UBP_EnvironmentInteractorComponent_C*> EnvironmentInteractorComponent;     // 0x00B0 (size: 0x10)
    FVector CurrentSnappedWorldLocation;                                              // 0x00C0 (size: 0x18)
    class UTextureRenderTarget2D* GrassRenderTarget_Flip;                             // 0x00D8 (size: 0x8)
    class UTextureRenderTarget2D* GrassRenderTarget_Flop;                             // 0x00E0 (size: 0x8)
    class UTextureRenderTarget2D* SnowRenderTarget_Flip;                              // 0x00E8 (size: 0x8)
    class UTextureRenderTarget2D* SnowRenderTarget_Flop;                              // 0x00F0 (size: 0x8)
    class UTextureRenderTarget2D* SandRenderTarget_Flip;                              // 0x00F8 (size: 0x8)
    class UTextureRenderTarget2D* SandRenderTarget_Flop;                              // 0x0100 (size: 0x8)
    int32 GrassMulitplySizeInteractionZone;                                           // 0x0108 (size: 0x4)
    int32 SandMultiplySizeInteractionZone;                                            // 0x010C (size: 0x4)
    int32 SnowMulitplySizeInteractionZone;                                            // 0x0110 (size: 0x4)
    bool DEBUG_DisplayInteractors;                                                    // 0x0114 (size: 0x1)
    class UMaterialParameterCollection* MPC_Global;                                   // 0x0118 (size: 0x8)
    TMap<TEnumAsByte<E_InteractiveEnvironmentType::Type>, FVector> PreviousCamPositions; // 0x0120 (size: 0x50)
    TArray<ABP_TriggerInteractiveEnvironmentZone_C*> ArrayOfTriggerInteractiveZone;   // 0x0170 (size: 0x10)
    TArray<UBP_EnvironmentInteractorComponent_C*> ArrayOfTempInteractorComponents;    // 0x0180 (size: 0x10)
    TMap<TEnumAsByte<E_InteractiveEnvironmentType::Type>, FS_ListOfActorsPerInteractionType> TypeMapOfStructArray; // 0x0190 (size: 0x50)

    void Retrieve Actor List from Zones();
    void UpdateActorListInMap(const TEnumAsByte<E_InteractiveEnvironmentType::Type>& Key, const FS_ListOfActorsPerInteractionType& Value);
    void GetOrCreateActorList(const TEnumAsByte<E_InteractiveEnvironmentType::Type>& Key, FS_ListOfActorsPerInteractionType& List);
    FName GetEnvironmentInteractionTypeMPC_ID(TEnumAsByte<E_InteractiveEnvironmentType::Type> Enumerator);
    void StampOnCanvasAndRenderMaterialFull(class UTextureRenderTarget2D* Render Target Flip, class UTextureRenderTarget2D* Render Target Flop, class UMaterialInterface* Parent Canvas Material, bool IsFlip, const TEnumAsByte<E_InteractiveEnvironmentType::Type> TypeOfInteraction, double Impact Size Multiplicator, class UMaterialInterface* Stamp Material, int32 MulitplySizeOfInteraction, bool IsStampRotate);
    FVector SnapWorldLocation(FVector A, int32 MulitplySizeOfInteraction);
    void UnregisterGrassInteractorComponent(const class UBP_EnvironmentInteractorComponent_C*& InteractorComponent);
    void RegisterGrassInteractorComponent(class UBP_EnvironmentInteractorComponent_C* Component);
    void UpdateTickEnabled();
    void UnregisterGrassInteractor(class AActor* Actor);
    void RegisterGrassInteractor(class AActor* Actor);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_InteractiveEnvironmentManagerComponent(int32 EntryPoint);
}; // Size: 0x1E0

#endif
