#ifndef UE4SS_SDK_BP_GameAction_ShowCredits_HPP
#define UE4SS_SDK_BP_GameAction_ShowCredits_HPP

class UBP_GameAction_ShowCredits_C : public UBP_PDT_GameAction_C
{
    class UBP_DataAsset_GameCredits_C* CreditsAsset;                                  // 0x0030 (size: 0x8)

    TSubclassOf<class UGameActionInstance> GetInstanceClass();
    void ValidateGameAction(TArray<FText>& ErrorMessages, FString& PropertyPath, bool& ExploreAssetChildren);
}; // Size: 0x38

#endif
