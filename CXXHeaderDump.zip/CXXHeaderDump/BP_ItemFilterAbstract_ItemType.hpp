#ifndef UE4SS_SDK_BP_ItemFilterAbstract_ItemType_HPP
#define UE4SS_SDK_BP_ItemFilterAbstract_ItemType_HPP

class UBP_ItemFilterAbstract_ItemType_C : public UBP_ItemFilter_Base_C
{

    void GetFilteredTypes(TArray<TEnumAsByte<E_jRPG_ItemType::Type>>& FilteredType);
    void ExecuteFilter(const TArray<UBP_ItemInstance_Base_C*>& ItemInstances, TArray<UBP_ItemInstance_Base_C*>& FilteredItemInstances);
}; // Size: 0x28

#endif
