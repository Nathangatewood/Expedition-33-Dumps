#ifndef UE4SS_SDK_BP_ItemSorter_Alphabetically_HPP
#define UE4SS_SDK_BP_ItemSorter_Alphabetically_HPP

class UBP_ItemSorter_Alphabetically_C : public UBP_ItemSorterAbstract_C
{

    void SortItemInstances(class UBP_ItemInstance_Base_C* A, class UBP_ItemInstance_Base_C* B, class UOrderingResult* Result);
    void GetDisplayName(FText& DisplayName);
}; // Size: 0x38

#endif
