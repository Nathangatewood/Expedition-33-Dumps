#ifndef UE4SS_SDK_BP_jRPG_Enemy_Battle_Base_HPP
#define UE4SS_SDK_BP_jRPG_Enemy_Battle_Base_HPP

class ABP_jRPG_Enemy_Battle_Base_C : public ABP_jRPG_Character_Battle_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x1568 (size: 0x8)
    class UBP_RandomVariation_C* BP_RandomColor;                                      // 0x1570 (size: 0x8)
    float Summon_0_To_1_D651999F4D3D7B2A531AA4AE6BC1DCEB;                             // 0x1578 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Summon__Direction_D651999F4D3D7B2A531AA4AE6BC1DCEB; // 0x157C (size: 0x1)
    class UTimelineComponent* Summon;                                                 // 0x1580 (size: 0x8)
    float Die_Timeline_0to1_EE63331D49F0B879DD242BAAAEDBB88C;                         // 0x1588 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Die_Timeline__Direction_EE63331D49F0B879DD242BAAAEDBB88C; // 0x158C (size: 0x1)
    class UTimelineComponent* Die_Timeline;                                           // 0x1590 (size: 0x8)
    double Stack1;                                                                    // 0x1598 (size: 0x8)
    TEnumAsByte<E_EnemyIdleState::Type> CurrentIdleState_0;                           // 0x15A0 (size: 0x1)
    class ABP_jRPG_Character_Battle_Base_C* DEBUG_RandomHeroAcquireOverride;          // 0x15A8 (size: 0x8)
    TArray<UAnimMontage*> DEPRECATED_HitAnim_Normal_0;                                // 0x15B0 (size: 0x10)
    TArray<UAnimMontage*> DEPRECATED_HitAnim_Weakness_0;                              // 0x15C0 (size: 0x10)
    TArray<UAnimMontage*> DEPRECATED_HitAnim_Resistant_0;                             // 0x15D0 (size: 0x10)
    class UPostProcessComponent* TurnStartPostProcessing;                             // 0x15E0 (size: 0x8)
    bool DesaturateWhenLosingLife;                                                    // 0x15E8 (size: 0x1)
    double HighestApAmount;                                                           // 0x15F0 (size: 0x8)
    bool ShouldDesintegrateOnDeath;                                                   // 0x15F8 (size: 0x1)
    bool IsSkillSummon;                                                               // 0x15F9 (size: 0x1)
    double Delay Before Inversion;                                                    // 0x1600 (size: 0x8)
    double BaseDesaturation;                                                          // 0x1608 (size: 0x8)
    int32 ElementIndexForBaseDesaturation;                                            // 0x1610 (size: 0x4)
    class UMaterialInterface* SummonMaterial;                                         // 0x1618 (size: 0x8)
    FLinearColor VFXSummonColor;                                                      // 0x1620 (size: 0x10)
    double SkillSummonVFXMultiplier;                                                  // 0x1630 (size: 0x8)

    void ClearAcquiredTargets();
    void EndLastStandMove();
    void SetIsSkillSummon(bool Enabled);
    void AcquireTargetAllEnemies(TArray<ABP_jRPG_Character_Battle_Base_C*>& Target Enemies);
    void DONTUSEAcquireTargetWithHighestApAmount(class ABP_jRPG_Character_Battle_Base_C*& Output);
    void DEBUG_CheckDisintegrationComponents(TArray<UMeshComponent*>& MeshComponents, bool& Success);
    void GetMiddleHeroForFeedback(class ABP_jRPG_Character_Battle_Base_C*& MiddleHero);
    void GetCharacterAtBattleSpotIndex(int32 BattleSpotIndex, bool IncludedKickedCharacters, class ABP_jRPG_Character_Battle_Base_C*& Character);
    void Desaturation();
    void AcquireSpecificTargetFromActorRef(class ABP_jRPG_Character_Battle_Base_C* ActorRefTarget, class ABP_jRPG_Character_Battle_Base_C*& TargetRef);
    void GetExtraDisintegrationComponents(TArray<UMeshComponent*>& MeshComponent);
    void AcquireTargetWithHigherHealth(class ABP_jRPG_Character_Battle_Base_C*& Output);
    void AcquireTargetWithLowerHealth(class ABP_jRPG_Character_Battle_Base_C*& Output);
    void SetCurrentIdleState_0(TEnumAsByte<E_EnemyIdleState::Type> CurrentIdleState);
    void AcquireSpecificTarget(int32 DesiredTargetIndex, bool AcquireRandomTargetIfWantedTargetDead, class ABP_jRPG_Character_Battle_Base_C*& TargetRef, bool& IsTargetDead);
    void Clear Hero Targeting();
    void AcquireTargetMiddleHero(bool RandomIfDead, class ABP_jRPG_Character_Battle_Base_C*& Output);
    void AcquireTargetAllHeroes(bool OnlyAlive, TArray<ABP_jRPG_Character_Battle_Base_C*>& Target Heroes);
    void AcquireTargetRandomHero(class ABP_jRPG_Character_Battle_Base_C*& Output);
    void GetAllEnemies_0(TArray<ABP_jRPG_Character_Battle_Base_C*>& Enemies);
    void GetRandomEnemy(class ABP_jRPG_Character_Battle_Base_C*& Output);
    void Die_Timeline__FinishedFunc();
    void Die_Timeline__UpdateFunc();
    void Summon__FinishedFunc();
    void Summon__UpdateFunc();
    void DebugSkipTurn();
    void OnDeath(bool DeathByCounter);
    void OnTurnStart();
    void AfterTutoEvent();
    void JumpStandardSlowmo();
    void DesintegrateOnDeath();
    void InvertDesintegrateOnDeath();
    void BndEvt__BP_jRPG_Enemy_Battle_Base_AC_jRPG_CharacterStats_K2Node_ComponentBoundEvent_0_OnHPChanged__DelegateSignature(double NewHP, double PreviousHP);
    void ReceiveBeginPlay();
    void SkillSummon(double DelayBeforeInversion);
    void OnTurnEnded();
    void ExecuteUbergraph_BP_jRPG_Enemy_Battle_Base(int32 EntryPoint);
}; // Size: 0x1638

#endif
