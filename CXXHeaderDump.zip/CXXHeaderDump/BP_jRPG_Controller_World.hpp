#ifndef UE4SS_SDK_BP_jRPG_Controller_World_HPP
#define UE4SS_SDK_BP_jRPG_Controller_World_HPP

class ABP_jRPG_Controller_World_C : public AALS_Player_Controller_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0878 (size: 0x8)
    class UBP_InputContextComponent_C* BP_InputContextComponent;                      // 0x0880 (size: 0x8)
    class UBP_InputLockComponent_C* BP_InputLockComponent;                            // 0x0888 (size: 0x8)
    class UBP_AchievementManager_C* BP_AchievementManager;                            // 0x0890 (size: 0x8)
    class UBP_LevelAmbienceAreaManager_C* BP_LevelAmbienceAreaManager;                // 0x0898 (size: 0x8)
    class UBP_InteractiveEnvironmentManagerComponent_C* BP_InteractiveEnvironmentManagerComponent; // 0x08A0 (size: 0x8)
    class UBP_CinematicSystem_C* BP_CinematicSystem;                                  // 0x08A8 (size: 0x8)
    class UBP_LootSystemComponent_C* BP_LootSystemComponent;                          // 0x08B0 (size: 0x8)
    class UBP_GameActionExecutorComponent_C* BP_GameActionExecutorComponent;          // 0x08B8 (size: 0x8)
    class UBP_LoadingSystemComponent_C* BP_LoadingSystemComponent_Battle;             // 0x08C0 (size: 0x8)
    class UBP_World_Audio_Component_C* BP_World_Audio_Component;                      // 0x08C8 (size: 0x8)
    class UBP_UINavigationComponent_C* BP_UINavigationComponent;                      // 0x08D0 (size: 0x8)
    class UBP_CharacterReactionSystem_C* BP_CharacterReactionSystem;                  // 0x08D8 (size: 0x8)
    class UBP_InteractionSystem_C* BP_InteractionSystem;                              // 0x08E0 (size: 0x8)
    class UBP_TutorialSystemComponent_C* BP_TutorialSystemComponent;                  // 0x08E8 (size: 0x8)
    class UBP_InputManager_C* BP_InputManager;                                        // 0x08F0 (size: 0x8)
    class UBP_DialogueSystemComponent_C* BP_DialogueSystemComponent;                  // 0x08F8 (size: 0x8)
    class UBP_GameDirectorComponent_C* BP_GameDirectorComponent;                      // 0x0900 (size: 0x8)
    class UAC_jRPG_TargetingManager_C* AC_jRPG_TargetingManager;                      // 0x0908 (size: 0x8)
    class UBP_QTEManager_C* AC_jRPG_QTEManager;                                       // 0x0910 (size: 0x8)
    class UAC_jRPG_ActionsManager_C* AC_jRPG_ActionsManager;                          // 0x0918 (size: 0x8)
    class UAC_jRPG_BattleManager_C* AC_jRPG_BattleManager;                            // 0x0920 (size: 0x8)
    class UAC_jRPG_CharactersManager_C* AC_jRPG_CharactersManager;                    // 0x0928 (size: 0x8)
    class UAC_jRPG_InventoryManager_C* AC_jRPG_InventoryManager;                      // 0x0930 (size: 0x8)
    class ABP_jRPG_Character_World_C* LastControlledCharacterReference;               // 0x0938 (size: 0x8)
    class UWBP_jRPG_InteractionPopUp_C* InteractionPopUp;                             // 0x0940 (size: 0x8)
    class UTimelineComponent* Timeline_0;                                             // 0x0948 (size: 0x8)
    class UAC_jRPG_DynamicCameraManager_C* DynamicCameraManagerReference;             // 0x0950 (size: 0x8)
    bool Debug_ShowControlRotation;                                                   // 0x0958 (size: 0x1)
    bool Debug_LogMouseRaycast;                                                       // 0x0959 (size: 0x1)
    FBP_jRPG_Controller_World_CTriggerLeftPressed TriggerLeftPressed;                 // 0x0960 (size: 0x10)
    void TriggerLeftPressed();
    FBP_jRPG_Controller_World_CVendorWindowClosed VendorWindowClosed;                 // 0x0970 (size: 0x10)
    void VendorWindowClosed();
    class UWBP_Exploration_HUD_C* ExplorationHUDWidget;                               // 0x0980 (size: 0x8)
    FBP_jRPG_Controller_World_CPlaceholderTutorialInput PlaceholderTutorialInput;     // 0x0988 (size: 0x10)
    void PlaceholderTutorialInput();
    bool IsGameMenuVisible;                                                           // 0x0998 (size: 0x1)
    class AActor* GameActionActorLocation;                                            // 0x09A0 (size: 0x8)
    class UBP_GameAction_TriggerBattle_C* CurrentTriggerBattleGameAction;             // 0x09A8 (size: 0x8)
    TEnumAsByte<E_BattleFlowState::Type> BattleFlowState;                             // 0x09B0 (size: 0x1)
    bool IsDefenseInputBound;                                                         // 0x09B1 (size: 0x1)
    TArray<AActor*> DEBUG_PreviouslyHiddenBlockoutActors;                             // 0x09B8 (size: 0x10)
    FSF_ReferenceCounterHandle InteractionSystemPayload;                              // 0x09C8 (size: 0x20)
    class ABP_GameMenuScene_C* GameMenuSceneActor;                                    // 0x09E8 (size: 0x8)
    FSF_ReferenceCounter GameplayIsPausedReferenceCounter;                            // 0x09F0 (size: 0x20)
    TArray<AActor*> PausedActors;                                                     // 0x0A10 (size: 0x10)
    TArray<ABP_jRPG_Enemy_World_Base_Seamless_C*> WorldEnemiesAutomaticallyHiddenForBattle; // 0x0A20 (size: 0x10)
    FSF_ReferenceCounterHandle InteractBlocker_GameMenu;                              // 0x0A30 (size: 0x20)
    TArray<UActorComponent*> PausedComponents;                                        // 0x0A50 (size: 0x10)
    class UWorldPartitionStreamingSourceComponent* GameMenuTemporaryStreamingSourceCharacter; // 0x0A60 (size: 0x8)
    TArray<TScriptInterface<class IBPI_GameplayPausable_C>> PausedInterfaces;         // 0x0A68 (size: 0x10)
    TArray<AActor*> ActorsHiddenByMenu;                                               // 0x0A78 (size: 0x10)
    class UDataTable* Data Table;                                                     // 0x0A88 (size: 0x8)
    class AActor* CameraOverrideActor;                                                // 0x0A90 (size: 0x8)
    FBP_jRPG_Controller_World_COnMainMenuClosed OnMainMenuClosed;                     // 0x0A98 (size: 0x10)
    void OnMainMenuClosed();
    FSF_ReferenceCounterHandle PauseBlocker_GameMenu;                                 // 0x0AA8 (size: 0x20)
    FSF_ReferenceCounterHandle PauseBlocker_Debug;                                    // 0x0AC8 (size: 0x20)
    FBP_jRPG_Controller_World_COnMainMenuOpened OnMainMenuOpened;                     // 0x0AE8 (size: 0x10)
    void OnMainMenuOpened();
    TArray<FS_CameraOverrideParameters> CameraOverrideParametersStack;                // 0x0AF8 (size: 0x10)
    FBP_jRPG_Controller_World_COnPauseMenuOpened OnPauseMenuOpened;                   // 0x0B08 (size: 0x10)
    void OnPauseMenuOpened();
    FBP_jRPG_Controller_World_COnPauseMenuClosed OnPauseMenuClosed;                   // 0x0B18 (size: 0x10)
    void OnPauseMenuClosed();
    FBP_jRPG_Controller_World_COnTargetViewAboutToChanged OnTargetViewAboutToChanged; // 0x0B28 (size: 0x10)
    void OnTargetViewAboutToChanged(class AActor* PreviousViewTarget, class AActor* CurrentViewTarget);
    FBP_jRPG_Controller_World_CDummy_SortCameraOverrideParameters Dummy_SortCameraOverrideParameters; // 0x0B38 (size: 0x10)
    void Dummy_SortCameraOverrideParameters(FS_CameraOverrideParameters A, FS_CameraOverrideParameters B, class UOrderingResult* OrderingResult);
    FBP_jRPG_Controller_World_COnSavePointMenuOpened OnSavePointMenuOpened;           // 0x0B48 (size: 0x10)
    void OnSavePointMenuOpened();
    FBP_jRPG_Controller_World_COnSavePointMenuClosed OnSavePointMenuClosed;           // 0x0B58 (size: 0x10)
    void OnSavePointMenuClosed();
    FBP_jRPG_Controller_World_COnDocumentActorOpened OnDocumentActorOpened;           // 0x0B68 (size: 0x10)
    void OnDocumentActorOpened();
    FBP_jRPG_Controller_World_COnDocumentActorClosed OnDocumentActorClosed;           // 0x0B78 (size: 0x10)
    void OnDocumentActorClosed();
    FSF_ReferenceCounterHandle InteractBlocker_PauseMenu;                             // 0x0B88 (size: 0x20)
    FSF_ReferenceCounterHandle PauseBlocker_PauseMenu;                                // 0x0BA8 (size: 0x20)
    bool IsPauseMenuVisible;                                                          // 0x0BC8 (size: 0x1)
    class UWBP_PauseMenu_C* PauseMenuWidget;                                          // 0x0BD0 (size: 0x8)
    class AExponentialHeightFog* SpawnedFogForGameMenu;                               // 0x0BD8 (size: 0x8)
    bool IsSavePointMenuVisible;                                                      // 0x0BE0 (size: 0x1)
    FSF_ReferenceCounter ForceFeedbackEnabledReferenceCounter;                        // 0x0BE8 (size: 0x20)
    FSF_ReferenceCounterHandle ForceFeedbackBlocker_PauseMenu;                        // 0x0C08 (size: 0x20)
    FSF_ReferenceCounterHandle ForceFeedbackBlocker_GameMenu;                         // 0x0C28 (size: 0x20)
    FSF_ReferenceCounterHandle SaveBlocker_Debug;                                     // 0x0C48 (size: 0x20)
    FSF_ReferenceCounterHandle InteractBlocker_SavePoint;                             // 0x0C68 (size: 0x20)
    FSF_ReferenceCounterHandle ForceFeedbackBlocker_SavePoint;                        // 0x0C88 (size: 0x20)
    FSF_ReferenceCounterHandle PauseBlock_SavePoint;                                  // 0x0CA8 (size: 0x20)
    FSF_ReferenceCounterHandle UIInputLockBlockerReference;                           // 0x0CC8 (size: 0x20)
    FSF_ReferenceCounterHandle BattleInputLockBlockerReference;                       // 0x0CE8 (size: 0x20)
    FSF_ReferenceCounterHandle TransitionInputLockBlockerReference;                   // 0x0D08 (size: 0x20)
    FSF_ReferenceCounterHandle SavePointInputLockBlockerReference;                    // 0x0D28 (size: 0x20)
    FSF_ReferenceCounterHandle ChangingMapInputLockBlockerReference;                  // 0x0D48 (size: 0x20)
    FSF_ReferenceCounter EnabledStreamingSourcesReferenceCounte;                      // 0x0D68 (size: 0x20)
    FSF_ReferenceCounterHandle PauseBlocker_FullscreenNotification;                   // 0x0D88 (size: 0x20)
    FSF_ReferenceCounterHandle ForceFeedbackBlocker_FullscreenNotification;           // 0x0DA8 (size: 0x20)
    FSF_ReferenceCounterHandle InteractBlocker_FullscreenNotification;                // 0x0DC8 (size: 0x20)
    bool IsChangingArea;                                                              // 0x0DE8 (size: 0x1)
    class UWBP_PlatformPauseModal_C* PlatformPauseWidget;                             // 0x0DF0 (size: 0x8)
    bool PlatformIsPaused;                                                            // 0x0DF8 (size: 0x1)
    FFBattleStartParams local_lastEncounterSettings;                                  // 0x0E00 (size: 0x158)
    FBP_jRPG_Controller_World_COnBattleFinished OnBattleFinished;                     // 0x0F58 (size: 0x10)
    void OnBattleFinished(bool Victory);
    FS_BattleInitialState PreviousBattleInitialState;                                 // 0x0F68 (size: 0x40)
    bool IsTakingActionInBattle;                                                      // 0x0FA8 (size: 0x1)

    void ForceApplyCameraViewTarget();
    void HandleInputsOnPause(bool IsInPause);
    void ReloadLastCheckpoint(FS_LoadGameOverrideParameters LoadGameOverrideParameters);
    void CreateDynamicCameraManager();
    void HandlePauseWidget(bool ShouldPause);
    void IsAreaChangeInProgress(bool& ReturnNode);
    void PauseOnFullScreenNotification(bool IsPaused);
    void SetStreamingSourcesEnabled(bool Enabled, FSF_ReferenceCounterHandle& BlockerReferenceHandle, FString DebugName);
    bool AreStreamingSourcesEnabled();
    void SetMiniMapVisible(bool Visible);
    void OnDismountRequested();
    void IsForceFeedbackEnabled(bool& Enabled);
    void SetForceFeedbackEnabled(bool Enabled, FSF_ReferenceCounterHandle& ForceFeedbackBlocker, FString DebugName);
    bool ShouldProcessForceFeedbackAndHaptics();
    void GetDialogueOverlay(class UWBP_DialogueOverlay_C*& DialogueOverlay);
    bool IsAnyMenuVisible();
    void GetPauseMenuWidget(class UWBP_PauseMenu_C*& PauseMenuWidget);
    bool CanOpenTeamOverlay();
    void ResumeWorldAfterTransition();
    void PrepareWorldForTransition();
    void CleanAndQuit();
    void MakePauseMenuVisible(bool InIsVisible);
    bool CanOpenPauseMenu();
    void ResetBattleComponents();
    void GetDebugLightingScenario(class ABP_LightingScenarioReference_C*& LightingScenario);
    void ResumeWorldActorsAfterBattle();
    void PrepareSystemsForBattle();
    void PrepareLightingForBattle();
    void HideWorldActorsAroundBattleMap();
    void PrepareWorldActorsForBattle();
    void PrepareCharacterForBattle();
    void DisableExplorationControlsForBattle();
    void ResetBattleState();
    void OnBattleFlee(FName EnemyGlobalID);
    void ResumeExplorationOnBattleEnd(FName EnemyGlobalID, TEnumAsByte<EBattleEndResult::Type> BattleEndResult);
    void OnBattleStart();
    void OnBattleDependenciesLoaded();
    void OnBattleRequested();
    bool IsInBattle();
    bool CanStartBattle();
    void OnBattleBeginTransitionRequested();
    bool IsInBattleBeginTransition();
    void CloseDocumentActor();
    void OpenDocumentActor();
    void CloseSavePointMenu(bool IsFromGameplay);
    void OpenSavePointMenu(bool IsFromGameplay);
    void ParseCommandLine();
    void CreateWidgets();
    void ForcePreloadAssets();
    void StartNewGameIfNeeded();
    void ApplyUserSettings();
    void DEBUG_ApplyCharacterDebugSaveOverrides(FFDebugSaveGame InputPin, FFDebugSaveGame& OutputPin);
    void DEBUG_FindAsset(FName AssetName, FSoftClassPath ClassSoft, bool& Found, FAssetData& Array Element);
    void UpdateAudioListenerOverride();
    void DEBUG_UpdateDisplay(double DeltaSeconds);
    void TeleportCharacterToSpawnPoint();
    void ProcessAreaChanged();
    void PrepareToChangeMap(FFLevelDataEntry& LevelData);
    void UnpauseGameplay();
    void PauseGameplay(FS_GameplayPauseParameters Parameters);
    void ShouldPauseActor(const class AActor*& Actor, FS_GameplayPauseParameters& PauseParameters, bool& ShouldPause);
    void UpdateCameraViewTarget();
    void UpdateControlRotationFromView();
    void CompareCameraOverrideParametersByPriority(FS_CameraOverrideParameters A, FS_CameraOverrideParameters B, class UOrderingResult* OrderingResult);
    bool DEBUG_IsWeaponInHandleList(FName WeaponID, TArray<FS_WeaponInstanceHandle>& WeaponInstanceHandle);
    void RollEncounter(double InputScale);
    void SetLevelLightingHiddenForGameMenu(bool Hidden);
    void DEBUG_CVarChange_DebugCustomPause(bool NewValue);
    void SetActorTickPaused(const class AActor*& Actor, const TArray<AActor*>& AlreadyPausedActors, const TArray<UActorComponent*>& AlreadyPausedComponents, FS_GameplayPauseParameters& PauseParameters);
    void SetGameplayPaused(FS_GameplayPauseParameters Parameters, FSF_ReferenceCounterHandle& PauseBlocker, FString DebugName);
    void IsGameplayPaused(bool& IsPaused);
    void GetCurrentLevelData(FFLevelDataEntry& LevelData);
    void RemoveCameraOverride(class AActor* ViewTarget);
    void AddCameraOverrideRequest(FS_CameraOverrideParameters CameraOverrideParameters);
    void GetCameraOverrideActor(class AActor*& CameraOverrideActor);
    void HasCameraOverride(bool& HasOverride);
    bool CanReceiveExplorationDamage();
    void GetPlayerCharacter(class ABP_jRPG_Character_World_C*& AsBP J RPG Character World);
    void DEBUG_FindDebugSaveAsset(FName AssetName, FAssetData& Array Element);
    void DEBUG_GetAllPreviousQuestObjectives(FName QuestName, FName QuestObjectiveName, TEnumAsByte<E_QuestStatus::Type> Status, TMap<FName, TEnumAsByte<E_QuestStatus::Type>>& Objectives);
    void DEBUG_PatchDebugSaveDataBeforeLoading(FFDebugSaveGame& SaveData);
    void DEBUG_LoadDebugQuestData(class UBP_SaveGameData_C* SaveGameData, TMap<FName, TEnumAsByte<E_QuestStatus::Type>> GoldenPathObjectives);
    void DEBUG_LoadDebugSaveData(FFDebugSaveGame SaveData);
    void LoadCharacterStateFromGameInstance(class AActor* ControlledCharacterWorld);
    void SetInputModeUI(bool UIModeEnabled, bool ConfigureUI_Navigation);
    void SetInputModeBattle(bool IsTakingAction);
    void GetCustomGameInstance(class UBP_jRPG_GI_Custom_C*& BP J RPG GI Custom);
    void GetClosestLightingScenario(FVector Location, class ABP_LightingScenarioReference_C*& LightingScenario);
    bool CanOpenGameMenu();
    void ForceInputForTutorial(TEnumAsByte<EInputAction::Type> InputAction, const FForceInputForTutorialOnGameActionDone& OnGameActionDone);
    void AxisInputThreshold(double AxisValue, int32& Value);
    void DEBUG_TriggerCVarOnGameStart();
    void DEBUG_RegisterCVars();
    void UserConstructionScript();
    void InpActEvt_L_K2Node_InputKeyEvent_0(FKey Key);
    void InpActEvt_IA_UI_Menu_Game_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UI_Menu_Pause_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UI_Exploration_ShowTeamStatus_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Battle_QTE_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Battle_Defense_Jump_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Battle_Defense_JumpCounter_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Battle_Defense_GradientCounter_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Battle_Defense_Parry_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Battle_Defense_Dodge_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteGameActionWrapperController(FGameAction_Wrapper GameActionWrapper);
    void DEBUG_GivePictos();
    void DEBUG_CVarChange_GivePictosOnBoot(bool NewValue);
    void DEBUG_OnRaytraceMouseCVarChanged(bool NewValue);
    void DEBUG_UnlockAllLuminaPassives();
    void DEBUG_CVarChange_LearnAllLuminasOnBoot(bool NewValue);
    void DEBUG_CVarChange_SingleCharacterParty(FString NewValue);
    void DEBUG_LoadDebugSaveGameAsset(FName AssetName);
    void DEBUG_CVarChange_ShowClimbableProps(bool Enabled);
    void DEBUG_CVarChange_ShowGameActionTree(bool NewValue);
    void DEBUG_CVarChange_EnableAutoSave(bool NewValue);
    void DEBUG_CVarChange_HideUI(bool Value);
    void DEBUG_CVarChange_DiegeticQTE(bool NewValue);
    void TryBindDefendInput();
    void OnDefendAction();
    void OnDefendReleased();
    void MakeGameMenuVisible(bool Visible, FS_GameMenuParameters GameMenuParameters);
    void OpenMainMenu();
    void InputAction_UI_OpenGameMenu();
    void UnbindDefendInput();
    void ReturnFromGameMenuWorld();
    void BackToTitleMenu();
    void OnControllerConnectionChanged(bool bIsConnected);
    void OnPlatformPaused(bool bShouldPause);
    void BndEvt__BP_jRPG_Controller_World_BP_CinematicSystem_K2Node_ComponentBoundEvent_0_OnCinematicRequested__DelegateSignature();
    void BndEvt__BP_jRPG_Controller_World_BP_CinematicSystem_K2Node_ComponentBoundEvent_1_EventWhenTriggeringCinematic__DelegateSignature();
    void OnAppLostFocus(bool LostFocus);
    void OpenPauseMenu();
    void ShowInteractionPopUp(FText TextToDisplay);
    void HideInteractionPopUp();
    void ReceiveBeginPlay();
    void PlayGlobalFeedback(FFGlobalFeedback Feedback);
    void EventDoSpawnActor();
    void PlaceholderTriggerTutorialInput();
    void ReceiveTeamDamage(TEnumAsByte<EExplorationHealthDamageType::Type> DamageType, int32 Value);
    void ShowGameOverScreen();
    void OnExplorationGroupDeath();
    void OnAreaChanged(class ABP_jRPG_Character_World_C* CharacterWorld, class ABP_LightingScenarioReference_C* LightingScenario, FS_AreaAudioParameters AreaAudioParameters, FS_ChangeLevelParameters ChangeLevelParameters);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void HealParty();
    void ReceivePossess(class APawn* PossessedPawn);
    void ProcessAreaChangedForAudio(const FS_AreaAudioParameters& AreaAudioParameters);
    void BndEvt__BP_jRPG_Controller_World_BP_DialogueSystemComponent_K2Node_ComponentBoundEvent_0_OnDialogueFinished__DelegateSignature(class ABP_Dialogue_C* Dialogue);
    void OnBackToExplorationFromPause();
    void OnQuitRequest();
    void RestartCurrentEncounter(FS_BattleInitialState InitialState);
    void OnGameOverScreenClosed();
    void ExecuteUbergraph_BP_jRPG_Controller_World(int32 EntryPoint);
    void OnBattleFinished__DelegateSignature(bool Victory);
    void OnPauseMenuClosed__DelegateSignature();
    void OnPauseMenuOpened__DelegateSignature();
    void OnDocumentActorClosed__DelegateSignature();
    void OnDocumentActorOpened__DelegateSignature();
    void OnSavePointMenuClosed__DelegateSignature();
    void OnSavePointMenuOpened__DelegateSignature();
    void OnTargetViewAboutToChanged__DelegateSignature(class AActor* PreviousViewTarget, class AActor* CurrentViewTarget);
    void Dummy_SortCameraOverrideParameters__DelegateSignature(FS_CameraOverrideParameters A, FS_CameraOverrideParameters B, class UOrderingResult* OrderingResult);
    void OnMainMenuOpened__DelegateSignature();
    void OnMainMenuClosed__DelegateSignature();
    void PlaceholderTutorialInput__DelegateSignature();
    void VendorWindowClosed__DelegateSignature();
    void TriggerLeftPressed__DelegateSignature();
}; // Size: 0xFA9

#endif
