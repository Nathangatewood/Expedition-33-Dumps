#ifndef UE4SS_SDK_BP_GPE_Orchestrator_HPP
#define UE4SS_SDK_BP_GPE_Orchestrator_HPP

class ABP_GPE_Orchestrator_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBP_GPE_IndexSelectorComponent_C* BP_GPE_IndexSelectorComponent;            // 0x0298 (size: 0x8)
    class UBP_GPE_InternalActivationComponent_C* BP_GPEInternalActivationComponent;   // 0x02A0 (size: 0x8)
    class UBP_GPE_DebugComponent_C* BP_GPEDebugComponent;                             // 0x02A8 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x02B0 (size: 0x8)
    FGPEInterfacesReferences GameplayElementsToActivate;                              // 0x02B8 (size: 0x10)
    TEnumAsByte<E_GPE_OrchestratorMode::Type> Mode;                                   // 0x02C8 (size: 0x1)
    bool ActivateGPE_AllAtOnce;                                                       // 0x02C9 (size: 0x1)
    bool ResetCurrentGPE_OrderOnDeactivate;                                           // 0x02CA (size: 0x1)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void GPETrigger_GetGameplayElementsToActivate(FGPEInterfacesReferences& GameplayElementsToActivate);
    void GPE_GetActivationComponent(class UBP_GPE_InternalActivationComponent_C*& ActivationComponent);
    void DeactivateGPEInternal(TScriptInterface<class IBPI_GPE_Interface_C> GPE);
    void Activate GPEInternal(TScriptInterface<class IBPI_GPE_Interface_C> GPE);
    void UserConstructionScript();
    void ProcessTickOrchestrator(class UBP_GPE_InternalActivationComponent_C* GPE);
    void ProcessDeactivateOrchestrator(class UBP_GPE_InternalActivationComponent_C* GPE);
    void ReceiveBeginPlay();
    void OnTickOrchestrator();
    void BndEvt__BP_GPE_Orchestrator_BP_GPEInternalActivationComponent_K2Node_ComponentBoundEvent_0_OnActivationChanged__DelegateSignature(bool Activated);
    void ExecuteUbergraph_BP_GPE_Orchestrator(int32 EntryPoint);
}; // Size: 0x2CB

#endif
