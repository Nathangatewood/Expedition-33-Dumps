#ifndef UE4SS_SDK_BP_InteractiveBattleMusicController_HPP
#define UE4SS_SDK_BP_InteractiveBattleMusicController_HPP

class UBP_InteractiveBattleMusicController_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    double AlliesHealthRatio;                                                         // 0x0030 (size: 0x8)
    double EnemiesHealthRatio;                                                        // 0x0038 (size: 0x8)

    void OnCharacterDealtDamages(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, double Damages, double& ProcessedDamages);
    void IsTurnStartInProgress(bool& InProgress);
    void UpdateHealthAudioTriggers();
    void ComputeHealthRatioForCharacters(const TArray<ABP_jRPG_Character_Battle_Base_C*>& Characters, double& Ratio);
    void UpdateHealthRatio();
    void OnBattleStop();
    void OnCharacterKilled(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterResurrected();
    void ProcessAddBuffAction(const class UAction_AddBuff_C*& BuffAddAction);
    void OnSuccessfulParry();
    void OnSuccessfulDodge();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void BPI_OnAnyCharacterDamaged(class UBP_BattleDamages_C* BattleDamage);
    void BPI_OnAnyCharacterAP_Changed(class UBP_BattleEvent_APChange_C* AP_Change);
    void BPI_OnBattleStart();
    void BPI_OnReserveTeamSent();
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void ExecuteUbergraph_BP_InteractiveBattleMusicController(int32 EntryPoint);
}; // Size: 0x40

#endif
