#ifndef UE4SS_SDK_BP_GPE_OrchestratorComponent_Base_HPP
#define UE4SS_SDK_BP_GPE_OrchestratorComponent_Base_HPP

class UBP_GPE_OrchestratorComponent_Base_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FBP_GPE_OrchestratorComponent_Base_CTickOrchestrator TickOrchestrator;            // 0x00A8 (size: 0x10)
    void TickOrchestrator();

    void StartOrchestrator();
    void StopOrchestrator();
    void ExecuteUbergraph_BP_GPE_OrchestratorComponent_Base(int32 EntryPoint);
    void TickOrchestrator__DelegateSignature();
}; // Size: 0xB8

#endif
