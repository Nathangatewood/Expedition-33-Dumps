#ifndef UE4SS_SDK_BP_GameAction_RequestSaveGame_HPP
#define UE4SS_SDK_BP_GameAction_RequestSaveGame_HPP

class UBP_GameAction_RequestSaveGame_C : public UBP_PDT_GameAction_C
{

    TSubclassOf<class UGameActionInstance> GetInstanceClass();
}; // Size: 0x30

#endif
