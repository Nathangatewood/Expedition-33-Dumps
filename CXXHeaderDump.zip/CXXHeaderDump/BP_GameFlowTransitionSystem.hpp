#ifndef UE4SS_SDK_BP_GameFlowTransitionSystem_HPP
#define UE4SS_SDK_BP_GameFlowTransitionSystem_HPP

class UBP_GameFlowTransitionSystem_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FS_GameFlowTransitionState TransitionState;                                       // 0x00A8 (size: 0x30)
    double DefaultWaitTime;                                                           // 0x00D8 (size: 0x8)
    double DefaultFadeOutTime;                                                        // 0x00E0 (size: 0x8)
    FBP_GameFlowTransitionSystem_COnWaitCompleted OnWaitCompleted;                    // 0x00E8 (size: 0x10)
    void OnWaitCompleted();
    class UWBP_BattleTransition_C* TransitionWidget;                                  // 0x00F8 (size: 0x8)
    FBP_GameFlowTransitionSystem_COnFadeInCompleted OnFadeInCompleted;                // 0x0100 (size: 0x10)
    void OnFadeInCompleted();
    FBP_GameFlowTransitionSystem_COnFadeOutCompleted OnFadeOutCompleted;              // 0x0110 (size: 0x10)
    void OnFadeOutCompleted();
    bool IsGameplayPaused;                                                            // 0x0120 (size: 0x1)
    FSF_ReferenceCounterHandle PauseBlocker;                                          // 0x0128 (size: 0x20)
    FSF_ReferenceCounterHandle InteractionBlocker;                                    // 0x0148 (size: 0x20)
    FSF_ReferenceCounterHandle TransitionInputLockBlockerReference;                   // 0x0168 (size: 0x20)

    void SetGameplayPaused(bool Paused);
    double GetFadeAmountDuringFadeOut();
    void StopBlackScreenTransition();
    void UpdateWait();
    void OnTransitionPhaseChange();
    void SetTransitionPhase(TEnumAsByte<E_GameFlowTransitionPhase::Type> Phase);
    void ValidateTransitionRequest(FS_GameFlowTransitionRequest& TransitionRequest);
    void SetIsTransitionInHold(bool Hold);
    void ReleaseTransition(double OverrideFadeOutTransition);
    void GetTransitionPhase(TEnumAsByte<E_GameFlowTransitionPhase::Type>& Phase);
    bool IsTransitionStateValid();
    void HoldTransition();
    void StopTransitionOfType(TEnumAsByte<S_GameFlowTransitionType::Type> TransitionType);
    void UpdateBlackScreenFadeOut();
    void UpdateFadeOutOfType(TEnumAsByte<S_GameFlowTransitionType::Type> TransitionType);
    void RequestTransition(const FS_GameFlowTransitionRequest& TransitionRequest);
    void UpdateBlackScreenFadeIn();
    void UpdateFadeInOfType(TEnumAsByte<S_GameFlowTransitionType::Type> TransitionType);
    void StartNewTransition(FS_GameFlowTransitionRequest TransitionRequest);
    void UpdateElapsedTime(double ElapsedSeconds);
    void UpdateFadeOutTransitionOfType(TEnumAsByte<S_GameFlowTransitionType::Type> TransitionType);
    void UpdateCurrentTransition(double ElapsedSeconds);
    void UpdateTransitionSystem(double DeltaSeconds);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_GameFlowTransitionSystem(int32 EntryPoint);
    void OnFadeOutCompleted__DelegateSignature();
    void OnFadeInCompleted__DelegateSignature();
    void OnWaitCompleted__DelegateSignature();
}; // Size: 0x188

#endif
