#ifndef UE4SS_SDK_BP_ItemSorterAbstract_HPP
#define UE4SS_SDK_BP_ItemSorterAbstract_HPP

class UBP_ItemSorterAbstract_C : public UExtendedObject
{
    FBP_ItemSorterAbstract_CDummy_SortItemInstances Dummy_SortItemInstances;          // 0x0028 (size: 0x10)
    void Dummy_SortItemInstances(class UBP_ItemInstance_Base_C* A, class UBP_ItemInstance_Base_C* B, class UOrderingResult* OrderingResult);

    void ExecuteSorter(const TArray<UBP_ItemInstance_Base_C*>& ItemInstances);
    void GetDisplayName(FText& DisplayName);
    void SortItemInstances(class UBP_ItemInstance_Base_C* A, class UBP_ItemInstance_Base_C* B, class UOrderingResult* Result);
    void Dummy_SortItemInstances__DelegateSignature(class UBP_ItemInstance_Base_C* A, class UBP_ItemInstance_Base_C* B, class UOrderingResult* OrderingResult);
}; // Size: 0x38

#endif
