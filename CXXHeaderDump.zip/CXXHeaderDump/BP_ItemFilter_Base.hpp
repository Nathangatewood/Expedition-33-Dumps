#ifndef UE4SS_SDK_BP_ItemFilter_Base_HPP
#define UE4SS_SDK_BP_ItemFilter_Base_HPP

class UBP_ItemFilter_Base_C : public UExtendedObject
{

    void GetCompatibleItemSorters(TArray<TSubclassOf<class UBP_ItemSorterAbstract_C>>& ItemSorters);
    void ExecuteFilter(const TArray<UBP_ItemInstance_Base_C*>& ItemInstances, TArray<UBP_ItemInstance_Base_C*>& FilteredItemInstances);
    void GetDisplayName(FText& DisplayName);
}; // Size: 0x28

#endif
