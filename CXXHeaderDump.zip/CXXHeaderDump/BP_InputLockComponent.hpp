#ifndef UE4SS_SDK_BP_InputLockComponent_HPP
#define UE4SS_SDK_BP_InputLockComponent_HPP

class UBP_InputLockComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FSF_ReferenceCounter MovementAndCameraLockReferenceCounter;                       // 0x00A8 (size: 0x20)
    FSF_ReferenceCounter MovementOnlyLockReferenceCounter;                            // 0x00C8 (size: 0x20)
    FSF_ReferenceCounter CameraOnlyLockReferenceCounter;                              // 0x00E8 (size: 0x20)
    FBP_InputLockComponent_COnInputLocksUpdated OnInputLocksUpdated;                  // 0x0108 (size: 0x10)
    void OnInputLocksUpdated();

    void OnAnyInputLockChanged(bool _isActive);
    bool IsCameraInputLocked();
    bool IsMovementInputLocked();
    void RemoveInputLock(FS_InputLockParameters Parameters, FSF_ReferenceCounterHandle& InputLockBlocker);
    void AddInputLock(FS_InputLockParameters Parameters, FSF_ReferenceCounterHandle& InputLockBlocker, FString DebugName);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_InputLockComponent(int32 EntryPoint);
    void OnInputLocksUpdated__DelegateSignature();
}; // Size: 0x118

#endif
