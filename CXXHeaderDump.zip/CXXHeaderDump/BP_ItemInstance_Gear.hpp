#ifndef UE4SS_SDK_BP_ItemInstance_Gear_HPP
#define UE4SS_SDK_BP_ItemInstance_Gear_HPP

class UBP_ItemInstance_Gear_C : public UBP_ItemInstance_Base_C
{
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> CurrentStats;                    // 0x0178 (size: 0x50)
    int32 CurrentLevel;                                                               // 0x01C8 (size: 0x4)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> BaseStatsMultipliers;            // 0x01D0 (size: 0x50)

    class UBP_ItemInstance_Gear_C* CreateCopy();
    int32 GetChromaValue();
    void TryUpgradeLevel(int32 NewLevel, bool& HasUpgraded);
    void GetUnlockedPassiveEffectsIDs(TArray<FName>& PassiveEffectIDs);
    void MergeItem(class UBP_ItemInstance_Base_C* OtherItemInstance);
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> GetBaseStatsMultipliers();
    void LoadItemDefinition();
    void GetStatBaseValue();
    void LoadState(FS_WeaponInstanceHandle SaveData);
    void SaveState(FS_WeaponInstanceHandle SaveData);
    void GetCurrentQuality(TEnumAsByte<EWeaponQuality::Type>& Quality);
    void UpgradeLevel(FString DebugReason);
    void ChangeLevelWithLootContext(FS_LootContext LootContext, FString DebugReason);
    void ChangeLevel(int32 NewLevel, FString DebugReason);
    class UDataTable* GetScalingDataTable();
    TSubclassOf<class UBP_GeneratedItemInfo_UpgradableItem_C> GetGearGeneratedItemClass();
    void SetBaseStatsMultiplier(const TEnumAsByte<E_jRPG_StatType::Type> Stat, const double Value);
    void SetCurrentStatValue(const TEnumAsByte<E_jRPG_StatType::Type> StatType, const double& Value, FString Reason);
    void RefreshCurrentGearStats();
    void LoadBaseStatsMultipliers();
    void GenerateItem(FS_jRPG_Item_StaticData& ItemStaticItem, FS_LootContext& LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItemInfo);
    int32 GetCurrentLevel();
    void GetCurrentStats(TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& CurrentStats);
}; // Size: 0x220

#endif
