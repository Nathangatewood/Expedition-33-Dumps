#ifndef UE4SS_SDK_BP_jRPG_Enemy_World_Base_Seamless_HPP
#define UE4SS_SDK_BP_jRPG_Enemy_World_Base_Seamless_HPP

class ABP_jRPG_Enemy_World_Base_Seamless_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UBoxComponent* FreeAimBoxCollision;                                         // 0x0678 (size: 0x8)
    class UAudioComponent* ACWeaponL01;                                               // 0x0680 (size: 0x8)
    class UAudioComponent* ACWeaponR01;                                               // 0x0688 (size: 0x8)
    class UAudioComponent* ACWeaponL02;                                               // 0x0690 (size: 0x8)
    class UAudioComponent* ACHandL01;                                                 // 0x0698 (size: 0x8)
    class USceneComponent* Hand_L;                                                    // 0x06A0 (size: 0x8)
    class UAudioComponent* ACHandR01;                                                 // 0x06A8 (size: 0x8)
    class USceneComponent* Hand_R;                                                    // 0x06B0 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_foot_right; // 0x06B8 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_foot_left; // 0x06C0 (size: 0x8)
    class UBP_Enemy_SerializableComponent_C* BP_Enemy_SerializableComponent;          // 0x06C8 (size: 0x8)
    class UBP_SmartObjectInteractorComponent_C* BP_SmartObjectInteractorComponent;    // 0x06D0 (size: 0x8)
    class UBP_RandomVariation_C* BP_RandomColor;                                      // 0x06D8 (size: 0x8)
    class UAudioComponent* Weapon_Small_LP;                                           // 0x06E0 (size: 0x8)
    class UAudioComponent* Weapon_Heavy_LP;                                           // 0x06E8 (size: 0x8)
    class UStaticMeshComponent* weapon_r;                                             // 0x06F0 (size: 0x8)
    class UStaticMeshComponent* weapon_l;                                             // 0x06F8 (size: 0x8)
    class UMotionWarpingComponent* StartMotionWarp;                                   // 0x0700 (size: 0x8)
    class UBP_RoamingAiComponent_C* BP_RoamingAiComponent;                            // 0x0708 (size: 0x8)
    class UAudioComponent* AC_Idle;                                                   // 0x0710 (size: 0x8)
    class UAudioComponent* AC_SFX_02;                                                 // 0x0718 (size: 0x8)
    class UAudioComponent* AC_Foleys_02;                                              // 0x0720 (size: 0x8)
    class UAudioComponent* AC_FT_R;                                                   // 0x0728 (size: 0x8)
    class UAudioComponent* AC_Vocal_02;                                               // 0x0730 (size: 0x8)
    class UAudioComponent* AC_SFX_01;                                                 // 0x0738 (size: 0x8)
    class UAudioComponent* AC_Foleys_01;                                              // 0x0740 (size: 0x8)
    class UAudioComponent* AC_FT_L;                                                   // 0x0748 (size: 0x8)
    class UAudioComponent* AC_Vocal_01;                                               // 0x0750 (size: 0x8)
    class UBP_AudioCharacter_Manager_C* BP_AudioCharacter_Manager;                    // 0x0758 (size: 0x8)
    class USphereComponent* PPBattleTransitionZone;                                   // 0x0760 (size: 0x8)
    class UArrowComponent* PromptLocation;                                            // 0x0768 (size: 0x8)
    class UNiagaraComponent* StunFX;                                                  // 0x0770 (size: 0x8)
    class UArrowComponent* Arrow1;                                                    // 0x0778 (size: 0x8)
    class UCapsuleComponent* EncounterCapsuleRange;                                   // 0x0780 (size: 0x8)
    class UNiagaraComponent* NS_Sparks_ToughEnemy;                                    // 0x0788 (size: 0x8)
    class UAC_InteractionCheck_C* AC_InteractionCheck;                                // 0x0790 (size: 0x8)
    float Timeline_0_NewTrack_0_FF1BABD84E0F05C82447F48EFFD07FA9;                     // 0x0798 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_FF1BABD84E0F05C82447F48EFFD07FA9; // 0x079C (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x07A0 (size: 0x8)
    bool EnableDetection;                                                             // 0x07A8 (size: 0x1)
    double EncounterRadius;                                                           // 0x07B0 (size: 0x8)
    class ABP_jRPG_Character_World_C* LastPlayerCharacterSeen;                        // 0x07B8 (size: 0x8)
    TArray<FDataTableRowHandle> PossibleEncounters;                                   // 0x07C0 (size: 0x10)
    FDataTableRowHandle SelectedEncounter;                                            // 0x07D0 (size: 0x10)
    TArray<FName> DEPRECATED_PossibleEncounters;                                      // 0x07E0 (size: 0x10)
    TSoftObjectPtr<class ABP_BattleMap_C> BattleMap_BP;                               // 0x07F0 (size: 0x28)
    TArray<UDataLayerAsset*> BattleMapDataLayers;                                     // 0x0818 (size: 0x10)
    class UBP_PDT_GameAction_C* GameActionPostBattle;                                 // 0x0828 (size: 0x8)
    FS_MusicParameters BattleMusicParameters;                                         // 0x0830 (size: 0x30)
    FFSoundEvent BattleMusic;                                                         // 0x0860 (size: 0x8)
    FS_RangedAmbienceParameters BattleAmbienceParameters;                             // 0x0868 (size: 0x10)
    bool RespawnsOnRest;                                                              // 0x0878 (size: 0x1)
    bool Boss?;                                                                       // 0x0879 (size: 0x1)
    class UBP_jRPG_GI_Custom_C* GameInstanceReference;                                // 0x0880 (size: 0x8)
    bool ToughEnemy;                                                                  // 0x0888 (size: 0x1)
    FVector OriginalLocation;                                                         // 0x0890 (size: 0x18)
    bool FleeImpossible;                                                              // 0x08A8 (size: 0x1)
    bool IsChasingPlayer;                                                             // 0x08A9 (size: 0x1)
    double RoamingSpeed;                                                              // 0x08B0 (size: 0x8)
    bool IsRoamingWhenIdle;                                                           // 0x08B8 (size: 0x1)
    double IdleRoamingRadius;                                                         // 0x08C0 (size: 0x8)
    double MovementSpeed;                                                             // 0x08C8 (size: 0x8)
    class UAC_jRPG_BattleManager_C* BattleManagerRef;                                 // 0x08D0 (size: 0x8)
    bool IsAlreadyHitByWorldStrike;                                                   // 0x08D8 (size: 0x1)
    double FreezeDuration;                                                            // 0x08E0 (size: 0x8)
    bool IsStun;                                                                      // 0x08E8 (size: 0x1)
    class AController_WorldAI_C* ControllerRef;                                       // 0x08F0 (size: 0x8)
    class UBehaviorTree* WaitBehaviorTree;                                            // 0x08F8 (size: 0x8)
    class UBehaviorTree* ChaseBehaviorTree;                                           // 0x0900 (size: 0x8)
    bool CanBeStun;                                                                   // 0x0908 (size: 0x1)
    double StunDurationFreeAimShoot;                                                  // 0x0910 (size: 0x8)
    TSoftObjectPtr<class ATargetPoint> WaitingPoint;                                  // 0x0918 (size: 0x28)
    TEnumAsByte<E_AiStates::Type> MainState;                                          // 0x0940 (size: 0x1)
    TEnumAsByte<E_EnemyIdleState::Type> CurrentIdleState;                             // 0x0941 (size: 0x1)
    bool CanPlaySpottedSound;                                                         // 0x0942 (size: 0x1)
    FVector CamOriginalLocation;                                                      // 0x0948 (size: 0x18)
    bool PlayBattleCameraIntro?;                                                      // 0x0960 (size: 0x1)
    class UBehaviorTree* DetectPlayerBehaviorTree;                                    // 0x0968 (size: 0x8)
    FRotator targetLookAtRot;                                                         // 0x0970 (size: 0x18)
    bool is rotating to player;                                                       // 0x0988 (size: 0x1)
    double DetectionDistance;                                                         // 0x0990 (size: 0x8)
    double VisionAngle;                                                               // 0x0998 (size: 0x8)
    double DetectionDistancePeripheral;                                               // 0x09A0 (size: 0x8)
    double AggroVisionRange;                                                          // 0x09A8 (size: 0x8)
    class UBehaviorTree* StunBehaviorTree;                                            // 0x09B0 (size: 0x8)
    bool Back to Exploration on Lost;                                                 // 0x09B8 (size: 0x1)
    bool LookAtPlayer;                                                                // 0x09B9 (size: 0x1)
    bool LookAtPlayerAllTheTime;                                                      // 0x09BA (size: 0x1)
    class USoundBase* CanBeStunHitSound;                                              // 0x09C0 (size: 0x8)
    class USoundBase* CantBeStunHitSound;                                             // 0x09C8 (size: 0x8)
    bool PP_Transition_Battle;                                                        // 0x09D0 (size: 0x1)
    bool CanBeAttacked;                                                               // 0x09D1 (size: 0x1)
    class USoundBase* CanBeAttackHitFeedBack;                                         // 0x09D8 (size: 0x8)
    class UNiagaraSystem* CanBeAttackHitFx1;                                          // 0x09E0 (size: 0x8)
    class UNiagaraSystem* CanBeAttackHitFx2;                                          // 0x09E8 (size: 0x8)
    class UNiagaraSystem* StunFXhit;                                                  // 0x09F0 (size: 0x8)
    bool ShouldDisplayAttackPrompt;                                                   // 0x09F8 (size: 0x1)
    FFPromptParams Prompt Params;                                                     // 0x0A00 (size: 0x18)
    bool DebugMe;                                                                     // 0x0A18 (size: 0x1)
    FFSoundEvent SD_WorldStrikeHit;                                                   // 0x0A20 (size: 0x8)
    bool HasBeenAttacked;                                                             // 0x0A28 (size: 0x1)
    FFSoundEvent SD_WorldSound;                                                       // 0x0A30 (size: 0x8)
    double WorldSound_LowerDelay;                                                     // 0x0A38 (size: 0x8)
    double WorldSound_MaxDelay;                                                       // 0x0A40 (size: 0x8)
    FBP_jRPG_Enemy_World_Base_Seamless_COnAggroBegin OnAggroBegin;                    // 0x0A48 (size: 0x10)
    void OnAggroBegin(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class ACharacter* AggroedCharacter);
    TArray<FName> AggroLocks;                                                         // 0x0A58 (size: 0x10)
    float ExtraDelayBeforeChase;                                                      // 0x0A68 (size: 0x4)
    TArray<UPrimitiveComponent*> ActiveVisionPrimitives;                              // 0x0A70 (size: 0x10)
    FTimerHandle Timer_StopEnterChaseMode_Hysteresis;                                 // 0x0A80 (size: 0x8)
    FTimerHandle Timer_PlayerLeftVision_Hysteresis;                                   // 0x0A88 (size: 0x8)
    FTimerHandle Timer_ForcedAggro;                                                   // 0x0A90 (size: 0x8)
    TArray<TSoftObjectPtr<class ABP_GameplayRoom_C>> RoomsRequiredForAggro;           // 0x0A98 (size: 0x10)
    TArray<TSoftObjectPtr<class ABP_GameplayRoom_C>> RoomsTriggeringAggro;            // 0x0AA8 (size: 0x10)
    TArray<ABP_GameplayRoom_C*> RoomsRequiredForAggroHardRef;                         // 0x0AB8 (size: 0x10)
    TArray<ABP_GameplayRoom_C*> RoomsTriggeringAggroHardRef;                          // 0x0AC8 (size: 0x10)
    bool PlayerCharacterMatchesRoomRequirement;                                       // 0x0AD8 (size: 0x1)
    class ABP_jRPG_Character_World_C* CharacterInVisionRange;                         // 0x0AE0 (size: 0x8)
    TArray<UObject*> CustomScriptSources;                                             // 0x0AE8 (size: 0x10)
    bool LODOptimizationActive;                                                       // 0x0AF8 (size: 0x1)
    double AggroMaxRange;                                                             // 0x0B00 (size: 0x8)
    bool DEBUG_ShowAggroRange;                                                        // 0x0B08 (size: 0x1)
    bool UseMaxRadiusForCurrentAggro;                                                 // 0x0B09 (size: 0x1)
    bool DEBUG_DebugFlag;                                                             // 0x0B0A (size: 0x1)
    bool HasCharacterInVisionCones;                                                   // 0x0B0B (size: 0x1)
    double DetectionProgressDuration;                                                 // 0x0B10 (size: 0x8)
    double DetectionForgetProgressDuration;                                           // 0x0B18 (size: 0x8)
    bool LookAtPlayerWhenChasing;                                                     // 0x0B20 (size: 0x1)
    bool NoEndChaseOnEndOverlap;                                                      // 0x0B21 (size: 0x1)
    class UAnimSequence* DetectPlayerAnimSequence;                                    // 0x0B28 (size: 0x8)
    class USoundBase* DetectPlayerCharacterSound;                                     // 0x0B30 (size: 0x8)
    class USoundBase* DetectPlayerCharacterSound_Generic;                             // 0x0B38 (size: 0x8)
    bool PlayerCharacterIsInDetectionRange;                                           // 0x0B40 (size: 0x1)
    double DetectionProgress;                                                         // 0x0B48 (size: 0x8)
    double CurrentDetectionProgressDurationMultiplier;                                // 0x0B50 (size: 0x8)
    FRotator StartDetectPlayerRot;                                                    // 0x0B58 (size: 0x18)
    bool EnableNewVisionSystem;                                                       // 0x0B70 (size: 0x1)
    bool DEBUG_DisplayVision;                                                         // 0x0B71 (size: 0x1)
    bool IsInBattle;                                                                  // 0x0B72 (size: 0x1)
    bool AdaptBattlemapLocation?;                                                     // 0x0B73 (size: 0x1)
    class UAnimSequence* MainIdleAnimSequence;                                        // 0x0B78 (size: 0x8)
    TEnumAsByte<E_AiStates::Type> StartingAiState;                                    // 0x0B80 (size: 0x1)
    TEnumAsByte<E_AiStates::Type> CurrentAiState;                                     // 0x0B81 (size: 0x1)
    class UAnimMontage* DetectPlayerAnim;                                             // 0x0B88 (size: 0x8)
    int32 EncounterLevelOffset;                                                       // 0x0B90 (size: 0x4)
    TEnumAsByte<E_AiStates::Type> StateWhenPlayerIsDetected;                          // 0x0B94 (size: 0x1)
    FTransform InitialTransform;                                                      // 0x0BA0 (size: 0x60)
    bool ShouldTick;                                                                  // 0x0C00 (size: 0x1)
    bool VO IdleScream?;                                                              // 0x0C01 (size: 0x1)
    bool VO ChasingScream?;                                                           // 0x0C02 (size: 0x1)
    class USoundBase* VO Idle Sound;                                                  // 0x0C08 (size: 0x8)
    double VO Idle Delay Min;                                                         // 0x0C10 (size: 0x8)
    double VO Idle Delay Max;                                                         // 0x0C18 (size: 0x8)
    class USoundBase* VO Chasing Sound;                                               // 0x0C20 (size: 0x8)
    double VO Chasing Delay Min;                                                      // 0x0C28 (size: 0x8)
    double VO Chasing Delay Max;                                                      // 0x0C30 (size: 0x8)
    FTimerHandle Timer Exploration Growl;                                             // 0x0C38 (size: 0x8)
    FTimerHandle Timer Chasing Growl;                                                 // 0x0C40 (size: 0x8)
    bool IsTransient;                                                                 // 0x0C48 (size: 0x1)
    class USoundBase* VO Pain Sound;                                                  // 0x0C50 (size: 0x8)
    float VO Pain Sound Start Time;                                                   // 0x0C58 (size: 0x4)
    class USoundBase* Foley Pain Sound;                                               // 0x0C60 (size: 0x8)
    float Foley Pain Sound Start Time;                                                // 0x0C68 (size: 0x4)
    TSoftObjectPtr<class ABP_EnemyGroup_C> EnemyGroupReference;                       // 0x0C70 (size: 0x28)
    class UBehaviorTree* FleeingBehaviorTree;                                         // 0x0C98 (size: 0x8)
    TArray<USkeletalMeshComponent*> SkeletalComponentsList;                           // 0x0CA0 (size: 0x10)
    TArray<UCameraAnimationSequence*> EncounterCamAnimSequence;                       // 0x0CB0 (size: 0x10)
    double CustomIdlePlayRate;                                                        // 0x0CC0 (size: 0x8)
    double MainIdleStartPosition;                                                     // 0x0CC8 (size: 0x8)
    bool MirrorIdle;                                                                  // 0x0CD0 (size: 0x1)
    bool HasDetectedPlayerOnce;                                                       // 0x0CD1 (size: 0x1)
    FTimerHandle Timer_WaitBetweenDetection;                                          // 0x0CD8 (size: 0x8)
    bool IsStunned;                                                                   // 0x0CE0 (size: 0x1)
    double StunDurationFleeBattle;                                                    // 0x0CE8 (size: 0x8)

    bool Editor_DrawDebugShapes();
    bool Editor_GetDebugShapes(TArray<FEditorDebugShape_Arrow>& Arrows, TArray<FEditorDebugShape_Arrow>& Lines);
    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void GetAllAudioComponents(TArray<UAudioComponent*>& AudioComponents);
    void GetAudioComponentByType(const TEnumAsByte<EInWorldAudioContainerComponents::Type> Type, class UAudioComponent*& AudioComponent);
    void GetAudioCharacterManager(class UActorComponent*& AudioCharacterManager);
    void GetAudioComponents(class UAudioComponent*& AC_SFX_01, class UAudioComponent*& AC_Foleys_01, class UAudioComponent*& AC_FT_L, class UAudioComponent*& AC_Vocals_01, class UAudioComponent*& AC_SFX_02, class UAudioComponent*& AC_Foleys_02, class UAudioComponent*& AC_FT_R, class UAudioComponent*& AC_Vocals_02, class UAudioComponent*& AC_Idle, class UAudioComponent*& AC_Weapon_L_01, class UAudioComponent*& AC_Weapon_L_02, class UAudioComponent*& AC_Weapon_R_01, class UAudioComponent*& AC_Hand_L_01, class UAudioComponent*& AC_Hand_R_01);
    void GetCurrentInputDevice(TEnumAsByte<EInputDevices::Type>& InputDevice);
    void GetClosestInteractable(class AActor*& Interactable);
    void IsFreeAimTargetDisabled(bool& IsDisabled);
    bool ShouldHideDistantInteraction();
    void CanInteractWithMount(bool& CanInteract);
    void IsInteractionDone(bool& Done);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    void IsInteractionAvailable(bool& Available);
    void GetInteractionFeedbackLocation(FVector& Location);
    void GetInteractionLocation(FVector& Location);
    bool ShouldEncounterCapsuleGenerateOverlaps();
    void PlayFeedbackHitCanBeAttacked();
    void PlayFeedbackHitCanNotBeAttacked();
    void OnStunRecoveryAnimationFinished();
    void UpdateFreeAimCollisionBox();
    FTransform GetInitialTransform();
    void InitializeGameplayRooms();
    void SpawnDesintegrationFX();
    void UpdateEncounterCapsuleSettings();
    void OnFailedDetection();
    void OnWaitBetweenDetectionTimerElapsed();
    void PlayBattleCameraTransition();
    void GetBattleCameraTransition(class UCameraAnimationSequence*& CameraTransition);
    void OptimizeCharacterMovementComponent();
    void OptimizeSkeletalMeshComponents();
    void GetLookAtRotator(class AActor* Target, FRotator& Rotator);
    void ComputeDetectionParameters(FActorDetectionParameters& DetectionParameters);
    void UpdateDetectionProgressMultiplierByDistance();
    void UpdateDetectionProgressDurationMultiplierByGait();
    void UpdateDetectionProgressDurationMultiplier();
    void UpdateDetectionProgressValue();
    void StartBattle(TEnumAsByte<E_jRPG_EngageTypes::Type> EngagementType);
    void UnpauseAllSound();
    void PauseAllSound();
    void PlayChasingSound();
    void StartChasingSoundTimer();
    void PlayExplorationSound();
    void StartExplorationSoundTimer();
    void OnBattleFled();
    void OnBattleFinished(TEnumAsByte<EBattleEndResult::Type> BattleEndResult);
    bool CanStartBattleWithCharacter(class ABP_jRPG_Character_World_C* Character);
    void OnEnemyBattledEvent(FName EnemyID);
    void GetGlobalObjectIDWithGroup(FName& ObjectId);
    void RestoreTransformIfNeeded();
    void DEBUG_ShowState();
    void ResetStateInternal();
    void ResetAnimation();
    void ResetAggro();
    void DEBUG_ShowVisionCone(float Lifetime);
    void IsActorAggroTriggerRoom(class AActor* Actor, bool& IsTriggerRoom);
    void UpdateDetectionProgress();
    void UpdateDetectionWithLineOfSight(FActorDetectionParameters DetectionParameters, bool& IsVisible);
    void UpdateDetectionInVisionCone(FActorDetectionParameters DetectionParameters, bool& Detected);
    bool IsPlayerTooPowerfullToChase();
    void GetPlayerCharacterIsInDetectionRange(bool& PlayerCharacterIsInDetectionRange);
    void UpdatePlayerCharacterDetection(bool& Detected);
    void DisplayVisionAngle(FVector Center, double A, float Lifetime, FLinearColor Color, float Radius);
    bool IsWithinMaxAggroRange();
    void EndCustomScriptState(const class UObject*& CustomScriptSource, TEnumAsByte<E_AiStates::Type> DesiredState);
    void BeginCustomScriptState(class UObject* SourceObject);
    bool ShouldReactToCharacter(FString& DebugReason);
    bool UpdateCharacterRoomsRequirement(class ABP_jRPG_Character_World_C* Character);
    void OnCharacterLeftVisionHysteresisTimerCompleted();
    void OnVisionShapeEndOverlap(const class UPrimitiveComponent*& Component, class AActor* Actor, FString Reason, bool& ValidEvent);
    void OnVisionShapeBeginOverlap(const class UPrimitiveComponent*& Primitive, FString Reason);
    void RegisterExtraVisionShape(class UPrimitiveComponent* Primitive);
    void RemoveAggroLock(const FName& LockName);
    void AddAggroLock(const FName& LockName);
    void SetAllOverlapCollision(TEnumAsByte<ECollisionEnabled::Type> NewType);
    void SetCurrentIdleState(TEnumAsByte<E_EnemyIdleState::Type> CurrentIdleState);
    bool SetCurrentBT(class UBehaviorTree* BTAsset);
    void SetAiState(TEnumAsByte<E_AiStates::Type> NewAiState);
    void RegisterEvents();
    void UserConstructionScript();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void UpdateInteractables();
    void RemoveInteractable(class AActor* Interactable);
    void AddInteractable(class AActor* Interactable);
    void GetTest();
    void OnInteractionEnabled();
    void OnInteractionDisabled();
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void OnEnemyBattleStateLoaded(bool BattleState);
    void ExplorationAttacked(class ABP_jRPG_Character_World_C* PlayerCharacter, FVector ImpactPoint);
    void FreeAimHit(class ABP_jRPG_Character_World_C* PlayerCharacterWorld, FVector HitLocation, bool IsDisabled);
    void BoxTriggered();
    void EnterDetectPlayerStateInternal();
    void RequestStopEnterChaseMode();
    void BndEvt__BP_jRPG_Enemy_World_Base_Seamless_EncounterCapsuleRange_K2Node_ComponentBoundEvent_5_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_jRPG_Enemy_World_Base_Seamless_PPBattleTransitionZone_K2Node_ComponentBoundEvent_6_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_jRPG_Enemy_World_Base_Seamless_PPBattleTransitionZone_K2Node_ComponentBoundEvent_7_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void OnCharacterEnteredVisionRange(class ABP_jRPG_Character_World_C* JRPG Character world);
    void UpdateCharacterDetection();
    void OnExtraVisionShapeBeginOverlap(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void OnExtraVisionShapeEndOverlap(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void InterruptEnterChaseMode();
    void OnDetectedCharacterChangedRoom(class ABP_jRPG_Character_World_C* Character);
    void OnCharacterDetected();
    void StopChasing();
    void DEBUG_SetOptimizationActive(bool LODOptimizationActive);
    void UpdateCharacterDetectionTick();
    void DEBUG_OnCVarChanged_DisplayVisionDebug(bool NewValue);
    void ResetState();
    void SetGameplayPaused(bool Paused);
    void OnDetectionComplete();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void PlayBattleBeginTransition();
    void EnterStunState(double StunDuration);
    void ExecuteUbergraph_BP_jRPG_Enemy_World_Base_Seamless(int32 EntryPoint);
    void OnAggroBegin__DelegateSignature(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class ACharacter* AggroedCharacter);
}; // Size: 0xCF0

#endif
