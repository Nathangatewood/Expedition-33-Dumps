#ifndef UE4SS_SDK_ABP_PostProcess_MonocoWeapons_Joyaro_HPP
#define UE4SS_SDK_ABP_PostProcess_MonocoWeapons_Joyaro_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_28;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_29;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_30;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_5;         // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_4;         // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_3;         // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_2;         // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_1;         // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics;           // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0280 (size: 0x30)

}; // Size: 0x2B0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
}; // Size: 0x1

class UABP_PostProcess_MonocoWeapons_Joyaro_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;                              // 0x03B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;                              // 0x08D0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;                              // 0x0DF0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;                              // 0x1310 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_1;                              // 0x1830 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;                                // 0x1D50 (size: 0x520)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x2270 (size: 0xB8)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x2328 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x2348 (size: 0x20)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void ExecuteUbergraph_ABP_PostProcess_MonocoWeapons_Joyaro(int32 EntryPoint);
}; // Size: 0x2368

#endif
