#ifndef UE4SS_SDK_BP_GameActionTriggerZone_HPP
#define UE4SS_SDK_BP_GameActionTriggerZone_HPP

class ABP_GameActionTriggerZone_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x0298 (size: 0x8)
    class UBP_ConditionCheckerComponent_C* BP_ConditionCheckerComponent;              // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* InteractionLocation;                                  // 0x02A8 (size: 0x8)
    class UBP_Interaction_SerializableComponent_C* BP_Interaction_SerializableComponent; // 0x02B0 (size: 0x8)
    class UBoxComponent* TriggerBox;                                                  // 0x02B8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02C0 (size: 0x8)
    TEnumAsByte<E_GameActionTriggerZoneDestroyCategory::Type> DestroyCategory;        // 0x02C8 (size: 0x1)
    TEnumAsByte<E_GameActionTriggerZoneResetCategory::Type> ResetCategory;            // 0x02C9 (size: 0x1)
    bool IsBehaviorDone;                                                              // 0x02CA (size: 0x1)
    TArray<UPrimitiveComponent*> TriggerComponents;                                   // 0x02D0 (size: 0x10)
    FGameAction_Wrapper GameActionOnOverlap;                                          // 0x02E0 (size: 0x10)
    bool IsGameActionOnOverlapPlaying;                                                // 0x02F0 (size: 0x1)
    FGameAction_Wrapper GameActionOnInteract;                                         // 0x02F8 (size: 0x10)
    bool IsGameActionOnInteractPlaying;                                               // 0x0308 (size: 0x1)
    FFPromptParams InteractionPromptParams;                                           // 0x0310 (size: 0x18)
    class USoundBase* AudioOnInteract;                                                // 0x0328 (size: 0x8)

    bool ShouldHideDistantInteraction();
    void CanInteractWithMount(bool& CanInteract);
    void GetInteractionLocation(FVector& Location);
    void GetInteractionFeedbackLocation(FVector& Location);
    void IsInteractionAvailable(bool& Available);
    void IsInteractionDone(bool& Done);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void IsPlayerOverlappingWithOtherTriggers(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, bool& IsOverlapping);
    void OnActorOverlap(class AActor* Actor);
    void SetTriggerComponentsCollisionEnabled(bool Enabled);
    void UpdateTriggerComponentsCollision();
    void UnbindAllTriggerComponents();
    void BindAllTriggerComponents();
    void SaveBehaviorState();
    void OnGameActionExecuted(class UGameAction* GameAction);
    void TryUnbindGameActionExecutor();
    void BindGameActionExecutor();
    void ExecuteGameActionOnInteract();
    void ShouldExecuteGameActionOnInteract(bool& Result);
    void TryRegisterInteract();
    void TryExecuteGameActionOnOverlap();
    void ShouldExecuteGameActionOnOverlap(bool& Result);
    void UserConstructionScript();
    void OnInteractionEnabled();
    void OnInteractionDisabled();
    void OnEnemyBattleStateLoaded(bool BattleState);
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void BndEvt__BP_GameActionTriggerZone_BP_ConditionCheckerComponent_K2Node_ComponentBoundEvent_3_OnConditionChanged__DelegateSignature(bool Condition);
    void ReceiveBeginPlay();
    void OnComponentBeginOverlap(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void OnComponentEndOverlap(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ResetState();
    void ExecuteUbergraph_BP_GameActionTriggerZone(int32 EntryPoint);
}; // Size: 0x330

#endif
