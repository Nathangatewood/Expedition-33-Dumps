#ifndef UE4SS_SDK_BP_GameMenu_Maelle_HPP
#define UE4SS_SDK_BP_GameMenu_Maelle_HPP

class ABP_GameMenu_Maelle_C : public ABP_Cine_Maelle_C
{
    class UBP_CharacterVisualAlterationsComponent_C* BP_CharacterVisualAlterationsComponent; // 0x0698 (size: 0x8)

}; // Size: 0x6A0

#endif
