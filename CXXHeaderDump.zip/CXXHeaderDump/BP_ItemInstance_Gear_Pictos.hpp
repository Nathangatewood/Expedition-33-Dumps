#ifndef UE4SS_SDK_BP_ItemInstance_Gear_Pictos_HPP
#define UE4SS_SDK_BP_ItemInstance_Gear_Pictos_HPP

class UBP_ItemInstance_Gear_Pictos_C : public UBP_ItemInstance_Gear_C
{

    void GetUnlockedPassiveEffectsIDs(TArray<FName>& PassiveEffectIDs);
    void LoadBaseStatsMultipliers();
    class UDataTable* GetScalingDataTable();
}; // Size: 0x220

#endif
