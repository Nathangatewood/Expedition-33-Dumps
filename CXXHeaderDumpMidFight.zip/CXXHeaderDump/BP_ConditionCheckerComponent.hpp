#ifndef UE4SS_SDK_BP_ConditionCheckerComponent_HPP
#define UE4SS_SDK_BP_ConditionCheckerComponent_HPP

class UBP_ConditionCheckerComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FConditionChecker_Wrapper ConditionChecker;                                       // 0x00A8 (size: 0x8)
    bool CurrentValue;                                                                // 0x00B0 (size: 0x1)
    FBP_ConditionCheckerComponent_COnConditionChanged OnConditionChanged;             // 0x00B8 (size: 0x10)
    void OnConditionChanged(bool Condition);
    bool ForcedValue;                                                                 // 0x00C8 (size: 0x1)
    bool IsValueForced;                                                               // 0x00C9 (size: 0x1)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void Unforce();
    void ForceFalse();
    void ForceTrue();
    void GetCurrentConditionValue(bool& CurrentValue);
    void OnGameStateChanged();
    void DispatchConditionChanged();
    void EvaluateConditionChecker(bool ForceDispatchConditionChanged);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_ConditionCheckerComponent(int32 EntryPoint);
    void OnConditionChanged__DelegateSignature(bool Condition);
}; // Size: 0xCA

#endif
