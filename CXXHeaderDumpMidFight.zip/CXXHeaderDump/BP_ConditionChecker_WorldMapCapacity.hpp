#ifndef UE4SS_SDK_BP_ConditionChecker_WorldMapCapacity_HPP
#define UE4SS_SDK_BP_ConditionChecker_WorldMapCapacity_HPP

class UBP_ConditionChecker_WorldMapCapacity_C : public UBP_ConditionChecker_C
{
    TEnumAsByte<E_WorldMapExplorationCapacity::Type> WorldMapCapacity;                // 0x0060 (size: 0x1)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x61

#endif
