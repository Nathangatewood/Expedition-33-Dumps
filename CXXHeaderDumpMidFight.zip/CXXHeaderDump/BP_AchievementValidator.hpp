#ifndef UE4SS_SDK_BP_AchievementValidator_HPP
#define UE4SS_SDK_BP_AchievementValidator_HPP

class UBP_AchievementValidator_C : public UPrimaryDataAsset
{
    FName AchievementID;                                                              // 0x0030 (size: 0x8)
    FBP_AchievementValidator_COnAchievementValidatorPassed OnAchievementValidatorPassed; // 0x0038 (size: 0x10)
    void OnAchievementValidatorPassed(FName AchievementID);
    class UGameInstance* GameInstanceReference;                                       // 0x0048 (size: 0x8)

    void GetWorldContext(class UObject*& WorldContext);
    void EvaluateAchievement();
    void Uninitialize();
    void Initialize(class UGameInstance* GameInstance, bool& IsValidated);
    void OnAchievementValidatorPassed__DelegateSignature(FName AchievementID);
}; // Size: 0x50

#endif
