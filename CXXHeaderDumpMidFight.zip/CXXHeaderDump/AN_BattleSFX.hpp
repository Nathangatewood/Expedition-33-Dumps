#ifndef UE4SS_SDK_AN_BattleSFX_HPP
#define UE4SS_SDK_AN_BattleSFX_HPP

class UAN_BattleSFX_C : public UAnimNotify
{
    class UMetaSoundSource* BattleSFX;                                                // 0x0038 (size: 0x8)
    class USoundAttenuation* AttnOverrideBattleSFXEvent;                              // 0x0040 (size: 0x8)

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x48

#endif
