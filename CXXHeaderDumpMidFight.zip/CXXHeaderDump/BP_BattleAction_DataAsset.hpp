#ifndef UE4SS_SDK_BP_BattleAction_DataAsset_HPP
#define UE4SS_SDK_BP_BattleAction_DataAsset_HPP

class UBP_BattleAction_DataAsset_C : public UPrimaryDataAsset
{

    void ModifyNewSkillWheelWidget(class UWBP_HUD_SkillButton_Big_C* SkillWheelButton);
    void GetUniqueMechanicIcons(TArray<UTexture*>& Textures);
    void ValidateAction(class ABP_jRPG_Character_Battle_Base_C* CharacterBattle);
}; // Size: 0x30

#endif
