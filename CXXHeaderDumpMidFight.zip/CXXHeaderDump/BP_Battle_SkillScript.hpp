#ifndef UE4SS_SDK_BP_Battle_SkillScript_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_HPP

class ABP_Battle_SkillScript_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    class UAC_jRPG_BattleManager_C* BattleManagerReference;                           // 0x02A0 (size: 0x8)
    class ABP_jRPG_Character_Battle_Base_C* CurrentCharacter;                         // 0x02A8 (size: 0x8)
    FBP_Battle_SkillScript_COnSkillExecutionFinished OnSkillExecutionFinished;        // 0x02B0 (size: 0x10)
    void OnSkillExecutionFinished();
    TArray<ABP_jRPG_Character_Battle_Base_C*> TargetCharactersOverride;               // 0x02C0 (size: 0x10)
    bool WasFirstAcquireTargetsOverriden;                                             // 0x02D0 (size: 0x1)
    class UBP_SkillState_C* SkillState;                                               // 0x02D8 (size: 0x8)
    bool IsCostCanceled;                                                              // 0x02E0 (size: 0x1)
    bool IsCostCancelLocked;                                                          // 0x02E1 (size: 0x1)
    int32 ExecutionCount;                                                             // 0x02E4 (size: 0x4)
    TArray<ABP_jRPG_Character_Battle_Base_C*> ForcedSkillPreviousTargets;             // 0x02E8 (size: 0x10)
    bool AllowPlayerChoice;                                                           // 0x02F8 (size: 0x1)

    bool ShouldBlockForcedOverchargeFeedback();
    void ResetSkillScriptState();
    class UBP_DataAsset_Skill_C* GetSkillDefinition();
    void ShowPlayerChoice();
    bool DoesForcedSkillAllowPlayerChoice();
    TArray<ABP_jRPG_Character_Battle_Base_C*> GetForcedSkillPreviousTargets();
    int32 GetForcedSkillExecutionCount();
    void ExecuteSkill_Internal();
    void ForceSkillOnNextTurn(bool AllowPlayerChoice);
    void GetSkillCostOverride(bool& Override, int32& NewValue);
    void ValidateSkillTargets(TArray<UAC_jRPG_CharacterBattleStats_C*>& TargetCharacterStats, bool& ValidTargets, FS_BlockedActionFeedback& BlockedReason);
    void ValidateSkillAvailability(bool& Available, FS_BlockedActionFeedback& BlockedReason);
    void LockSkillCostCancelInternal();
    bool WasSkillCostCanceled();
    void CancelSkillCost();
    TEnumAsByte<EAttackType::Type> GetSkillElement();
    void Check Target Buff(class UAC_jRPG_CharacterBattleStats_C* Target, TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, bool& HasBuff);
    void ApplyBuff(TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, int32 TurnDuration, class UAC_jRPG_CharacterBattleStats_C* SourceCharacterIfNotSelf, TEnumAsByte<EBuffApplicationProbability::Type> StatusEffectProbability, class UBP_BattleBuffInstance_C*& CreatedBuffInstance);
    void AcquireTargets(TArray<ABP_jRPG_Character_Battle_Base_C*>& DesiredTargetCharacters, TArray<ABP_jRPG_Character_Battle_Base_C*>& AcquiredTargetCharacters);
    void GetTargetedCharacters(TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedCharacters);
    void AreAllAlive(TArray<ABP_jRPG_Character_Battle_Base_C*>& CharacterList, bool& SomeAreAlive);
    void CameraShake(TSubclassOf<class UCameraShakeBase> CameraShake, double Scale);
    void GetCurrentCharacter(class ABP_jRPG_Character_Battle_Base_C*& CurrentCharacter);
    void OnActionEffect();
    void UserConstructionScript();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript(int32 EntryPoint);
    void OnSkillExecutionFinished__DelegateSignature();
}; // Size: 0x2F9

#endif
