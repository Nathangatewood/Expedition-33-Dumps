#ifndef UE4SS_SDK_BP_BattleBuff_Inverted_HPP
#define UE4SS_SDK_BP_BattleBuff_Inverted_HPP

class UBP_BattleBuff_Inverted_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UNiagaraComponent* VFXPersistent;                                           // 0x0160 (size: 0x8)

    void PlayInvertedVFX();
    void ProcessHeal(class UBP_BattleHeal_C* Heal, bool& DummyOut);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Inverted(int32 EntryPoint);
}; // Size: 0x168

#endif
