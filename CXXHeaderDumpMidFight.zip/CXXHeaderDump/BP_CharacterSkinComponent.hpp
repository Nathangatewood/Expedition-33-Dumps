#ifndef UE4SS_SDK_BP_CharacterSkinComponent_HPP
#define UE4SS_SDK_BP_CharacterSkinComponent_HPP

class UBP_CharacterSkinComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class ABP_CharacterSkinBase_C* SpawnedCharacterSkin;                              // 0x00A8 (size: 0x8)
    FBP_CharacterSkinComponent_COnCharacterSkinChanged OnCharacterSkinChanged;        // 0x00B0 (size: 0x10)
    void OnCharacterSkinChanged(class UBP_CharacterSkinComponent_C* SkinComponent);
    TSubclassOf<class UAnimInstance> AnimInstanceClass;                               // 0x00C0 (size: 0x8)
    FS_AnimationProfile_Skins AnimationProfile;                                       // 0x00C8 (size: 0x90)
    TArray<UMaterialInstanceDynamic*> CurrentCharacterSkinMaterialInstances;          // 0x0158 (size: 0x10)
    TArray<UNiagaraComponent*> ArmRingComponents;                                     // 0x0168 (size: 0x10)
    int32 ArmRingMaterialIndex;                                                       // 0x0178 (size: 0x4)
    class UMaterialInstanceDynamic* ArmRingMaterialInstance;                          // 0x0180 (size: 0x8)
    class USkeletalMeshComponent* AttachedFaceOnCharacter;                            // 0x0188 (size: 0x8)
    class ABP_CharacterFaceBase_C* SpawnedCharacterFace;                              // 0x0190 (size: 0x8)
    FBP_CharacterSkinComponent_COnCharacterFaceChanged OnCharacterFaceChanged;        // 0x0198 (size: 0x10)
    void OnCharacterFaceChanged(class UBP_CharacterSkinComponent_C* SkinComponent);
    FBP_CharacterSkinComponent_COnCharacterCustomizationChanged OnCharacterCustomizationChanged; // 0x01A8 (size: 0x10)
    void OnCharacterCustomizationChanged(class UBP_CharacterSkinComponent_C* SkinComponent);
    class USkeletalMeshComponent* AttachedBodyOnCharacter;                            // 0x01B8 (size: 0x8)
    FS_CharacterCustomization CurrentCharacterCustomization;                          // 0x01C0 (size: 0x50)
    TSubclassOf<class UCharacterSkinAssignPolicy> SkinAssignPolicyClass;              // 0x0210 (size: 0x8)
    class UCharacterSkinAssignPolicy* SkinAssignPolicy;                               // 0x0218 (size: 0x8)

    void UpdateCharacterFaceMaterialInstances();
    void OnSkinAssignCompleted(class AActor* NewBodySkinObject, class AActor* NewFaceSkinObject);
    void OnFaceSkinAssigned(class AActor* NewFaceSkinObject);
    void OnBodySkinAssigned(class AActor* NewBodySkinObject);
    void GetCurrentAssignPolicy(class UCharacterSkinAssignPolicy*& SkinAssignPolicy);
    void ConstructSkinAssignPolicy();
    void ApplyFootstepWithSkin();
    void ApplyAnimationProfile();
    void TryCacheCharacterBody();
    void TryCacheCharacterFace();
    void SetupCharacterFace();
    void GetFaceSkeletalMesh(class USkeletalMeshComponent*& Face);
    void UpdateArmRing();
    void GetArmRingMaterialInstance(class UMaterialInstanceDynamic*& ArmRingMaterialInstance);
    void GetArmRingMaterialIndex(int32& ArmRingMaterialIndex);
    void GetArmRingComponents(TArray<UNiagaraComponent*>& ArmRingComponents);
    void GetSkinMaterialInstances(TArray<UMaterialInstanceDynamic*>& SkinMaterialInstances);
    void UpdateCharacterSkinMaterialInstances();
    void ApplyAnimationConfig();
    void CacheAnimationConfig();
    void ShouldApplyCustomization(FS_CharacterCustomization CharacterCustomization, bool& Result);
    void ApplyCurrentCustomization();
    void OverrideCharacterSkin(TSubclassOf<class ABP_CharacterSkinBase_C> Character Skin, FName Character Name);
    void OverrideCharacterFace(TSubclassOf<class ABP_CharacterFaceBase_C> Skin Face, FName Character Name);
    void SetCharacterCustomization(FName Character Name, FS_CharacterCustomization Character Customization);
    void ReceiveBeginPlay();
    void ApplyCurrentCharacterSkin(FName Character Name);
    void ApplyCurrentCharacterFace(FName Character Name);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_CharacterSkinComponent(int32 EntryPoint);
    void OnCharacterCustomizationChanged__DelegateSignature(class UBP_CharacterSkinComponent_C* SkinComponent);
    void OnCharacterFaceChanged__DelegateSignature(class UBP_CharacterSkinComponent_C* SkinComponent);
    void OnCharacterSkinChanged__DelegateSignature(class UBP_CharacterSkinComponent_C* SkinComponent);
}; // Size: 0x220

#endif
