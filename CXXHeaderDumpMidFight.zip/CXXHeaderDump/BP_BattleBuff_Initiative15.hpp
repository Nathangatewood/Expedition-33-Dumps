#ifndef UE4SS_SDK_BP_BattleBuff_Initiative15_HPP
#define UE4SS_SDK_BP_BattleBuff_Initiative15_HPP

class UBP_BattleBuff_Initiative15_C : public UBP_BattleBuff_Initiative_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0168 (size: 0x8)

    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_Initiative15(int32 EntryPoint);
}; // Size: 0x170

#endif
