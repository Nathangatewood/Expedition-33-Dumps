#ifndef UE4SS_SDK_BP_Battle_SkillScript_Sciel_EndSlice_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_Sciel_EndSlice_HPP

class ABP_Battle_SkillScript_Sciel_EndSlice_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    int32 ForetellConsumedAmount;                                                     // 0x0310 (size: 0x4)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript_Sciel_EndSlice(int32 EntryPoint);
}; // Size: 0x314

#endif
