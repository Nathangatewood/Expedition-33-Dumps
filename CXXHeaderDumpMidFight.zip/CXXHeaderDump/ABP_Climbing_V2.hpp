#ifndef UE4SS_SDK_ABP_Climbing_V2_HPP
#define UE4SS_SDK_ABP_Climbing_V2_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_157;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_158;                                                         // 0x000C (size: 0x8)
    int32 __IntProperty_159;                                                          // 0x0014 (size: 0x4)
    FName __NameProperty_160;                                                         // 0x0018 (size: 0x8)
    int32 __IntProperty_161;                                                          // 0x0020 (size: 0x4)
    FName __NameProperty_162;                                                         // 0x0024 (size: 0x8)
    int32 __IntProperty_163;                                                          // 0x002C (size: 0x4)
    FName __NameProperty_164;                                                         // 0x0030 (size: 0x8)
    int32 __IntProperty_165;                                                          // 0x0038 (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_166;                               // 0x003C (size: 0x2C)
    FName __NameProperty_167;                                                         // 0x0068 (size: 0x8)
    int32 __IntProperty_168;                                                          // 0x0070 (size: 0x4)
    float __FloatProperty_169;                                                        // 0x0074 (size: 0x4)
    bool __BoolProperty_170;                                                          // 0x0078 (size: 0x1)
    float __FloatProperty_171;                                                        // 0x007C (size: 0x4)
    float __FloatProperty_172;                                                        // 0x0080 (size: 0x4)
    bool __BoolProperty_173;                                                          // 0x0084 (size: 0x1)
    EAnimSyncMethod __EnumProperty_174;                                               // 0x0085 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_175;                             // 0x0086 (size: 0x1)
    FName __NameProperty_176;                                                         // 0x0088 (size: 0x8)
    FName __NameProperty_177;                                                         // 0x0090 (size: 0x8)
    FName __NameProperty_178;                                                         // 0x0098 (size: 0x8)
    int32 __IntProperty_179;                                                          // 0x00A0 (size: 0x4)
    FAnimNodeFunctionRef __StructProperty_180;                                        // 0x00A8 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00C8 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0148 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_11;    // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_10;    // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_9;     // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_8;     // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_7;     // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_6;     // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_5;     // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_4;     // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_3;     // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_2;     // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3;       // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_5;          // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2;       // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_4;          // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1;     // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_3;          // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0520 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2;          // 0x0550 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x0580 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x05B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x05E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0610 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0640 (size: 0x30)

}; // Size: 0x670

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)
    float __FloatProperty_1;                                                          // 0x000C (size: 0x4)

}; // Size: 0x10

class UABP_Climbing_V2_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x10)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0388 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0390 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0398 (size: 0x20)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x03B8 (size: 0x48)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;                     // 0x0400 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;                     // 0x0428 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;                      // 0x0450 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;                      // 0x0478 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;                      // 0x04A0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;                      // 0x04C8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;                      // 0x04F0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;                      // 0x0518 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;                      // 0x0540 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;                      // 0x0568 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x0590 (size: 0x28)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;                          // 0x05B8 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_5;                                // 0x0600 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;                          // 0x0620 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_4;                                // 0x0668 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1;                      // 0x0688 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult_3;                                // 0x06F8 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0718 (size: 0x28)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x0740 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_2;                                // 0x0788 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x07A8 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x07F0 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0810 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0880 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x08A0 (size: 0xC8)
    TEnumAsByte<E_ClimbingComponentState::Type> ClimbingState;                        // 0x0968 (size: 0x1)
    TEnumAsByte<E_Climbing_Direction::Type> ClimbingDirection;                        // 0x0969 (size: 0x1)
    double DistanceToNextHold;                                                        // 0x0970 (size: 0x8)
    double DistanceAboveWhichAHoldIsLong;                                             // 0x0978 (size: 0x8)
    class UBP_ClimbingComponent_C* ClimbingComponentReference;                        // 0x0980 (size: 0x8)
    double TimeToPerformAnimation;                                                    // 0x0988 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void UpdateClimbingComponentData();
    double GetAnimationPlayRate();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_SequencePlayer_F5E121D5483BAE4BA7B9A099437F40B7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_SequencePlayer_A8A4CAA24A67F4D37C97C1AE900C31FF();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_SequencePlayer_64CE3B384B4F57DA7F123E8DFE98AB52();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_SequencePlayer_FA598A834A5E09DDE5873CA101D50A50();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_A17B3EED4899DD941B7355B8B5C60BB7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_8674908A41B1505896FFB6925AD5B643();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_0558962E42C90F242FA5CFBD6D0EFF90();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_312FB91F4F10CA5E3EC9A4A6AB072AC5();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_347C64A0443AE0B50DEF04B3D7B4B2E2();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_964CC3134D0FFAA60BB6F0A8EA44F0AF();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_C03582CA44B0D0E569DD858C658CF092();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Climbing_V2_AnimGraphNode_TransitionResult_42DBB77A4D32489FDEDBD09856644693();
    void AnimNotify_OnClimbingMovementDone();
    void AnimNotify_OnStartClimbAnimationDone();
    void AnimNotify_OnAnimationInterrupted();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void BlueprintInitializeAnimation();
    void ExecuteUbergraph_ABP_Climbing_V2(int32 EntryPoint);
}; // Size: 0x990

#endif
