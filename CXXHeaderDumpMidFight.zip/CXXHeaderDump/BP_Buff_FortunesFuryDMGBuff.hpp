#ifndef UE4SS_SDK_BP_Buff_FortunesFuryDMGBuff_HPP
#define UE4SS_SDK_BP_Buff_FortunesFuryDMGBuff_HPP

class UBP_Buff_FortunesFuryDMGBuff_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    bool IsBuffActive;                                                                // 0x0160 (size: 0x1)
    FText SkillDisplayName;                                                           // 0x0168 (size: 0x10)

    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_Buff_FortunesFuryDMGBuff(int32 EntryPoint);
}; // Size: 0x178

#endif
