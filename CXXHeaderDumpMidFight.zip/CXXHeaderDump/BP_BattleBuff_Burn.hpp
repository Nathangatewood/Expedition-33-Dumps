#ifndef UE4SS_SDK_BP_BattleBuff_Burn_HPP
#define UE4SS_SDK_BP_BattleBuff_Burn_HPP

class UBP_BattleBuff_Burn_C : public UBP_BattleBuffInstance_C
{
    double BurnMultiplier;                                                            // 0x0158 (size: 0x8)

}; // Size: 0x160

#endif
