#ifndef UE4SS_SDK_BP_EnemyBattle_Ramasseur_HPP
#define UE4SS_SDK_BP_EnemyBattle_Ramasseur_HPP

class ABP_EnemyBattle_Ramasseur_C : public ABP_jRPG_Enemy_Battle_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x1638 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x1640 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart;                              // 0x1648 (size: 0x8)
    class USkeletalMeshComponent* RamasseurArmSapling;                                // 0x1650 (size: 0x8)
    class USkeletalMeshComponent* RamasseurArmCultist;                                // 0x1658 (size: 0x8)
    class USkeletalMeshComponent* RamasseurArmLancelier;                              // 0x1660 (size: 0x8)
    class USkeletalMeshComponent* RamasseurArmCruler;                                 // 0x1668 (size: 0x8)
    FDataTableRowHandle Encounter Row;                                                // 0x1670 (size: 0x10)
    bool IsDying;                                                                     // 0x1680 (size: 0x1)
    class ABP_EpicBattleSequenceActor_C* CurrentBattleSequence;                       // 0x1688 (size: 0x8)
    TEnumAsByte<E_RamasseurBaseWeapon::Type> RamasseurWeaponType;                     // 0x1690 (size: 0x1)
    bool FlipFlopA;                                                                   // 0x1691 (size: 0x1)
    FText Lancelier;                                                                  // 0x1698 (size: 0x10)
    FText Cruler;                                                                     // 0x16A8 (size: 0x10)
    FText Sapling;                                                                    // 0x16B8 (size: 0x10)
    FText Flying Cultist;                                                             // 0x16C8 (size: 0x10)
    class USkeletalMeshComponent* CurrentArm;                                         // 0x16D8 (size: 0x8)
    FFRoutedEventHandle Skill Handle_Combo2;                                          // 0x16E0 (size: 0x20)
    FFRoutedEventHandle Skill Handle_Combo1;                                          // 0x1700 (size: 0x20)
    bool IsAlpha;                                                                     // 0x1720 (size: 0x1)
    FFRoutedEventHandle SkillHandle_Alpha_LongCombo;                                  // 0x1728 (size: 0x20)
    bool UseComboLongSequence;                                                        // 0x1748 (size: 0x1)

    void PerformActionByAI();
    void Skill_Combo1();
    void Skill_Combo2();
    void Melee_Combo1_Hit1();
    void MeleeParryable_Combo1_Hit2();
    void MeleeParryable_Combo2_Hit1();
    void OnBattleStart();
    void ArmAnimation_Dash_in();
    void DeclareCharacterSkillEvents();
    void Skill_Alpha_LongCombo();
    void ActionEffect_LongCombo(int32 ActionEffectIndex);
    void ExecuteUbergraph_BP_EnemyBattle_Ramasseur(int32 EntryPoint);
}; // Size: 0x1749

#endif
