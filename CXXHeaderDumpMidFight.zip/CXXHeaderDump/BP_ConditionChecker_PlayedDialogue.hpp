#ifndef UE4SS_SDK_BP_ConditionChecker_PlayedDialogue_HPP
#define UE4SS_SDK_BP_ConditionChecker_PlayedDialogue_HPP

class UBP_ConditionChecker_PlayedDialogue_C : public UBP_ConditionChecker_C
{
    FGuid DialogueGUID;                                                               // 0x0060 (size: 0x10)
    int32 Stage;                                                                      // 0x0070 (size: 0x4)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x74

#endif
