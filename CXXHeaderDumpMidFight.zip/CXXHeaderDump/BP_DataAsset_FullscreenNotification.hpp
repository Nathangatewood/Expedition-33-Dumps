#ifndef UE4SS_SDK_BP_DataAsset_FullscreenNotification_HPP
#define UE4SS_SDK_BP_DataAsset_FullscreenNotification_HPP

class UBP_DataAsset_FullscreenNotification_C : public UPrimaryDataAsset
{
    TSubclassOf<class UCommonActivatableWidget> WidgetClass;                          // 0x0030 (size: 0x8)
    FText HeaderText;                                                                 // 0x0038 (size: 0x10)
    FText DescriptionText;                                                            // 0x0048 (size: 0x10)
    bool bIsHandledByGameAction;                                                      // 0x0058 (size: 0x1)

    void IsHandledByGameAction(bool& bIsHandledByGameAction);
    void GetDescriptionText(FText& DescriptionText);
    void GetHeaderText(FText& HeaderText);
    void GetWidgetClass(TSubclassOf<class UCommonActivatableWidget>& WidgetClass);
}; // Size: 0x59

#endif
