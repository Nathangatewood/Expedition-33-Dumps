#ifndef UE4SS_SDK_BP_CustomShapeExtruder_HPP
#define UE4SS_SDK_BP_CustomShapeExtruder_HPP

class ABP_CustomShapeExtruder_C : public AActor
{
    class UBillboardComponent* Billboard_EditorOnly;                                  // 0x0290 (size: 0x8)
    class UDynamicMeshComponent* TriggerDynamicMesh;                                  // 0x0298 (size: 0x8)
    class USplineComponent* ConstructionSpline;                                       // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    double TriggerShapeHeight;                                                        // 0x02B0 (size: 0x8)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void UserConstructionScript();
}; // Size: 0x2B8

#endif
