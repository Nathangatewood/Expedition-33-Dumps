#ifndef UE4SS_SDK_BP_EyeEffectsControllerComponent_HPP
#define UE4SS_SDK_BP_EyeEffectsControllerComponent_HPP

class UBP_EyeEffectsControllerComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class USkeletalMeshComponent* FaceSkeletalMeshComponent;                          // 0x00A8 (size: 0x8)

    void SetFaceSkeletalMeshComponent(class USkeletalMeshComponent* FaceSkeletalMeshComponent);
    void UpdateEyeSparkOrientation(class UMeshComponent* FaceMeshComponent);
    void OnCharacterCustomizationChanged(class UBP_CharacterSkinComponent_C* SkinComponent);
    void TryRegisterCharacterSkinComponent();
    void TryCacheCurrentCharacterFace();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_EyeEffectsControllerComponent(int32 EntryPoint);
}; // Size: 0xB0

#endif
