#ifndef UE4SS_SDK_BP_DialogSystem_HPP
#define UE4SS_SDK_BP_DialogSystem_HPP

class UBP_DialogSystem_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UDataTable* DataTable;                                                      // 0x00A8 (size: 0x8)
    FName DataTableRowID;                                                             // 0x00B0 (size: 0x8)
    TArray<FDialog_Struct> DialogStructs;                                             // 0x00B8 (size: 0x10)
    FName BattleName;                                                                 // 0x00C8 (size: 0x8)
    FName BattleMap;                                                                  // 0x00D0 (size: 0x8)
    class AActor* NPCReference;                                                       // 0x00D8 (size: 0x8)
    class UW_DialogBox_C* DialogBox;                                                  // 0x00E0 (size: 0x8)
    class UW_DialogEntry_C* DialogEntry;                                              // 0x00E8 (size: 0x8)
    class AActor* SceneCamera;                                                        // 0x00F0 (size: 0x8)
    class AActor* OldSceneCamera;                                                     // 0x00F8 (size: 0x8)
    bool MouseVisibility?;                                                            // 0x0100 (size: 0x1)
    bool ShowDebug?;                                                                  // 0x0101 (size: 0x1)
    FVector CameraSetting;                                                            // 0x0108 (size: 0x18)
    class AActor* Target;                                                             // 0x0120 (size: 0x8)
    class UAudioComponent* AudioDialogue;                                             // 0x0128 (size: 0x8)
    class UAudioComponent* AudioResponse;                                             // 0x0130 (size: 0x8)
    FName PlayedDialogID;                                                             // 0x0138 (size: 0x8)
    TSet<FName> AvailableItems;                                                       // 0x0140 (size: 0x50)
    FText Greeting;                                                                   // 0x0190 (size: 0x10)
    FName QuestName;                                                                  // 0x01A0 (size: 0x8)
    TArray<FDialogCondition_Struct> AddConditionDialog;                               // 0x01A8 (size: 0x10)
    FDataTableRowHandle CharacterToAddRow;                                            // 0x01B8 (size: 0x10)
    class UAC_jRPG_BattleManager_C* BattleManagerRef;                                 // 0x01C8 (size: 0x8)
    bool AdaptBattlemapLocation?;                                                     // 0x01D0 (size: 0x1)
    bool Flee Impossible;                                                             // 0x01D1 (size: 0x1)
    FFSoundEvent Battle Music;                                                        // 0x01D8 (size: 0x8)
    FVector Enemy Original Location;                                                  // 0x01E0 (size: 0x18)
    FName Enemy Global ID;                                                            // 0x01F8 (size: 0x8)
    TEnumAsByte<E_jRPG_EngageTypes::Type> Engage Type;                                // 0x0200 (size: 0x1)
    FName Encounter Name;                                                             // 0x0204 (size: 0x8)
    FName Battle Map Name;                                                            // 0x020C (size: 0x8)
    TSet<FName> AvailableItemsExtended;                                               // 0x0218 (size: 0x50)
    bool AlreadyBeat;                                                                 // 0x0268 (size: 0x1)
    bool NpcDefeated;                                                                 // 0x0269 (size: 0x1)
    bool TriggerDialogWhenDefeated;                                                   // 0x026A (size: 0x1)
    FName DataTableRowIdDefeat;                                                       // 0x026C (size: 0x8)
    TSoftObjectPtr<class ABP_BattleMap_C> BattleMapBP;                                // 0x0278 (size: 0x28)
    TEnumAsByte<E_NpcDialogEvent::Type> EventType;                                    // 0x02A0 (size: 0x1)

    void AnimDialog(FText Response, double& AnimDuration);
    void QuitDialog(class APlayerController* self2, class APlayerController* PlayerController, class AController* self3, bool DontRegisterDialog);
    void AddStructDialog(TArray<FDialog_Struct>& TargetArray, FName EventId, int32 SwitchID);
    void AddDataTable(class UDataTable* DataTable, FName RowName, int32 SwitchID);
    void Add Response(FText Name, FText Response, FName EventId, int32 SwitchID, FLinearColor NameColor, class UFont* ResponseFont, class USoundBase* ResponseVoice, FLinearColor TextColorHovered, FLinearColor TextColorNormal, class UTexture2D* BtnHoveredImage, class UTexture2D* BtnNormalImage, double EnableEventDelay, class UAnimMontage* ResponseAnim, class UBP_DialogSystem_C*& DialogSystem);
    void AddCameraAngle(class AActor* CameraActorTarget, double CameraBlendTime, double CameraDistence, double CameraHight, double CameraAngle, bool CameraAttach?, class UBP_DialogSystem_C*& DialogSystem);
    void GlobalDialogEvent(FName EventId, bool& Success);
    void AddDialog(class UTexture2D* Image, FText Name, FText Dialog, FName DialogID, FLinearColor NameColor, FLinearColor DialogHoveredColor, FLinearColor DialogNormalColor, class UFont* DialogFont, class UAnimMontage* DialogAnim, class USoundBase* DialogSound, double DialogEventDelay, double DialogTypingDelay, class USoundBase* DialogTypingSound, bool IsDialogClickable?, bool ClearDialogResponses?, class UBP_DialogSystem_C*& DialogSystem, double& DelayValue);
    void CreateDialogUI(class UTexture2D* GUITexture, FVector2D MainSize, FVector2D MainTranslation, FLinearColor MainBorderColor, FLinearColor TextBorderColor, FVector2D DialogIconSize, bool bShowMouseCursor, bool bCenterMouse?, bool bShowDebug?, class UBP_DialogSystem_C*& DialogSystem);
    void Dialog(FName EventId, int32 SwitchID, FText DialogText);
    void Talk();
    void StopAnim(class USkeletalMeshComponent* Mesh, class UAnimInstance* Target, class UAnimMontage* Montage);
    void ExecuteUbergraph_BP_DialogSystem(int32 EntryPoint);
}; // Size: 0x2A1

#endif
