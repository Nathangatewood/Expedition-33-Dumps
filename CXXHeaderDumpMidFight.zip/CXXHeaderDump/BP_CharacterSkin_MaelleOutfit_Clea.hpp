#ifndef UE4SS_SDK_BP_CharacterSkin_MaelleOutfit_Clea_HPP
#define UE4SS_SDK_BP_CharacterSkin_MaelleOutfit_Clea_HPP

class ABP_CharacterSkin_MaelleOutfit_Clea_C : public ABP_CharacterSkinBase_Maelle_C
{

    void GetArmRingNiagaraComponents(TArray<UNiagaraComponent*>& Array, int32& ArmRingMaterialIndex);
}; // Size: 0x3A0

#endif
