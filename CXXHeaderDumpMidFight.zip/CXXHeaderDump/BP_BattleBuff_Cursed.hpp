#ifndef UE4SS_SDK_BP_BattleBuff_Cursed_HPP
#define UE4SS_SDK_BP_BattleBuff_Cursed_HPP

class UBP_BattleBuff_Cursed_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UNiagaraComponent* Niagara System;                                          // 0x0160 (size: 0x8)
    class ABP_BatleFeedback_CurseDisplay_C* CurseDisplay;                             // 0x0168 (size: 0x8)
    class UBP_DependencyRefCounter_C* Turn Start Dependencies;                        // 0x0170 (size: 0x8)
    bool DieNextTurn;                                                                 // 0x0178 (size: 0x1)
    class UAudioComponent* AC_SoundLoop;                                              // 0x0180 (size: 0x8)
    int32 DisplayTurnDuration;                                                        // 0x0188 (size: 0x4)

    void SetCurseDuration(int32 CurseDuration);
    void UpdateCurseDisplay();
    void GetDamageSourceType(TEnumAsByte<EDamageReason::Type>& DamageSourceType);
    void GetDamageSourceCharacter(class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnCharacterDealtDamages(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, double Damages, double& ProcessedDamages);
    void IsTurnStartInProgress(bool& InProgress);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_Cursed(int32 EntryPoint);
}; // Size: 0x18C

#endif
