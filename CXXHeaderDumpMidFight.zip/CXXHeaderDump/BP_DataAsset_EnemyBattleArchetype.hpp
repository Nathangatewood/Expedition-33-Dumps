#ifndef UE4SS_SDK_BP_DataAsset_EnemyBattleArchetype_HPP
#define UE4SS_SDK_BP_DataAsset_EnemyBattleArchetype_HPP

class UBP_DataAsset_EnemyBattleArchetype_C : public UPrimaryDataAsset
{
    TMap<TEnumAsByte<E_GameDifficulty::Type>, UDataTable*> ArchetypeScalingDTPerDifficulty; // 0x0030 (size: 0x50)
    TArray<FLootTableReference> BaseLootTableRolls;                                   // 0x0080 (size: 0x10)

}; // Size: 0x90

#endif
