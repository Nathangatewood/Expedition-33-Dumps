#ifndef UE4SS_SDK_BP_Buff_EndSliceForetellConsumedCount_HPP
#define UE4SS_SDK_BP_Buff_EndSliceForetellConsumedCount_HPP

class UBP_Buff_EndSliceForetellConsumedCount_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 ForetellConsumedAmount;                                                     // 0x0160 (size: 0x4)

    void GetForetellConsumedAmount(int32& ForetellConsumedAmount);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ForetellConsumedCount(class UAC_jRPG_CharacterBattleStats_C* TargetStats, int32 PreviousForetell, int32 ForetellConsumed, TEnumAsByte<EBattleContext::Type> Reason);
    void ExecuteUbergraph_BP_Buff_EndSliceForetellConsumedCount(int32 EntryPoint);
}; // Size: 0x164

#endif
