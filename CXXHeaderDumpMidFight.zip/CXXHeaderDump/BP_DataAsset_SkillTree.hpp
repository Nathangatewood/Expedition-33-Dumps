#ifndef UE4SS_SDK_BP_DataAsset_SkillTree_HPP
#define UE4SS_SDK_BP_DataAsset_SkillTree_HPP

class UBP_DataAsset_SkillTree_C : public UPrimaryDataAsset
{
    TArray<FFSkillUnlockData> RootSkillUnlocks;                                       // 0x0030 (size: 0x10)
    TMap<UBP_DataAsset_Skill_C*, FFSkillUnlockDataList> SkillUnlockTable;             // 0x0040 (size: 0x50)
    TArray<UBP_DataAsset_Skill_C*> StartingSkills;                                    // 0x0090 (size: 0x10)

    void BPI_GetDependencies(TArray<TSoftClassPtr<UObject>>& Classes, TArray<TSoftObjectPtr<class UObject>>& Assets, TArray<TScriptInterface<class IBPI_LoadingDependenciesSource_C>>& ExternalDependencies);
    void GetAllSkillUnlockInfosMap(TMap<UBP_DataAsset_Skill_C*, FFSkillUnlockInfos>& SkillUnlockInfos);
    void GetSkillsUnlockedBySkill(const class UBP_DataAsset_Skill_C*& Key, TArray<FFSkillUnlockData>& SkillUnlocks);
    void GetUnlockedSkillsByNameIDs(TArray<FName>& NameIDs, TArray<UBP_DataAsset_Skill_C*>& UnlockedSkills, bool& AllFound, TArray<FName>& MissingNameIDs);
}; // Size: 0xA0

#endif
