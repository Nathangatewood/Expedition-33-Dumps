#ifndef UE4SS_SDK_BP_FL_BattleTowerHelpers_HPP
#define UE4SS_SDK_BP_FL_BattleTowerHelpers_HPP

class UBP_FL_BattleTowerHelpers_C : public UBlueprintFunctionLibrary
{

    void GetBattleTowerSystem(class UObject* __WorldContext, class UBP_BattleTowerSystem_C*& BattleTowerSystem);
}; // Size: 0x28

#endif
