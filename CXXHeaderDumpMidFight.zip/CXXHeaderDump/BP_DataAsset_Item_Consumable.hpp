#ifndef UE4SS_SDK_BP_DataAsset_Item_Consumable_HPP
#define UE4SS_SDK_BP_DataAsset_Item_Consumable_HPP

class UBP_DataAsset_Item_Consumable_C : public UBP_DataAsset_Item_C
{
    int32 MaxCharges;                                                                 // 0x0030 (size: 0x4)
    TSoftClassPtr<ABP_Battle_SkillScript_C> BattleSkillScript;                        // 0x0038 (size: 0x28)
    class UBP_DataAsset_Skill_C* ItemSkillDefinition;                                 // 0x0060 (size: 0x8)

    class UBP_DataAsset_Skill_C* GetItemSkillDefinition();
}; // Size: 0x68

#endif
