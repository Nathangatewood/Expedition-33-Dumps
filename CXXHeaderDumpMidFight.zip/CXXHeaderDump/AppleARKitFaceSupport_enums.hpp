enum class EARFaceComponentTransformMixing {
    ComponentOnly = 0,
    ComponentLocationTrackedRotation = 1,
    ComponentWithTracked = 2,
    TrackingOnly = 3,
    EARFaceComponentTransformMixing_MAX = 4,
};

