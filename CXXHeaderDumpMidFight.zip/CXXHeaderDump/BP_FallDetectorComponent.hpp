#ifndef UE4SS_SDK_BP_FallDetectorComponent_HPP
#define UE4SS_SDK_BP_FallDetectorComponent_HPP

class UBP_FallDetectorComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FTimerHandle TimerHandle;                                                         // 0x00A8 (size: 0x8)
    FVector WorldLocationOnStartFalling;                                              // 0x00B0 (size: 0x18)
    bool EnableKillDetection;                                                         // 0x00C8 (size: 0x1)
    double KillDistance;                                                              // 0x00D0 (size: 0x8)
    double KillTime;                                                                  // 0x00D8 (size: 0x8)
    bool IsInPause;                                                                   // 0x00E0 (size: 0x1)
    FBP_FallDetectorComponent_COnKillByFallDetected OnKillByFallDetected;             // 0x00E8 (size: 0x10)
    void OnKillByFallDetected();
    bool CharacterCanInteract;                                                        // 0x00F8 (size: 0x1)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void UnpauseFallDetection();
    void PauseFallDetection();
    void IsFallDetectionInPause(bool& IsInPause);
    void GetWorldLocationOnStartFalling(FVector& Location);
    void GetFallingDistance(double& Distance);
    bool IsTimerRunning();
    void OnKillDistanceOrTimerReached();
    void CheckFallingDistance();
    void CacheCurrentWorldLocation(class ACharacter* Character);
    void InvalidateTimer();
    void StartTimer();
    void OnFallingEnd(class ACharacter* Character);
    void OnFallingBegin(class ACharacter* Character);
    void OnCharacterCapabilitiesInitialized();
    void OnMovementModeChanged(class ACharacter* Character, TEnumAsByte<EMovementMode> PrevMovementMode, uint8 PreviousCustomMode);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void SetGameplayPaused(bool Paused);
    void ExecuteUbergraph_BP_FallDetectorComponent(int32 EntryPoint);
    void OnKillByFallDetected__DelegateSignature();
}; // Size: 0xF9

#endif
