#ifndef UE4SS_SDK_BP_DataAsset_CameraConfig_HPP
#define UE4SS_SDK_BP_DataAsset_CameraConfig_HPP

class UBP_DataAsset_CameraConfig_C : public UPrimaryDataAsset
{
    FS_CameraConfig CameraConfig;                                                     // 0x0030 (size: 0x88)

}; // Size: 0xB8

#endif
