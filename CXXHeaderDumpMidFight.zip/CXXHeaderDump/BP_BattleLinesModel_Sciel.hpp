#ifndef UE4SS_SDK_BP_BattleLinesModel_Sciel_HPP
#define UE4SS_SDK_BP_BattleLinesModel_Sciel_HPP

class UBP_BattleLinesModel_Sciel_C : public UBP_BattleLinesModel_Base_C
{
}; // Size: 0x4C0

#endif
