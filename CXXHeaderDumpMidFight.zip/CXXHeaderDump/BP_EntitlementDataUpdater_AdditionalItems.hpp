#ifndef UE4SS_SDK_BP_EntitlementDataUpdater_AdditionalItems_HPP
#define UE4SS_SDK_BP_EntitlementDataUpdater_AdditionalItems_HPP

class UBP_EntitlementDataUpdater_AdditionalItems_C : public UBP_EntitlementDataUpdaterBase_C
{
    FS_ItemRowList ItemList;                                                          // 0x0030 (size: 0x10)

    void GetItemNameFromDataTableRow(const FItemDataTableRowHandle& ItemDataTableRow, FName& Name);
    void RemoveEntitlementData(class UGameInstance* GameInstance, class APlayerController* PlayerController);
    void ApplyEntitlementData(class UGameInstance* GameInstance, class APlayerController* PlayerController);
}; // Size: 0x40

#endif
