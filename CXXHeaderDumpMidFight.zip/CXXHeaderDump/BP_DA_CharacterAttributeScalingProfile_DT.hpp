#ifndef UE4SS_SDK_BP_DA_CharacterAttributeScalingProfile_DT_HPP
#define UE4SS_SDK_BP_DA_CharacterAttributeScalingProfile_DT_HPP

class UBP_DA_CharacterAttributeScalingProfile_DT_C : public UPrimaryDataAsset
{
    TMap<TEnumAsByte<ECharacterAttribute::Type>, UDataTable*> AttributesScaling;      // 0x0030 (size: 0x50)

}; // Size: 0x80

#endif
