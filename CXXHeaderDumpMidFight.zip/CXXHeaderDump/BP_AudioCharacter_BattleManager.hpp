#ifndef UE4SS_SDK_BP_AudioCharacter_BattleManager_HPP
#define UE4SS_SDK_BP_AudioCharacter_BattleManager_HPP

class UBP_AudioCharacter_BattleManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool Debug;                                                                       // 0x00A8 (size: 0x1)
    class USoundBase* Battle_Sound Played;                                            // 0x00B0 (size: 0x8)
    class ABP_jRPG_Character_Battle_Base_C* BP_CharacterBattle;                       // 0x00B8 (size: 0x8)
    TEnumAsByte<EUiBattleType::Type> EUiBattleType;                                   // 0x00C0 (size: 0x1)
    FFAudioCharacter_Battle_UI StructureBattleUiType;                                 // 0x00C8 (size: 0x10)
    class UBP_DataAsset_CharacterBattleAudioProfile_C* DataAsset_Battle;              // 0x00D8 (size: 0x8)
    TEnumAsByte<EBattleCommonSFX::Type> CommonSFX;                                    // 0x00E0 (size: 0x1)
    TEnumAsByte<EBattleHitBy::Type> EBattle Hit By_Call By BP;                        // 0x00E1 (size: 0x1)
    FFAudioBattleCommonSFX StructureBattleCommonSFX;                                  // 0x00E8 (size: 0x58)
    FFAudioCharacter_Battle_HitBy_BP StructureBattle_HitBy_CallByBP;                  // 0x0140 (size: 0x10)
    FFAudioCharacter_Battle_HitBy_AnimCommon StructureBattle_HitByCommonAnim;         // 0x0150 (size: 0x40)
    FFAudioCharacter_Battle_DeathCommon StructureBattle_DeathByCommonAnim;            // 0x0190 (size: 0x20)
    bool hasShield?;                                                                  // 0x01B0 (size: 0x1)
    class USceneComponent* Container_SFX;                                             // 0x01B8 (size: 0x8)
    class USceneComponent* Container_Weapon_L;                                        // 0x01C0 (size: 0x8)
    class USceneComponent* Container_Weapon_R;                                        // 0x01C8 (size: 0x8)
    class USceneComponent* Container_Foley;                                           // 0x01D0 (size: 0x8)
    class USceneComponent* Container_Vocal;                                           // 0x01D8 (size: 0x8)
    class USceneComponent* Container_Foot_L;                                          // 0x01E0 (size: 0x8)
    class USceneComponent* Container_Foot_R;                                          // 0x01E8 (size: 0x8)
    bool PLACEHOLDER_FootFlipFlop;                                                    // 0x01F0 (size: 0x1)
    class USceneComponent* Container_HitBy;                                           // 0x01F8 (size: 0x8)
    TArray<UAudioComponent*> SpawnedAudioComponentsContainer;                         // 0x0200 (size: 0x10)
    TArray<USoundEffectSubmixPreset*> Submix Effect Preset Chain;                     // 0x0210 (size: 0x10)
    TArray<FS_BattleHitSoundOverrideHandle> HitSoundOverrideStack;                    // 0x0220 (size: 0x10)
    class UAudioComponent* CurrentSkillBattleLine;                                    // 0x0230 (size: 0x8)
    class UAudioComponent* CurrentDialogueBattleLine;                                 // 0x0238 (size: 0x8)
    class UBP_BattleLinesModel_Base_C* BattleLinesModel;                              // 0x0240 (size: 0x8)
    class UAudioComponent* CurrentEventBattleLine;                                    // 0x0248 (size: 0x8)

    void SetAudioComponentPaused(class UAudioComponent* AudioComponent, bool bPause);
    void PlayEventBattleLine(FS_BattleLine BattleLine);
    void OnDamageReceived(class UBP_BattleDamages_C* BattleDamage);
    void PlayDialogueBattleLineInternal(class USoundBase* SoundAsset);
    class UBP_BattleLinesModel_Base_C* GetBattleLineModel();
    void TryInterruptActiveSkillBattleLine(bool& HasInterrupted);
    void HasActiveSkillBattleLine(bool& Active);
    void PlaySkillBattleLineInternal(class USoundBase* SoundAsset);
    void StopAllSFXs();
    void ProcessTaggedGameplayEvent(FTaggedGameplayEvent Event);
    void RemoveHitOverride(FS_BattleHitSoundOverrideHandle& OutHitOverrideHandle);
    void PlayHitSoundFromDamageObject(class UBP_BattleDamages_C* BattleDamages);
    void PushHitOverride(class UBP_DataAsset_BattleHitSound_C* HitSoundAsset, FS_BattleHitSoundOverrideHandle& OutHitOverrideHandle);
    void ResolveHitSound(class UBP_BattleDamages_C* BattleDamage, class USoundBase*& Sound);
    void ResolveHitSoundAsset(class UBP_BattleDamages_C* BattleDamage, class UBP_DataAsset_BattleHitSound_C*& HitSoundAsset);
    void Internal_PlayOnoFromData(TEnumAsByte<EOnoType::Type> OnoType);
    void Battle_PlaySeqOno(TEnumAsByte<EOnoType::Type> OnoType);
    void CleanSpawnedAudioComponentList();
    void Internal_PlayAudioComponent(class USoundBase* Sound, class USceneComponent* OriginComponent, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleDeactivateControlBusMix(class USoundControlBusMix* Deactivate ControlBusMix);
    void HandleActivateControlBusMix(class USoundControlBusMix* Activate ControlBusMix);
    void HandleBattleDeathCommonBodyFall(class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void Stop_AC_SFX_01();
    void BattleHitBy_CallByBP(TEnumAsByte<EBattleHitBy::Type> BattleHitBy_CallByBP);
    void HandleBattleDeathCommon(class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleBattleHitByCommon(class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleBattleHitBy(class UMetaSoundSource* BattleHitBy, bool ShouldAttachToComponent?);
    void Battle_PlaySeqStep(class USoundBase* Battle_PlaySeqStep, bool IsRight, class USoundAttenuation* AttenuationOverride, bool SoundShouldFollow?);
    void Battle_PlaySeqVocal(class USoundBase* Battle_PlaySeqVocal, class USoundAttenuation* AttenuationOverride, bool SoundShouldFollow?);
    void BattleCommonSFX(TEnumAsByte<EBattleCommonSFX::Type> Common SFX);
    void HandleBattlePlaceholder(class USoundBase* Battle Placeholder);
    void HandleBattleFoley(class UMetaSoundSource* Battle Foley, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleBattleFootstep(TEnumAsByte<EFootstepsType::Type> FootstepType, FVector Location, const TEnumAsByte<EPhysicalSurface>& SurfaceType, bool ShouldAttachToComponent?);
    void HandleBattleVocal(class UMetaSoundSource* Battle Vocal, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleBattleWeaponRight(class UMetaSoundSource* Battle Weapon Right, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleBattleWeaponLeft(class UMetaSoundSource* Battle Weapon Left, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleBattleSFX(class UMetaSoundSource* Battle SFX, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void HandleBattleUiCharacter(TEnumAsByte<EUiBattleType::Type> Battle UI Type, bool ShouldAttachToComponent?);
    void HandleBattleOno(TEnumAsByte<EOnoType::Type> OnoType);
    void OnGameModePauseStateChanged(bool bIsPaused);
    void Battle_PlaySeqFoley(class USoundBase* Battle_PlaySeqFoley, class USoundAttenuation* AttenuationOverride, bool SoundShouldFollow?);
    void Init();
    void Battle_PlayWeaponR(class USoundBase* Battle_Weapon_R, class USoundAttenuation* AttenuationOverride, bool SoundShouldFollow?);
    void Battle Play Weapon L(class USoundBase* Battle_Weapon_L, class USoundAttenuation* AttenuationOverride, bool SoundShouldFollow?);
    void Battle_PlaySeqSFX(class USoundBase* Battle_PlaySeqSFX, class USoundAttenuation* AttenuationOverride, bool SoundShouldFollow?);
    void PlayBattleWeaponLeft(class UMetaSoundSource* BattleWeaponLeft, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void PlayBattleWeaponRight(class UMetaSoundSource* BattleWeaponRight, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void PlayBattleVocalEvent(class UMetaSoundSource* BattleVocal, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void PlayBattleSFXEvent(class UMetaSoundSource* BattleSFX, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void PlayBattleFootstepEvent(TEnumAsByte<EFootstepsType::Type> FootstepType, FVector Location, TEnumAsByte<EPhysicalSurface> SurfaceType, bool ShouldAttachToComponent?);
    void PlayBattleFoley(class UMetaSoundSource* BattleFoley, class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void PlayBattleUi(TEnumAsByte<EUiBattleType::Type> UI Battle Type, bool ShouldAttachToComponent?);
    void PlayBattleSoundProto(class USoundBase* BattlePlaceholder);
    void PlayHitByEvent(class UMetaSoundSource* BattleHitBy, bool ShouldAttachToComponent?);
    void PlayHitByCommonEvent(class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void ReceiveBeginPlay();
    void PlayHitBy_CallByBP(TEnumAsByte<EBattleHitBy::Type> Hit By_CallByBP);
    void Deactivate ControlBusMix(class USoundControlBusMix* Deactivate ControlBusMix);
    void Battle_Stop_AC_SFX_01();
    void Activate ControlBusMix(class USoundControlBusMix* Activate ControlBusMix);
    void PlayDeathCommon(class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void PlayBattleCommonSFX(TEnumAsByte<EBattleCommonSFX::Type> Battle Common SFX, bool ShouldAttachToComponent?);
    void PlayDeathCommon_Bodyfall(class USoundAttenuation* AttenuationOverride, bool ShouldAttachToComponent?);
    void PlayBattleOno(TEnumAsByte<EOnoType::Type> OnoType);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_AudioCharacter_BattleManager(int32 EntryPoint);
}; // Size: 0x250

#endif
