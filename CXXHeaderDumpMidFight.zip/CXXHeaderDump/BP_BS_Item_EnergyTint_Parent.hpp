#ifndef UE4SS_SDK_BP_BS_Item_EnergyTint_Parent_HPP
#define UE4SS_SDK_BP_BS_Item_EnergyTint_Parent_HPP

class ABP_BS_Item_EnergyTint_Parent_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    int32 Amount;                                                                     // 0x0310 (size: 0x4)
    class UNiagaraSystem* ApGainFx;                                                   // 0x0318 (size: 0x8)
    class USoundBase* Energy Tint Sound;                                              // 0x0320 (size: 0x8)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_BS_Item_EnergyTint_Parent(int32 EntryPoint);
}; // Size: 0x328

#endif
