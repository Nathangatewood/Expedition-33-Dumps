#ifndef UE4SS_SDK_BP_CharacterData_HPP
#define UE4SS_SDK_BP_CharacterData_HPP

class UBP_CharacterData_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    FName HardcodedNameID;                                                            // 0x0030 (size: 0x8)
    TMap<FFEquipmentSlot, FS_jRPG_Item_StaticData> EquipmentPerSlot;                  // 0x0038 (size: 0x50)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> BaseStats;                       // 0x0088 (size: 0x50)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> LevelingStats;                   // 0x00D8 (size: 0x50)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> EquipmentStats;                  // 0x0128 (size: 0x50)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> AttributeStats;                  // 0x0178 (size: 0x50)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> ComputedStats;                   // 0x01C8 (size: 0x50)
    int32 CurrentLevel;                                                               // 0x0218 (size: 0x4)
    int32 CurrentExperienceInLevel;                                                   // 0x021C (size: 0x4)
    int32 MaxActionPoints;                                                            // 0x0220 (size: 0x4)
    int32 LuminaMaxPointsFromLevel;                                                   // 0x0224 (size: 0x4)
    int32 LuminaMaxPointsFromConsumables;                                             // 0x0228 (size: 0x4)
    int32 CurrentlyUsedLuminaPoints;                                                  // 0x022C (size: 0x4)
    TArray<FName> EquippedPassiveEffects;                                             // 0x0230 (size: 0x10)
    TMap<FName, FFPassiveEffectProgression> PassiveEffectProgressions;                // 0x0240 (size: 0x50)
    double CurrentHP;                                                                 // 0x0290 (size: 0x8)
    double CurrentAP;                                                                 // 0x0298 (size: 0x8)
    FS_jRPG_CharacterDefinition CharacterDefinition;                                  // 0x02A0 (size: 0x328)
    TMap<TEnumAsByte<ECharacterAttribute::Type>, int32> AssignedCharacterAttributePoints; // 0x05C8 (size: 0x50)
    class UBP_DA_CharacterAttributeScalingProfile_C* AttributeScalingProfile;         // 0x0618 (size: 0x8)
    TMap<FName, int32> LearntSkills;                                                  // 0x0620 (size: 0x50)
    int32 MaxAttributesPointsFromLeveling;                                            // 0x0670 (size: 0x4)
    int32 MaxAttributesPointsFromItems;                                               // 0x0674 (size: 0x4)
    int32 SkillPointsFromLeveling;                                                    // 0x0678 (size: 0x4)
    int32 SkillPointsFromItems;                                                       // 0x067C (size: 0x4)
    int32 CurrentlyUsedSkillPoints;                                                   // 0x0680 (size: 0x4)
    TArray<UBP_DataAsset_Skill_C*> UnlockedSkills;                                    // 0x0688 (size: 0x10)
    TMap<UBP_DataAsset_Skill_C*, FFSkillUnlockData> CurrentSkillTreeUnlocksMap;       // 0x0698 (size: 0x50)
    FBP_CharacterData_COnSkillTreeChanged OnSkillTreeChanged;                         // 0x06E8 (size: 0x10)
    void OnSkillTreeChanged();
    TMap<UBP_DataAsset_Skill_C*, UBP_DataAsset_Skill_C*> CurrentSkillTreeParentsMap;  // 0x06F8 (size: 0x50)
    TMap<UBP_DataAsset_Skill_C*, FFSkillUnlockInfos> CurrentSkillTreeUnlockInfosMap;  // 0x0748 (size: 0x50)
    TArray<UBP_DataAsset_Skill_C*> EquippedSkills;                                    // 0x0798 (size: 0x10)
    FBP_CharacterData_COnChange OnChange;                                             // 0x07A8 (size: 0x10)
    void OnChange();
    FBP_CharacterData_COnExplorationDeath OnExplorationDeath;                         // 0x07B8 (size: 0x10)
    void OnExplorationDeath(class UBP_CharacterData_C* CharacterData);
    FS_CharacterCustomization CharacterCustomization;                                 // 0x07C8 (size: 0x50)
    FS_CharacterCustomizationItemData CharacterCustomizationItemData;                 // 0x0818 (size: 0x10)
    bool ShouldDeferUpdate;                                                           // 0x0828 (size: 0x1)
    bool IsDeferredUpdateDirty;                                                       // 0x0829 (size: 0x1)
    class UBP_CharacterSkillGraphSystem_C* SkillGraphSystem;                          // 0x0830 (size: 0x8)
    bool IsExcluded;                                                                  // 0x0838 (size: 0x1)
    TMap<FFEquipmentSlot, UBP_ItemInstance_Gear_C*> EquipmentInstancePerSlot;         // 0x0840 (size: 0x50)
    class UBP_DA_CharacterStatsPerLevelScalingProfile_C* StatPerLevelProfile;         // 0x0890 (size: 0x8)
    class UBP_DA_CharacterAttributeScalingProfile_DT_C* AttributeScalingProfile_DT;   // 0x0898 (size: 0x8)
    bool ShouldDispatchModifications;                                                 // 0x08A0 (size: 0x1)
    class UBP_DataAsset_SkillGraph_C* SkillGraph;                                     // 0x08A8 (size: 0x8)
    class UBP_DataAsset_CharacterExplorationAudioProfile_C* LoadedAudioProfile_Exploration; // 0x08B0 (size: 0x8)
    class UBP_DataAsset_CharacterBattleAudioProfile_C* LoadedAudioProfile_Battle;     // 0x08B8 (size: 0x8)
    class UBP_GearSetManager_C* GearSetManager;                                       // 0x08C0 (size: 0x8)

    void BPI_GetDependencies(TArray<TSoftClassPtr<UObject>>& Classes, TArray<TSoftObjectPtr<class UObject>>& Assets, TArray<TScriptInterface<class IBPI_LoadingDependenciesSource_C>>& ExternalDependencies);
    void SetManuallyEquippedPassiveEffects(TArray<FName>& Array);
    void GetManuallyEquippedPassiveEffects(TArray<FName>& Array);
    void GetGearSetManager(class UBP_GearSetManager_C*& GearSetManager);
    void InitializeGearSetManager(FS_jRPG_CharacterSaveState CharacterSaveState);
    void GetWeaponScalingPotencyMultiplier(TEnumAsByte<EAttributeScalingGrade::Type> ScalingGrade, const TEnumAsByte<ECharacterAttribute::Type> Attribute, double& Multiplier);
    void GetCustomizationTypeForCharacter(FS_jRPG_Item_StaticData Item, TEnumAsByte<E_CustomizationItemType::Type>& CustomizationType);
    class UBP_DataAsset_CharacterExplorationAudioProfile_C* GetAudioProfile_Exploration();
    void DispatchModificationsIfPossible(const FString DebugReason);
    void SetShouldDispatchModifications(bool ShouldDispatchModifications);
    void GetCharacterGenderTag(ETextGender& GenderTag);
    void GetEquippedPassiveEffectsData(TArray<FFPassiveEffect>& PassiveEffectDefinitions);
    void LearnPassiveEffectShared(FName PassiveEffectID);
    void ProgressPassiveEffectShared(FName PassiveEffectID);
    void SetPassiveEffectSharedProgression(FName PassiveEffectID, int32 LearntSteps);
    void GetMaxLuminaPointsDetails(int32& FromLevel, int32& FromConsumables);
    void AddLuminaPointFromConsumable();
    void GetExplorationAudioProfile(class UBP_DataAsset_CharacterExplorationAudioProfile_C*& AudioProfileAsset);
    void GetGearPassiveEffects(class UBP_ItemInstance_Gear_C* GearInstance, TArray<FName>& PassiveEffectIDs);
    bool CanUseGearPassiveEffects(class UBP_ItemInstance_Base_C* ItemInstance);
    bool CanUseWeaponPassiveEffects();
    bool HasReachedMaximulLevel();
    bool HasMoreSkillsToEquip();
    class UBP_ItemInstance_Gear_Weapon_C* GetEquippedWeaponItemInstance(bool& Valid);
    void UnequipItemFromInstance(class UBP_ItemInstance_Gear_C* GearInstance);
    void UnequipItemInstanceInSlot(FFEquipmentSlot Slot);
    void ReplaceItemInstanceInSlot(const FFEquipmentSlot& Slot, class UBP_ItemInstance_Gear_C* Item);
    void EquipMissingLuminaPassivesFromItemInstance(class UBP_ItemInstance_Gear_C* ItemInstance);
    void GetWeaponInstancePower(class UBP_ItemInstance_Gear_Weapon_C* WeaponInstanceData, int32& TotalDamage, int32& BaseDamage, int32& ScalingDamage, TMap<TEnumAsByte<ECharacterAttribute::Type>, int32>& ScalingDamageByAttribute);
    void GetGearItemsFromEquipmentSlots(TMap<FFEquipmentSlot, FS_jRPG_Item_StaticData> EquipmentPerSlot);
    void GetIsExcluded(bool& Excluded);
    void SetIsExcluded(bool Excluded);
    TEnumAsByte<EAttackType::Type> GetElementForSkill(class UBP_DataAsset_Skill_C* SkillDefinition);
    FS_WeaponDefinition GetEquippedWeaponDefinition(bool& Valid);
    FS_jRPG_Item_StaticData GetEquippedWeaponItem(bool& Valid);
    void OnSkillGraphStateChanged();
    bool HasLearnableSkills();
    void FlushDeferredUpdate();
    void StartDeferUpdate();
    bool CanUpdateInternals();
    void GetAvailablePassiveEffectsForSlots(TArray<FFEquipmentSlot>& Slots, TArray<FName>& PassiveEffectIDs);
    void EquipMissingLuminaPassivesFromItems(FS_jRPG_Item_StaticData& Item);
    void GetAllowedEquipmentSubtypes(TSet<TEnumAsByte<E_jRPG_ItemSubtype::Type>>& AllowedEquipmentSubtypes);
    void UnequipLuminaPassiveListInternal(TArray<FName>& PassiveIDs);
    void ApplyCharacterCustomizationItem(FName ItemName);
    void LoadCharacterCustomizationFromItemData();
    void SetCharacterCustomizationItemData(FS_CharacterCustomizationItemData CharacterCustomizationItemData);
    void Get Weapon Power(FS_WeaponInstanceData WeaponInstanceData, int32& PhysicalPower, int32& MagicalPower, int32& BasePhysicalPower, int32& BaseMagicalPower, int32& ScalingPhysicalPower, int32& ScalingMagicalPower);
    void GetAttributeStats(TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& EquipmentStats);
    void GetEquipmentStats(TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& EquipmentStats);
    class UBP_CharacterData_C* CreateCopy();
    void ComputeAttributeStats(const TMap<TEnumAsByte<ECharacterAttribute::Type>, int32>& AssignedAttributes);
    void GetEquippedSkillsSaveData(TArray<FName>& EquippedSkillIDs);
    void GetBattleStartAP_Count(int32& AP_Count);
    bool CanAffordSkillUnlock(class UBP_DataAsset_Skill_C* Skill);
    void GetSkillState(class UBP_DataAsset_Skill_C* Skill, TEnumAsByte<ESkillNodeState::Type>& NodeState);
    void ReceiveExplorationDamagePercent(int32 Percent);
    void ReceiveExplorationDamage(int32 Amount);
    void UnequipLuminaPassiveList(TArray<FName>& PassiveIDs);
    void SetEquippedSkillOverrides(TArray<UBP_DataAsset_Skill_C*>& EquippedSkills);
    void GetEquippedSkills(TArray<UBP_DataAsset_Skill_C*>& EquippedSkills);
    void UnequipSkill(class UBP_DataAsset_Skill_C* SkillID);
    void EquipSkill(class UBP_DataAsset_Skill_C* SkillID);
    void InitializeAssignedAttributePoints();
    void ResetAssignedAttributePoints();
    void GetTotalAssignedAttributePoints(int32& TotalAssignedAttributePoints);
    void GetAssignedAttributePoints(const TEnumAsByte<ECharacterAttribute::Type> Attribute, int32& Value);
    void GetUnlockedSkillSaveData(TArray<FName>& UnlockedSkillIDs);
    bool HasLearntAnyAdjacentSkill(const class UBP_DataAsset_Skill_C*& Skill);
    bool CanLearnSkill_OLD(const class UBP_DataAsset_Skill_C*& Skill, TEnumAsByte<ELearnSkillBlockedReason::Type>& BlockedReason);
    bool CanLearnSkill(const class UBP_DataAsset_Skill_C*& Skill, TEnumAsByte<ELearnSkillBlockedReason::Type>& BlockedReason);
    void TryUnlockSkill(class UBP_DataAsset_Skill_C* Skill, bool& Success);
    void GetSkillGraph(class UBP_DataAsset_SkillGraph_C*& SkillGraph);
    void GetSkillTree(class UBP_DataAsset_SkillTree_C*& SkillTree);
    bool IsSkillUnlocked(const class UBP_DataAsset_Skill_C*& Skill);
    int32 GetAvailableSkillPoints();
    int32 GetTotalSkillPoints();
    int32 GetAttributePointsToAssign();
    void LoadAssignedAttributePoints(TMap<TEnumAsByte<ECharacterAttribute::Type>, int32> InputPin);
    int32 GetMaxAttributePoints();
    void GetCharacterIconBig(class UTexture2D*& CharacterIconBig);
    void GetActionsOrder(TArray<FName>& CharacterActionsOrder);
    void GetLearntSkills(TMap<FName, int32>& LearntSkills);
    void GetOverdriveSources(FS_jRPG_OverdriveSource& OverdriveSources);
    void GetCommonBattleStats(FFCharacterStats& CommonStats);
    void GetBattleSoftClass(TSoftClassPtr<ABP_jRPG_Character_Battle_Base_C>& CharacterActorSoftClass);
    void GetBattleIcon(class UTexture2D*& CharacterIconBattle);
    void GetBaseStats(TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& CharacterStats);
    void AssignPointToAttribute(TEnumAsByte<ECharacterAttribute::Type> Attribute);
    void GetPassiveEffectProgressionFromItem(FS_jRPG_Item_StaticData ItemData, bool& Found, FFPassiveEffectProgression& Progression);
    void GetEquipmentSaveData(TMap<FFEquipmentSlot, FName>& local_equipmentPerSlotSave1);
    void GetMaxHP(double& MaxHP);
    void GetHPPercent(double& HPPercent);
    void LoadBattleFinalState(FS_BattleCharacterFinalState CharacterFinalState);
    class UTexture2D* GetArmUITexture();
    void GetBattleAudioProfile(FFCharacterBattleAudioProfile& BattleAudioProfile);
    bool CanEquipItem(FS_jRPG_Item_StaticData ItemData);
    void GetAudioProfile_Battle(FFCharacterBattleAudioProfile& BattleAudioProfile);
    void AddExperience(int32 XP);
    void GetCurrentLevelExperience(int32& CurrentExperienceInLevel);
    void GetCurrentLevelExperienceProgression(double& Progress);
    bool HasPassiveEffectProgressionData(const FName& Key);
    void DEBUG_UnlockAllLuminaPassives();
    void GetAvailablePassiveEffects(TArray<FName>& PassiveEffectIDs, TArray<FName>& EquipmentPassiveEffectIDs, TArray<FName>& LearntPassiveEffectIDs);
    void GetCharacterDisplayName(FText& CharacterDisplayName);
    void GetSlotForItem(FName ItemId, bool& Found, FFEquipmentSlot& Slot);
    void GetItemInstanceInSlot(FFEquipmentSlot Slot, class UBP_ItemInstance_Gear_C*& ItemInstance);
    void GetItemInSlot(FFEquipmentSlot Slot, FS_jRPG_Item_StaticData& Value);
    void GetAllEquipmentSlotTypes(TArray<FFEquipmentSlot>& EquipmentSlots);
    bool IsSlotEmpty(const FFEquipmentSlot& Slot);
    bool IsSlotUsed(const FFEquipmentSlot& Key);
    void UnequipItem(FS_jRPG_Item_StaticData Item);
    void InitLuminaPassiveProgression(FName PassiveEffectID);
    void OnNewItemAcquired(FS_jRPG_Item_StaticData& ItemStaticData);
    void HasItemEquipped(FName ItemId, bool& IsEquipped, FFEquipmentSlot& Slot);
    void GetCharacterDeadPortrait(class UMaterialInstance*& CharacterDeadPortrait);
    void GetCharacterPortrait(class UTexture2D*& CharacterIcon);
    void UpdatePassiveEffectProgression(FFPassiveEffectProgression DirtyProgression, FFPassiveEffectProgression& UpdatedProgression);
    void GetPassiveEffectProgression(const FName& PassiveEffectID, FFPassiveEffectProgression& Progression);
    void ProgressEquippedLuminas();
    void DEBUG_CVarChange_IgnoreLuminaCost(bool NewValue);
    void DoEquippedItemsGivePassiveEffect(FName PassiveEffectID, bool& GivePassiveEffect);
    void UpdateLuminaSystem();
    void IsPassiveEffectUnlocked(FName PassiveEffectName, bool& IsUnlocked, bool& BecauseLearnt, bool& BecauseEquipment);
    void RefreshUsedLuminaPointsInternal();
    int32 GetAvailableLuminaPoints();
    bool CanAffordLuminaCost(int32 LuminaCost);
    int32 GetEffectiveLuminaCost(FFPassiveEffect PassiveEffectDefinition, const FFPassiveEffectProgression& PassiveEffectProgression);
    void Error_PassiveEffectNotFoundInDT(FName Name);
    void UnequipLuminaPassive(FName Name);
    void EquipLuminaPassive(FName Name);
    void TryEquipLuminaPassive(FName Name, bool& Successful);
    bool CanEquipLuminaPassive(FFPassiveEffect PassiveEffectDefinition, const FFPassiveEffectProgression& PassiveEffectProgression, int32& EffectiveCost);
    int32 GetCurrentlyUsedLuminaPoints();
    int32 GetMaxLuminaPoints();
    void GetLuminaDisplayDataFromName(FName Name, FS_PassiveEffectDisplayData& PassiveEffectDisplayData);
    void GetLuminaInfoFromName(FName Name, FFPassiveEffect& Definition, FFPassiveEffectProgression& Progression);
    void ComputeStatsFromParts(const TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& base, const TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& Leveling, const TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& Equipment, TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> Attributes, TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& ComputedStats);
    void PreviewStatsWithEquipmentOverrides(TMap<FFEquipmentSlot, UBP_ItemInstance_Gear_C*> EquipmentOverrides, TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& StatsPreview);
    void MergeCurrentEquipmentInstancesWithOverrides(TMap<FFEquipmentSlot, UBP_ItemInstance_Gear_C*> EquipmentOverrides, TMap<FFEquipmentSlot, UBP_ItemInstance_Gear_C*>& MergedEquipment);
    void ComputeEquipmentStats(const TMap<FFEquipmentSlot, UBP_ItemInstance_Gear_C*>& EquipmentInstances, TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& EquipmentStats);
    void SetLevel(int32 NewLevel);
    void GetCharacterStats(TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& Stats);
    void UpdateStats();
    void Update Attribute Stats();
    void UpdateEquipmentStats();
    void UpdateLevelingStats();
    void UnequipItemInSlot(FFEquipmentSlot Slot);
    void EquipItemInstanceInSlot(FFEquipmentSlot Slot, class UBP_ItemInstance_Gear_C* Item);
    void EquipItemInSlot(FFEquipmentSlot Slot, FS_jRPG_Item_StaticData& Item);
    void ReplaceItemInSlot(const FFEquipmentSlot& Slot, FS_jRPG_Item_StaticData& Item);
    void SaveCharacterState(FS_jRPG_CharacterSaveState& OutState, FS_jRPG_CharacterSaveState& StructOut);
    void LoadCharacterState(FS_jRPG_CharacterSaveState CharacterState);
    void LoadCharacterDefinition(FS_jRPG_CharacterDefinition CharacterDefinition);
    void LoadCharacterBaseDataFromID(FName HardcodedNameID);
    void LoadCharacterBaseDataLegacy(FS_jRPG_CharacterSaveState Legacy_CharacterSaveData, class UBP_jRPG_GI_Custom_C*& LegacyOnly_GameInstance);
    void DEBUG_ForceProgressEquippedLumina();
    void ExecuteUbergraph_BP_CharacterData(int32 EntryPoint);
    void OnExplorationDeath__DelegateSignature(class UBP_CharacterData_C* CharacterData);
    void OnChange__DelegateSignature();
    void OnSkillTreeChanged__DelegateSignature();
}; // Size: 0x8C8

#endif
