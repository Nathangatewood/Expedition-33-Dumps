#ifndef UE4SS_SDK_BP_BattleBuff_Enraged_HPP
#define UE4SS_SDK_BP_BattleBuff_Enraged_HPP

class UBP_BattleBuff_Enraged_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    bool ShouldPlayAgainNextTurn;                                                     // 0x0160 (size: 0x1)
    bool NextTurnIsEnraged;                                                           // 0x0161 (size: 0x1)

    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void DeactivateBuff();
    void ExecuteUbergraph_BP_BattleBuff_Enraged(int32 EntryPoint);
}; // Size: 0x162

#endif
