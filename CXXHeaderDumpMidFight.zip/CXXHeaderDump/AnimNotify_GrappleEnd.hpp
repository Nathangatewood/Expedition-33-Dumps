#ifndef UE4SS_SDK_AnimNotify_GrappleEnd_HPP
#define UE4SS_SDK_AnimNotify_GrappleEnd_HPP

class UAnimNotify_GrappleEnd_C : public UAnimNotify
{

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x38

#endif
