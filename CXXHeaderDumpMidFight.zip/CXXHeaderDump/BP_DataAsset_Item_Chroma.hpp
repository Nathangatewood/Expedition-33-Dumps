#ifndef UE4SS_SDK_BP_DataAsset_Item_Chroma_HPP
#define UE4SS_SDK_BP_DataAsset_Item_Chroma_HPP

class UBP_DataAsset_Item_Chroma_C : public UBP_DataAsset_Item_C
{
    double Multiplier;                                                                // 0x0030 (size: 0x8)

    void OnAddedToInventory(class UAC_jRPG_InventoryManager_C* InventoryManager, FName ItemId, FS_LootContext& LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItem);
}; // Size: 0x38

#endif
