#ifndef UE4SS_SDK_BP_Cine_Maelle_HPP
#define UE4SS_SDK_BP_Cine_Maelle_HPP

class ABP_Cine_Maelle_C : public ABP_CineCharacter_Main_C
{
}; // Size: 0x698

#endif
