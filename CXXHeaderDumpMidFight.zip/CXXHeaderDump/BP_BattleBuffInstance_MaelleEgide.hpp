#ifndef UE4SS_SDK_BP_BattleBuffInstance_MaelleEgide_HPP
#define UE4SS_SDK_BP_BattleBuffInstance_MaelleEgide_HPP

class UBP_BattleBuffInstance_MaelleEgide_C : public UBP_BattleBuff_InterceptTargetDamage_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0160 (size: 0x8)
    TArray<UNiagaraComponent*> EgideFX;                                               // 0x0168 (size: 0x10)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ProcessAddBuffAction(const class UAction_AddBuff_C*& BuffAddAction);
    void ExecuteUbergraph_BP_BattleBuffInstance_MaelleEgide(int32 EntryPoint);
}; // Size: 0x178

#endif
