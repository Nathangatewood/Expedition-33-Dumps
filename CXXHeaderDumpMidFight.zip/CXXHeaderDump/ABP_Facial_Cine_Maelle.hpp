#ifndef UE4SS_SDK_ABP_Facial_Cine_Maelle_HPP
#define UE4SS_SDK_ABP_Facial_Cine_Maelle_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x1750

class UABP_Facial_Cine_Maelle_C : public UABP_Facial_Cine_Main_C
{
}; // Size: 0x305D

#endif
