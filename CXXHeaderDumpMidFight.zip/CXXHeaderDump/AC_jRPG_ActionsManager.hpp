#ifndef UE4SS_SDK_AC_jRPG_ActionsManager_HPP
#define UE4SS_SDK_AC_jRPG_ActionsManager_HPP

class UAC_jRPG_ActionsManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UBP_jRPG_GI_Custom_C* GameInstanceReference;                                // 0x00A8 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> UNUSED_TargetHeroes;                    // 0x00B0 (size: 0x10)
    bool PureWhiteLearnt;                                                             // 0x00C0 (size: 0x1)
    bool FleeImpossible;                                                              // 0x00C1 (size: 0x1)
    double DamageCount;                                                               // 0x00C8 (size: 0x8)
    bool IsSecondTrigger;                                                             // 0x00D0 (size: 0x1)
    class ABP_jRPG_Character_Battle_Base_C* AllyDualTarget;                           // 0x00D8 (size: 0x8)
    double CurrentDamagesDealt;                                                       // 0x00E0 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> Target List;                            // 0x00E8 (size: 0x10)
    double StanceDamageMultiply;                                                      // 0x00F8 (size: 0x8)
    bool BurningPraiseConditionFilled;                                                // 0x0100 (size: 0x1)
    FDataTableRowHandle SoundEventFleeSelect;                                         // 0x0108 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEventTurnPass;                                 // 0x0118 (size: 0x10)

    void GetActionData(FName ActionName, FS_jRPG_Action& Out Row, bool& Found);
    void SkipTurn();
    void StanceDamageMultiplier();
    void CheckTargetBuff(class UAC_jRPG_CharacterBattleStats_C*& Target, TSubclassOf<class UBP_BattleBuffInstance_C> Buff, bool& HasBuff);
    void AttackStatCalculation_WithPerfection(double& Power, double& CritRate, double& CriticalPower, double& Sharpness);
    void AttackStatCalculation(double& Power, double& CritRate, double& CriticalPower, double& Sharpness, double& Defense, double& Speed, double& Luck, double& HP, double& AP);
    void Select_Magic_SinglleAllyAny();
    void Select_Magic_SingleEnemyAny();
    void Select_Magic_AllAlliesDead();
    void Select_Magic_SingleAllyDead();
    void CallFunctionByName(FString FunctionName);
    void AreAllAlive(TArray<ABP_jRPG_Character_Battle_Base_C*>& NewParam, bool& SomeAreAlive);
    void Select_Magic_SingleAllyAndEnemy();
    void Select_Magic_AllAllies();
    void Select_Magic_AllEnemies();
    void Select_Magic_SingleEnemy();
    void Select_Magic_OnlySelf();
    void Select_Magic_SingleAlly();
    void Select_Test();
    void GetActionCost(FName ActionName, double& CostHP, double& CostMP);
    void Select_Magic_Heal();
    void Flee();
    void Defend();
    void Attack();
    void Select_Magic_Thunder();
    void Select_Magic_Fireball();
    void Select_Flee();
    void Select_Defend();
    void Select_Attack();
    void ActivateActionEffect();
    void SelectAction(TEnumAsByte<E_jRPG_ActionType::Type> ActionType, FName SecondaryActionName);
    void ReceiveBeginPlay();
    void FleeStart();
    void FreezeFrame(double TimeDilation, double Duration);
    void FleeActivation();
    void ExecuteUbergraph_AC_jRPG_ActionsManager(int32 EntryPoint);
}; // Size: 0x128

#endif
