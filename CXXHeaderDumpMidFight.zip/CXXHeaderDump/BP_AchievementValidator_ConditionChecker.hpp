#ifndef UE4SS_SDK_BP_AchievementValidator_ConditionChecker_HPP
#define UE4SS_SDK_BP_AchievementValidator_ConditionChecker_HPP

class UBP_AchievementValidator_ConditionChecker_C : public UBP_AchievementValidator_C
{
    FConditionChecker_Wrapper ConditionChecker;                                       // 0x0050 (size: 0x8)

    void EvaluateAchievement();
    void Uninitialize();
    void Initialize(class UGameInstance* GameInstance, bool& IsValidated);
}; // Size: 0x58

#endif
