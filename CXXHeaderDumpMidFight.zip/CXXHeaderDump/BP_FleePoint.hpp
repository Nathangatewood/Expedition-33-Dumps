#ifndef UE4SS_SDK_BP_FleePoint_HPP
#define UE4SS_SDK_BP_FleePoint_HPP

class ABP_FleePoint_C : public ATargetPoint
{
    class UTextRenderComponent* TextRender;                                           // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0298 (size: 0x8)
    TArray<ABP_FleePoint_C*> LinkedFleePoints;                                        // 0x02A0 (size: 0x10)
    TArray<USceneComponent*> DebugComponents;                                         // 0x02B0 (size: 0x10)
    bool IsEndLocation;                                                               // 0x02C0 (size: 0x1)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void LinkFleePoints();
    void ComputeFleePointDistance(class AActor* FleePoint, double& Distance, bool& IsAtValidDistance);
    void UpdateDebugDisplay();
    void FindNextFleePoint(class AActor* PursuerActor, class ABP_FleePoint_C*& FleePoint);
    void UserConstructionScript();
}; // Size: 0x2C1

#endif
