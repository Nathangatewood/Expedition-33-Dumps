#ifndef UE4SS_SDK_BP_DEPRECIATE_EnvironmentInteractionComponent_HPP
#define UE4SS_SDK_BP_DEPRECIATE_EnvironmentInteractionComponent_HPP

class UBP_DEPRECIATE_EnvironmentInteractionComponent_C : public USceneComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0230 (size: 0x8)
    float Interaction Size;                                                           // 0x0238 (size: 0x4)
    TArray<UNiagaraComponent*> NiagaraSystems;                                        // 0x0240 (size: 0x10)
    float Impact Duration;                                                            // 0x0250 (size: 0x4)
    float Impact power / Alpha;                                                       // 0x0254 (size: 0x4)
    float Spawn Rate / Optimisation;                                                  // 0x0258 (size: 0x4)
    TArray<UMaterialInterface*> OverrideMaterialList;                                 // 0x0260 (size: 0x10)
    double Radius;                                                                    // 0x0270 (size: 0x8)
    bool Active Interactor;                                                           // 0x0278 (size: 0x1)
    double Impact Size;                                                               // 0x0280 (size: 0x8)
    double Save Impact Size;                                                          // 0x0288 (size: 0x8)
    double Impact Opacity;                                                            // 0x0290 (size: 0x8)
    double Save Impact Opacity;                                                       // 0x0298 (size: 0x8)
    bool AllowRotationMaterial;                                                       // 0x02A0 (size: 0x1)

    void CreateSecondaryNiagaraSystemIfNeeded();
    void GetMainParticleSystem(class UNiagaraComponent*& NiagaraSystem);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_DEPRECIATE_EnvironmentInteractionComponent(int32 EntryPoint);
}; // Size: 0x2A1

#endif
