#ifndef UE4SS_SDK_ABP_Maelle_Battle_V2_HPP
#define UE4SS_SDK_ABP_Maelle_Battle_V2_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x3B70

class UABP_Maelle_Battle_V2_C : public UABP_Battle_Global_C
{
}; // Size: 0x5F30

#endif
