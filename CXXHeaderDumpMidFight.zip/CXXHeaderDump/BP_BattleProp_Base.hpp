#ifndef UE4SS_SDK_BP_BattleProp_Base_HPP
#define UE4SS_SDK_BP_BattleProp_Base_HPP

class ABP_BattleProp_Base_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0290 (size: 0x8)

    void TryGetEnemyAtSpot(class ABP_jRPG_EnemyBattleSpot_C* BattleSpot, class ABP_jRPG_Character_Battle_Base_C*& CharacterBase, bool& Found);
    void OnSyphArrowHit();
}; // Size: 0x298

#endif
