#ifndef UE4SS_SDK_BP_ExplorationProgressionSystem_HPP
#define UE4SS_SDK_BP_ExplorationProgressionSystem_HPP

class UBP_ExplorationProgressionSystem_C : public UExtendedObject
{
    TArray<TEnumAsByte<E_ExplorationCapacity::Type>> UnlockedExplorationCapacities;   // 0x0028 (size: 0x10)
    int32 FreeAimDamageLevel;                                                         // 0x0038 (size: 0x4)
    FBP_ExplorationProgressionSystem_COnFreeAimTeleportUnlocked OnFreeAimTeleportUnlocked; // 0x0040 (size: 0x10)
    void OnFreeAimTeleportUnlocked();
    FBP_ExplorationProgressionSystem_COnFreeAimDamageLevelUnlocked OnFreeAimDamageLevelUnlocked; // 0x0050 (size: 0x10)
    void OnFreeAimDamageLevelUnlocked(int32 NewLevel);
    TArray<TEnumAsByte<E_WorldMapExplorationCapacity::Type>> UnlockedWorldMapCapacities; // 0x0060 (size: 0x10)
    FBP_ExplorationProgressionSystem_COnWorldMapCapacityUnlocked OnWorldMapCapacityUnlocked; // 0x0070 (size: 0x10)
    void OnWorldMapCapacityUnlocked(TEnumAsByte<E_WorldMapExplorationCapacity::Type> WorldMapCapacity);
    FBP_ExplorationProgressionSystem_COnAnyWorldMapCapacityUnlocked OnAnyWorldMapCapacityUnlocked; // 0x0080 (size: 0x10)
    void OnAnyWorldMapCapacityUnlocked();
    bool ShouldDispatchModifications;                                                 // 0x0090 (size: 0x1)
    FBP_ExplorationProgressionSystem_COnAnyExplorationCapacityUnlocked OnAnyExplorationCapacityUnlocked; // 0x0098 (size: 0x10)
    void OnAnyExplorationCapacityUnlocked();

    void DEBUG_UnlockExplorationCapacity(TEnumAsByte<E_ExplorationCapacity::Type> Capacity, bool Unlocked);
    void DEBUG_OnCVarChanged_Camp(bool NewValue);
    void DEBUG_OnCVarChanged_AttackInWorld(bool NewValue);
    void DEBUG_OnCVarChanged_FreeAim(bool NewValue);
    void DEBUG_OnCVarChanged_Overlay(bool NewValue);
    void DEBUG_OnCVarChanged_GameMenu(bool NewValue);
    void IsExplorationCapacityUnlocked(TEnumAsByte<E_ExplorationCapacity::Type> Capacity, bool& IsUnlocked);
    void GetUnlockedExplorationCapacities(TArray<TEnumAsByte<E_ExplorationCapacity::Type>>& UnlockedExplorationCapacities);
    void SetExplorationCapacityUnlocked(TEnumAsByte<E_ExplorationCapacity::Type> Capacity, bool Unlocked);
    void GetUnlockedWorldMapCapacities(TArray<TEnumAsByte<E_WorldMapExplorationCapacity::Type>>& UnlockedWorldMapCapacities);
    void DEBUG_LoadCVar_UnlockedWorldMapCapacities(FString SourceString);
    void DEBUG_OnCVarChanged_Teleport(bool NewValue);
    void DEBUG_LoadCVar_DamageLevel(FString InputPin);
    void DEBUG_OnCVarChanged_DamageLevel(FString NewValue);
    void DEBUG_UnlockFreeAimDamageLevel(int32 DamageLevel);
    void DEBUG_LoadCVars();
    void IsWorldMapCapacityUnlocked(TEnumAsByte<E_WorldMapExplorationCapacity::Type> Capacity, bool& IsUnlocked);
    void UnlockWorldMapCapacities(TArray<TEnumAsByte<E_WorldMapExplorationCapacity::Type>>& Capacities);
    void GetFreeAimDamageLevel(int32& FreeAimDamageLevel);
    void UnlockFreeAimDamageLevel(int32 DamageLevel);
    void IsFreeAimTeleportUnlocked(bool& FreeAimTeleportUnlocked);
    void UnlockFreeAimTeleport();
    void ResetState();
    void SaveState(FFExplorationProgression_SaveState& State);
    void LoadState(FFExplorationProgression_SaveState State);
    void Initialize();
    void OnWorldMapCapacityUnlocked__DelegateSignature(TEnumAsByte<E_WorldMapExplorationCapacity::Type> WorldMapCapacity);
    void OnAnyExplorationCapacityUnlocked__DelegateSignature();
    void OnAnyWorldMapCapacityUnlocked__DelegateSignature();
    void OnFreeAimDamageLevelUnlocked__DelegateSignature(int32 NewLevel);
    void OnFreeAimTeleportUnlocked__DelegateSignature();
}; // Size: 0xA8

#endif
