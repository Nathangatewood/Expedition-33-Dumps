#ifndef UE4SS_SDK_Battle_Shake2_HPP
#define UE4SS_SDK_Battle_Shake2_HPP

class UBattle_Shake2_C : public UDefaultCameraShakeBase
{

    void NewFunction_0();
}; // Size: 0xE0

#endif
