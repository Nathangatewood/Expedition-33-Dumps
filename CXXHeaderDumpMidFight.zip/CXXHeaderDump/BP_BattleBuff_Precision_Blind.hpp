#ifndef UE4SS_SDK_BP_BattleBuff_Precision_Blind_HPP
#define UE4SS_SDK_BP_BattleBuff_Precision_Blind_HPP

class UBP_BattleBuff_Precision_Blind_C : public UBP_BattleBuff_PrecisionParent_C
{
}; // Size: 0x178

#endif
