#ifndef UE4SS_SDK_BP_BattleBuffInstanceWrapper_HPP
#define UE4SS_SDK_BP_BattleBuffInstanceWrapper_HPP

class UBP_BattleBuffInstanceWrapper_C : public UExtendedObject
{
    class UBP_BattleBuffInstance_C* BattleBuffInstance;                               // 0x0028 (size: 0x8)
    TArray<FGuid> StatMultipliers;                                                    // 0x0030 (size: 0x10)
    int32 CurrentTurnHitCount;                                                        // 0x0040 (size: 0x4)
    FBP_BattleBuffInstanceWrapper_COnBuffDeactivated OnBuffDeactivated;               // 0x0048 (size: 0x10)
    void OnBuffDeactivated(class UBP_BattleBuffInstanceWrapper_C* BattleBuffInstanceWrapper);

    void ProcessReceivedRawDamages(class UBP_BattleDamages_C*& BattleDamages);
    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages);
    void OnCharacterTurnStart();
    void ProcessReceivedFinalDamages(class UBP_BattleDamages_C*& BattleDamages);
    void DeactivateBuff();
    void IsActive(bool& IsActive);
    void HasExpired(bool& HasExpired);
    void ApplyBuffOnTurnEnd();
    void ActivateBuff(class UAC_jRPG_CharacterBattleStats_C*& TargetCharacterStats);
    void OnBuffDeactivated__DelegateSignature(class UBP_BattleBuffInstanceWrapper_C* BattleBuffInstanceWrapper);
}; // Size: 0x58

#endif
