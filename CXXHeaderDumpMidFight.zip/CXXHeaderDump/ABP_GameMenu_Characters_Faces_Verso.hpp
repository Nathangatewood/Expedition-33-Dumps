#ifndef UE4SS_SDK_ABP_GameMenu_Characters_Faces_Verso_HPP
#define UE4SS_SDK_ABP_GameMenu_Characters_Faces_Verso_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x1698

class UABP_GameMenu_Characters_Faces_Verso_C : public UABP_GameMenu_Characters_Faces_C
{
}; // Size: 0x20C0

#endif
