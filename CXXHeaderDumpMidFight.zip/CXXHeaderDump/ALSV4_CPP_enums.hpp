enum class EALSAnimFeatureExample {
    StrideBlending = 0,
    AdditiveBlending = 1,
    SprintImpulse = 2,
    EALSAnimFeatureExample_MAX = 3,
};

enum class EALSFootstepType {
    Step = 0,
    WalkRun = 1,
    Jump = 2,
    Land = 3,
    EALSFootstepType_MAX = 4,
};

enum class EALSGait {
    Walking = 0,
    Running = 1,
    Sprinting = 2,
    EALSGait_MAX = 3,
};

enum class EALSGroundedEntryState {
    None = 0,
    Roll = 1,
    EALSGroundedEntryState_MAX = 2,
};

enum class EALSHipsDirection {
    F = 0,
    B = 1,
    RF = 2,
    RB = 3,
    LF = 4,
    LB = 5,
    EALSHipsDirection_MAX = 6,
};

enum class EALSMantleType {
    HighMantle = 0,
    LowMantle = 1,
    FallingCatch = 2,
    EALSMantleType_MAX = 3,
};

enum class EALSMovementAction {
    None = 0,
    LowMantle = 1,
    HighMantle = 2,
    Rolling = 3,
    GettingUp = 4,
    EALSMovementAction_MAX = 5,
};

enum class EALSMovementDirection {
    Forward = 0,
    Right = 1,
    Left = 2,
    Backward = 3,
    EALSMovementDirection_MAX = 4,
};

enum class EALSMovementState {
    None = 0,
    Grounded = 1,
    InAir = 2,
    Mantling = 3,
    Ragdoll = 4,
    EALSMovementState_MAX = 5,
};

enum class EALSOverlayState {
    Default = 0,
    Masculine = 1,
    Feminine = 2,
    Injured = 3,
    HandsTied = 4,
    Rifle = 5,
    PistolOneHanded = 6,
    PistolTwoHanded = 7,
    Bow = 8,
    Torch = 9,
    Binoculars = 10,
    Box = 11,
    Barrel = 12,
    EALSOverlayState_MAX = 13,
};

enum class EALSRotationMode {
    VelocityDirection = 0,
    LookingDirection = 1,
    Aiming = 2,
    EALSRotationMode_MAX = 3,
};

enum class EALSSpawnType {
    Location = 0,
    Attached = 1,
    EALSSpawnType_MAX = 2,
};

enum class EALSStance {
    Standing = 0,
    Crouching = 1,
    EALSStance_MAX = 2,
};

enum class EALSViewMode {
    ThirdPerson = 0,
    FirstPerson = 1,
    EALSViewMode_MAX = 2,
};

