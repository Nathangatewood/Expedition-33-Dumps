#ifndef UE4SS_SDK_BP_CharacterFaceBase_Monoco_HPP
#define UE4SS_SDK_BP_CharacterFaceBase_Monoco_HPP

class ABP_CharacterFaceBase_Monoco_C : public ABP_CharacterFaceBase_C
{
}; // Size: 0x2E0

#endif
