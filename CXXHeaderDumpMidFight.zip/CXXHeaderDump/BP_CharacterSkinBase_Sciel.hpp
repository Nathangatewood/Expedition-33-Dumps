#ifndef UE4SS_SDK_BP_CharacterSkinBase_Sciel_HPP
#define UE4SS_SDK_BP_CharacterSkinBase_Sciel_HPP

class ABP_CharacterSkinBase_Sciel_C : public ABP_CharacterSkinBase_C
{
    class USkeletalMeshComponent* SK_Hair_Bun;                                        // 0x03A0 (size: 0x8)
    bool BaseSkin;                                                                    // 0x03A8 (size: 0x1)

}; // Size: 0x3A9

#endif
