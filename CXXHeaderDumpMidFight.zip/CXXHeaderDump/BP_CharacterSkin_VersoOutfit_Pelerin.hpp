#ifndef UE4SS_SDK_BP_CharacterSkin_VersoOutfit_Pelerin_HPP
#define UE4SS_SDK_BP_CharacterSkin_VersoOutfit_Pelerin_HPP

class ABP_CharacterSkin_VersoOutfit_Pelerin_C : public ABP_CharacterSkinBase_Verso_C
{
}; // Size: 0x3B0

#endif
