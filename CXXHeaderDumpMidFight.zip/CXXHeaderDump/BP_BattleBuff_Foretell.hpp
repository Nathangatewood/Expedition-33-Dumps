#ifndef UE4SS_SDK_BP_BattleBuff_Foretell_HPP
#define UE4SS_SDK_BP_BattleBuff_Foretell_HPP

class UBP_BattleBuff_Foretell_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UWBP_BuffWidget_Foretell_C* local_customWidget;                             // 0x0160 (size: 0x8)

    void UpdateCustomBuffWidget(class UWBP_jRPG_BuffSlot_C* BuffWidget, bool& DummyOut);
    void InitializeCustomBuffWidget(class UWBP_jRPG_BuffSlot_C* BuffWidget, bool& DummyOut);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_Foretell(int32 EntryPoint);
}; // Size: 0x168

#endif
