#ifndef UE4SS_SDK_AN_ENM_IsBattle_HPP
#define UE4SS_SDK_AN_ENM_IsBattle_HPP

class UAN_ENM_IsBattle_C : public UAnimNotify
{
    class USoundBase* Sound;                                                          // 0x0038 (size: 0x8)
    bool PlayInComponent?;                                                            // 0x0040 (size: 0x1)
    bool SoundShouldFollow?;                                                          // 0x0041 (size: 0x1)
    double PercentageChanceToTriggerBattleSound;                                      // 0x0048 (size: 0x8)
    TEnumAsByte<EBattleAudioContainerComponents::Type> AttachToComponentInBattle;     // 0x0050 (size: 0x1)
    TEnumAsByte<EInWorldAudioContainerComponents::Type> AttachToComponentInWorld;     // 0x0051 (size: 0x1)
    class USoundAttenuation* AttnInBattleOverride;                                    // 0x0058 (size: 0x8)
    class USoundConcurrency* BattleConcurrencyOverride;                               // 0x0060 (size: 0x8)

    void GetAudioComponentBattle(class UObject* Owner, class USceneComponent*& BattleComponent);
    void GetAudioComponentEnviro(class UObject* Owner, class UAudioComponent*& EnviroComponent);
    void PlayEnviroSound(class UObject* Owner);
    void PlayBattleSound(class AActor* Owner);
    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x68

#endif
