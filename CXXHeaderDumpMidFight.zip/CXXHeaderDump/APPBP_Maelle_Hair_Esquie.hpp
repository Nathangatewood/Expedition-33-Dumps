#ifndef UE4SS_SDK_APPBP_Maelle_Hair_Esquie_HPP
#define UE4SS_SDK_APPBP_Maelle_Hair_Esquie_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_145;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_146;                                                         // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_147;                                        // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_33;        // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_32;        // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose;                       // 0x0190 (size: 0x8)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0198 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_31;        // 0x01C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_30;        // 0x01F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_29;        // 0x0228 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_28;        // 0x0258 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_27;        // 0x0288 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_26;        // 0x02B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_25;        // 0x02E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_24;        // 0x0318 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_23;        // 0x0348 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_22;        // 0x0378 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_21;        // 0x03A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_20;        // 0x03D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_19;        // 0x0408 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_18;        // 0x0438 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_17;        // 0x0468 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_16;        // 0x0498 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_15;        // 0x04C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_14;        // 0x04F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_13;        // 0x0528 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_12;        // 0x0558 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_11;        // 0x0588 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_10;        // 0x05B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_9;         // 0x05E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_8;         // 0x0618 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_7;         // 0x0648 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_6;         // 0x0678 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_5;         // 0x06A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_4;         // 0x06D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_3;         // 0x0708 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_2;         // 0x0738 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_1;         // 0x0768 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics;           // 0x0798 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_10;       // 0x07C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_9;        // 0x07F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_8;        // 0x0828 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_7;        // 0x0858 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_6;        // 0x0888 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_5;        // 0x08B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_4;        // 0x08E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x0918 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x0948 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x0978 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x09A8 (size: 0x30)

}; // Size: 0x9D8

class UAPPBP_Maelle_Hair_Esquie_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_33;                             // 0x03B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_32;                             // 0x08D0 (size: 0x520)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0DF0 (size: 0x20)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x0E10 (size: 0xB8)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0EC8 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_31;                             // 0x0EF0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_30;                             // 0x1410 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_29;                             // 0x1930 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_28;                             // 0x1E50 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_27;                             // 0x2370 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_26;                             // 0x2890 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_25;                             // 0x2DB0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_24;                             // 0x32D0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_23;                             // 0x37F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_22;                             // 0x3D10 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_21;                             // 0x4230 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_20;                             // 0x4750 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_19;                             // 0x4C70 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_18;                             // 0x5190 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_17;                             // 0x56B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_16;                             // 0x5BD0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_15;                             // 0x60F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_14;                             // 0x6610 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_13;                             // 0x6B30 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12;                             // 0x7050 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;                             // 0x7570 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;                             // 0x7A90 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;                              // 0x7FB0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;                              // 0x84D0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;                              // 0x89F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;                              // 0x8F10 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;                              // 0x9430 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;                              // 0x9950 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;                              // 0x9E70 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;                              // 0xA390 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_1;                              // 0xA8B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;                                // 0xADD0 (size: 0x520)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_10;                           // 0xB2F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_9;                            // 0xBA90 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_8;                            // 0xC230 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7;                            // 0xC9D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6;                            // 0xD170 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5;                            // 0xD910 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4;                            // 0xE0B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0xE850 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0xEFF0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0xF790 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0xFF30 (size: 0x7A0)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_38FB97954BDAE2C9C10327BBD9827126();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_D68C65FC45E9CFB14FA51CA300CAFE4F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_F1B585BF4BE77EBFC5F8CA83AF67C674();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_046C92F94078C639B89287AF4A728240();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_B7DE7B3143A13D43C02F888D18AE95D6();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_3A4A0CC24FC1EC9E9B5BA29149E5A153();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_6F27B51248FEC38E2000C1BBE88C34C5();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_187165E245DA5B9BEE2DEB8DCD71A6EC();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_3C77813F44AC77BB1D58FE9197644467();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_08C961C64773B9535D0DE2B2002CB5AC();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Maelle_Hair_Esquie_AnimGraphNode_KawaiiPhysics_76F7EF9D4C4F71FEFC93608B18AD148A();
    void ExecuteUbergraph_APPBP_Maelle_Hair_Esquie(int32 EntryPoint);
}; // Size: 0x106D0

#endif
