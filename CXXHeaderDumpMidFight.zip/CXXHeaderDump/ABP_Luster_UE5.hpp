#ifndef UE4SS_SDK_ABP_Luster_UE5_HPP
#define UE4SS_SDK_ABP_Luster_UE5_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x3B70

class UABP_Luster_UE5_C : public UABP_Battle_Global_C
{
}; // Size: 0x5F30

#endif
