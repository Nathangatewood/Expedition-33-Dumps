#ifndef UE4SS_SDK_BP_CommonUIKeyboardControllerData_HPP
#define UE4SS_SDK_BP_CommonUIKeyboardControllerData_HPP

class UBP_CommonUIKeyboardControllerData_C : public UCommonInputBaseControllerData
{
}; // Size: 0xF8

#endif
