#ifndef UE4SS_SDK_BP_CharacterFace_Lune_HalfPonytail_HPP
#define UE4SS_SDK_BP_CharacterFace_Lune_HalfPonytail_HPP

class ABP_CharacterFace_Lune_HalfPonytail_C : public ABP_CharacterFaceBase_Lune_C
{
}; // Size: 0x2E0

#endif
