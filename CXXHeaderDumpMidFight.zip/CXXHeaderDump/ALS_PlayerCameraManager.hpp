#ifndef UE4SS_SDK_ALS_PlayerCameraManager_HPP
#define UE4SS_SDK_ALS_PlayerCameraManager_HPP

class AALS_PlayerCameraManager_C : public AALSPlayerCameraManager
{

    void DrawDebugTargets(FVector PivotTargetLocation);
}; // Size: 0x25C0

#endif
