enum class EARFaceTrackingFileWriterType {
    None = 0,
    CSV = 1,
    JSON = 2,
    EARFaceTrackingFileWriterType_MAX = 3,
};

enum EARKitTextureType {
    TextureY = 0,
    TextureCbCr = 1,
    EARKitTextureType_MAX = 2,
};

enum class ELivelinkTrackingType {
    FaceTracking = 0,
    PoseTracking = 1,
    ELivelinkTrackingType_MAX = 2,
};

