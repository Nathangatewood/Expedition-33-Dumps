#ifndef UE4SS_SDK_BP_ExplorationCapacityComponent_FreeAimTeleport_HPP
#define UE4SS_SDK_BP_ExplorationCapacityComponent_FreeAimTeleport_HPP

class UBP_ExplorationCapacityComponent_FreeAimTeleport_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UBP_ExplorationProgressionSystem_C* ExplorationProgressionState;            // 0x00A8 (size: 0x8)

    bool IsFreeAimTeleportUnlocked();
    void LoadStateFromGI(class UBP_jRPG_GI_Custom_C* GameInstance);
    void ExecuteUbergraph_BP_ExplorationCapacityComponent_FreeAimTeleport(int32 EntryPoint);
}; // Size: 0xB0

#endif
