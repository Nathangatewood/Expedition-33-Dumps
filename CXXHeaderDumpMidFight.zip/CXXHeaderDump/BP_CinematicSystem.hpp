#ifndef UE4SS_SDK_BP_CinematicSystem_HPP
#define UE4SS_SDK_BP_CinematicSystem_HPP

class UBP_CinematicSystem_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class ULevelSequencePlayer* LevelSequencePlayer;                                  // 0x00A8 (size: 0x8)
    class ALevelSequenceActor* LevelSequencePlayerActor;                              // 0x00B0 (size: 0x8)
    FS_TriggerCinematicVariables CurrentTriggerCinematicParameters;                   // 0x00B8 (size: 0x150)
    FBP_CinematicSystem_CEventAfterPostCinematicEvents EventAfterPostCinematicEvents; // 0x0208 (size: 0x10)
    void EventAfterPostCinematicEvents();
    FBP_CinematicSystem_CEventWhenTriggeringCinematic EventWhenTriggeringCinematic;   // 0x0218 (size: 0x10)
    void EventWhenTriggeringCinematic();
    class UWBP_CinematicControls_C* CurrentCinematicWidget;                           // 0x0228 (size: 0x8)
    class ABP_MediaPlayer_C* SpawnedMediaPlayerActor;                                 // 0x0230 (size: 0x8)
    bool IsPlayingCinematic;                                                          // 0x0238 (size: 0x1)
    bool CinematicPaused;                                                             // 0x0239 (size: 0x1)
    class UWBP_MediaPlayerCinematic_C* CurrentMediaPlayerWidget;                      // 0x0240 (size: 0x8)
    bool IsSkippingCinematic;                                                         // 0x0248 (size: 0x1)
    FSF_ReferenceCounterHandle InteractionBlockerReferenceHandle;                     // 0x0250 (size: 0x20)
    class USF_BlueprintLatentAction* CurrentLatentAction;                             // 0x0270 (size: 0x8)
    float PreCinematicCameraBlendTime;                                                // 0x0278 (size: 0x4)
    float PreCinematicTimeBeforeInputLock;                                            // 0x027C (size: 0x4)
    double MinimumDelayBeforeStartingCinematicAfterBlend;                             // 0x0280 (size: 0x8)
    double DelayBeforeAllowingInputPostCinematicTransition;                           // 0x0288 (size: 0x8)
    class ABP_Cine_ExitPoint_C* CinematicExitPoint;                                   // 0x0290 (size: 0x8)
    bool SequenceStarted;                                                             // 0x0298 (size: 0x1)
    bool HasInputLockFromPreCinematic;                                                // 0x0299 (size: 0x1)
    FBP_CinematicSystem_CEventBeforePostCinematicTransitionStarted EventBeforePostCinematicTransitionStarted; // 0x02A0 (size: 0x10)
    void EventBeforePostCinematicTransitionStarted();
    class UBP_LoadAssetRequest_C* LoadCinematicAssetRequest;                          // 0x02B0 (size: 0x8)
    class UWBP_CinematicTransition_C* CinematicTransitionWidget;                      // 0x02B8 (size: 0x8)
    FTimerHandle PreCinematicInputLockTimer;                                          // 0x02C0 (size: 0x8)
    FS_jRPG_Character_World_Movement_Data CharacterWorldMovementData;                 // 0x02C8 (size: 0x10)
    FDataTableRowHandle SDPause;                                                      // 0x02D8 (size: 0x10)
    FDataTableRowHandle SDUnPause;                                                    // 0x02E8 (size: 0x10)
    FDataTableRowHandle SDSkip;                                                       // 0x02F8 (size: 0x10)
    float FrameRateLimit;                                                             // 0x0308 (size: 0x4)
    float SequencePlayRate;                                                           // 0x030C (size: 0x4)
    FBP_CinematicSystem_COnCinematicRequested OnCinematicRequested;                   // 0x0310 (size: 0x10)
    void OnCinematicRequested();
    TArray<UUserWidget*> SpawnedWidgets;                                              // 0x0320 (size: 0x10)
    FSF_ReferenceCounterHandle InputLockBlockerReference;                             // 0x0330 (size: 0x20)
    bool IsInTransition;                                                              // 0x0350 (size: 0x1)
    TArray<ALevelSequenceActor*> ToDestroyLevelSequenceActors;                        // 0x0358 (size: 0x10)
    FDateTime LastPausedTime;                                                         // 0x0368 (size: 0x8)
    double PauseCoolDownTime;                                                         // 0x0370 (size: 0x8)
    bool PhotoModeRequested;                                                          // 0x0378 (size: 0x1)

    void PlayFeedbackSoundOnSkip();
    void OnGameModePauseStateChanged(bool bIsPaused);
    void PlayFeedbackSoundOnPause();
    void EnterPhotoMode();
    void OnExitPhotoMode();
    void OnPhotoModeRequested();
    void IsMediaPlayerReadyForPause(bool& CanPause);
    void CanPause(bool& CanPause);
    void ResetBindings();
    void AddLevelSequenceActorToDestroy(class ALevelSequenceActor* ToDestroy);
    bool IsSequenceStarted();
    void CreateAssetLoadRequest();
    FString GetSequenceTimeDebugInfo();
    void ExecuteGameActionIfNeeded();
    void SetPauseForSpawnedWidgets(bool Paused);
    void UnregisterSpawnedWidget(const class UUserWidget*& Widget);
    void RegisterSpawnedWidget(class UUserWidget* Widget);
    void UpdateWorldCharacterIfNeeded();
    void SetPauseMediaPlayerActor(bool Paused);
    void UnregisterSpawnedMediaPlayerActor();
    void RegisterSpawnedMediaPlayerActor(class ABP_MediaPlayer_C* MediaPlayer);
    void RemoveLODSettingsOnGroom();
    void ApplyLODSettingsOnGroom();
    void UpdateDynamicResolutionFrameBudget(bool FrameRateLimitApplied);
    void IsPlayingSequence(bool& IsPlaying);
    void DestroyCinematicControlsWidget();
    void UpdateCinematicControlsWidget();
    void CreateCinematicControlsWidget();
    void RemoveFrameRateLimit();
    void ApplyFrameRateLimit();
    void DEBUG_AutoSkipCinematicIfNeeded();
    void DEBUG_ModifyCinematicParameters();
    void DisplayCinematicTransitionWidget(TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode);
    void PrepareWorldToStartCinematic();
    bool IsInCinematicTransition();
    void FinishLatentAction();
    void PlayCinematicWithLevelSequence();
    void GetOverlayForPreCinematicTransition(EALSOverlayState& Overlay);
    void OnSequenceStarted();
    void OnPreCinematicInputLockTimerElapsed();
    void PlayCinematicWithMediaPlayer();
    void StartLevelSequence(class ULevelSequence* LevelSequence, FMovieSceneSequencePlaybackSettings Settings);
    void ValidateCinematicParameters(bool& IsValid);
    void ValidateCinematicContext(FS_TriggerCinematicVariables TriggerCinematicParameters, bool& IsValid);
    void SetSequencePlayRate(double PlayRate);
    void CleanUpAfterCinematic();
    void ResumeGameAfterCinematic();
    void GetCharacterWorld(class ABP_jRPG_Character_World_C*& AsBP J RPG Character World);
    void StartPostCinematicTransition();
    void ExitCinematicModeForCharacter();
    void FinishPreCinematicTransition();
    void StartPreCinematicTransitionWithoutCameraBlend();
    void StartPreCinematicTransitionWithCameraBlend();
    FString DEBUG_GetCurrentState();
    void OnSequenceFinished();
    void TriggerCinematic(FS_TriggerCinematicVariables TriggerCinematicVariableStruct, class USF_BlueprintLatentAction* LatentAction);
    void PauseCinematic();
    void SkipCinematic();
    void ExecutePostCinematicTransition();
    void ExecutePreCinematicTransition();
    void OnUnpauseAnimationFinished();
    void ExecuteExitPointTransition();
    void ReceiveBeginPlay();
    void OnPlatformPauseEvent(bool bShouldPause);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_CinematicSystem(int32 EntryPoint);
    void OnCinematicRequested__DelegateSignature();
    void EventBeforePostCinematicTransitionStarted__DelegateSignature();
    void EventWhenTriggeringCinematic__DelegateSignature();
    void EventAfterPostCinematicEvents__DelegateSignature();
}; // Size: 0x379

#endif
