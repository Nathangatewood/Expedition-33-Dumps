#ifndef UE4SS_SDK_BP_AudioCharacter_Manager_HPP
#define UE4SS_SDK_BP_AudioCharacter_Manager_HPP

class UBP_AudioCharacter_Manager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UAudioComponent* AC_FT_L;                                                   // 0x00A8 (size: 0x8)
    class UAudioComponent* AC_Foley_01;                                               // 0x00B0 (size: 0x8)
    class UAudioComponent* AC_SFX_01;                                                 // 0x00B8 (size: 0x8)
    class UAudioComponent* AC_Vocal_01;                                               // 0x00C0 (size: 0x8)
    class ABP_jRPG_Character_World_C* BP_CharacterWorld;                              // 0x00C8 (size: 0x8)
    class ABP_jRPG_Character_Battle_Base_C* BP_CharacterBattle;                       // 0x00D0 (size: 0x8)
    TEnumAsByte<EFootstepsType::Type> FootstepsType;                                  // 0x00D8 (size: 0x1)
    FName StepPlayed;                                                                 // 0x00DC (size: 0x8)
    class UAudioComponent* AC Footsteps;                                              // 0x00E8 (size: 0x8)
    bool Debug;                                                                       // 0x00F0 (size: 0x1)
    class USoundAttenuation* ATT_Footsteps;                                           // 0x00F8 (size: 0x8)
    class UBP_DataAsset_CharacterExplorationAudioProfile_C* DataAsset_Exploration;    // 0x0100 (size: 0x8)
    TEnumAsByte<ESfxType::Type> SfxType;                                              // 0x0108 (size: 0x1)
    FFAudioCharacter_ExplorationSFXType StructureSfxType;                             // 0x0110 (size: 0x38)
    class UAudioComponent* AC_FT_R;                                                   // 0x0148 (size: 0x8)
    class UAudioComponent* AC_Foley_02;                                               // 0x0150 (size: 0x8)
    class UAudioComponent* AC_SFX_02;                                                 // 0x0158 (size: 0x8)
    class UAudioComponent* AC_Vocal_02;                                               // 0x0160 (size: 0x8)
    class UAudioComponent* AC_Idle;                                                   // 0x0168 (size: 0x8)
    class UAudioComponent* ACWeaponR01;                                               // 0x0170 (size: 0x8)
    class UAudioComponent* ACWeaponR02;                                               // 0x0178 (size: 0x8)
    class UAudioComponent* ACWeaponL01;                                               // 0x0180 (size: 0x8)
    class UAudioComponent* ACWeaponL02;                                               // 0x0188 (size: 0x8)
    class UAudioComponent* ACHandL01;                                                 // 0x0190 (size: 0x8)
    class UAudioComponent* ACHandL02;                                                 // 0x0198 (size: 0x8)
    class UAudioComponent* ACHandR01;                                                 // 0x01A0 (size: 0x8)
    class UAudioComponent* ACHandR02;                                                 // 0x01A8 (size: 0x8)
    class USoundBase* ExploSoundPlayed;                                               // 0x01B0 (size: 0x8)
    class ABP_jRPG_Enemy_World_Base_Seamless_C* EnemyRef;                             // 0x01B8 (size: 0x8)
    class USoundBase* DefaultFootstep;                                                // 0x01C0 (size: 0x8)

    void GetFootStepToPlay(const TEnumAsByte<EPhysicalSurface> SurfaceType, class USoundBase*& Value);
    void SetupDefaultFootstep();
    void HandleFootsteps(const TEnumAsByte<EFootstepsType::Type>& FootstepsType, FVector& Location, TEnumAsByte<EPhysicalSurface> SurfaceType);
    void OnCharacterSwitch(class UBP_CharacterData_C* CharacterData);
    void Initialize();
    void HandleSFX(TEnumAsByte<ESfxType::Type> SfxType);
    void PlayFoleyEvent();
    void PlayVocalEvent();
    void PlaySFXEvent(TEnumAsByte<ESfxType::Type> SfxType);
    void ResetState();
    void ReceiveBeginPlay();
    void PlayFootstepEvent(const TEnumAsByte<EFootstepsType::Type>& FootstepsType, const FVector& Location, TEnumAsByte<EPhysicalSurface> SurfaceType);
    void ExecuteUbergraph_BP_AudioCharacter_Manager(int32 EntryPoint);
}; // Size: 0x1C8

#endif
