#ifndef UE4SS_SDK_BP_BattleMap_HPP
#define UE4SS_SDK_BP_BattleMap_HPP

class ABP_BattleMap_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CameraPath_Overview_Static;                   // 0x0298 (size: 0x8)
    class UWorldPartitionStreamingSourceComponent* WorldPartitionStreamingSource;     // 0x02A0 (size: 0x8)
    class USplineComponent* EnemyLineSpline;                                          // 0x02A8 (size: 0x8)
    class USphereComponent* BattlemapMetricsMinimum;                                  // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* EDITOR_CheckCylinder;                                 // 0x02B8 (size: 0x8)
    class USceneComponent* TargetingEnemyCameraFocusPoint;                            // 0x02C0 (size: 0x8)
    class UChildActorComponent* BP_jRPG_DynamicCameraPath3;                           // 0x02C8 (size: 0x8)
    class USceneComponent* TargetingAllyCameraFocusPoint;                             // 0x02D0 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CameraPath_TargetingAlly;                     // 0x02D8 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CameraPath_Overview;                          // 0x02E0 (size: 0x8)
    class UChildActorComponent* BP_jRPG_DynamicCameraPath4;                           // 0x02E8 (size: 0x8)
    class USceneComponent* IntroCameraFocusPoint1;                                    // 0x02F0 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CameraPath_Intro;                             // 0x02F8 (size: 0x8)
    class USceneComponent* OverviewCameraFocusPoint;                                  // 0x0300 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CameraPath_TargetingEnemy;                    // 0x0308 (size: 0x8)
    class USceneComponent* Cameras;                                                   // 0x0310 (size: 0x8)
    class UChildActorComponent* BP_jRPG_EnemyBattleSpot0;                             // 0x0318 (size: 0x8)
    class UStaticMeshComponent* OverviewFocusPreviz;                                  // 0x0320 (size: 0x8)
    class UStaticMeshComponent* TargetingAllyPreviz;                                  // 0x0328 (size: 0x8)
    class UStaticMeshComponent* TargetingEnemyPreviz;                                 // 0x0330 (size: 0x8)
    class UChildActorComponent* BP_jRPG_EnemyBattleSpot3;                             // 0x0338 (size: 0x8)
    class UChildActorComponent* BP_jRPG_EnemyBattleSpot2;                             // 0x0340 (size: 0x8)
    class UChildActorComponent* BP_jRPG_EnemyBattleSpot1;                             // 0x0348 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CharacterBattleSpot2;                         // 0x0350 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CharacterBattleSpot1;                         // 0x0358 (size: 0x8)
    class UChildActorComponent* BP_jRPG_CharacterBattleSpot;                          // 0x0360 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0368 (size: 0x8)
    class ABP_LightingScenarioReference_C* LightingScenarioForBattle;                 // 0x0370 (size: 0x8)
    bool UseStaticCharacterLocations;                                                 // 0x0378 (size: 0x1)
    bool ShouldDoRandomRotationAtStart;                                               // 0x0379 (size: 0x1)
    TArray<AActor*> PreviewActors;                                                    // 0x0380 (size: 0x10)
    TSoftClassPtr<AActor> Preview_EnemySpawn_0;                                       // 0x0390 (size: 0x28)
    TSoftClassPtr<AActor> Preview_EnemySpawn_1;                                       // 0x03B8 (size: 0x28)
    TSoftClassPtr<AActor> Preview_EnemySpawn_2;                                       // 0x03E0 (size: 0x28)
    TSoftClassPtr<AActor> Preview_EnemySpawn_3;                                       // 0x0408 (size: 0x28)
    TSoftClassPtr<AActor> Preview_CharacterSpawn_0;                                   // 0x0430 (size: 0x28)
    TSoftClassPtr<AActor> Preview_CharacterSpawn_1;                                   // 0x0458 (size: 0x28)
    TSoftClassPtr<AActor> Preview_CharacterSpawn_2;                                   // 0x0480 (size: 0x28)
    bool IsPreviewEnabled;                                                            // 0x04A8 (size: 0x1)
    TArray<TSoftObjectPtr<class AActor>> ActorsToHideDuringBattle;                    // 0x04B0 (size: 0x10)
    bool SetBattleMapVisible;                                                         // 0x04C0 (size: 0x1)
    TArray<TSoftObjectPtr<class AActor>> ActorsToUnHideDuringBattle;                  // 0x04C8 (size: 0x10)
    TMap<FGameplayTag, TSoftObjectPtr<class AActor>> BattleActorReferences;           // 0x04D8 (size: 0x50)
    FSF_ReferenceCounterHandle StreamingSourcesEnabledReferenceBlockerHandle;         // 0x0528 (size: 0x20)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void GetInvalidDynamicCameraPaths(TArray<UChildActorComponent*>& ChildActorComponents);
    bool ShouldProcessActorHiddenState(class AActor* Target);
    void ProcessActorsToUnhide(bool ShouldUnhide);
    void ProcessActorsToHide(bool ShouldHide);
    void SetBattleMapStreamingSourceActive(bool Active);
    void FindBattleActorByTag(const FGameplayTag Tag, class AActor*& Actor);
    void SetBattleMapActive(bool IsActive);
    void CheckForErrorsActorArray(const TArray<FText>& ErrorMessages, TArray<TSoftObjectPtr<class AActor>>& Array, FString ArrayName);
    void UpdateCamerasLookAtPoints();
    bool EDITORCHECK_TraceFreeAimLineOfSight(class UChildActorComponent* HeroSpot, class UChildActorComponent* EnemySpot, TEnumAsByte<EDrawDebugTrace::Type> DrawDebugType, FHitResult& OutHit);
    void GetEnemiesSpots(TArray<UChildActorComponent*>& Array);
    void GetAlliesSpots(TArray<UChildActorComponent*>& Array);
    void GetFurthestBound(FVector& Point);
    void GetAllSpotsActors(TArray<AActor*>& Array);
    void GetAllSpots(TArray<UChildActorComponent*>& Array);
    void SpawnPreviewActorAtSpot(TSoftClassPtr<AActor> ActorClass, class USceneComponent* BattleSpotComponent);
    FTransform GetBattleSpotTransform(class USceneComponent* self2);
    void UserConstructionScript();
    void TogglePreviewMeshes();
    void ReceiveBeginPlay();
    void RotationUpdateMap();
    void CustomEvent_0();
    void ExecuteUbergraph_BP_BattleMap(int32 EntryPoint);
}; // Size: 0x548

#endif
