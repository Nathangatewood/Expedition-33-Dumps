#ifndef UE4SS_SDK_bp_FogSheet_GOOD_HPP
#define UE4SS_SDK_bp_FogSheet_GOOD_HPP

class Abp_FogSheet_GOOD_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0290 (size: 0x8)
    class UBillboardComponent* FogSheet;                                              // 0x0298 (size: 0x8)
    class UMaterialInstanceConstant* FogSheetMasterMaterial;                          // 0x02A0 (size: 0x8)
    class UMaterialInstanceDynamic* FogSheetMID;                                      // 0x02A8 (size: 0x8)
    FLinearColor Color;                                                               // 0x02B0 (size: 0x10)
    double Brightness;                                                                // 0x02C0 (size: 0x8)
    FVector Size;                                                                     // 0x02C8 (size: 0x18)
    double Opacity;                                                                   // 0x02E0 (size: 0x8)
    double DepthFadeDistance;                                                         // 0x02E8 (size: 0x8)
    double NoiseProjectionDistance;                                                   // 0x02F0 (size: 0x8)
    double NoiseSize;                                                                 // 0x02F8 (size: 0x8)
    double PanningSpeed;                                                              // 0x0300 (size: 0x8)
    double FadeDistance;                                                              // 0x0308 (size: 0x8)
    double EyeAdaptation;                                                             // 0x0310 (size: 0x8)

    void UserConstructionScript();
}; // Size: 0x318

#endif
