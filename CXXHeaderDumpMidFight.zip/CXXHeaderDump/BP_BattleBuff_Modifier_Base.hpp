#ifndef UE4SS_SDK_BP_BattleBuff_Modifier_Base_HPP
#define UE4SS_SDK_BP_BattleBuff_Modifier_Base_HPP

class UBP_BattleBuff_Modifier_Base_C : public UBP_BattleBuffInstance_C
{
}; // Size: 0x151

#endif
