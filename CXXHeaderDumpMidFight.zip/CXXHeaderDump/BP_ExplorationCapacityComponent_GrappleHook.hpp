#ifndef UE4SS_SDK_BP_ExplorationCapacityComponent_GrappleHook_HPP
#define UE4SS_SDK_BP_ExplorationCapacityComponent_GrappleHook_HPP

class UBP_ExplorationCapacityComponent_GrappleHook_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class ABP_GrapplePoint_C* GrapplePointReference;                                  // 0x00A8 (size: 0x8)
    FVector GrapplingDestination;                                                     // 0x00B0 (size: 0x18)
    class ACharacter* CharacterReference;                                             // 0x00C8 (size: 0x8)
    FVector StartingPosition;                                                         // 0x00D0 (size: 0x18)
    bool MovingWithGrapple;                                                           // 0x00E8 (size: 0x1)
    float PreviousGravityScale;                                                       // 0x00EC (size: 0x4)
    double MontagePosition;                                                           // 0x00F0 (size: 0x8)
    class UCurveFloat* AirSpeedCurve;                                                 // 0x00F8 (size: 0x8)
    class UCurveFloat* GroundSpeedCurve;                                              // 0x0100 (size: 0x8)
    class UCurveFloat* AirHeightOffsetCurve;                                          // 0x0108 (size: 0x8)
    class UCurveFloat* GroundHeightOffsetCurve;                                       // 0x0110 (size: 0x8)
    class ABP_GrapplePoint_C* CurrentGrapplePoint;                                    // 0x0118 (size: 0x8)
    class UCurveFloat* AirRopeLength;                                                 // 0x0120 (size: 0x8)
    class UCurveFloat* GroundRopeLength;                                              // 0x0128 (size: 0x8)
    double RopeBaseLength;                                                            // 0x0130 (size: 0x8)
    class UCurveFloat* AirRopePosition;                                               // 0x0138 (size: 0x8)
    class UCurveFloat* GroundRopePosition;                                            // 0x0140 (size: 0x8)
    class UStaticMeshComponent* RopeEnd;                                              // 0x0148 (size: 0x8)
    class ABP_GrappleHook_Rope_C* GrappleHookRopeReference;                           // 0x0150 (size: 0x8)
    float Radius;                                                                     // 0x0158 (size: 0x4)
    double GrappleThrowDistance;                                                      // 0x0160 (size: 0x8)
    bool DEBUG_VerboseLog;                                                            // 0x0168 (size: 0x1)
    bool IsGrapplingFromGround;                                                       // 0x0169 (size: 0x1)
    FSF_ReferenceCounterHandle ClimbingInputLockBlockerReference;                     // 0x0170 (size: 0x20)

    void OnAnimationMontagePlayed(class UAnimMontage* Montage, bool bInterrupted);
    void GetCharacterWorld(class ABP_jRPG_Character_World_C*& CharacterWorld);
    void DestroyRope();
    void SpawnRope();
    void MoveRope();
    void EndGrapplingMovement();
    void UpdateGrapplingMovement();
    void StartGrapplingMovement();
    void StartGrapplingAnimation(class ABP_GrapplePoint_C* GrapplePointReference);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void BPI_OnGrappleEndFootContact();
    void ExecuteUbergraph_BP_ExplorationCapacityComponent_GrappleHook(int32 EntryPoint);
}; // Size: 0x190

#endif
