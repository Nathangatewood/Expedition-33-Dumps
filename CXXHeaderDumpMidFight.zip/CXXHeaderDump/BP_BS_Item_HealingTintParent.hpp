#ifndef UE4SS_SDK_BP_BS_Item_HealingTintParent_HPP
#define UE4SS_SDK_BP_BS_Item_HealingTintParent_HPP

class ABP_BS_Item_HealingTintParent_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    double Healthmultiplier;                                                          // 0x0310 (size: 0x8)
    class UNiagaraSystem* HealFX;                                                     // 0x0318 (size: 0x8)
    class USoundBase* Healing Tint Sound;                                             // 0x0320 (size: 0x8)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_BS_Item_HealingTintParent(int32 EntryPoint);
}; // Size: 0x328

#endif
