#ifndef UE4SS_SDK_ABP_PostProcess_Ramasseur_Weapon_HPP
#define UE4SS_SDK_ABP_PostProcess_Ramasseur_Weapon_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_16;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_17;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_18;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose;                       // 0x0100 (size: 0x8)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0108 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0138 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_1;         // 0x0168 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics;           // 0x0198 (size: 0x30)

}; // Size: 0x1C8

class UABP_PostProcess_Ramasseur_Weapon_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x03A8 (size: 0xB8)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0460 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0480 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_1;                              // 0x04A0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;                                // 0x09C0 (size: 0x520)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void ExecuteUbergraph_ABP_PostProcess_Ramasseur_Weapon(int32 EntryPoint);
}; // Size: 0xEE0

#endif
