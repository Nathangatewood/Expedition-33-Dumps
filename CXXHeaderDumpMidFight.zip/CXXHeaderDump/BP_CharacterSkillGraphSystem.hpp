#ifndef UE4SS_SDK_BP_CharacterSkillGraphSystem_HPP
#define UE4SS_SDK_BP_CharacterSkillGraphSystem_HPP

class UBP_CharacterSkillGraphSystem_C : public UExtendedObject
{
    class UBP_CharacterData_C* TempCharacterData;                                     // 0x0028 (size: 0x8)
    TArray<UBP_DataAsset_Skill_C*> UnlockedSkills;                                    // 0x0030 (size: 0x10)
    int32 SkillPointsFromItems;                                                       // 0x0040 (size: 0x4)
    int32 SkillPointsFromLeveling;                                                    // 0x0044 (size: 0x4)
    TArray<UBP_DataAsset_Skill_C*> EquippedSkills;                                    // 0x0048 (size: 0x10)
    FBP_CharacterSkillGraphSystem_COnSkillTreeChanged OnSkillTreeChanged;             // 0x0058 (size: 0x10)
    void OnSkillTreeChanged();
    int32 CurrentlyUsedSkillPoints;                                                   // 0x0068 (size: 0x4)

    void NotifyOtherSystems(class UBP_DataAsset_Skill_C* Skill);
    void ResetProgression();
    void GetFirstEmptySlotIndex(int32& Index);
    TArray<UBP_DataAsset_Skill_C*> GetUnlockedSkills();
    TArray<UBP_DataAsset_Skill_C*> GetAllAvailableEquippedSkills();
    TArray<UBP_DataAsset_Skill_C*> GetAvailableGradientAttacks();
    bool CanEquipMoreSkills();
    void SetEquippedSkillOverrides(TArray<UBP_DataAsset_Skill_C*>& EquippedSkills);
    void GetEquippedSkillsSaveData(TArray<FName>& EquippedSkillIDs);
    void GetUnlockedSkillSaveData(TArray<FName>& UnlockedSkillIDs);
    void GetEquippedSkills(TArray<UBP_DataAsset_Skill_C*>& EquippedSkills);
    bool HasLearnableSkills();
    void UpdateCurrentSkillsUsedSkillPoints();
    void OnOwnerLevelSet(int32 CurrentLevel);
    void OnNewItemAcquired(FS_jRPG_Item_StaticData ItemDefinition);
    void UnequipSkill(class UBP_DataAsset_Skill_C* SkillID);
    void EquipSkillAtSlot(const class UBP_DataAsset_Skill_C*& SkillDefinition, int32 Index);
    void EquipSkill(class UBP_DataAsset_Skill_C* SkillID);
    bool IsSkillUnlocked(const class UBP_DataAsset_Skill_C*& Skill);
    void UpdateUsedSkillPoints();
    bool CanAffordSkillUnlock(class UBP_DataAsset_Skill_C* Skill);
    int32 GetTotalSkillPoints();
    int32 GetAvailableSkillPoints();
    void GetSkillState(class UBP_DataAsset_Skill_C* Skill, TEnumAsByte<ESkillNodeState::Type>& NodeState);
    void GetSkillGraph(class UBP_DataAsset_SkillGraph_C*& SkillGraph);
    bool HasLearntDependencySkills(const class UBP_DataAsset_Skill_C*& Skill);
    bool CanLearnSkill(const class UBP_DataAsset_Skill_C*& Skill, TEnumAsByte<ELearnSkillBlockedReason::Type>& BlockedReason);
    void TryUnlockSkill(class UBP_DataAsset_Skill_C* Skill, bool& Success);
    void LoadCharacterState(FS_jRPG_CharacterSaveState CharacterSaveState);
    void Init();
    void OnSkillTreeChanged__DelegateSignature();
}; // Size: 0x6C

#endif
