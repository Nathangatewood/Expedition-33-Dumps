#ifndef UE4SS_SDK_BP_CharacterFace_Sciel_Esquie_HPP
#define UE4SS_SDK_BP_CharacterFace_Sciel_Esquie_HPP

class ABP_CharacterFace_Sciel_Esquie_C : public ABP_CharacterFaceBase_Sciel_C
{
}; // Size: 0x2E0

#endif
