#ifndef UE4SS_SDK_BP_DataAsset_CharacterBattleAudioProfile_HPP
#define UE4SS_SDK_BP_DataAsset_CharacterBattleAudioProfile_HPP

class UBP_DataAsset_CharacterBattleAudioProfile_C : public UPrimaryDataAsset
{
    FFAudioCharacter_Battle_UI CharacterBattleUiType;                                 // 0x0030 (size: 0x10)
    FFAudioBattleCommonSFX Common SFX;                                                // 0x0040 (size: 0x58)
    FFAudioCharacter_Battle_HitBy_AnimCommon HitByCommon_AnimCall;                    // 0x0098 (size: 0x40)
    FFAudioCharacter_Battle_DeathCommon DeathCommon_AnimCall;                         // 0x00D8 (size: 0x20)
    FFAudioCharacter_Battle_HitBy_BP BattleHitBy_CallByBP;                            // 0x00F8 (size: 0x10)
    class UBP_DataAsset_Footsteps_C* DA_Footsteps;                                    // 0x0108 (size: 0x8)
    FFAudioCharacter_Battle_DeathCommon_Bodyfall DeathCommon_Bodyfall_AnimCall;       // 0x0110 (size: 0x8)
    FS_OnoSoundData OnoSoundData;                                                     // 0x0118 (size: 0x50)
    class UBP_DataAsset_BattleHitSound_C* CharacterBaseHitSound;                      // 0x0168 (size: 0x8)
    bool EventReactions_MatchingRule;                                                 // 0x0170 (size: 0x1)
    bool Event_HitReceived_MatchingRule;                                              // 0x0171 (size: 0x1)
    TSoftClassPtr<UBP_BattleLinesModel_Base_C> CharacterBattleLineClass;              // 0x0178 (size: 0x28)

    void GetCharacterBattleLinesClass(TSoftClassPtr<UBP_BattleLinesModel_Base_C>& CharacterBattleLineClass);
    void NewFunction();
    void GetCharacterBaseHitSound(class UBP_DataAsset_BattleHitSound_C*& DefaultHitSound);
}; // Size: 0x1A0

#endif
