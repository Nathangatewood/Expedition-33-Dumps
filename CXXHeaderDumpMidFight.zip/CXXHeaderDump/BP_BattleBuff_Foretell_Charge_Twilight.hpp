#ifndef UE4SS_SDK_BP_BattleBuff_Foretell_Charge_Twilight_HPP
#define UE4SS_SDK_BP_BattleBuff_Foretell_Charge_Twilight_HPP

class UBP_BattleBuff_Foretell_Charge_Twilight_C : public UBP_BattleBuffInstance_C
{
    FDataTableRowHandle BalancingRow_BonusPerStack;                                   // 0x0158 (size: 0x10)
    int32 Multiplier;                                                                 // 0x0168 (size: 0x4)

    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
}; // Size: 0x16C

#endif
