#ifndef UE4SS_SDK_BP_BattleBuff_InterceptTargetDamage_HPP
#define UE4SS_SDK_BP_BattleBuff_InterceptTargetDamage_HPP

class UBP_BattleBuff_InterceptTargetDamage_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void ExecuteUbergraph_BP_BattleBuff_InterceptTargetDamage(int32 EntryPoint);
}; // Size: 0x160

#endif
