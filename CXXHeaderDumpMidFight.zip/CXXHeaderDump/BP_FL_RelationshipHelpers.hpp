#ifndef UE4SS_SDK_BP_FL_RelationshipHelpers_HPP
#define UE4SS_SDK_BP_FL_RelationshipHelpers_HPP

class UBP_FL_RelationshipHelpers_C : public UBlueprintFunctionLibrary
{

    void SetCurrentRelationshipLevel(TEnumAsByte<E_CharacterList::Type> Character, int32 Level, class UObject* __WorldContext);
    void GetCurrentRelationshipLevel(TEnumAsByte<E_CharacterList::Type> Character, class UObject* __WorldContext, int32& Level);
    void GetRelationshipSystem(class UObject* __WorldContext, class UBP_RelationshipSystem_C*& RelationshipSystem);
}; // Size: 0x28

#endif
