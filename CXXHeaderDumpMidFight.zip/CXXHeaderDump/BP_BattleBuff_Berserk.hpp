#ifndef UE4SS_SDK_BP_BattleBuff_Berserk_HPP
#define UE4SS_SDK_BP_BattleBuff_Berserk_HPP

class UBP_BattleBuff_Berserk_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 Damage MultiplierStackCount;                                                // 0x0160 (size: 0x4)
    class UBP_DependencyRefCounter_C* Turn Start Dependencies;                        // 0x0168 (size: 0x8)
    int32 MaxBerserkStack;                                                            // 0x0170 (size: 0x4)
    double DamageIncreasePerStack;                                                    // 0x0178 (size: 0x8)

    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void ExecuteUbergraph_BP_BattleBuff_Berserk(int32 EntryPoint);
}; // Size: 0x180

#endif
