#ifndef UE4SS_SDK_BP_FX_FollowingSwordVerso_HPP
#define UE4SS_SDK_BP_FX_FollowingSwordVerso_HPP

class ABP_FX_FollowingSwordVerso_C : public ABP_FX_AfterImage_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UMeshComponent* TargetToFollow_0;                                           // 0x02E8 (size: 0x8)

    void Deactivate();
    void ExecuteUbergraph_BP_FX_FollowingSwordVerso(int32 EntryPoint);
}; // Size: 0x2F0

#endif
