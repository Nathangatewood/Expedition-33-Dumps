#ifndef UE4SS_SDK_ABP_Maelle_NPC_HPP
#define UE4SS_SDK_ABP_Maelle_NPC_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x2C18

class UABP_Maelle_NPC_C : public UABP_Humanoid_NPC_C
{
}; // Size: 0x671A

#endif
