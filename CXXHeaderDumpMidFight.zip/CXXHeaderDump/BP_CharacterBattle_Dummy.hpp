#ifndef UE4SS_SDK_BP_CharacterBattle_Dummy_HPP
#define UE4SS_SDK_BP_CharacterBattle_Dummy_HPP

class ABP_CharacterBattle_Dummy_C : public ABP_jRPG_Character_Battle_Base_C
{
}; // Size: 0x1562

#endif
