#ifndef UE4SS_SDK_ABP_GaultB_HPP
#define UE4SS_SDK_ABP_GaultB_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x3B70

class UABP_GaultB_C : public UABP_Battle_Global_C
{
}; // Size: 0x5F30

#endif
