#ifndef UE4SS_SDK_BP_GameAction_PlayInworldDialogue_HPP
#define UE4SS_SDK_BP_GameAction_PlayInworldDialogue_HPP

class UBP_GameAction_PlayInworldDialogue_C : public UBP_PDT_GameAction_C
{
    class UBP_DA_IWD_data_C* DialogueData;                                            // 0x0030 (size: 0x8)
    bool ShouldWaitEndOfDialogueToFinishExecution;                                    // 0x0038 (size: 0x1)

    TSubclassOf<class UGameActionInstance> GetInstanceClass();
    void ValidateGameAction(TArray<FText>& ErrorMessages, FString& PropertyPath, bool& ExploreAssetChildren);
}; // Size: 0x39

#endif
