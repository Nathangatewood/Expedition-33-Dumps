#ifndef UE4SS_SDK_BP_FootstepVisualComponent_HPP
#define UE4SS_SDK_BP_FootstepVisualComponent_HPP

class UBP_FootstepVisualComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UBP_DataAsset_FootstepVisualProfile_C* FootstepVisualProfile;               // 0x00A8 (size: 0x8)

    void FootstepVisualEvent(bool IsRightFoot, FVector Location, FRotator Rotation);
    void ExecuteUbergraph_BP_FootstepVisualComponent(int32 EntryPoint);
}; // Size: 0xB0

#endif
