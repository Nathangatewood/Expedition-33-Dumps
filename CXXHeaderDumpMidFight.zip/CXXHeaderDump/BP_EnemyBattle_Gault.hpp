#ifndef UE4SS_SDK_BP_EnemyBattle_Gault_HPP
#define UE4SS_SDK_BP_EnemyBattle_Gault_HPP

class ABP_EnemyBattle_Gault_C : public ABP_jRPG_Enemy_Battle_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x1638 (size: 0x8)
    class UNiagaraComponent* Trail;                                                   // 0x1640 (size: 0x8)
    class UStaticMeshComponent* Sword2;                                               // 0x1648 (size: 0x8)
    class UChildActorComponent* BP_Sword_Gault_Test;                                  // 0x1650 (size: 0x8)
    class UCapsuleComponent* Capsule1;                                                // 0x1658 (size: 0x8)
    class UStaticMeshComponent* SwordMesh;                                            // 0x1660 (size: 0x8)
    class UAnimMontage* AmMeleeMonoAtk;                                               // 0x1668 (size: 0x8)
    class UAnimMontage* AmMoveTo;                                                     // 0x1670 (size: 0x8)
    class UAnimMontage* AmDashBack;                                                   // 0x1678 (size: 0x8)
    class ABP_EpicBattleSequenceActor_C* CurrentBattleSequence;                       // 0x1680 (size: 0x8)
    FFSoundEvent SD_Gault_Dashback;                                                   // 0x1688 (size: 0x8)
    class UMaterialInstanceDynamic* EnrgySwordMaterial;                               // 0x1690 (size: 0x8)
    class UAnimMontage* AM_ComboX2;                                                   // 0x1698 (size: 0x8)
    class UAnimMontage* AM_ComboX3;                                                   // 0x16A0 (size: 0x8)
    FFSoundEvent SD_Gault_Skill_AttackA;                                              // 0x16A8 (size: 0x8)
    FFSoundEvent SD_Gault_Skill_AttackB;                                              // 0x16B0 (size: 0x8)
    bool IsBuffed;                                                                    // 0x16B8 (size: 0x1)
    TArray<FVector> DarkCloneSpawnLocation;                                           // 0x16C0 (size: 0x10)
    TArray<ABP_GaultDarkClone_C*> DarkClones;                                         // 0x16D0 (size: 0x10)
    class ABP_GaultDarkClone_C* CurrentClone;                                         // 0x16E0 (size: 0x8)
    int32 CloneId;                                                                    // 0x16E8 (size: 0x4)
    FFRoutedEventHandle SkilHandle_MonoAtk1;                                          // 0x16F0 (size: 0x20)
    FFRoutedEventHandle Skill Handle Mono Atk 2;                                      // 0x1710 (size: 0x20)
    FFRoutedEventHandle Skill Handle_Combo_AlphaRage;                                 // 0x1730 (size: 0x20)
    FFRoutedEventHandle Skill Handle_Combo1;                                          // 0x1750 (size: 0x20)
    FFRoutedEventHandle Skill Handle_Combo2;                                          // 0x1770 (size: 0x20)
    FFRoutedEventHandle Skill Handle_Buff;                                            // 0x1790 (size: 0x20)
    FFRoutedEventHandle Skill Handle_Single1;                                         // 0x17B0 (size: 0x20)
    FFRoutedEventHandle Skill Handle_Single2;                                         // 0x17D0 (size: 0x20)
    bool IsAlpha;                                                                     // 0x17F0 (size: 0x1)
    class ULevelSequence* Combo1Sequence_Standard;                                    // 0x17F8 (size: 0x8)
    class ULevelSequence* Combo1Sequence_Alpha;                                       // 0x1800 (size: 0x8)
    class ULevelSequence* Combo2Sequence_Standard;                                    // 0x1808 (size: 0x8)
    class ULevelSequence* Combo2Sequence_Alpha;                                       // 0x1810 (size: 0x8)
    class ULevelSequence* Attack1Sequence_Standard;                                   // 0x1818 (size: 0x8)
    class ULevelSequence* Attack1Sequence_Alpha;                                      // 0x1820 (size: 0x8)
    class ULevelSequence* attack2Sequence_Standard;                                   // 0x1828 (size: 0x8)
    class ULevelSequence* attack2Sequence_Alpha;                                      // 0x1830 (size: 0x8)

    void TemporaryGetTarget(int32 BattleSpotIndex, class ABP_jRPG_Character_Battle_Base_C*& Output_Get);
    void UpdateCloneId(int32& Output_Get);
    void PerformActionByAI();
    void Melee_Mono_Atk();
    void Melee_Mono_Atk2();
    void ReceiveBeginPlay();
    void Mono_Melee_Combo_1();
    void Mono_Melee_Combo_2();
    void Skill_Single1();
    void Skill_Single2();
    void Skill_Buff();
    void Skill_Combo_AlphaRage();
    void Hit_Combo_Hit1();
    void Hit_Combo_Hit2();
    void DeclareCharacterSkillEvents();
    void Hit_GaultA_Attack1(int32 ActionEffectIndex);
    void Hit_Attack2(int32 ActionEffectIndex);
    void GaultB_Combo1(int32 ActionEffectIndex);
    void Hit_Combo2(int32 ActionEffectIndex);
    void OnTurnStart();
    void OnTurnEnded();
    void ExecuteUbergraph_BP_EnemyBattle_Gault(int32 EntryPoint);
}; // Size: 0x1838

#endif
