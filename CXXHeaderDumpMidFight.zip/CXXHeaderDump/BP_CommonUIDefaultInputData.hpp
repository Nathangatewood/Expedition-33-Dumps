#ifndef UE4SS_SDK_BP_CommonUIDefaultInputData_HPP
#define UE4SS_SDK_BP_CommonUIDefaultInputData_HPP

class UBP_CommonUIDefaultInputData_C : public UCommonUIInputData
{
}; // Size: 0x80

#endif
