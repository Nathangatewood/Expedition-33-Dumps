#ifndef UE4SS_SDK_BP_BattleBuff_Flee_HPP
#define UE4SS_SDK_BP_BattleBuff_Flee_HPP

class UBP_BattleBuff_Flee_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UParticleSystemComponent* Particle System Component;                        // 0x0160 (size: 0x8)
    int32 NumberOfCharactersAliveFleeing;                                             // 0x0168 (size: 0x4)
    FDataTableRowHandle SoundEventFleeActivation;                                     // 0x0170 (size: 0x10)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void FleeSuccessActivation();
    void ExecuteUbergraph_BP_BattleBuff_Flee(int32 EntryPoint);
}; // Size: 0x180

#endif
