#ifndef UE4SS_SDK_ABP_Sciel_NPC_HPP
#define UE4SS_SDK_ABP_Sciel_NPC_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x2C18

class UABP_Sciel_NPC_C : public UABP_Humanoid_NPC_C
{
}; // Size: 0x671A

#endif
