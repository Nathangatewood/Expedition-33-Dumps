#ifndef UE4SS_SDK_BP_DataAsset_CharacterExplorationAudioProfile_HPP
#define UE4SS_SDK_BP_DataAsset_CharacterExplorationAudioProfile_HPP

class UBP_DataAsset_CharacterExplorationAudioProfile_C : public UPrimaryDataAsset
{
    FFAudioCharacter_ExplorationSFXType SfxType;                                      // 0x0030 (size: 0x38)
    class UBP_DataAsset_Footsteps_C* DA_Footsteps;                                    // 0x0068 (size: 0x8)
    FS_OnoSoundData OnoSoundData;                                                     // 0x0070 (size: 0x50)
    class USoundBase* FoleyMetaSound;                                                 // 0x00C0 (size: 0x8)
    class USoundBase* BreathMetaSound;                                                // 0x00C8 (size: 0x8)

}; // Size: 0xD0

#endif
