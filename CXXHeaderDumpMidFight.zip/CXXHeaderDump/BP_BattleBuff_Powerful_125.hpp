#ifndef UE4SS_SDK_BP_BattleBuff_Powerful_125_HPP
#define UE4SS_SDK_BP_BattleBuff_Powerful_125_HPP

class UBP_BattleBuff_Powerful_125_C : public UBP_BattleBuff_Power_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0170 (size: 0x8)

    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Powerful_125(int32 EntryPoint);
}; // Size: 0x178

#endif
