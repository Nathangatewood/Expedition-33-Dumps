#ifndef UE4SS_SDK_BP_BattleBuff_Marked_HPP
#define UE4SS_SDK_BP_BattleBuff_Marked_HPP

class UBP_BattleBuff_Marked_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 HitCountToRemoveMark;                                                       // 0x0160 (size: 0x4)
    FBP_BattleBuff_Marked_CMarkRemoved MarkRemoved;                                   // 0x0168 (size: 0x10)
    void MarkRemoved(class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UBP_BattleDamages_C* BattleDamage);
    bool ModifyDamageElements;                                                        // 0x0178 (size: 0x1)
    TEnumAsByte<EAttackType::Type> newMarkDamageElement;                              // 0x0179 (size: 0x1)
    class UNiagaraComponent* NiagaraSystem;                                           // 0x0180 (size: 0x8)

    void SetHitCountToRemoveMark(int32 NewHitCount);
    void ProcessReceivedFinalDamages(class UBP_BattleDamages_C*& BattleDamages, int32 CurrentTurnHitCount, bool& Out);
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void ExecuteUbergraph_BP_BattleBuff_Marked(int32 EntryPoint);
    void MarkRemoved__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UBP_BattleDamages_C* BattleDamage);
}; // Size: 0x188

#endif
