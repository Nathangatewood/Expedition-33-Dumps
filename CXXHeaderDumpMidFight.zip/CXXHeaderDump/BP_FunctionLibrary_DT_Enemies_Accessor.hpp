#ifndef UE4SS_SDK_BP_FunctionLibrary_DT_Enemies_Accessor_HPP
#define UE4SS_SDK_BP_FunctionLibrary_DT_Enemies_Accessor_HPP

class UBP_FunctionLibrary_DT_Enemies_Accessor_C : public UBlueprintFunctionLibrary
{

    void GetEncounterDataTableRow(FName RowName, class UObject* __WorldContext, bool& Found, FS_jRPG_Encounter& EncounterData);
    void GetEnemyDataTableRow(FName RowName, class UObject* __WorldContext, bool& Found, FS_jRPG_Enemy& EnemyData);
}; // Size: 0x28

#endif
