#ifndef UE4SS_SDK_BP_ButtonGenericStyle_HPP
#define UE4SS_SDK_BP_ButtonGenericStyle_HPP

class UBP_ButtonGenericStyle_C : public UCommonButtonStyle
{
}; // Size: 0x7B0

#endif
