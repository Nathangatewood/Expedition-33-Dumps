#ifndef UE4SS_SDK_BP_FL_DialogueHelpers_HPP
#define UE4SS_SDK_BP_FL_DialogueHelpers_HPP

class UBP_FL_DialogueHelpers_C : public UBlueprintFunctionLibrary
{

    void GetItemStructFromDataTableRowHandle(const FItemDataTableRowHandle& ItemDataTableRowHandle, class UObject* __WorldContext, bool& Found, FS_jRPG_Item_StaticData& ItemStruct);
    void SetSpeakerIsActive(class AActor* Actor, bool IsActive, class UObject* __WorldContext);
}; // Size: 0x28

#endif
