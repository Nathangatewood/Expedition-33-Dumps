#ifndef UE4SS_SDK_BP_ConditionChecker_BattledEnemy_HPP
#define UE4SS_SDK_BP_ConditionChecker_BattledEnemy_HPP

class UBP_ConditionChecker_BattledEnemy_C : public UBP_ConditionChecker_C
{
    FName EnemyGlobalID;                                                              // 0x0060 (size: 0x8)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x68

#endif
