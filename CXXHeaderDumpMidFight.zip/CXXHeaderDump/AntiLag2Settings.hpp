#ifndef UE4SS_SDK_AntiLag2Settings_HPP
#define UE4SS_SDK_AntiLag2Settings_HPP

class UAntiLag2Settings : public UDeveloperSettings
{
    bool bEnabled;                                                                    // 0x0038 (size: 0x1)

}; // Size: 0x40

#endif
