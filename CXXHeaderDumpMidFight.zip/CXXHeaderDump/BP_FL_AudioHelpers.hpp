#ifndef UE4SS_SDK_BP_FL_AudioHelpers_HPP
#define UE4SS_SDK_BP_FL_AudioHelpers_HPP

class UBP_FL_AudioHelpers_C : public UBlueprintFunctionLibrary
{

    void GetFoleyAudioValuesFromOwner(class UAudioComponent* AudioComponent, class UObject* __WorldContext, double& FoleyLowCut, double& FoleyVolume);
    void GetWorldAudioComponent(class UObject* __WorldContext, class UBP_World_Audio_Component_C*& WorldAudioComponent);
    void ValidateRangedAmbienceParameters(FS_RangedAmbienceParameters AmbienceParameters, class UObject* __WorldContext, bool& IsValid);
    void GetInteractiveMusicSystem(class UObject* __WorldContext, class UBP_InteractiveMusicSystem_C*& InteractiveMusicSystem);
    void ValidateInteractiveMusicParameters(FS_InteractiveMusicParameters& Parameters, class UObject* __WorldContext, bool& IsValid);
    FVector GetPlayerAudioLocation(class UObject* __WorldContext);
    void StartTimer(FS_RuntimeSoundDataWithDelay& SoundData, FStartTimerEvent& Event, class UObject* __WorldContext);
    void ApplySlidingWindow(FS_RuntimeSoundDataWithDelay& SoundData, class USoundBase* PlayedSound, class UObject* __WorldContext);
}; // Size: 0x28

#endif
