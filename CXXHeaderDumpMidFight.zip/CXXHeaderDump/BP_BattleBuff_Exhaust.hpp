#ifndef UE4SS_SDK_BP_BattleBuff_Exhaust_HPP
#define UE4SS_SDK_BP_BattleBuff_Exhaust_HPP

class UBP_BattleBuff_Exhaust_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)

    void ProcessAPChange(int32 NewAPAmount, int32 PreviousAPAmount, TEnumAsByte<EAPChangeReason::Type> ChangeReason, bool& HasChanged, int32& ChangedValue);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Exhaust(int32 EntryPoint);
}; // Size: 0x160

#endif
