#ifndef UE4SS_SDK_BP_DocumentActor_HPP
#define UE4SS_SDK_BP_DocumentActor_HPP

class ABP_DocumentActor_C : public ABP_jRPG_InteractionObject_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent;                                  // 0x02F8 (size: 0x8)
    class UAudioComponent* DialogueAudio;                                             // 0x0300 (size: 0x8)
    bool bIsInteractable;                                                             // 0x0308 (size: 0x1)
    class UWBP_Document_C* DocumentWidget;                                            // 0x0310 (size: 0x8)
    bool DestroyDocumentAfterReading?;                                                // 0x0318 (size: 0x1)
    class ABP_jRPG_Character_World_C* InteractingCharacter;                           // 0x0320 (size: 0x8)
    FBP_DocumentActor_COnDocumentPutAway OnDocumentPutAway;                           // 0x0328 (size: 0x10)
    void OnDocumentPutAway();

    void OnPutAwayDocument();
    void BlackFadeOut();
    void BlackFadeIn();
    void SetInputModeUI();
    void CreateDocumentWidget();
    void SetInputModeGame();
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void ReceiveBeginPlay();
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void ExecuteUbergraph_BP_DocumentActor(int32 EntryPoint);
    void OnDocumentPutAway__DelegateSignature();
}; // Size: 0x338

#endif
