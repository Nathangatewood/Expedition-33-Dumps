#ifndef UE4SS_SDK_BP_BattleMap_Gargant_Child_HPP
#define UE4SS_SDK_BP_BattleMap_Gargant_Child_HPP

class ABP_BattleMap_Gargant_Child_C : public ABP_BattleMap_C
{
}; // Size: 0x548

#endif
