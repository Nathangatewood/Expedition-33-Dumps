#ifndef UE4SS_SDK_BP_AICompanion_CompanionManager_HPP
#define UE4SS_SDK_BP_AICompanion_CompanionManager_HPP

class UBP_AICompanion_CompanionManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool SpawnCompanionsEnabled;                                                      // 0x00A8 (size: 0x1)
    TArray<ABP_Pawn_AICompanion_C*> SpawnedCompanions;                                // 0x00B0 (size: 0x10)
    class UBP_AICompanion_TargetPointsComponent_C* TargetPointsComponent;             // 0x00C0 (size: 0x8)
    TArray<FS_jRPG_PartySlot> PreviousParty;                                          // 0x00C8 (size: 0x10)
    bool IsInCinematicMode;                                                           // 0x00D8 (size: 0x1)
    TArray<UBP_LoadClassAssetRequest_C*> LoadClassAssetRequests;                      // 0x00E0 (size: 0x10)
    FVector DefaultQueryExtentOnSpawn;                                                // 0x00F0 (size: 0x18)
    FVector FallbackQueryExtentOnSpawn;                                               // 0x0108 (size: 0x18)
    TMap<FName, ABP_Pawn_AICompanion_C*> Name To Companion Map;                       // 0x0120 (size: 0x50)
    TArray<FName> Companion Names In Party;                                           // 0x0170 (size: 0x10)
    bool AreCompanionsHidden;                                                         // 0x0180 (size: 0x1)

    void OnPhotoModeStateChanged(bool Activated);
    void OnExitPhotoMode();
    void OnEnterPhotoMode();
    void DestroyCompanionsNoLongerInTheParty();
    void UpdateActivatedCompanions();
    void SpawnAndUpdateCompanions();
    void GetCompanionNamesToActivate(TArray<FName>& Companion Names To Activate);
    void SpawnCompanion(TSubclassOf<class ABP_Pawn_AICompanion_C> Companion Class, class ABP_Pawn_AICompanion_C*& Spawned Companion);
    void SpawnCompanionFromClass(TSubclassOf<class ABP_Pawn_AICompanion_C> Companion Class, class ABP_Pawn_AICompanion_C*& Spawned Companion);
    void GetCompanionNamesInParty(TArray<FName>& Companion Names In Party);
    void DeactivateCompanion(class ABP_Pawn_AICompanion_C* Companion To Deactivate);
    void ActivateCompanion(class ABP_Pawn_AICompanion_C* Companion To Activate, FVector Teleport Position, bool& Success);
    void ProjectLocationOnNavigationForCompanion(const FVector& Location, const FVector QueryExtent, FVector& ProjectedLocation, bool& Success);
    void TryTeleportToLocation(class ABP_Pawn_AICompanion_C* Companion, const FVector& Location, FRotator Rotation, bool SpawnTeleportationFX, bool& Success);
    void OnLoadRequestCompleted(class UBP_LoadClassAssetRequest_C* LoadRequest);
    void CancelAllLoadRequests();
    void TryTeleportToTargetPoint(class ABP_Pawn_AICompanion_C* Companion, bool SpawnTeleportationFX, bool& Success);
    void UpdateCompanionsVisualAlterations();
    void SetCompanionsEnabled(bool Enabled);
    void CanSpawnCompanions(bool& CanSpawn);
    void RegisterEvents();
    void OnMainMenuOpened();
    void OnMainMenuClosed();
    void SetCinematicMode(bool IsInCinematic);
    void OnCompanionDestroyed(class AActor* DestroyedActor);
    void DestroyAllCompanionActors(bool Instant);
    void UnspawnAllCompanions(bool Instant);
    void ReceiveBeginPlay();
    void ApplyAllCharacterCustomizations();
    void ResetCompanionLocations(bool SpawnTeleportationFX);
    void SpawnAllCompanions();
    void ExecuteUbergraph_BP_AICompanion_CompanionManager(int32 EntryPoint);
}; // Size: 0x181

#endif
