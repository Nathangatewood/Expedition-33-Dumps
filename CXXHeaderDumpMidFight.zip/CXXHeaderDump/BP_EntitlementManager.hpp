#ifndef UE4SS_SDK_BP_EntitlementManager_HPP
#define UE4SS_SDK_BP_EntitlementManager_HPP

class UBP_EntitlementManager_C : public UExtendedObject
{
    class UDataTable* EntitlementDataTable;                                           // 0x0028 (size: 0x8)
    TArray<FName> AddedEntitlements;                                                  // 0x0030 (size: 0x10)

    TArray<FName> RetrieveAllIDsForEntitlement(FS_EntitlementData& EntitlementData);
    void ResetState();
    bool HasAnyEntitlement(const TArray<FName>& Entitlements);
    void OnEntitlementUndetected(FName EntitlementID, class UBP_EntitlementDataUpdaterBase_C* EntitlementDataUpdater);
    void OnEntitlementDetected(FName EntitlementID, class UBP_EntitlementDataUpdaterBase_C* EntitlementDataUpdater);
    void UpdateEntitlementData();
    void LoadState(FS_EntitlementSaveData& EntitlementData);
    void SaveState(FS_EntitlementSaveData& EntitlementData);
}; // Size: 0x40

#endif
