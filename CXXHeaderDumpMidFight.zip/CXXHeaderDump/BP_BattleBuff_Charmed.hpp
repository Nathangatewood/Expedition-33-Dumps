#ifndef UE4SS_SDK_BP_BattleBuff_Charmed_HPP
#define UE4SS_SDK_BP_BattleBuff_Charmed_HPP

class UBP_BattleBuff_Charmed_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UParticleSystemComponent* Particle System Component;                        // 0x0160 (size: 0x8)
    FBP_BattleBuff_Charmed_COnRemoveCharmBuff OnRemoveCharmBuff;                      // 0x0168 (size: 0x10)
    void OnRemoveCharmBuff();
    FSF_ReferenceCounterHandle ForceAutoAttackReferenceHandle;                        // 0x0178 (size: 0x20)
    class UNiagaraComponent* FX_Charm;                                                // 0x0198 (size: 0x8)

    void DeactivateBuff();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void OnRemoveCharmBuff_Event();
    void DispellCharm();
    void ExecuteUbergraph_BP_BattleBuff_Charmed(int32 EntryPoint);
    void OnRemoveCharmBuff__DelegateSignature();
}; // Size: 0x1A0

#endif
