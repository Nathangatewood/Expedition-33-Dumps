#ifndef UE4SS_SDK_BP_DataAsset_SkillGraph_HPP
#define UE4SS_SDK_BP_DataAsset_SkillGraph_HPP

class UBP_DataAsset_SkillGraph_C : public UPrimaryDataAsset
{
    TArray<FFSkillGraphNode> Nodes;                                                   // 0x0030 (size: 0x10)
    TArray<FFSkillGraphEdge> Edges;                                                   // 0x0040 (size: 0x10)
    TArray<TSubclassOf<class UBP_GroupingPolicy_Base_C>> CustomGroupingPolicies;      // 0x0050 (size: 0x10)

    TArray<TSubclassOf<class UBP_GroupingPolicy_Base_C>> GetCustomGroupingPolicies();
    void GetSkillNodePointUnlockCost(const FFSkillUnlockData& FSkillUnlockData, int32& UnlockCost);
    TArray<FFSkillGraphNode> FindSkillsUnlockedByItem(FName ItemId);
    void FindSkillByNameID(FName SkillNameID, bool& Found, class UBP_DataAsset_Skill_C*& Skill);
    void GetNodesInsideBox(FVector2D StartPoint, FVector2D Size, TArray<FFSkillGraphNode>& Nodes);
    void TryFindSkillsByNameIDs(TArray<FName>& NameIDs, TArray<UBP_DataAsset_Skill_C*>& SkillAssets, bool& AllFound, TArray<FName>& MissingNameIDs);
    void IsSecretSkill(class UBP_DataAsset_Skill_C* Skill, bool& IsSecret);
    void GetAdjacentSkills(class UBP_DataAsset_Skill_C* Skill, TArray<UBP_DataAsset_Skill_C*>& Skills);
    void GetSkillPointUnlockCost(class UBP_DataAsset_Skill_C* Skill, int32& UnlockCost);
    void GetStartingSkills(TArray<UBP_DataAsset_Skill_C*>& Skills);
    bool IsStartingSkill(class UBP_DataAsset_Skill_C* Skill);
    void FindSkillNodeSafe(class UBP_DataAsset_Skill_C* Skill, bool& Found, FFSkillGraphNode& Node);
    void RemoveSkill(class UBP_DataAsset_Skill_C* Skill);
    void FindSkillNode(class UBP_DataAsset_Skill_C* Skill, bool& Found, FFSkillGraphNode& Node, int32& Index);
    void FindEdge(class UBP_DataAsset_Skill_C* skill1, class UBP_DataAsset_Skill_C* Skill2, bool& Found, FFSkillGraphEdge& Edge, int32& EdgeIndex);
    void RemoveEdge(class UBP_DataAsset_Skill_C* Node1, class UBP_DataAsset_Skill_C* Node2);
    void UpdateSkillNode(FFSkillGraphNode Node);
    void UpdateSkillNodeFromSkill(class UBP_DataAsset_Skill_C* Skill, FFSkillGraphNode Node);
    void DoesEdgeExist(class UBP_DataAsset_Skill_C* Node1, class UBP_DataAsset_Skill_C* Node2, bool& Exists);
    void FindEdgesFromSkill(class UBP_DataAsset_Skill_C* Skill, TArray<FFSkillGraphEdge>& MatchingEdges);
}; // Size: 0x60

#endif
