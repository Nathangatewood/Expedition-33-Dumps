#ifndef UE4SS_SDK_AC_jRPG_DynamicCameraManager_HPP
#define UE4SS_SDK_AC_jRPG_DynamicCameraManager_HPP

class UAC_jRPG_DynamicCameraManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FName DefaultPathID;                                                              // 0x00A8 (size: 0x8)
    class ACineCameraActor* CameraActor;                                              // 0x00B0 (size: 0x8)
    TMap<FName, ABP_jRPG_DynamicCameraPath_C*> DynamicCameraPaths;                    // 0x00B8 (size: 0x50)
    class ABP_jRPG_DynamicCameraPath_C* ActiveCameraPath;                             // 0x0108 (size: 0x8)
    double PathDistance;                                                              // 0x0110 (size: 0x8)
    double Speed;                                                                     // 0x0118 (size: 0x8)
    bool LoopEnabled;                                                                 // 0x0120 (size: 0x1)
    bool UseAutoCameraManagement;                                                     // 0x0121 (size: 0x1)
    FPostProcessSettings CameraPostProcess;                                           // 0x0130 (size: 0x6F0)
    class UObject* Battlemap_Prefab;                                                  // 0x0820 (size: 0x8)
    FName LastPathID;                                                                 // 0x0828 (size: 0x8)
    FVector LastLocation;                                                             // 0x0830 (size: 0x18)
    bool LastUpdatePathLocation;                                                      // 0x0848 (size: 0x1)
    class ABP_BattleMap_C* BattleMapBP;                                               // 0x0850 (size: 0x8)
    bool IsTargeting;                                                                 // 0x0858 (size: 0x1)

    void LoadBattleMap(class ABP_BattleMap_C* BattleMapBP);
    void SetAsViewTargetInstant();
    void ReapplyDynamicPath();
    void StoreDynamicPathActors();
    void UpdateCameraLocAndRot(double PathTime, bool IsTargeting);
    void SetNewDynamicPath(FName PathID, bool RandomStartDistance, bool Loop, bool UpdatePathLocation, FVector NewLocation);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_AC_jRPG_DynamicCameraManager(int32 EntryPoint);
}; // Size: 0x859

#endif
