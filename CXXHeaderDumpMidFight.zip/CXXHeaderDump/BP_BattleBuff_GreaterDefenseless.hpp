#ifndef UE4SS_SDK_BP_BattleBuff_GreaterDefenseless_HPP
#define UE4SS_SDK_BP_BattleBuff_GreaterDefenseless_HPP

class UBP_BattleBuff_GreaterDefenseless_C : public UBP_BattleBuff_Defense_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0170 (size: 0x8)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_GreaterDefenseless(int32 EntryPoint);
}; // Size: 0x178

#endif
