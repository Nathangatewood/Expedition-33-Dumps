#ifndef UE4SS_SDK_BP_ExtendedDebugCameraController_HPP
#define UE4SS_SDK_BP_ExtendedDebugCameraController_HPP

class ABP_ExtendedDebugCameraController_C : public ACustomDebugCameraController
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0A48 (size: 0x8)

    void ReceiveOnActivate(class APlayerController* OriginalPC);
    void ReceiveOnDeactivate(class APlayerController* RestoredPC);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_ExtendedDebugCameraController(int32 EntryPoint);
}; // Size: 0xA50

#endif
