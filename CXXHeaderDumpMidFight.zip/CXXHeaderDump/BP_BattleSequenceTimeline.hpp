#ifndef UE4SS_SDK_BP_BattleSequenceTimeline_HPP
#define UE4SS_SDK_BP_BattleSequenceTimeline_HPP

class UBP_BattleSequenceTimeline_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    class ABP_EpicBattleSequenceActor_C* CurrentBattleSequence;                       // 0x0030 (size: 0x8)
    TMap<double, FFBattleSequenceTimelineKeyframe> CurrentBattleSequenceTimeline;     // 0x0038 (size: 0x50)
    double NextBattleSequenceActionTime;                                              // 0x0088 (size: 0x8)
    double NextBattleKeyframeRealTime;                                                // 0x0090 (size: 0x8)
    TEnumAsByte<EBattleActionEvent::Type> LastBattleSequenceAction;                   // 0x0098 (size: 0x1)
    class ABP_jRPG_Character_Battle_Base_C* BattleCharacter;                          // 0x00A0 (size: 0x8)
    bool IsComboWaitingForActionEffect;                                               // 0x00A8 (size: 0x1)
    bool IsInSkillComboWindow;                                                        // 0x00A9 (size: 0x1)
    bool IsSkillComboSuccessful;                                                      // 0x00AA (size: 0x1)
    TArray<bool> ComboSuccessHistory;                                                 // 0x00B0 (size: 0x10)
    TArray<double> ComboPreTimes;                                                     // 0x00C0 (size: 0x10)
    TArray<double> ComboWindowStartTimes;                                             // 0x00D0 (size: 0x10)
    TArray<double> ComboWindowEndTimes;                                               // 0x00E0 (size: 0x10)
    double CurrentWindowStartRealTime;                                                // 0x00F0 (size: 0x8)
    double CurrentWindowEndRealTime;                                                  // 0x00F8 (size: 0x8)
    int32 TrackIndex;                                                                 // 0x0100 (size: 0x4)
    bool CanGetInput;                                                                 // 0x0104 (size: 0x1)
    bool IsQTEInterrupted;                                                            // 0x0105 (size: 0x1)
    double AnticipationDuration;                                                      // 0x0108 (size: 0x8)
    double ValidityDuration;                                                          // 0x0110 (size: 0x8)
    double LastSkillComboWindowStartTime;                                             // 0x0118 (size: 0x8)
    TArray<FString> EDITOR_ValidationErrors;                                          // 0x0120 (size: 0x10)
    int32 ActionEffectCount;                                                          // 0x0130 (size: 0x4)
    bool IsSkillComboPerfect;                                                         // 0x0134 (size: 0x1)
    double TriggerAutoQTEAtTime;                                                      // 0x0138 (size: 0x8)

    void GetTiedObject(class UObject*& Object);
    void ForceStopSequence();
    void StopSequence();
    float GetCurrentBattleSequenceTimeInAsset();
    void SetCurrentBattleSequenceAction(TEnumAsByte<EBattleActionEvent::Type> BattleSequenceAction);
    FText GetDebugText();
    void GetQTEWidget(class UWBP_HUD_QTE_Base_C*& Output);
    bool IsInPerfectWindow();
    void GetCurrentTimeForBattleSequenceTimeline(double& NewParam);
    void AddQTEPresetKeyframes_Legacy(double WindowStartTime, double AnticipationDuration, double ValidityDuration, double NowTime);
    void AddQTEPresetKeyframes(double WindowStartTime, double AnticipationDuration, double ValidityDuration, double NowTime);
    void InterruptTimeline();
    void TryActivate(bool& Success, bool& Perfect);
    void ExpiresSoonerThan(class UBP_BattleSequenceTimeline_C* Other, bool& Result);
    void VerifyBattleSequenceActionChange(TEnumAsByte<EBattleActionEvent::Type> CurrentState, TEnumAsByte<EBattleActionEvent::Type> PreviousState, bool& IsValid, TArray<TEnumAsByte<EBattleActionEvent::Type>>& ExpectedValue);
    void VerifyBattleSequenceTimeline(TMap<double, FFBattleSequenceTimelineKeyframe> Timeline);
    void AddBattleSequenceCameraKeyframe(double Time, BattleSequenceCameraType CameraType);
    void AddBattleSequenceActionKeyframe(double Time, TEnumAsByte<EBattleActionEvent::Type> ActionType);
    void StopAllowSkillCombo();
    void StartAllowSkillCombo();
    void OnBattleSequenceFinished();
    void OnSkillEffectReached();
    void OnSkillComboExitPointReached();
    void OnSkillComboWindowEndReached();
    void OnSkillComboWindowStartReached();
    void OnSkillComboWindowPreReached();
    void GetCurrentBattleSequenceTime(double& Time);
    void QueueNextBattleSequenceKeyframe();
    void OnBattleSequenceActionReached(TEnumAsByte<EBattleActionEvent::Type> KeyframeType);
    void TickBattleSequenceTimeline();
    void DeclareBattleSequenceTimingsAsList(class ABP_EpicBattleSequenceActor_C* BattleSequence, TArray<FBattleSequenceKeyframe>& BattleSequenceKeyframes, TMap<double, BattleSequenceCameraType> CameraKeyframes);
    void OnUINavigationFocus(const class UBP_UINavigationFocusEvent_C* FocusEventBP);
    void OnUINavigationFocusLost();
    void OnUIAction();
    void StartPrePhase();
    void TickCustomTimers();
    void StartValidityPhase();
    void StartEndPhase();
    void ExecuteUbergraph_BP_BattleSequenceTimeline(int32 EntryPoint);
}; // Size: 0x140

#endif
