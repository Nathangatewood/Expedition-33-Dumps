#ifndef UE4SS_SDK_BP_DataAsset_GameCredits_HPP
#define UE4SS_SDK_BP_DataAsset_GameCredits_HPP

class UBP_DataAsset_GameCredits_C : public UPrimaryDataAsset
{
    TArray<FFCreditsParagraph> Credits;                                               // 0x0030 (size: 0x10)

}; // Size: 0x40

#endif
