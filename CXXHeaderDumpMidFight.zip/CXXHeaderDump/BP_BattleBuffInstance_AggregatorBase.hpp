#ifndef UE4SS_SDK_BP_BattleBuffInstance_AggregatorBase_HPP
#define UE4SS_SDK_BP_BattleBuffInstance_AggregatorBase_HPP

class UBP_BattleBuffInstance_AggregatorBase_C : public UBP_BattleBuffInstance_C
{
    TArray<UBP_BattleBuffInstance_C*> ChildBuffInstances;                             // 0x0158 (size: 0x10)
    FBP_BattleBuffInstance_AggregatorBase_COnAggregatorChildrenChanged OnAggregatorChildrenChanged; // 0x0168 (size: 0x10)
    void OnAggregatorChildrenChanged();

    void OnChildBuffInstanceStackChanged(class UBP_BattleBuffInstance_C* BuffInstance);
    void GetDamageSourceCharacter(class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    int32 ComputeAggregatorStackCount();
    void OnChildBuffInstanceRemoved();
    void OnChildBuffInstanceAdded();
    FText GetBuffDisplayName();
    void RemoveChildBuffInstance(const class UBP_BattleBuffInstance_C*& ChildBuffInstance);
    void AddChildBuffInstance(const class UBP_BattleBuffInstance_C*& ChildBuff);
    void OnAggregatorChildrenChanged__DelegateSignature();
}; // Size: 0x178

#endif
