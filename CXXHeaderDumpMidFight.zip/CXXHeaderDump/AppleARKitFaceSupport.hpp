#ifndef UE4SS_SDK_AppleARKitFaceSupport_HPP
#define UE4SS_SDK_AppleARKitFaceSupport_HPP

#include "AppleARKitFaceSupport_enums.hpp"

struct FAppleARKitLiveLinkConnectionSettings
{
    int32 Port;                                                                       // 0x0000 (size: 0x4)

}; // Size: 0x4

struct FNetQuantizeFaceCurve
{
}; // Size: 0x2

class UAppleARKitFaceMeshComponent : public UProceduralMeshComponent
{
    bool bWantsMeshUpdates;                                                           // 0x05D0 (size: 0x1)
    bool bWantsCollision;                                                             // 0x05D1 (size: 0x1)
    bool bAutoBindToLocalFaceMesh;                                                    // 0x05D2 (size: 0x1)
    EARFaceComponentTransformMixing TransformSetting;                                 // 0x05D3 (size: 0x1)
    bool bFlipTrackedRotation;                                                        // 0x05D4 (size: 0x1)
    class UMaterialInterface* FaceMaterial;                                           // 0x05D8 (size: 0x8)
    FName LiveLinkSubjectName;                                                        // 0x05E0 (size: 0x8)
    TArray<FNetQuantizeFaceCurve> RemoteCurves;                                       // 0x05E8 (size: 0x10)

    void UpdateMeshFromBlendShapes();
    void UpdateMesh(const TArray<FVector>& Vertices);
    void SetBlendShapes(const TMap<EARFaceBlendShape, float>& InBlendShapes);
    void SetBlendShapeAmount(EARFaceBlendShape BlendShape, float Amount);
    void SetAutoBind(bool bAutoBind);
    void ServerUpdateFaceCurves(const TArray<FNetQuantizeFaceCurve>& ClientCurves);
    void PublishViaLiveLink(FName SubjectName);
    void OnRep_RemoteCurves();
    FTransform GetTransform();
    float GetLastUpdateTimestamp();
    int32 GetLastUpdateFrameNumber();
    float GetFaceBlendShapeAmount(EARFaceBlendShape BlendShape);
    void CreateMesh(const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector2D>& UV0);
}; // Size: 0x6D0

class UAppleARKitLiveLinkSourceFactory : public ULiveLinkSourceFactory
{
}; // Size: 0x28

#endif
