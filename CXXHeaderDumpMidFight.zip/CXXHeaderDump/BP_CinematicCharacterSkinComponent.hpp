#ifndef UE4SS_SDK_BP_CinematicCharacterSkinComponent_HPP
#define UE4SS_SDK_BP_CinematicCharacterSkinComponent_HPP

class UBP_CinematicCharacterSkinComponent_C : public UBP_CharacterSkinComponent_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    FName CharacterHardcodedName;                                                     // 0x0228 (size: 0x8)
    bool ApplyCharacterSkin;                                                          // 0x0230 (size: 0x1)
    bool ApplyCharacterFace;                                                          // 0x0231 (size: 0x1)
    TSoftObjectPtr<class USkeletalMesh> DefaultCharacterSkeletalMesh;                 // 0x0238 (size: 0x28)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void SwapBody(class USkeletalMeshComponent* Body, class USkeletalMesh* NewSkeletalMesh);
    void ApplyCustomizationFromCharacterData();
    bool ShouldApplyUserCustomization();
    bool ShouldApplyAnyCustomization();
    void ApplyPreviewCustomization();
    void ApplyCustomization();
    void OnLoaded_E073811A4DDB0114C9452A9C8DBC132C(class UObject* Loaded);
    void ReceiveBeginPlay();
    void ApplyDefaultCustomization(class USkeletalMeshComponent* Body);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_CinematicCharacterSkinComponent(int32 EntryPoint);
}; // Size: 0x260

#endif
