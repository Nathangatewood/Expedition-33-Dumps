#ifndef UE4SS_SDK_BP_ConditionChecker_PersistentFlag_HPP
#define UE4SS_SDK_BP_ConditionChecker_PersistentFlag_HPP

class UBP_ConditionChecker_PersistentFlag_C : public UBP_ConditionChecker_C
{
    class UNamedID* PersistentFlag;                                                   // 0x0060 (size: 0x8)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x68

#endif
