#ifndef UE4SS_SDK_BP_ClimbingComponent_HPP
#define UE4SS_SDK_BP_ClimbingComponent_HPP

class UBP_ClimbingComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FBP_ClimbingComponent_COnStartClimbing OnStartClimbing;                           // 0x00A8 (size: 0x10)
    void OnStartClimbing();
    FBP_ClimbingComponent_COnEndClimbing OnEndClimbing;                               // 0x00B8 (size: 0x10)
    void OnEndClimbing();
    class ABP_jRPG_Character_World_C* OwnerAsCharacter;                               // 0x00C8 (size: 0x8)
    class UCharacterMovementComponent* CharacterMovement;                             // 0x00D0 (size: 0x8)
    FVector BeginLocation;                                                            // 0x00D8 (size: 0x18)
    FRotator BeginRotation;                                                           // 0x00F0 (size: 0x18)
    FVector EndLocation;                                                              // 0x0108 (size: 0x18)
    FRotator EndRotation;                                                             // 0x0120 (size: 0x18)
    TScriptInterface<class IBPI_ClimbingElement_C> CurrentClimbingElement;            // 0x0138 (size: 0x10)
    TScriptInterface<class IBPI_ClimbingElement_C> NextClimbingElement;               // 0x0148 (size: 0x10)
    double DistanceToNextClimbingElement;                                             // 0x0158 (size: 0x8)
    FVector CurrentClimbingLocation;                                                  // 0x0160 (size: 0x18)
    FRotator CurrentClimbingRotation;                                                 // 0x0178 (size: 0x18)
    double ClimbingSpeed;                                                             // 0x0190 (size: 0x8)
    class UCurveFloat* EnteringClimbingTransitionCurve;                               // 0x0198 (size: 0x8)
    TEnumAsByte<E_Climbing_Direction::Type> CurrentClimbingDirection;                 // 0x01A0 (size: 0x1)
    TEnumAsByte<E_ClimbingComponentState::Type> CurrentState;                         // 0x01A1 (size: 0x1)
    double TimeToPerformStateChange;                                                  // 0x01A8 (size: 0x8)
    double AccumulatedDeltaTime;                                                      // 0x01B0 (size: 0x8)
    class UCurveFloat* MoveToNextClimbingZoneCurve;                                   // 0x01B8 (size: 0x8)
    class UCurveFloat* ExitingClimbingTransitionCurve;                                // 0x01C0 (size: 0x8)
    double TimeToPerformMoveFromAnimation;                                            // 0x01C8 (size: 0x8)
    bool IsWaitingForAnimation;                                                       // 0x01D0 (size: 0x1)
    double SpringArmTargetArmLength;                                                  // 0x01D8 (size: 0x8)
    double SpringArmCameraLagMaxDistance;                                             // 0x01E0 (size: 0x8)
    FVector LeftFootRaycastLocation;                                                  // 0x01E8 (size: 0x18)
    FVector RightFootRaycastLocation;                                                 // 0x0200 (size: 0x18)
    bool HasDoneEndClimbAnimation;                                                    // 0x0218 (size: 0x1)
    bool DEBUG_IsDebugEnabled;                                                        // 0x0219 (size: 0x1)
    FSF_ReferenceCounterHandle InteractionsBlockerReferenceHandle;                    // 0x0220 (size: 0x20)
    FName AggroLockName;                                                              // 0x0240 (size: 0x8)

    bool IsClimbing();
    void CameraShake();
    void InitializeDebug();
    void DEBUG_UpdateClimbingComponent(double DeltaSeconds);
    void DEBUG_OnDebugModeEnabled(bool Enabled);
    void GetFootRaycasts(FVector& LeftFootRaycastLocation, FVector& RightFootRaycastLocation);
    void ComputeFootRaycast(FName SocketName, bool& HasHit, FVector& Location);
    void ComputeFootRaycasts();
    void SetCharacterCollisions(TEnumAsByte<ECollisionResponse> NewResponse);
    void UpdateEndLocationWithHandsOffset(TScriptInterface<class IBPI_ClimbingElement_C> ClimbingElement);
    FVector GetCharacterHandsOffset();
    FVector GetCharacterHandsLocation();
    bool IsMovingToTop();
    void GetTimeToPerformStateChange(double& Value);
    void GetClimbingDirectionFromAngle(double Angle, TEnumAsByte<E_Climbing_Direction::Type>& ClimbingDirection);
    void ComputeClimbingAngle(double& Angle);
    void ComputeClimbingDirection();
    void GetClimbingState(TEnumAsByte<E_ClimbingComponentState::Type>& ClimbingState);
    void GetClimbingDirection(TEnumAsByte<E_Climbing_Direction::Type>& ClimbingDirection);
    void GetDistanceToNextClimbingElement(double& Value);
    FTransform GetCurrentClimbingElementTransform();
    void PrepareCharacterForWalking();
    void UpdateExitingTransition(double DeltaSeconds);
    void SetDataForExitTransition(FVector Location, FRotator Rotation);
    void ChangeState(TEnumAsByte<E_ClimbingComponentState::Type> NewState);
    void LerpLocationAndRotationForExit(double Time, class UCurveFloat* Curve, double& Alpha, FVector& Location, FRotator& Rotation);
    void LerpLocationAndRotationForEntry(double Time, class UCurveFloat* Curve, double& Alpha, FVector& Location, FRotator& Rotation);
    void LerpLocationAndRotation(double Time, class UCurveFloat* Curve, double& Alpha, FVector& Location, FRotator& Rotation);
    void ComputeInputDirections(FVector& InputDirectionHorizontal, FVector& InputDirectionVertical, double& InputScale);
    void ComputeAlpha(double Time, class UCurveFloat* Curve, double& Alpha);
    void CheckExitingClimbing();
    void InputAxisClimbingRight(double AxisValue);
    void InputAxisClimbingUp(double AxisValue);
    void UpdateEnteringTransition(double DeltaSeconds);
    void SetDataForEnterTransition();
    void PrepareCharacterForClimbing();
    void UpdateClimbingComponent(double DeltaSeconds);
    void StopClimbing();
    void ComputeTime(double DeltaSeconds, double MaxTime, double& Time);
    void InitializeClimbingComponent();
    void UpdateClimbingMovement();
    void ComputeClimbingLocation(double DeltaSeconds);
    void SetDataForMove(TScriptInterface<class IBPI_ClimbingElement_C> ClimbingElement);
    void CheckNextHold();
    void StartClimbing(TScriptInterface<class IBPI_ClimbingElement_C> ClimbingElement);
    void CanUseClimbingElement(bool& CanClimb);
    void InpActEvt_IA_CustomMovement_ForwardMovementAction_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CustomMovement_RightMovementAction_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnClimbingJumpMovementStart(double TotalDuration);
    void OnClimbingJumpMovementEnd();
    void OnClimbingMovementDone();
    void OnStartClimbAnimationDone();
    void OnClimbingAnimationInterrupted();
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_ClimbingComponent(int32 EntryPoint);
    void OnEndClimbing__DelegateSignature();
    void OnStartClimbing__DelegateSignature();
}; // Size: 0x248

#endif
