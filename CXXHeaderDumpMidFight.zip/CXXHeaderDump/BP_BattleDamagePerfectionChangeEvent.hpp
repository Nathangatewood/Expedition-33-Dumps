#ifndef UE4SS_SDK_BP_BattleDamagePerfectionChangeEvent_HPP
#define UE4SS_SDK_BP_BattleDamagePerfectionChangeEvent_HPP

class UBP_BattleDamagePerfectionChangeEvent_C : public UObject
{
    class UBP_BattleDamages_C* BattleDamage;                                          // 0x0028 (size: 0x8)
    int32 InitialNewPerfection;                                                       // 0x0030 (size: 0x4)
    int32 CurrentNewPerfection;                                                       // 0x0034 (size: 0x4)

    int32 GetCurrentNewPerfection();
    int32 GetInitialNewPerfection();
    void OverrideNewPerfection(int32 CurrentNewPerfection, FString DebugReason);
    void Init();
}; // Size: 0x38

#endif
