#ifndef UE4SS_SDK_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_HPP
#define UE4SS_SDK_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_88;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_89;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_90;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_25;       // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_24;       // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_23;       // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_22;       // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_21;       // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_20;       // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_19;       // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_18;       // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_17;       // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_16;       // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_15;       // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_14;       // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_13;       // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_12;       // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_11;       // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_10;       // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_9;        // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_8;        // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_7;        // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_6;        // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_5;        // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_4;        // 0x0520 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x0550 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x0580 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x05B0 (size: 0x30)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose;                       // 0x05E0 (size: 0x8)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x05E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x0618 (size: 0x30)

}; // Size: 0x648

class UAPPBP_Hair_Maelle_Ponytail_V3_Metahumansk_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_25;                           // 0x0390 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_24;                           // 0x0B30 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_23;                           // 0x12D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_22;                           // 0x1A70 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_21;                           // 0x2210 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_20;                           // 0x29B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_19;                           // 0x3150 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_18;                           // 0x38F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_17;                           // 0x4090 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_16;                           // 0x4830 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_15;                           // 0x4FD0 (size: 0x7A0)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x5770 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_14;                           // 0x5790 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_13;                           // 0x5F30 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_12;                           // 0x66D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_11;                           // 0x6E70 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_10;                           // 0x7610 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_9;                            // 0x7DB0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_8;                            // 0x8550 (size: 0x7A0)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x8CF0 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7;                            // 0x8D10 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6;                            // 0x94B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5;                            // 0x9C50 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4;                            // 0xA3F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0xAB90 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0xB330 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0xBAD0 (size: 0x7A0)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0xC270 (size: 0xB8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0xC328 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0xC350 (size: 0x7A0)
    int32 LOD Threshold;                                                              // 0xCAF0 (size: 0x4)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_518A4AA9409A12DE24AF9581A3FFA8C8();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_C84E73B64627B07D387BD99695E16BB9();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_20FD31744105E3EA2FB3BC813E3455D1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_41BFA9C548CB15C8B1946CAF68417E0F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_CBBE054947C2E467D6E8E2ACDAE98FCE();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_6D6F5B7046736B89A4C510BF5E6E6469();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_038792C54C778F0D5436BCB527BFA643();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_6DA8B7344128DF0824987996C98A6B2D();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_130690354B842CD9D437E6BB16012B59();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_0A6E69634D1D4720FC83CDB6EF1B2BCF();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_7FE34A634B44E9BDF5C4A68A51920036();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_63C71B39487936C484BE7E87AE707F12();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_73F61A0140A34FC0360CCDB444EC6CED();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_4158E9614EFB9AC5A7B560BD5EB7ADF7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_27893686426D52A9EF7AD6AE914EA264();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_5769C1934DE55C6FE6EE6792BB6B061F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_F3106C794CB0B13E673A798878F50E8B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_D4FD03E342A6C5A73C0D2F87B2036E71();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_0E4BD6A44B0649D00F021B8F33435389();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_299D39164B2C69CDEAF424A6DAB9A859();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_38627715470611456104E78C59AAF9A0();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_DE1EB72F41937D7A9D5BEBBEB443D1E4();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_F2E940064A4E89C9673057851DBE68FA();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_5ADDA59E4DEC8F04E2CA5FAD08DD809B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_112FE9B840AAC93626420C8A47DBBC90();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk_AnimGraphNode_KawaiiPhysics_FA86003B439077B224EBA389058CA731();
    void ExecuteUbergraph_APPBP_Hair_Maelle_Ponytail_V3_Metahumansk(int32 EntryPoint);
}; // Size: 0xCAF4

#endif
