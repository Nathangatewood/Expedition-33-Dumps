#ifndef UE4SS_SDK_BP_FreeAimShooterBattleComponent_HPP
#define UE4SS_SDK_BP_FreeAimShooterBattleComponent_HPP

class UBP_FreeAimShooterBattleComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    int32 ShotsLeft;                                                                  // 0x00A8 (size: 0x4)
    int32 ShotsFired;                                                                 // 0x00AC (size: 0x4)
    double TimeLeft;                                                                  // 0x00B0 (size: 0x8)
    bool IsAiming;                                                                    // 0x00B8 (size: 0x1)
    FBP_FreeAimShooterBattleComponent_COnFreeAimEnabled OnFreeAimEnabled;             // 0x00C0 (size: 0x10)
    void OnFreeAimEnabled();
    FBP_FreeAimShooterBattleComponent_COnFreeAimEnded OnFreeAimEnded;                 // 0x00D0 (size: 0x10)
    void OnFreeAimEnded(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllHitCharacters, TEnumAsByte<EFreeAimType::Type> FreeAimType);
    FBP_FreeAimShooterBattleComponent_COnFreeAimCancelled OnFreeAimCancelled;         // 0x00E0 (size: 0x10)
    void OnFreeAimCancelled();
    FBP_FreeAimShooterBattleComponent_COnFreeAimHit_Character_Skill OnFreeAimHit_Character_Skill; // 0x00F0 (size: 0x10)
    void OnFreeAimHit_Character_Skill(class ABP_jRPG_Character_Battle_Base_C* HitCharacter, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPartType, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
    TEnumAsByte<EFreeAimType::Type> CurrentFreeAimType;                               // 0x0100 (size: 0x1)
    class USceneComponent* SpawnLocationComponent;                                    // 0x0108 (size: 0x8)
    class USceneComponent* SpawnRotationComponent;                                    // 0x0110 (size: 0x8)
    FComponentReference CompRef;                                                      // 0x0118 (size: 0x28)
    FBP_FreeAimShooterBattleComponent_COnFreeAimHit_Character_Regular OnFreeAimHit_Character_Regular; // 0x0140 (size: 0x10)
    void OnFreeAimHit_Character_Regular(class ABP_jRPG_Character_Battle_Base_C* Character, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, FHitResult HitResult, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
    FBP_FreeAimShooterBattleComponent_CShootFreeAimProjectile ShootFreeAimProjectile; // 0x0150 (size: 0x10)
    void ShootFreeAimProjectile();
    bool IsEnding;                                                                    // 0x0160 (size: 0x1)
    FRotator AimingRotation;                                                          // 0x0168 (size: 0x18)
    FName BoneProjectileSpawnLocation;                                                // 0x0180 (size: 0x8)
    bool ActiveHandComponent;                                                         // 0x0188 (size: 0x1)
    class ABP_FreeAimProjectile_Base_C* NextProjectileActor;                          // 0x0190 (size: 0x8)
    TSubclassOf<class ABP_FreeAimProjectile_Base_C> ProjectileClass;                  // 0x0198 (size: 0x8)
    bool IsShootingProjectile;                                                        // 0x01A0 (size: 0x1)
    bool PreBlocked;                                                                  // 0x01A1 (size: 0x1)

    void BeginPreBlock();
    void OnProjectileFiringFinished();
    bool CanCancelFreeAim();
    void SetShotsLeft(int32 ShotsLeft);
    bool HasUnlimitedShots();
    bool HasShotsLeft();
    void FireFreeAimProjectile();
    void PrepareNextFreeAimProjectile(class ABP_FreeAimProjectile_Base_C*& CreatedProjectileActor);
    bool HasFreeAimTimeExpired();
    void Internal_DisableFreeAim();
    void CancelRegularFreeAim();
    void EndFreeAim();
    void EnableFreeAim(TEnumAsByte<EFreeAimType::Type> FreeAimType, int32 AmmoCount, double TimeLimit, TSubclassOf<class ABP_FreeAimProjectile_Base_C> ProjectileClass);
    void OnFreeAimShootAction();
    void ReceiveTick(float DeltaSeconds);
    void BindFreeAimProjectile(class ABP_FreeAimProjectile_Base_C* Projectile);
    void OnFreeAimProjectileHit(class ABP_jRPG_Character_Battle_Base_C* Character, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, FHitResult HitResult, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
    void UnbindFreeAimEvents();
    void UpdateAimingLocation(FVector WorldAimLocation);
    void ExecuteUbergraph_BP_FreeAimShooterBattleComponent(int32 EntryPoint);
    void OnFreeAimCancelled__DelegateSignature();
    void ShootFreeAimProjectile__DelegateSignature();
    void OnFreeAimHit_Character_Regular__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, FHitResult HitResult, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
    void OnFreeAimEnabled__DelegateSignature();
    void OnFreeAimEnded__DelegateSignature(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllHitCharacters, TEnumAsByte<EFreeAimType::Type> FreeAimType);
    void OnFreeAimHit_Character_Skill__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* HitCharacter, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPartType, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
}; // Size: 0x1A2

#endif
