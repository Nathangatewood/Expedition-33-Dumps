#ifndef UE4SS_SDK_BP_CommonUIPS5ControllerData_HPP
#define UE4SS_SDK_BP_CommonUIPS5ControllerData_HPP

class UBP_CommonUIPS5ControllerData_C : public UCommonInputBaseControllerData
{
}; // Size: 0xF8

#endif
