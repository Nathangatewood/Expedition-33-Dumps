#ifndef UE4SS_SDK_BP_Buff_VersoAscendingAssault_HPP
#define UE4SS_SDK_BP_Buff_VersoAscendingAssault_HPP

class UBP_Buff_VersoAscendingAssault_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 AscendingAssaultCastCount;                                                  // 0x0160 (size: 0x4)

    void GetCastCount(int32& AscendingAssaultCastCount);
    void IncreaseCastCount();
    void ExecuteUbergraph_BP_Buff_VersoAscendingAssault(int32 EntryPoint);
}; // Size: 0x164

#endif
