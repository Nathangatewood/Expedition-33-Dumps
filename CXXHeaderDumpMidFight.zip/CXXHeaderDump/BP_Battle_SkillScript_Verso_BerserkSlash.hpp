#ifndef UE4SS_SDK_BP_Battle_SkillScript_Verso_BerserkSlash_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_Verso_BerserkSlash_HPP

class ABP_Battle_SkillScript_Verso_BerserkSlash_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    double Damage Multiplier;                                                         // 0x0310 (size: 0x8)
    double Local_QteDamage;                                                           // 0x0318 (size: 0x8)
    int32 CastCount;                                                                  // 0x0320 (size: 0x4)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript_Verso_BerserkSlash(int32 EntryPoint);
}; // Size: 0x324

#endif
