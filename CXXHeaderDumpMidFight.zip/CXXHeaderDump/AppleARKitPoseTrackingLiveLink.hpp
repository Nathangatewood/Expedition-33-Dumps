#ifndef UE4SS_SDK_AppleARKitPoseTrackingLiveLink_HPP
#define UE4SS_SDK_AppleARKitPoseTrackingLiveLink_HPP

class UDEPRECATED_AppleARKitPoseTrackingLiveLinkRemapAsset : public ULiveLinkRetargetAsset
{
    FVector AppleARKitHumanForward;                                                   // 0x0028 (size: 0x18)
    FVector MeshForward;                                                              // 0x0040 (size: 0x18)
    TMap<FName, FName> AppleARKitBoneNamesToMeshBoneNames;                            // 0x0058 (size: 0x50)

}; // Size: 0xA8

#endif
