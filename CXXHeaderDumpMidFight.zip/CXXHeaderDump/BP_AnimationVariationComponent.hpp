#ifndef UE4SS_SDK_BP_AnimationVariationComponent_HPP
#define UE4SS_SDK_BP_AnimationVariationComponent_HPP

class UBP_AnimationVariationComponent_C : public UActorComponent
{
    FVector ScaleRoot;                                                                // 0x00A0 (size: 0x18)
    FVector ScaleSpine01;                                                             // 0x00B8 (size: 0x18)
    FVector ScaleSpine03;                                                             // 0x00D0 (size: 0x18)
    FVector ScaleArmL;                                                                // 0x00E8 (size: 0x18)
    FVector ScaleArmR;                                                                // 0x0100 (size: 0x18)
    FVector ScaleLowerArmL;                                                           // 0x0118 (size: 0x18)
    FVector ScaleLowerArmR;                                                           // 0x0130 (size: 0x18)

}; // Size: 0x148

#endif
