#ifndef UE4SS_SDK_BP_CharacterVisualAlterationsComponent_HPP
#define UE4SS_SDK_BP_CharacterVisualAlterationsComponent_HPP

class UBP_CharacterVisualAlterationsComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<UMeshComponent*> MeshesToAlter;                                            // 0x00A8 (size: 0x10)
    FVector LastCharacterLocation;                                                    // 0x00B8 (size: 0x18)
    double DistanceTraveled;                                                          // 0x00D0 (size: 0x8)
    bool ShouldAlter;                                                                 // 0x00D8 (size: 0x1)
    bool IsCharacterInCinematic;                                                      // 0x00D9 (size: 0x1)
    FLinearColor DefaultWaterFXColor;                                                 // 0x00DC (size: 0x10)
    class ABP_Water_Reaction_C* CurrentWaterFX;                                       // 0x00F0 (size: 0x8)
    bool IsInWater;                                                                   // 0x00F8 (size: 0x1)
    double WaterLevel;                                                                // 0x0100 (size: 0x8)
    double CurrentWaterLevel;                                                         // 0x0108 (size: 0x8)
    double TargetWaterLevel;                                                          // 0x0110 (size: 0x8)
    double SpeedWaterLevel;                                                           // 0x0118 (size: 0x8)
    bool EnableDynamicCharacterOpacity;                                               // 0x0120 (size: 0x1)
    double MinimumDistanceToOpacifyCharacter;                                         // 0x0128 (size: 0x8)
    double MaximumDistanceToOpacifyCharacter;                                         // 0x0130 (size: 0x8)
    double ThresholdToHideGroom;                                                      // 0x0138 (size: 0x8)

    double ComputeCameraDistanceToCapsule();
    void UpdateCharacterOpacity(double DeltaSeconds);
    double GetWaterLevel();
    double ComputeMeshHeight();
    void UpdateWaterLevelParameter(double DeltaSeconds, double Speed);
    void UpdateWaterLevelData(bool IsInWaterCheck, FVector ImpactPoint, double MeshHeight);
    void SpawnWaterFXIfNeeded(bool IsInWaterCheck, FVector Location, FVector CharacterForwardVector, class ABP_Water_Reaction_C*& CurrentWaterFX);
    void GetOwnerAsCharacter(class ACharacter*& Character);
    void UpdateWaterOnCharacter(double DeltaSeconds);
    void SetCharacterOpacity(double NewOpacity);
    void ApplyAlterationsWithHealthRatio(double HealthRatio);
    void SetTearsLevel(double TearLevel);
    void SetSweatLevel(double NewValue);
    void SetBloodLevel(double NewValue);
    void SetDirtLevel(double NewValue);
    void UpdateMudOnCharacter(double DeltaSeconds);
    void UpdateCharacterVisualAlterationsElements();
    void GetOwnerCurrentHealthRatio(double& Ratio);
    void GetOwnerCharacterName(FName& HardcodedNameID);
    void OnCharacterCustomizationChanged(class UBP_CharacterSkinComponent_C* SkinComponent);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void OnCharacterUpdateNeeded();
    void ReceiveTick(float DeltaSeconds);
    void ForceCharacterVisualAlteration(double BloodLevel, double SweatLevel, double DirtLevel, double TearLevel);
    void ExecuteUbergraph_BP_CharacterVisualAlterationsComponent(int32 EntryPoint);
}; // Size: 0x140

#endif
