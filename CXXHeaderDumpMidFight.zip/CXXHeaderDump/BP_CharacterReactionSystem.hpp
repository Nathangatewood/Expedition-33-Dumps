#ifndef UE4SS_SDK_BP_CharacterReactionSystem_HPP
#define UE4SS_SDK_BP_CharacterReactionSystem_HPP

class UBP_CharacterReactionSystem_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool AllyWasAttackedDuringTurn;                                                   // 0x00A8 (size: 0x1)
    class UAC_jRPG_CharacterBattleStats_C* AttackedAllyDuringTurn;                    // 0x00B0 (size: 0x8)
    class UAC_jRPG_CharacterBattleStats_C* Character Turn;                            // 0x00B8 (size: 0x8)
    class UAC_jRPG_BattleManager_C* BattleManagerReference;                           // 0x00C0 (size: 0x8)
    class UAC_jRPG_CharacterBattleStats_C* LastAllyCharacterToPlay;                   // 0x00C8 (size: 0x8)
    class UBP_BattleLineGatherer_C* ActiveBattleLineGatherer;                         // 0x00D0 (size: 0x8)
    bool SkipAllRolls;                                                                // 0x00D8 (size: 0x1)

    bool ShouldSkipAllRolls();
    void OnCharacterKilled(class UBP_BattleDamages_C* LethalDamages);
    void OnCharacterHealSuccessful(class UBP_BattleHeal_C* HealObject);
    void OnCharacterHealed(class UBP_BattleHeal_C* HealEvent);
    void GetBattleLineSettings(class UBP_BattleLineSettings_C*& Settings);
    void OnEnemyAcquiredTarget(class UAC_jRPG_CharacterBattleStats_C* EnemyStats, class UAC_jRPG_CharacterBattleStats_C* TargetedStats);
    void RollFromPool(const FS_BattleLinePool& BattleLinePool, FS_BattleLine& BattleLine);
    void Internal_EndGatherBattleLines_OLD();
    void EndChooseBattleLines(class UBP_BattleLineGatherer_C* Gatherer);
    void BeginChoosingBattleLines(class UBP_BattleLineGatherer_C*& Gatherer);
    void LogPerCharacterReaction(FString Reaction, class UAC_jRPG_CharacterBattleStats_C* ReactingCharacter, class UAC_jRPG_CharacterBattleStats_C* SubjectCharacter);
    void GetAnyAllyCharacterExcept(class UAC_jRPG_CharacterBattleStats_C* Except, class ABP_jRPG_Character_Battle_Base_C*& CharacterActor);
    void ResetTurnState();
    void OnCharacterReceivedDamage(class UAC_jRPG_CharacterBattleStats_C* AttackedCharacter, class UAC_jRPG_CharacterBattleStats_C* AttackerCharacter, double DamageAmount);
    void OnTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterTurn);
    void OnCharacterRevived(class UAC_jRPG_CharacterBattleStats_C* RevivedCharacter, class UAC_jRPG_CharacterBattleStats_C* RevivingCharacter);
    void OnCharacterBuffed(class UBP_BattleBuffInstance_C* BuffInstance, class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter);
    void OnBattleEnds();
    void OnBattleStart(class UAC_jRPG_BattleManager_C* BattleManager);
    void ReceiveBeginPlay();
    void DEBUG_CVarChange_BattleLine_SkipRoll(bool NewValue);
    void ExecuteUbergraph_BP_CharacterReactionSystem(int32 EntryPoint);
}; // Size: 0xD9

#endif
