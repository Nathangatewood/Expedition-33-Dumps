#ifndef UE4SS_SDK_BlockoutToolsPlugin_HPP
#define UE4SS_SDK_BlockoutToolsPlugin_HPP

#include "BlockoutToolsPlugin_enums.hpp"

class ABlockoutToolsParent : public AActor
{
    class USceneComponent* Root;                                                      // 0x0290 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x0298 (size: 0x8)
    class UMaterialInterface* BlockoutGridParent;                                     // 0x02A0 (size: 0x8)
    class UMaterialInstanceDynamic* BlockoutGridMID;                                  // 0x02A8 (size: 0x8)
    class UMaterialInterface* BlockoutCurrentMaterial;                                // 0x02B0 (size: 0x8)
    TArray<UStaticMeshComponent*> BlockoutMeshComponents;                             // 0x02B8 (size: 0x10)
    TEnumAsByte<EBlockoutMaterialType> BlockoutMaterialType;                          // 0x02C8 (size: 0x1)
    FLinearColor BlockoutMaterialColor;                                               // 0x02CC (size: 0x10)
    bool bBlockoutMaterialUseGrid;                                                    // 0x02DC (size: 0x1)
    bool bBlockoutWorldAligned;                                                       // 0x02DD (size: 0x1)
    float BlockoutMaterialGridSize;                                                   // 0x02E0 (size: 0x4)
    float BlockoutMaterialCheckerLuminance;                                           // 0x02E4 (size: 0x4)
    float BlockoutMaterialRoughness;                                                  // 0x02E8 (size: 0x4)
    bool bBlockoutMaterialUseTopColor;                                                // 0x02EC (size: 0x1)
    FLinearColor BlockoutMaterialTopColor;                                            // 0x02F0 (size: 0x10)
    bool bUseCustomMaterial;                                                          // 0x0300 (size: 0x1)
    class UMaterialInterface* CustomMaterial;                                         // 0x0308 (size: 0x8)
    class UMaterialInterface* BlockoutCustomMaterial;                                 // 0x0310 (size: 0x8)
    bool bBlockoutEnableCollisions;                                                   // 0x0318 (size: 0x1)
    bool bBlockoutEnableCustomCollision;                                              // 0x0319 (size: 0x1)
    FName BlockoutCustomCollisionProfileName;                                         // 0x031C (size: 0x8)
    bool bBlockoutCastShadows;                                                        // 0x0324 (size: 0x1)

    void RerunConstructionScript();
    void BlockoutSetMaterial();
}; // Size: 0x328

class UBlockoutToolsSettings : public UObject
{
    TEnumAsByte<EBlockoutMaterialType> BlockoutMaterialType;                          // 0x0028 (size: 0x1)
    FLinearColor BlockoutMaterialColor;                                               // 0x002C (size: 0x10)
    bool bBlockoutMaterialUseGrid;                                                    // 0x003C (size: 0x1)
    bool bBlockoutWorldAligned;                                                       // 0x003D (size: 0x1)
    float BlockoutMaterialGridSize;                                                   // 0x0040 (size: 0x4)
    float BlockoutMaterialCheckerLuminance;                                           // 0x0044 (size: 0x4)
    float BlockoutMaterialRoughness;                                                  // 0x0048 (size: 0x4)
    bool bBlockoutMaterialUseTopColor;                                                // 0x004C (size: 0x1)
    FLinearColor BlockoutMaterialTopColor;                                            // 0x0050 (size: 0x10)

}; // Size: 0x60

#endif
