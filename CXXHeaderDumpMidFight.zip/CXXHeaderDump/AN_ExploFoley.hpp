#ifndef UE4SS_SDK_AN_ExploFoley_HPP
#define UE4SS_SDK_AN_ExploFoley_HPP

class UAN_ExploFoley_C : public UAnimNotify
{
    TEnumAsByte<EFoleyType::Type> FoleyType;                                          // 0x0038 (size: 0x1)
    bool ShouldPlaySpecificSound;                                                     // 0x0039 (size: 0x1)
    class USoundBase* SpecificSound;                                                  // 0x0040 (size: 0x8)

    void Play Foley Sound(class ABP_jRPG_Character_World_C* BP JRPG CharacterWorld, class UObject* Owner);
    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x48

#endif
