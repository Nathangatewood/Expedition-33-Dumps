#ifndef UE4SS_SDK_BP_BattleBuff_Bound_HPP
#define UE4SS_SDK_BP_BattleBuff_Bound_HPP

class UBP_BattleBuff_Bound_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UParticleSystemComponent* Particle System Component;                        // 0x0160 (size: 0x8)
    FSF_ReferenceCounterHandle Lock Handle;                                           // 0x0168 (size: 0x20)
    class UAC_jRPG_CharacterBattleStats_C* Character Stats;                           // 0x0188 (size: 0x8)
    TArray<UNiagaraComponent*> NiagaraSystemArray;                                    // 0x0190 (size: 0x10)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Bound(int32 EntryPoint);
}; // Size: 0x1A0

#endif
