#ifndef UE4SS_SDK_BP_BattleBuff_GreaterPowerful_HPP
#define UE4SS_SDK_BP_BattleBuff_GreaterPowerful_HPP

class UBP_BattleBuff_GreaterPowerful_C : public UBP_BattleBuff_Power_C
{
}; // Size: 0x170

#endif
