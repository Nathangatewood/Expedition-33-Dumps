#ifndef UE4SS_SDK_BP_Cine_Verso_HPP
#define UE4SS_SDK_BP_Cine_Verso_HPP

class ABP_Cine_Verso_C : public ABP_CineCharacter_Main_C
{
    class USkeletalMeshComponent* Mustache_Verso_skl;                                 // 0x0698 (size: 0x8)
    class USkeletalMeshComponent* Beard_Verso_skl;                                    // 0x06A0 (size: 0x8)
    FRawAnimSequenceTrack AudioTrack;                                                 // 0x06A8 (size: 0x30)

}; // Size: 0x6D8

#endif
