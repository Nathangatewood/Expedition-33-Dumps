#ifndef UE4SS_SDK_AN_ExploBreath_HPP
#define UE4SS_SDK_AN_ExploBreath_HPP

class UAN_ExploBreath_C : public UAnimNotify
{
    float FloatValueToAdd;                                                            // 0x0038 (size: 0x4)
    TEnumAsByte<EBreathType::Type> BreathType;                                        // 0x003C (size: 0x1)

    void ResetHeartRate(class ABP_jRPG_Character_World_C* Target, FString String);
    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x3D

#endif
