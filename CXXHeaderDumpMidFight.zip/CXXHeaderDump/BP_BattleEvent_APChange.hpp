#ifndef UE4SS_SDK_BP_BattleEvent_APChange_HPP
#define UE4SS_SDK_BP_BattleEvent_APChange_HPP

class UBP_BattleEvent_APChange_C : public UBP_BattleEvent_Base_C
{
    int32 NewValue;                                                                   // 0x0028 (size: 0x4)
    int32 PreviousValue;                                                              // 0x002C (size: 0x4)
    class UAC_jRPG_CharacterBattleStats_C* CharacterStats;                            // 0x0030 (size: 0x8)
    TEnumAsByte<EAPChangeReason::Type> ChangeReason;                                  // 0x0038 (size: 0x1)

    int32 GetPreviousValue();
    int32 GetNewValue();
    class UAC_jRPG_CharacterBattleStats_C* GetAffectedCharacterStats();
    void BroadcastBattleEvent(class UAC_jRPG_BattleManager_C*& BattleManager);
    bool IsLoss();
    bool IsGain();
    int32 GetDelta();
    TEnumAsByte<EAPChangeReason::Type> GetChangeReason();
}; // Size: 0x39

#endif
