enum class ESortDirection {
    Ascending = 0,
    Descending = 1,
    ESortDirection_MAX = 2,
};

enum class ESortOrdering {
    LessThan = 0,
    Equal = 1,
    GreaterThan = 2,
    ESortOrdering_MAX = 3,
};

