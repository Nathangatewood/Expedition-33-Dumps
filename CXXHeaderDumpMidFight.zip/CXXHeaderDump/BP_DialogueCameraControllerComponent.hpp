#ifndef UE4SS_SDK_BP_DialogueCameraControllerComponent_HPP
#define UE4SS_SDK_BP_DialogueCameraControllerComponent_HPP

class UBP_DialogueCameraControllerComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<UCineCameraComponent*> DialogueCameraList;                                 // 0x00A8 (size: 0x10)
    TMap<UCineCameraComponent*, FTransform> OriginalCamerasTransform;                 // 0x00B8 (size: 0x50)
    TMap<UCineCameraComponent*, FTransform> OnDialogueStartCamerasTransform;          // 0x0108 (size: 0x50)
    class UBP_NPCAnimationComponent_C* OwnerAnimationComponentRef;                    // 0x0158 (size: 0x8)
    class ABP_jRPG_Character_World_C*  CharacterWorldRef;                             // 0x0160 (size: 0x8)
    class ABP_jRPG_NPC_Dialog_C* NpcDialogueRef;                                      // 0x0168 (size: 0x8)
    bool OwnerIsCharacterWorld;                                                       // 0x0170 (size: 0x1)
    TArray<TSoftObjectPtr<class ASpotLight>> SpotlightsToActivateDuringDialogues;     // 0x0178 (size: 0x10)
    TEnumAsByte<E_NPC_SpolightTypes::Type> TurnOnSpotlights;                          // 0x0188 (size: 0x1)
    TScriptInterface<class IBPI_DialogueCharacter_C> OwnerCharacter;                  // 0x0190 (size: 0x10)
    bool ShouldUseAutomaticFocusMode;                                                 // 0x01A0 (size: 0x1)

    void GetAllCharacterLights(TScriptInterface<class IBPI_DialogueCharacter_C> DialogueCharacter, TArray<ULightComponent*>& Lights);
    void EndDialogueSetup();
    void DefineDialogueCamerasSide();
    void StartDialogueSetup();
    void ForceCheckSpotlightsOff();
    void CopyLightValuesToCharacterWorld(class ULightComponent* TargetLight, class ULightComponent* ReferenceLight);
    void TurnOnDialogueSpotlights(bool TurnOn);
    void ChangeAllDialogueCamerasSide();
    void ResetCamerasToOriginalTransform();
    void ResetCamerasBetweenShot();
    void SaveCamerasTransformOnDialogueStart();
    void SaveCamerasOriginalTransform();
    void UpdateCameraFocusPoint();
    void CacheEnvironmentSpotlights();
    void CacheCameraList();
    void GetCameraList(TArray<UCineCameraComponent*>& DialogueCameraList);
    void ApplyCharacterCameraOffset();
    void InitializeCamerasAndSpotlights();
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void StartPreviz();
    void ExecuteUbergraph_BP_DialogueCameraControllerComponent(int32 EntryPoint);
}; // Size: 0x1A1

#endif
