#ifndef UE4SS_SDK_BP_BattleBuff_AutoApplyBuff_HPP
#define UE4SS_SDK_BP_BattleBuff_AutoApplyBuff_HPP

class UBP_BattleBuff_AutoApplyBuff_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass;                            // 0x0160 (size: 0x8)
    int32 BuffTurnDuration;                                                           // 0x0168 (size: 0x4)

    void ProcessBattleStartEvent(class UBP_DependencyRefCounter_C* DepsRefCount);
    void ExecuteUbergraph_BP_BattleBuff_AutoApplyBuff(int32 EntryPoint);
}; // Size: 0x16C

#endif
