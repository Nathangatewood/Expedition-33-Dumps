#ifndef UE4SS_SDK_BP_BattleBuffInstance_HitCountSinceSincePreviousTurn_HPP
#define UE4SS_SDK_BP_BattleBuffInstance_HitCountSinceSincePreviousTurn_HPP

class UBP_BattleBuffInstance_HitCountSinceSincePreviousTurn_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 HitCountSincePreviousTurn;                                                  // 0x0160 (size: 0x4)

    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void ApplyOnTurnEnd();
    void ExecuteUbergraph_BP_BattleBuffInstance_HitCountSinceSincePreviousTurn(int32 EntryPoint);
}; // Size: 0x164

#endif
