#ifndef UE4SS_SDK_BP_Dialog_AlphaCanvas_CleasTower_HPP
#define UE4SS_SDK_BP_Dialog_AlphaCanvas_CleasTower_HPP

class ABP_Dialog_AlphaCanvas_CleasTower_C : public ABP_Dialogue_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0338 (size: 0x8)
    class UGameAction* Game Action Reference;                                         // 0x0340 (size: 0x8)

    void StartDialog();
    void ExecuteUbergraph_BP_Dialog_AlphaCanvas_CleasTower(int32 EntryPoint);
}; // Size: 0x348

#endif
