#ifndef UE4SS_SDK_BP_BattleCheckContext_HPP
#define UE4SS_SDK_BP_BattleCheckContext_HPP

class UBP_BattleCheckContext_C : public UObject
{
    TArray<FName> ActiveChecks;                                                       // 0x0028 (size: 0x10)
    class UAC_jRPG_CharacterBattleStats_C* CharacterStats;                            // 0x0038 (size: 0x8)
    FName Constant_IsAlive;                                                           // 0x0040 (size: 0x8)
    FName Constant_CanResurrect;                                                      // 0x0048 (size: 0x8)
    bool IsConstructed;                                                               // 0x0050 (size: 0x1)
    FName Constant_CanRecoverHP;                                                      // 0x0054 (size: 0x8)
    FName Constant_CanRecoverMP;                                                      // 0x005C (size: 0x8)
    bool FEATURE_IsAssertive;                                                         // 0x0064 (size: 0x1)

    bool ShouldAssert(bool bool);
    void OnNewTurn();
    void ClearCheckList(TArray<FName>& CheckNames);
    void OnHPChanged();
    bool CheckCanRecoverActionPoint(bool CheckMode, bool& BecauseDead);
    bool CheckCanRecoverHP(bool CheckMode, bool& BecauseDead);
    void GetAllConstants(TArray<FName>& Array);
    void OnConstruct();
    void InvalidateCheck();
    void IsCheckDeclared(FName CheckName);
    bool CheckCanResurrect(bool CheckMode);
    void ClearAllChecks();
    void CheckIsAlive(bool CheckMode, bool Bypass, bool& Value);
    void MergeFrom(class UBP_BattleCheckContext_C* Other);
    bool HasCheck(const FName& ItemToFind);
    void Add Check(FName CheckName, bool CheckMode);
}; // Size: 0x65

#endif
