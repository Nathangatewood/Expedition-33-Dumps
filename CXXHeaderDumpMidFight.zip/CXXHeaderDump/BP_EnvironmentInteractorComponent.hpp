#ifndef UE4SS_SDK_BP_EnvironmentInteractorComponent_HPP
#define UE4SS_SDK_BP_EnvironmentInteractorComponent_HPP

class UBP_EnvironmentInteractorComponent_C : public USceneComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0230 (size: 0x8)
    float Interaction Size;                                                           // 0x0238 (size: 0x4)
    float Impact Duration;                                                            // 0x023C (size: 0x4)
    float Impact power / Alpha;                                                       // 0x0240 (size: 0x4)
    float Spawn Rate / Optimisation;                                                  // 0x0244 (size: 0x4)
    TArray<UMaterialInterface*> OverrideMaterialList;                                 // 0x0248 (size: 0x10)
    double Radius;                                                                    // 0x0258 (size: 0x8)
    bool Active Interactor;                                                           // 0x0260 (size: 0x1)
    double Impact Size;                                                               // 0x0268 (size: 0x8)
    double Save Impact Size;                                                          // 0x0270 (size: 0x8)
    double Impact Opacity;                                                            // 0x0278 (size: 0x8)
    double Save Impact Opacity;                                                       // 0x0280 (size: 0x8)
    bool AllowRotationMaterial;                                                       // 0x0288 (size: 0x1)

    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_EnvironmentInteractorComponent(int32 EntryPoint);
}; // Size: 0x289

#endif
