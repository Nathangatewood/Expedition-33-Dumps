#ifndef UE4SS_SDK_BP_BattleLinesModel_Maelle_HPP
#define UE4SS_SDK_BP_BattleLinesModel_Maelle_HPP

class UBP_BattleLinesModel_Maelle_C : public UBP_BattleLinesModel_Base_C
{
}; // Size: 0x4C0

#endif
