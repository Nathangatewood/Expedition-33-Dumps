#ifndef UE4SS_SDK_BP_EnemyBattle_GaultB_Unique_HPP
#define UE4SS_SDK_BP_EnemyBattle_GaultB_Unique_HPP

class ABP_EnemyBattle_GaultB_Unique_C : public ABP_EnemyBattle_Gault_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x1838 (size: 0x8)
    class UNiagaraComponent* FX_Fire1;                                                // 0x1840 (size: 0x8)
    class UNiagaraComponent* Trail_0;                                                 // 0x1848 (size: 0x8)
    class UNiagaraComponent* Fx_Fire;                                                 // 0x1850 (size: 0x8)
    class UNiagaraComponent* Niagara_0;                                               // 0x1858 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x1860 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart_Body;                         // 0x1868 (size: 0x8)
    bool IsPowerfuled;                                                                // 0x1870 (size: 0x1)
    bool IsShelled;                                                                   // 0x1871 (size: 0x1)
    bool IsEnraged;                                                                   // 0x1872 (size: 0x1)
    bool ShouldApplyPowerful;                                                         // 0x1873 (size: 0x1)
    bool ShouldApplyShell;                                                            // 0x1874 (size: 0x1)
    bool ShouldApplyRage;                                                             // 0x1875 (size: 0x1)
    class UMaterialInstanceDynamic* M_Material0Dynamic;                               // 0x1878 (size: 0x8)
    FFRoutedEventHandle Skill Handle Alpha Bound;                                     // 0x1880 (size: 0x20)
    bool First Turn;                                                                  // 0x18A0 (size: 0x1)

    void PerformActionByAI();
    void OnDamageReceivedPublic(class UBP_BattleDamages_C* BattleDamages, TScriptInterface<class IIBattleDamageSource_C> DamageSourceCharacter);
    void OnCharacterTurnEnd(class ABP_jRPG_Character_Battle_Base_C* Character);
    void TurnEnd_ApplyBuff(int32 BuffId);
    void ActionEffect_TurnEndBuff(int32 ActionEffectIndex);
    void Alpha Bound();
    void ApplyBound(int32 ActionEffectIndex);
    void DeclareCharacterSkillEvents();
    void OnTurnStart();
    void OnTurnEnded();
    void ExecuteUbergraph_BP_EnemyBattle_GaultB_Unique(int32 EntryPoint);
}; // Size: 0x18A1

#endif
