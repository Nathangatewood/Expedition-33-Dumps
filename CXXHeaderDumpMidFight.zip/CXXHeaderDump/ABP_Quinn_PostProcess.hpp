#ifndef UE4SS_SDK_ABP_Quinn_PostProcess_HPP
#define UE4SS_SDK_ABP_Quinn_PostProcess_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_49;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_50;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_51;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ControlRig;             // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_13;          // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_12;          // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_11;          // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_10;          // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_9;           // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_8;           // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_7;           // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_6;           // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_5;           // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_4;           // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_3;           // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_2;           // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver_1;           // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseDriver;             // 0x03D0 (size: 0x30)

}; // Size: 0x400

class UABP_Quinn_PostProcess_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x03A8 (size: 0xB8)
    FAnimNode_ControlRig AnimGraphNode_ControlRig;                                    // 0x0460 (size: 0x4D0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_13;                                 // 0x0930 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_12;                                 // 0x0AD0 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_11;                                 // 0x0C70 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_10;                                 // 0x0E10 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_9;                                  // 0x0FB0 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_8;                                  // 0x1150 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_7;                                  // 0x12F0 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_6;                                  // 0x1490 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_5;                                  // 0x1630 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_4;                                  // 0x17D0 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_3;                                  // 0x1970 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_2;                                  // 0x1B10 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver_1;                                  // 0x1CB0 (size: 0x1A0)
    FAnimNode_PoseDriver AnimGraphNode_PoseDriver;                                    // 0x1E50 (size: 0x1A0)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void ExecuteUbergraph_ABP_Quinn_PostProcess(int32 EntryPoint);
}; // Size: 0x1FF0

#endif
