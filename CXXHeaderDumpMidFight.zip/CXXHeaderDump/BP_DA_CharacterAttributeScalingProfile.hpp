#ifndef UE4SS_SDK_BP_DA_CharacterAttributeScalingProfile_HPP
#define UE4SS_SDK_BP_DA_CharacterAttributeScalingProfile_HPP

class UBP_DA_CharacterAttributeScalingProfile_C : public UPrimaryDataAsset
{
    TMap<TEnumAsByte<ECharacterAttribute::Type>, FFCharacterAttributeScalingList> AttributesScaling; // 0x0030 (size: 0x50)

}; // Size: 0x80

#endif
