#ifndef UE4SS_SDK_AN_BattleVocal_HPP
#define UE4SS_SDK_AN_BattleVocal_HPP

class UAN_BattleVocal_C : public UAnimNotify
{
    class UMetaSoundSource* BattleVocal;                                              // 0x0038 (size: 0x8)
    class USoundAttenuation* AttnOverrideBattleVocalEvent;                            // 0x0040 (size: 0x8)

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x48

#endif
