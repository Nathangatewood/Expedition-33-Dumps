#ifndef UE4SS_SDK_BP_CharacterFaceBase_HPP
#define UE4SS_SDK_BP_CharacterFaceBase_HPP

class ABP_CharacterFaceBase_C : public AActor
{
    class UStaticMeshComponent* Haircut_StaticMesh;                                   // 0x0290 (size: 0x8)
    class USkeletalMeshComponent* Haircut_SkeletalMesh;                               // 0x0298 (size: 0x8)
    class UGroomComponent* Hair;                                                      // 0x02A0 (size: 0x8)
    class UGroomComponent* Eyebrows;                                                  // 0x02A8 (size: 0x8)
    class UGroomComponent* Eyelashes;                                                 // 0x02B0 (size: 0x8)
    class UGroomComponent* Mustache;                                                  // 0x02B8 (size: 0x8)
    class UGroomComponent* Beard;                                                     // 0x02C0 (size: 0x8)
    class USkeletalMeshComponent* Face;                                               // 0x02C8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02D0 (size: 0x8)
    FName BoneToAttachHaircutTo;                                                      // 0x02D8 (size: 0x8)

    void UserConstructionScript();
}; // Size: 0x2E0

#endif
