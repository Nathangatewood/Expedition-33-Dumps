#ifndef UE4SS_SDK_BP_FL_SaveGameHelpers_HPP
#define UE4SS_SDK_BP_FL_SaveGameHelpers_HPP

class UBP_FL_SaveGameHelpers_C : public UBlueprintFunctionLibrary
{

    void AddMerchantRemainingItem(class UBP_SaveGameObject_V0_C* From, class UBP_SaveGameObject_V0_C* To, const FName& MerchantID, const TMap<FName, int32>& ItemsToAdd, class UObject* __WorldContext);
    void CreateModalPopupFromLoadingError(class UBP_LatentAction_LoadGame_C* LoadGameLatentAction, class UCommonActivatableWidget* ParentActivatableWidget, class UObject* __WorldContext, class UWBP_ModalPopup_C*& ModalPopup);
    class UDataTable* GetSaveUpgraderDataTable(class UObject* __WorldContext);
    void ConvertItemsFromSave(const TMap<FName, int32>& Items, class UObject* __WorldContext, TArray<FS_jRPG_Item_DynamicData>& DynamicItems);
    void ConvertItemsToSave(TArray<FS_jRPG_Item_DynamicData>& DynamicItems, class UObject* __WorldContext, TMap<FName, int32>& SavedItems);
    void GetSaveManager(class UObject* __WorldContext, class UBP_SaveManager_C*& SaveManager);
    void ForceLoadLastSave(class UObject* __WorldContext);
    void ForceAutoSave(const FString DebugReason, class UObject* __WorldContext);
    void RequestAutoSave(const FString DebugReason, class UObject* __WorldContext);
}; // Size: 0x28

#endif
