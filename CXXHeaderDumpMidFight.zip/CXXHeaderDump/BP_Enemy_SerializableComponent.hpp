#ifndef UE4SS_SDK_BP_Enemy_SerializableComponent_HPP
#define UE4SS_SDK_BP_Enemy_SerializableComponent_HPP

class UBP_Enemy_SerializableComponent_C : public UBP_SerializableActorComponent_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)

    void MakeWorldMapEnemyID();
    void OnPreSave();
    void ExecuteUbergraph_BP_Enemy_SerializableComponent(int32 EntryPoint);
}; // Size: 0xB8

#endif
