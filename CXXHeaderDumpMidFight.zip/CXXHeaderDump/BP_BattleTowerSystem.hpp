#ifndef UE4SS_SDK_BP_BattleTowerSystem_HPP
#define UE4SS_SDK_BP_BattleTowerSystem_HPP

class UBP_BattleTowerSystem_C : public UExtendedObject
{
    int32 UnlockedBattleIndex;                                                        // 0x0028 (size: 0x4)
    TMap<FName, int32> BattleVictoryCount;                                            // 0x0030 (size: 0x50)
    class UDataTable* BattleTowerDataTable;                                           // 0x0080 (size: 0x8)
    int32 MaxNumberOfBattles;                                                         // 0x0088 (size: 0x4)

    void VerifyBattleIndex(int32 BattleIndex, bool& IsValid);
    void Initialize();
    void OnBattleVictory(int32 BattleIndex);
    void ComputeBattleRewardParameters(int32 BattleIndex, const FS_BattleTowerStageData& BattleTowerStageData, FS_BattleRewardParameters& BattleRewardParameters);
    void FindBattleIDFromIndex(int32 BattleIndex, FName& BattleID);
    void ComputeBattleParametersByIndex(int32 BattleIndex, FFBattleStartParams& BattleParameters);
    void DEBUG_UnlockAllBattles();
    void ResetState();
    void SaveState(FS_BattleTowerSaveData& SaveData);
    void LoadState(FS_BattleTowerSaveData SaveData);
    void RetrieveUnlockedBattles(TArray<FS_BattleTowerStageData>& BatteTowerStageDatas);
}; // Size: 0x8C

#endif
