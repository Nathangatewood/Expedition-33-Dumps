#ifndef UE4SS_SDK_BP_EpicBattleSequenceActor_HPP
#define UE4SS_SDK_BP_EpicBattleSequenceActor_HPP

class ABP_EpicBattleSequenceActor_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    class ULevelSequence* LevelSequence;                                              // 0x02A0 (size: 0x8)
    class ABP_jRPG_Character_Battle_Base_C* SourceCharacter;                          // 0x02A8 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> TargetCharacters;                       // 0x02B0 (size: 0x10)
    FBP_EpicBattleSequenceActor_COnSequenceFinished OnSequenceFinished;               // 0x02C0 (size: 0x10)
    void OnSequenceFinished();
    FTransform AttackerFirstPosition;                                                 // 0x02D0 (size: 0x60)
    class ALevelSequenceActor* LevelSequenceActor;                                    // 0x0330 (size: 0x8)
    bool SnapOnTarget;                                                                // 0x0338 (size: 0x1)
    bool UseTargetAsOrigin;                                                           // 0x0339 (size: 0x1)
    FVector temp_SnapLocation;                                                        // 0x0340 (size: 0x18)
    TArray<FTimerHandle> impactTimers;                                                // 0x0358 (size: 0x10)
    int32 currentTimerIndex;                                                          // 0x0368 (size: 0x4)
    TMap<double, uint8> BattleSequenceKeyframes;                                      // 0x0370 (size: 0x50)
    double NextKeyframeTime;                                                          // 0x03C0 (size: 0x8)
    bool IsFinished;                                                                  // 0x03C8 (size: 0x1)
    bool UseTargetOrientation;                                                        // 0x03C9 (size: 0x1)
    bool LookAtTarget;                                                                // 0x03CA (size: 0x1)
    bool LookAtAttacker;                                                              // 0x03CB (size: 0x1)
    bool HasAttackerBinding;                                                          // 0x03CC (size: 0x1)
    TMap<int32, double> TimeMap;                                                      // 0x03D0 (size: 0x50)
    bool DisableSequenceSnapping;                                                     // 0x0420 (size: 0x1)
    bool WasInterrupted;                                                              // 0x0421 (size: 0x1)
    FBP_EpicBattleSequenceActor_COnActionEffect OnActionEffect;                       // 0x0428 (size: 0x10)
    void OnActionEffect(int32 ActionEffectIndex);
    class USF_BlueprintLatentAction* CompletedLatentAction;                           // 0x0438 (size: 0x8)
    bool ForceEnableCameraMovement;                                                   // 0x0440 (size: 0x1)

    FName GetBattleSequenceAttacker2Tag();
    void RegisterBattleSequenceAttacker2(class AActor* Actor);
    void FindTimelineObjectByEpicActor(int32& TimelineIndex);
    void ForceSequenceStop();
    FName GetBattleSequenceTargetCenterLocation();
    FName GetBattleSequenceTargetTag();
    void RegisterBindings();
    void ApplySequenceSnapping();
    void TryRegisterKeyframes();
    FName GetBattleSequenceAttackerTag();
    void TriggerActionEffect(int32 ActionEffectIndex);
    void BindActionEffectEvent(const FBindActionEffectEventEvent& Event);
    void ClearActiveSequenceEventBindings();
    void Queue Next Keyframe();
    void ProcessSequenceStopped();
    void ProcessSequenceFinished();
    void ProcessSequenceEndedInternal();
    void StartSequenceInternal();
    void StartSequence(double& SequenceDuration);
    void ReceiveBeginPlay();
    void QueueSequenceStop();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void InterruptSequence();
    void QueueInterrupt();
    void PlayBattleSequence(class USF_BlueprintLatentAction* CompletedLatentAction);
    void QueueDestroyActor();
    void ExecuteUbergraph_BP_EpicBattleSequenceActor(int32 EntryPoint);
    void OnActionEffect__DelegateSignature(int32 ActionEffectIndex);
    void OnSequenceFinished__DelegateSignature();
}; // Size: 0x441

#endif
