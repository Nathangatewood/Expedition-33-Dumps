#ifndef UE4SS_SDK_BP_BattleBuff_Stance_Defensive_HPP
#define UE4SS_SDK_BP_BattleBuff_Stance_Defensive_HPP

class UBP_BattleBuff_Stance_Defensive_C : public UBP_BattleBuff_Stance_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0160 (size: 0x8)

    void ShouldKeepOnDeath(bool& Keep);
    void ProcessAPChange(int32 NewAPAmount, int32 PreviousAPAmount, TEnumAsByte<EAPChangeReason::Type> ChangeReason, bool& HasChanged, int32& ChangedValue);
    void ProcessReceivedRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void APOnDodge(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void ExecuteUbergraph_BP_BattleBuff_Stance_Defensive(int32 EntryPoint);
}; // Size: 0x168

#endif
