#ifndef UE4SS_SDK_Action_AddBuff_HPP
#define UE4SS_SDK_Action_AddBuff_HPP

class UAction_AddBuff_C : public UObject
{
    class UAC_jRPG_CharacterBattleStats_C* SourceCharacter;                           // 0x0028 (size: 0x8)
    class UAC_jRPG_CharacterBattleStats_C* TargetCharacter;                           // 0x0030 (size: 0x8)
    bool logEnabled;                                                                  // 0x0038 (size: 0x1)
    bool IsPrevented;                                                                 // 0x0039 (size: 0x1)
    class UBP_BattleBuffInstance_C* BuffInstance;                                     // 0x0040 (size: 0x8)
    class UAction_AddBuff_C* ParentAddAction;                                         // 0x0048 (size: 0x8)

    bool WasBuffCreatedByOuterInActionChain(class UObject* OuterObject);
    bool WasBuffCreatedByOuter(class UObject* OuterObject);
    void SetParentAddAction(class UAction_AddBuff_C* ParentAction);
    void GetTargetCharacter(class UAC_jRPG_CharacterBattleStats_C*& TargetCharacter);
    void PreventAddBuff(FText Reason);
    void GetSourceCharacter(class UAC_jRPG_CharacterBattleStats_C*& SourceCharacter);
    void WasPrevented(bool& RawDamages);
    void PrintMessage(FText Message);
    void PrintError(FText Message);
}; // Size: 0x50

#endif
