#ifndef UE4SS_SDK_BP_ConditionChecker_AtLeastAmountOfItemInInventory_HPP
#define UE4SS_SDK_BP_ConditionChecker_AtLeastAmountOfItemInInventory_HPP

class UBP_ConditionChecker_AtLeastAmountOfItemInInventory_C : public UBP_ConditionChecker_ItemInInventory_C
{
    int32 Amount;                                                                     // 0x0070 (size: 0x4)

    bool CheckInternal();
}; // Size: 0x74

#endif
