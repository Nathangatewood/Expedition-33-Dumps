#ifndef UE4SS_SDK_BP_BattleSummaryStatsManager_HPP
#define UE4SS_SDK_BP_BattleSummaryStatsManager_HPP

class UBP_BattleSummaryStatsManager_C : public UObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    FDateTime StartBattleDateTime;                                                    // 0x0030 (size: 0x8)
    FDateTime EndBattleDateTime;                                                      // 0x0038 (size: 0x8)
    double TotalReceivedDamagesByCharacters;                                          // 0x0040 (size: 0x8)
    double TotalReceivedDamagesByEnemies;                                             // 0x0048 (size: 0x8)
    double HighestReceivedDamagesByEnemies;                                           // 0x0050 (size: 0x8)
    int32 DodgeCount;                                                                 // 0x0058 (size: 0x4)
    int32 ParryCount;                                                                 // 0x005C (size: 0x4)

    void OnCharacterDealtDamages(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, double Damages, double& ProcessedDamages);
    void IsTurnStartInProgress(bool& InProgress);
    void GetBattleSummaryStats(FS_BattleSummaryStats& BattleSummaryStats);
    void GetBattleTotalTime(FTimespan& Timespan);
    void ResetAllBattleSummarryStats();
    void OnCharacterKilled(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterResurrected();
    void ProcessAddBuffAction(const class UAction_AddBuff_C*& BuffAddAction);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void BPI_OnAnyCharacterDamaged(class UBP_BattleDamages_C* BattleDamage);
    void BPI_OnAnyCharacterAP_Changed(class UBP_BattleEvent_APChange_C* AP_Change);
    void BPI_OnReserveTeamSent();
    void OnSuccessfulDodge();
    void OnSuccessfulParry();
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void OnBattleStop();
    void BPI_OnBattleStart();
    void ExecuteUbergraph_BP_BattleSummaryStatsManager(int32 EntryPoint);
}; // Size: 0x60

#endif
