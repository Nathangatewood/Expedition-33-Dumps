#ifndef UE4SS_SDK_AN_BattleFoley_HPP
#define UE4SS_SDK_AN_BattleFoley_HPP

class UAN_BattleFoley_C : public UAnimNotify
{
    class UMetaSoundSource* BattleFoley;                                              // 0x0038 (size: 0x8)
    class USoundAttenuation* AttnOverrideBattleFoley;                                 // 0x0040 (size: 0x8)

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x48

#endif
