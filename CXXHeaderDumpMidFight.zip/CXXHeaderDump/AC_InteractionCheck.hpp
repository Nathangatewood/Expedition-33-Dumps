#ifndef UE4SS_SDK_AC_InteractionCheck_HPP
#define UE4SS_SDK_AC_InteractionCheck_HPP

class UAC_InteractionCheck_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<FName> Interactions;                                                       // 0x00A8 (size: 0x10)
    bool DestroyActor?;                                                               // 0x00B8 (size: 0x1)
    bool InteractionsStatus;                                                          // 0x00B9 (size: 0x1)

    void ReceiveBeginPlay();
    void ExecuteUbergraph_AC_InteractionCheck(int32 EntryPoint);
}; // Size: 0xBA

#endif
