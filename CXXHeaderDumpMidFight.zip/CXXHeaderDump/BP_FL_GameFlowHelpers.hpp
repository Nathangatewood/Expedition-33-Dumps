#ifndef UE4SS_SDK_BP_FL_GameFlowHelpers_HPP
#define UE4SS_SDK_BP_FL_GameFlowHelpers_HPP

class UBP_FL_GameFlowHelpers_C : public UBlueprintFunctionLibrary
{

    void IsInWorldMap(class UObject* __WorldContext, bool& Result);
    void IsTransitionRequestValid(const FS_GameFlowTransitionRequest& GameFlowTransitionRequest, class UObject* __WorldContext, bool& IsValid);
    void ReleaseAndWaitGameFlowTransitionFadeOut(double OverrideFadeOutTransition, class UObject* __WorldContext, class USF_BlueprintLatentAction*& LatentAction);
    void ReleaseAndWaitGameFlowTransition(double OverrideFadeOutTransition, class UObject* __WorldContext, class USF_BlueprintLatentAction*& LatentAction);
    void ReleaseGameFlowTransition(double OverrideFadeOutTransition, class UObject* __WorldContext);
    void HoldGameFlowTransition(class UObject* __WorldContext);
    void RequestGameFlowTransition(const FS_GameFlowTransitionRequest& TransitionRequest, class UObject* __WorldContext);
    void GetGameFlowTransitionSystem(class UObject* __WorldContext, class UBP_GameFlowTransitionSystem_C*& GameFlowTransitionSystem);
    class UBP_DataAsset_ProjectConfiguration_C* GetProjectConfiguration(class UObject* __WorldContext);
    void GetDemoLevelData(class UObject* __WorldContext, const TSoftObjectPtr<class UWorld>& LevelDestination, FGameplayTag& SpawnPointTag);
}; // Size: 0x28

#endif
