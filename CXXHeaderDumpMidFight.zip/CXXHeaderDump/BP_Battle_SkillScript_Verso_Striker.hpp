#ifndef UE4SS_SDK_BP_Battle_SkillScript_Verso_Striker_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_Verso_Striker_HPP

class ABP_Battle_SkillScript_Verso_Striker_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    double Local_QteDamage;                                                           // 0x0310 (size: 0x8)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript_Verso_Striker(int32 EntryPoint);
}; // Size: 0x318

#endif
