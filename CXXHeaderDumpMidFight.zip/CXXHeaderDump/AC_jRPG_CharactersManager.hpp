#ifndef UE4SS_SDK_AC_jRPG_CharactersManager_HPP
#define UE4SS_SDK_AC_jRPG_CharactersManager_HPP

class UAC_jRPG_CharactersManager_C : public UActorComponent
{
    int32 MaxCharactersAmountInParty;                                                 // 0x00A0 (size: 0x4)
    int32 MaxCharactersAmountInCollection;                                            // 0x00A4 (size: 0x4)
    FName SelectedCharacter;                                                          // 0x00A8 (size: 0x8)
    int32 CharacterMaxLevel;                                                          // 0x00B0 (size: 0x4)
    FName SelectedAction;                                                             // 0x00B4 (size: 0x8)
    FAC_jRPG_CharactersManager_COnCharacterCollectionChanged OnCharacterCollectionChanged; // 0x00C0 (size: 0x10)
    void OnCharacterCollectionChanged();
    FAC_jRPG_CharactersManager_COnCharacterPartyChanged OnCharacterPartyChanged;      // 0x00D0 (size: 0x10)
    void OnCharacterPartyChanged();
    FAC_jRPG_CharactersManager_COnAnyCharacterHealthPointChanged OnAnyCharacterHealthPointChanged; // 0x00E0 (size: 0x10)
    void OnAnyCharacterHealthPointChanged();
    FAC_jRPG_CharactersManager_COnAnySkillUnlocked OnAnySkillUnlocked;                // 0x00F0 (size: 0x10)
    void OnAnySkillUnlocked();

    void ValidateCharacterExclusions();
    void ComputePartyWithExclusions();
    void SetCharacterExclusions(TArray<FName>& CharactersToExclude, TArray<FName>& CharactersToInclude);
    class UBP_CharacterData_C* InitCharacterData(FS_jRPG_CharacterSaveState CharacterSaveState);
    void SetParty(TArray<FName>& InputPin);
    void LearnNewAction(FName Character, FName ActionName, bool UpgradeIfAlreadyLearned);
    void FullHealAllCharacters();
    void SetCharacterHP(FName CharacterHardcodedName, double Value);
    void RestoreMP(FName CharacterHardcodedName, double MP Amount);
    void RestoreHP(FName CharacterHardcodedName, double HP Amount);
    void RemoveCharacterFromCollection(class UBP_CharacterData_C* CharacterData);
    void CheckIfThereIsCharacterInParty(FName CharacterHardcodedName, bool& Success?, int32& SlotIndex);
    void ReplaceCharacterInParty(FName CharacterHardcodedName, int32 position);
    void RemoveCharacterFromParty(FName CharacterHardcodedName);
    void AddCharacterToParty(FName CharacterHardcodedName);
    void AddNewCharacterToCollection(FS_jRPG_CharacterSaveState CharacterSaveState);
    void GetCharacterData(FName CharacterId, class UBP_CharacterData_C*& CharacterData);
    void OnAnySkillUnlocked__DelegateSignature();
    void OnAnyCharacterHealthPointChanged__DelegateSignature();
    void OnCharacterPartyChanged__DelegateSignature();
    void OnCharacterCollectionChanged__DelegateSignature();
}; // Size: 0x100

#endif
