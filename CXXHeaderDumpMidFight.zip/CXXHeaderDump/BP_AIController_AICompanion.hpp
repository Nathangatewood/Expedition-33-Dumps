#ifndef UE4SS_SDK_BP_AIController_AICompanion_HPP
#define UE4SS_SDK_BP_AIController_AICompanion_HPP

class ABP_AIController_AICompanion_C : public AAIController
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x03B8 (size: 0x8)

    void ActivateAICompanions();
    void DeactivateAICompanions();
    void ReceivePossess(class APawn* PossessedPawn);
    void ExecuteUbergraph_BP_AIController_AICompanion(int32 EntryPoint);
}; // Size: 0x3C0

#endif
