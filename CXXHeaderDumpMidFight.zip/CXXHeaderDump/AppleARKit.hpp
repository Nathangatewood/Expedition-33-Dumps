#ifndef UE4SS_SDK_AppleARKit_HPP
#define UE4SS_SDK_AppleARKit_HPP

#include "AppleARKit_enums.hpp"

struct FAppleARKitCamera
{
    EARTrackingQuality TrackingQuality;                                               // 0x0000 (size: 0x1)
    EARTrackingQualityReason TrackingQualityReason;                                   // 0x0001 (size: 0x1)
    FTransform Transform;                                                             // 0x0010 (size: 0x60)
    FQuat Orientation;                                                                // 0x0070 (size: 0x20)
    FVector Translation;                                                              // 0x0090 (size: 0x18)
    FVector2D ImageResolution;                                                        // 0x00A8 (size: 0x10)
    FVector2D FocalLength;                                                            // 0x00B8 (size: 0x10)
    FVector2D PrincipalPoint;                                                         // 0x00C8 (size: 0x10)

}; // Size: 0xE0

struct FAppleARKitFrame
{
}; // Size: 0x160

struct FAppleARKitLightEstimate
{
    bool bIsValid;                                                                    // 0x0000 (size: 0x1)
    float AmbientIntensity;                                                           // 0x0004 (size: 0x4)
    float AmbientColorTemperatureKelvin;                                              // 0x0008 (size: 0x4)

}; // Size: 0xC

class UARKitCameraOverlayMaterialLoader : public UObject
{
    class UMaterialInterface* DefaultCameraOverlayMaterial;                           // 0x0028 (size: 0x8)
    class UMaterialInterface* DepthOcclusionOverlayMaterial;                          // 0x0030 (size: 0x8)
    class UMaterialInterface* MatteOcclusionOverlayMaterial;                          // 0x0038 (size: 0x8)
    class UMaterialInterface* SceneDepthOcclusionMaterial;                            // 0x0040 (size: 0x8)
    class UMaterialInterface* SceneDepthColorationMaterial;                           // 0x0048 (size: 0x8)

}; // Size: 0x50

class UARKitGeoTrackingSupport : public UARGeoTrackingSupport
{
}; // Size: 0x28

class UARKitMeshGeometry : public UARMeshGeometry
{
}; // Size: 0x160

class UAppleARKitCameraVideoTexture : public UARTextureCameraImage
{
}; // Size: 0x158

class UAppleARKitEnvironmentCaptureProbe : public UAREnvironmentCaptureProbe
{
    class UAppleARKitEnvironmentCaptureProbeTexture* ARKitEnvironmentTexture;         // 0x0178 (size: 0x8)

}; // Size: 0x180

class UAppleARKitEnvironmentCaptureProbeTexture : public UAREnvironmentCaptureProbeTexture
{
}; // Size: 0x160

class UAppleARKitOcclusionTexture : public UARTexture
{
}; // Size: 0x158

class UAppleARKitSettings : public UObject
{
    bool bRequireARKitSupport;                                                        // 0x0030 (size: 0x1)
    FString FaceTrackingLogDir;                                                       // 0x0038 (size: 0x10)
    TArray<ELivelinkTrackingType> LivelinkTrackingTypes;                              // 0x0048 (size: 0x10)
    bool bFaceTrackingLogData;                                                        // 0x0058 (size: 0x1)
    bool bFaceTrackingWriteEachFrame;                                                 // 0x0059 (size: 0x1)
    EARFaceTrackingFileWriterType FaceTrackingFileWriterType;                         // 0x005A (size: 0x1)
    bool bShouldWriteCameraImagePerFrame;                                             // 0x005B (size: 0x1)
    float WrittenCameraImageScale;                                                    // 0x005C (size: 0x4)
    int32 WrittenCameraImageQuality;                                                  // 0x0060 (size: 0x4)
    ETextureRotationDirection WrittenCameraImageRotation;                             // 0x0064 (size: 0x1)
    int32 LiveLinkPublishingPort;                                                     // 0x0068 (size: 0x4)
    FName DefaultFaceTrackingLiveLinkSubjectName;                                     // 0x006C (size: 0x8)
    FName DefaultPoseTrackingLiveLinkSubjectName;                                     // 0x0074 (size: 0x8)
    EARFaceTrackingDirection DefaultFaceTrackingDirection;                            // 0x007C (size: 0x1)
    bool bAdjustThreadPrioritiesDuringARSession;                                      // 0x007D (size: 0x1)
    int32 GameThreadPriorityOverride;                                                 // 0x0080 (size: 0x4)
    int32 RenderThreadPriorityOverride;                                               // 0x0084 (size: 0x4)
    FString ARKitTimecodeProvider;                                                    // 0x0088 (size: 0x10)

}; // Size: 0xC0

class UAppleARKitTextureCameraDepth : public UARTextureCameraDepth
{
}; // Size: 0x158

class UAppleARKitTextureCameraImage : public UARTextureCameraImage
{
}; // Size: 0x158

class UAppleARKitTimecodeProvider : public UTimecodeProvider
{
}; // Size: 0x38

class UDEPRECATED_MaterialExpressionARKitPassthroughCamera : public UMaterialExpression
{
    FExpressionInput Coordinates;                                                     // 0x00B0 (size: 0x28)
    uint32 ConstCoordinate;                                                           // 0x00D8 (size: 0x4)
    TEnumAsByte<EARKitTextureType> TextureType;                                       // 0x00DC (size: 0x1)

}; // Size: 0xE0

#endif
