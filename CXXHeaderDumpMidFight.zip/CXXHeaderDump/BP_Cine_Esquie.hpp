#ifndef UE4SS_SDK_BP_Cine_Esquie_HPP
#define UE4SS_SDK_BP_Cine_Esquie_HPP

class ABP_Cine_Esquie_C : public ABP_CineCharacter_Main_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0698 (size: 0x8)
    class UStaticMeshComponent* SM_Esquie_UE5_armband;                                // 0x06A0 (size: 0x8)
    class USpotLightComponent* Spotlight_Face_Left_Esquie;                            // 0x06A8 (size: 0x8)
    class USpotLightComponent* SpotLight_Bottom_Esquie;                               // 0x06B0 (size: 0x8)
    class USpotLightComponent* Spotlight_Rim_Face_Right_Esquie;                       // 0x06B8 (size: 0x8)
    class USpotLightComponent* Spotlight_Rim_Face_Left_Esquie;                        // 0x06C0 (size: 0x8)
    class USpotLightComponent* Spotlight_Face_Top_Esquie;                             // 0x06C8 (size: 0x8)
    class USpotLightComponent* Spotlight_Face_Right_Esquie;                           // 0x06D0 (size: 0x8)
    class USpringArmComponent* SpringArmFace_Esquie;                                  // 0x06D8 (size: 0x8)
    double esquie_inflate;                                                            // 0x06E0 (size: 0x8)
    bool Sequencer_CollideWithEnvironment;                                            // 0x06E8 (size: 0x1)
    bool Sequencer_ForceCollisionUpdate;                                              // 0x06E9 (size: 0x1)

    void SetSequencer_ForceCollisionUpdate(bool NewValue);
    void SetSequencer_CollideWithEnvironment(bool NewValue);
    void UpdateCharacterVisualAlterationElements();
    void ReceiveTick(float DeltaSeconds);
    void BndEvt__BP_CineCharacter_Main_LiveLinkComponentController_K2Node_ComponentBoundEvent_0_LiveLinkTickDelegate__DelegateSignature(float DeltaTime);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Cine_Esquie(int32 EntryPoint);
}; // Size: 0x6EA

#endif
