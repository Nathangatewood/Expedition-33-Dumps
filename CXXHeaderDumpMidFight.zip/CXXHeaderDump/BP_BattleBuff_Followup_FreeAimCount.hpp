#ifndef UE4SS_SDK_BP_BattleBuff_Followup_FreeAimCount_HPP
#define UE4SS_SDK_BP_BattleBuff_Followup_FreeAimCount_HPP

class UBP_BattleBuff_Followup_FreeAimCount_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 FreeAimCount;                                                               // 0x0160 (size: 0x4)

    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Followup_FreeAimCount(int32 EntryPoint);
}; // Size: 0x164

#endif
