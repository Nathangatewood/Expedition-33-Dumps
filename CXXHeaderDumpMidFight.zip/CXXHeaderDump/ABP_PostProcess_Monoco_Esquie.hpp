#ifndef UE4SS_SDK_ABP_PostProcess_Monoco_Esquie_HPP
#define UE4SS_SDK_ABP_PostProcess_Monoco_Esquie_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_88;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_89;                                                          // 0x000C (size: 0x8)
    class UBlendProfile* __BlendProfile_90;                                           // 0x0018 (size: 0x8)
    class UCurveFloat* __CurveFloat_91;                                               // 0x0020 (size: 0x8)
    bool __BoolProperty_92;                                                           // 0x0028 (size: 0x1)
    EAlphaBlendOption __EnumProperty_93;                                              // 0x0029 (size: 0x1)
    EBlendListTransitionType __EnumProperty_94;                                       // 0x002A (size: 0x1)
    TArray<float> __ArrayProperty_95;                                                 // 0x0030 (size: 0x10)
    FAnimNodeFunctionRef __StructProperty_96;                                         // 0x0040 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0060 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00E0 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_21;        // 0x00F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_20;        // 0x0128 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_19;        // 0x0158 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_18;        // 0x0188 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x01B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x01E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_17;        // 0x0218 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x0248 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x0278 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool;        // 0x02A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x02D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0308 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0338 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_16;        // 0x0368 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_15;        // 0x0398 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_14;        // 0x03C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_13;        // 0x03F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_12;        // 0x0428 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_11;        // 0x0458 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_10;        // 0x0488 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_9;         // 0x04B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_8;         // 0x04E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_7;         // 0x0518 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_6;         // 0x0548 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_5;         // 0x0578 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_4;         // 0x05A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_3;         // 0x05D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_2;         // 0x0608 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_1;         // 0x0638 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics;           // 0x0668 (size: 0x30)

}; // Size: 0x698

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    bool __BoolProperty;                                                              // 0x0001 (size: 0x1)

}; // Size: 0x2

class UABP_PostProcess_Monoco_Esquie_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x2)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0380 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0388 (size: 0x8)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_21;                             // 0x0390 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_20;                             // 0x08B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_19;                             // 0x0DD0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_18;                             // 0x12F0 (size: 0x520)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x1810 (size: 0xB8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x18C8 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_17;                             // 0x18F0 (size: 0x520)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x1E10 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x1E90 (size: 0x28)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0x1EB8 (size: 0x48)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x1F00 (size: 0x28)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x1F28 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x1F48 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_16;                             // 0x1F70 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_15;                             // 0x2490 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_14;                             // 0x29B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_13;                             // 0x2ED0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12;                             // 0x33F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;                             // 0x3910 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;                             // 0x3E30 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;                              // 0x4350 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;                              // 0x4870 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;                              // 0x4D90 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;                              // 0x52B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;                              // 0x57D0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;                              // 0x5CF0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;                              // 0x6210 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;                              // 0x6730 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_1;                              // 0x6C50 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;                                // 0x7170 (size: 0x520)
    bool ShouldDisablePostProcess;                                                    // 0x7690 (size: 0x1)
    double AlphaTransition;                                                           // 0x7698 (size: 0x8)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void OnPhotoModeExited();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void BlueprintBeginPlay();
    void ExecuteUbergraph_ABP_PostProcess_Monoco_Esquie(int32 EntryPoint);
}; // Size: 0x76A0

#endif
