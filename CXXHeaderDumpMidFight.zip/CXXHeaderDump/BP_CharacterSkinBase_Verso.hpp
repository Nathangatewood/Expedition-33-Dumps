#ifndef UE4SS_SDK_BP_CharacterSkinBase_Verso_HPP
#define UE4SS_SDK_BP_CharacterSkinBase_Verso_HPP

class ABP_CharacterSkinBase_Verso_C : public ABP_CharacterSkinBase_C
{
    class USkeletalMeshComponent* Mustache_Verso_skl;                                 // 0x03A0 (size: 0x8)
    class USkeletalMeshComponent* Beard_Verso_skl;                                    // 0x03A8 (size: 0x8)

}; // Size: 0x3B0

#endif
