#ifndef UE4SS_SDK_BP_Battle_SkillScript_New11_MezzoForte_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_New11_MezzoForte_HPP

class ABP_Battle_SkillScript_New11_MezzoForte_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript_New11_MezzoForte(int32 EntryPoint);
}; // Size: 0x310

#endif
