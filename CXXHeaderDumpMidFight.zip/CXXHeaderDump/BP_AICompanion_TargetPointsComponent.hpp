#ifndef UE4SS_SDK_BP_AICompanion_TargetPointsComponent_HPP
#define UE4SS_SDK_BP_AICompanion_TargetPointsComponent_HPP

class UBP_AICompanion_TargetPointsComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<FVector> TargetPoints;                                                     // 0x00A8 (size: 0x10)
    bool ShouldUpdatePointsBasedOnDistance;                                           // 0x00B8 (size: 0x1)
    TMap<ABP_Pawn_AICompanion_C*, int32> AcquiredPointsByCompanions;                  // 0x00C0 (size: 0x50)
    class ABP_Pawn_AICompanion_C* Companion;                                          // 0x0110 (size: 0x8)

    bool Editor_DrawDebugShapes();
    bool Editor_GetDebugShapes(TArray<FEditorDebugShape_Arrow>& Arrows, TArray<FEditorDebugShape_Arrow>& Lines);
    void FindBestPointBasedOnDistance(class ABP_Pawn_AICompanion_C* Companion, TArray<int32>& ForbiddenIndexes, int32& Index);
    void UpdatePointsBasedOnDistance();
    void ComputeTargetPoint(FVector LocalPoint, FVector& Result);
    void SearchNextAvailablePointIndex(int32& Index);
    void TryAcquireNextPoint(class ABP_Pawn_AICompanion_C* Companion, FVector& Point, bool& Success);
    int32 GetTotalNumberOfPoints();
    void HasAnyPointAvailable(bool& Result);
    void ReleaseAllPoints();
    void ReleasePoint(class ABP_Pawn_AICompanion_C* Companion);
    void GetOrTryAcquirePoint(class ABP_Pawn_AICompanion_C* Companion, FVector& Point, bool& Success);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_AICompanion_TargetPointsComponent(int32 EntryPoint);
}; // Size: 0x118

#endif
