#ifndef UE4SS_SDK_BP_DA_IWD_data_HPP
#define UE4SS_SDK_BP_DA_IWD_data_HPP

class UBP_DA_IWD_data_C : public UPrimaryDataAsset
{
    TArray<FS_DialogueLine> Lines;                                                    // 0x0030 (size: 0x10)

}; // Size: 0x40

#endif
