#ifndef UE4SS_SDK_BP_AudioControlSystem_HPP
#define UE4SS_SDK_BP_AudioControlSystem_HPP

class UBP_AudioControlSystem_C : public UExtendedObject
{
    bool IsInMainMenu;                                                                // 0x0028 (size: 0x1)
    class USoundControlBusMix* LastActivatedExplorationControlBusMix;                 // 0x0030 (size: 0x8)
    TArray<USoundClass*> SC_SFX_CineExplo;                                            // 0x0038 (size: 0x10)
    TArray<USoundClass*> SC_SFX_Combat;                                               // 0x0048 (size: 0x10)
    TArray<USoundClass*> SC_VO_CineExplo;                                             // 0x0058 (size: 0x10)
    TArray<USoundClass*> SC_VO_Combat;                                                // 0x0068 (size: 0x10)
    TArray<USoundClass*> SC_SharedAssets;                                             // 0x0078 (size: 0x10)

    void OnPhotoModeExited();
    void OnPhotoModeEntered();
    void OnDialogueBattleFinished();
    void OnDialogueBattleStarted();
    void GetLastActivatedExplorationControlBusMix(class USoundControlBusMix*& ControlBusMix);
    void DeactivateExplorationControlBusMix(class USoundControlBusMix* Mix);
    void ActivateExplorationControlBusMix(class USoundControlBusMix* Mix);
    void ActivateBusMixForMainMenu();
    void OnChangeMapProcessFinished(FName LevelDestination);
    void OnChangeMapProcessStarted(FName LevelDestination);
    void RegisterBusMixEvents();
    void ApplyAudioSettings();
    void ResetBusMixStates();
    void ApplySoundUserSettings();
    void OnDocumentActorClosed();
    void OnDocumentActorOpened();
    void OnSavePointMenuClosed();
    void OnSavePointMenuOpened();
    void OnPauseMenuClosed();
    void OnPauseMenuOpened();
    void OnMainMenuClosed();
    void OnMainMenuOpened();
    void OnInWorldDialogueFinished();
    void OnInWorldDialogueStarted();
    void OnDialogueFinished(class ABP_Dialogue_C* Dialogue);
    void OnDialogueStarted(class ABP_Dialogue_C* Dialogue);
    void OnCinematicFinishedEvent();
    void OnCinematicStartedEvent();
    void RegisterGameInstanceEvents();
    void RegisterControllerEvents();
    void RegisterDialogueEvents();
    void RegisterCinematicEvents();
}; // Size: 0x88

#endif
