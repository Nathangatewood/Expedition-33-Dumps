#ifndef UE4SS_SDK_BP_FL_StringManipulationHelpers_HPP
#define UE4SS_SDK_BP_FL_StringManipulationHelpers_HPP

class UBP_FL_StringManipulationHelpers_C : public UBlueprintFunctionLibrary
{

    FString GetCurrentTimeAsString(class UObject* __WorldContext);
    void Get Elapsed Time As Text(double Time, class UObject* __WorldContext, FText& Text);
    void MergeStringArray(TArray<FString>& StringArray, FString Separator, class UObject* __WorldContext, FString& Result);
    FString AppendFillString(FString String, int32 Count, FString Filler, class UObject* __WorldContext);
    void CreateFillString(int32 Count, FString Filler, class UObject* __WorldContext, FString& Result);
    void PadString(FString String, int32 Count, FString Filler, class UObject* __WorldContext, FString& Result);
}; // Size: 0x28

#endif
