#ifndef UE4SS_SDK_BP_FL_GPE_Helpers_HPP
#define UE4SS_SDK_BP_FL_GPE_Helpers_HPP

class UBP_FL_GPE_Helpers_C : public UBlueprintFunctionLibrary
{

    void ForceEvaluateAllConditionCheckers(class AActor* Actor, class UObject* __WorldContext);
    void ProcessGPEs(FGPEInterfacesReferences GPEs, class UObject* Activator, bool ShouldActivateGPEs, bool Instant, class UObject* __WorldContext);
    void PrintRemainingChestsInCurrentLevel(class UObject* __WorldContext);
    bool CanBeDeactivated(TScriptInterface<class IBPI_GPE_Interface_C> GPE, class UObject* __WorldContext);
    bool CanBeActivated(TScriptInterface<class IBPI_GPE_Interface_C> GPE, class UObject* __WorldContext);
    bool IsDeactivated(TScriptInterface<class IBPI_GPE_Interface_C> GPE, class UObject* __WorldContext);
    bool IsActivated(TScriptInterface<class IBPI_GPE_Interface_C> GPE, class UObject* __WorldContext);
}; // Size: 0x28

#endif
