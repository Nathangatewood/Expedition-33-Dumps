#ifndef UE4SS_SDK_AN_Ono_HPP
#define UE4SS_SDK_AN_Ono_HPP

class UAN_Ono_C : public UAnimNotify
{
    TEnumAsByte<EInWorldAudioContainerComponents::Type> AttachToComponentInWorld;     // 0x0038 (size: 0x1)
    TEnumAsByte<EOnoType::Type> OnoType;                                              // 0x0039 (size: 0x1)
    double PercentageChanceToTrigger;                                                 // 0x0040 (size: 0x8)
    class UBP_DataAsset_CharacterExplorationAudioProfile_C* Audio Profile Asset;      // 0x0048 (size: 0x8)
    class USoundAttenuation* AttnEnmOverrideBattleHitByCommonEvent;                   // 0x0050 (size: 0x8)

    void PlayEnmOnoInBattle(class UObject* Owner);
    void PlayMcOnoFromData(class USceneComponent* AttachToComponent, const FS_OnoSoundData& OnoSoundData);
    void PlayMcOnoInBattle(class ABP_jRPG_Character_Battle_Base_C* Owner);
    void PlayMcOnoInWorld(class ABP_jRPG_Character_World_C* BPReference, class UObject* Owner);
    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x58

#endif
