#ifndef UE4SS_SDK_AN_BattleDeathCommon_HPP
#define UE4SS_SDK_AN_BattleDeathCommon_HPP

class UAN_BattleDeathCommon_C : public UAnimNotify
{
    class USoundAttenuation* AttnOverrideBattleDeathCommon;                           // 0x0038 (size: 0x8)

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x40

#endif
