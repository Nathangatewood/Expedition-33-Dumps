#ifndef UE4SS_SDK_BP_CharacterSkinBase_Maelle_HPP
#define UE4SS_SDK_BP_CharacterSkinBase_Maelle_HPP

class ABP_CharacterSkinBase_Maelle_C : public ABP_CharacterSkinBase_C
{
}; // Size: 0x3A0

#endif
