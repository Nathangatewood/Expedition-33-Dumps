#ifndef UE4SS_SDK_BP_Battle_SkillScript_StandardSkill_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_StandardSkill_HPP

class ABP_Battle_SkillScript_StandardSkill_C : public ABP_Battle_SkillScript_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0300 (size: 0x8)

    void GetTargetCharactersForSequence(TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedCharacters);
    void StandardSkillExecution(class ULevelSequence* SkillSequence, bool SequenceLookAtTarget, bool SnapOnTarget, bool ShouldDashIn, bool ShouldDashBack, double DashInDistanceStop, class UAnimMontage* OverrideDashBackAnim, class UAnimMontage* OverrideDashInAnim, FText ToolTipText, double UsedInitiative, bool ForceEnableCameraMovement);
    void StandardItemExecution(class UAnimMontage* AnimMontageOverride);
    void OnStandardSkillDashInCompleted();
    void OnSequenceCompleted();
    void OnSequenceStartedWithoutDashIn();
    void ExecuteUbergraph_BP_Battle_SkillScript_StandardSkill(int32 EntryPoint);
}; // Size: 0x308

#endif
