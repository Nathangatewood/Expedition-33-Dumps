#ifndef UE4SS_SDK_BlueprintSorting_HPP
#define UE4SS_SDK_BlueprintSorting_HPP

#include "BlueprintSorting_enums.hpp"

class UBlueprintSortingHelperLibrary : public UBlueprintFunctionLibrary
{

    void TestTwoItems(int32& TargetItem1, int32& TargetItem2);
    void TestThreeItems(int32& TargetItem1, int32& TargetItem2, int32& TargetItem3);
    void TestItem(int32& TargetItem);
    void SwapItems(const TArray<int32>& TargetArray, int32& index1, int32& index2);
    bool LessThanOrEqualArrayLength(const TArray<int32>& TargetArray, int32& Index);
    int32 Increment(int32 ToIncrement);
    bool GreaterThanOrEqualArrayLength(const TArray<int32>& TargetArray, int32& Index);
}; // Size: 0x28

class UOrderingResult : public UObject
{
    ESortOrdering Result;                                                             // 0x0028 (size: 0x1)

    void SetForTexts(const FText& A, const FText& B);
    void SetForStrings(FString A, FString B);
    void SetForInts(int32 A, int32 B);
    void SetForInt(int32 R);
    void SetForFloat(float R, float Epsilon);
    class UOrderingResult* MakeOrderingResult();
    bool IsFirstAfterSecond(class UOrderingResult* OrderingResult, ESortDirection SortDirection);
}; // Size: 0x30

#endif
