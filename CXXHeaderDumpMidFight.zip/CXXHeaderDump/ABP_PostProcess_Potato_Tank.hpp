#ifndef UE4SS_SDK_ABP_PostProcess_Potato_Tank_HPP
#define UE4SS_SDK_ABP_PostProcess_Potato_Tank_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_85;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_86;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_87;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_16;        // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_15;        // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_14;        // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_13;        // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_12;        // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_11;        // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_10;        // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_9;         // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_8;         // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_7;         // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_6;         // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_5;         // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_4;         // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_3;         // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_2;         // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_1;         // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics;           // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_7;        // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_6;        // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_5;        // 0x0520 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_4;        // 0x0550 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x0580 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x05B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x05E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x0610 (size: 0x30)

}; // Size: 0x640

class UABP_PostProcess_Potato_Tank_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x03A8 (size: 0xB8)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0460 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0480 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_16;                             // 0x04A0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_15;                             // 0x09C0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_14;                             // 0x0EE0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_13;                             // 0x1400 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12;                             // 0x1920 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;                             // 0x1E40 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;                             // 0x2360 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;                              // 0x2880 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;                              // 0x2DA0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;                              // 0x32C0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;                              // 0x37E0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;                              // 0x3D00 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;                              // 0x4220 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;                              // 0x4740 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;                              // 0x4C60 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_1;                              // 0x5180 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;                                // 0x56A0 (size: 0x520)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7;                            // 0x5BC0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6;                            // 0x6360 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5;                            // 0x6B00 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4;                            // 0x72A0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0x7A40 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0x81E0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0x8980 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0x9120 (size: 0x7A0)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void ExecuteUbergraph_ABP_PostProcess_Potato_Tank(int32 EntryPoint);
}; // Size: 0x98C0

#endif
