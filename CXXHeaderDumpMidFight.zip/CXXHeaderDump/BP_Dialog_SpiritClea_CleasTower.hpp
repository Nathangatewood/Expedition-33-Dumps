#ifndef UE4SS_SDK_BP_Dialog_SpiritClea_CleasTower_HPP
#define UE4SS_SDK_BP_Dialog_SpiritClea_CleasTower_HPP

class ABP_Dialog_SpiritClea_CleasTower_C : public ABP_Dialogue_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0338 (size: 0x8)
    FItemDataTableRowHandle RewardCleaTower;                                          // 0x0340 (size: 0x10)

    void StartDialog();
    void ExecuteUbergraph_BP_Dialog_SpiritClea_CleasTower(int32 EntryPoint);
}; // Size: 0x350

#endif
