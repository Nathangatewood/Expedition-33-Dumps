#ifndef UE4SS_SDK_BP_BattleBuff_RemoveItselfAtAnotherCharacterTurn_HPP
#define UE4SS_SDK_BP_BattleBuff_RemoveItselfAtAnotherCharacterTurn_HPP

class UBP_BattleBuff_RemoveItselfAtAnotherCharacterTurn_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    bool ShouldPlayTooltip;                                                           // 0x0160 (size: 0x1)

    void ShouldKeepOnDeath(bool& Keep);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_RemoveItselfAtAnotherCharacterTurn(int32 EntryPoint);
}; // Size: 0x161

#endif
