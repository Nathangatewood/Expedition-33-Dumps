#ifndef UE4SS_SDK_BP_DataAsset_ProjectConfiguration_HPP
#define UE4SS_SDK_BP_DataAsset_ProjectConfiguration_HPP

class UBP_DataAsset_ProjectConfiguration_C : public UProjectConfiguration
{
    TSoftObjectPtr<class UWorld> DemoLevel;                                           // 0x0038 (size: 0x28)
    TSoftObjectPtr<class UWorld> NewGameLevel;                                        // 0x0060 (size: 0x28)
    FGameplayTag NewGameSpawnPoint;                                                   // 0x0088 (size: 0x8)
    TSoftObjectPtr<class UWorld> MainMenuLevel;                                       // 0x0090 (size: 0x28)
    class UDataTable* DT_CharacterSideQuestUnlock;                                    // 0x00B8 (size: 0x8)
    class UDataTable* DT_MainPath_DialoguesAndCutscenes;                              // 0x00C0 (size: 0x8)
    class UDataTable* DT_Camp_OptionalGameActions;                                    // 0x00C8 (size: 0x8)

    void GetNewGameSpawnPointTag(const FGameplayTag& SpawnPointTag);
    void GetMainMenuLevel(TSoftObjectPtr<class UWorld>& MainMenuLevel);
    void GetNewGameLevel(const TSoftObjectPtr<class UWorld>& LevelDestination);
}; // Size: 0xD0

#endif
