#ifndef UE4SS_SDK_BP_BattleDamages_HPP
#define UE4SS_SDK_BP_BattleDamages_HPP

class UBP_BattleDamages_C : public USF_ExtendedUserWidget
{
    double CurrentInputDamages_Base;                                                  // 0x02E0 (size: 0x8)
    bool IsFinalDamageInitialized;                                                    // 0x02E8 (size: 0x1)
    class UAC_jRPG_CharacterBattleStats_C* SourceCharacter;                           // 0x02F0 (size: 0x8)
    class UAC_jRPG_CharacterBattleStats_C* TargetCharacter;                           // 0x02F8 (size: 0x8)
    bool logEnabled;                                                                  // 0x0300 (size: 0x1)
    bool IgnoreTargetDefense;                                                         // 0x0301 (size: 0x1)
    TEnumAsByte<EAttackType::Type> InputAttackElement;                                // 0x0302 (size: 0x1)
    TEnumAsByte<EAttackType::Type> FinalAttackElement;                                // 0x0303 (size: 0x1)
    bool IsCriticalHit;                                                               // 0x0304 (size: 0x1)
    TEnumAsByte<EDamageReason::Type> DamageReason;                                    // 0x0305 (size: 0x1)
    FVector DamageWorldLocation;                                                      // 0x0308 (size: 0x18)
    double DamageBaseBeforeTargetHPClamp;                                             // 0x0320 (size: 0x8)
    TEnumAsByte<EElementalAffinity::Type> BaseTypeAffinity;                           // 0x0328 (size: 0x1)
    class UWBP_Debug_BattleDamageDetails_C* DEBUG_LogWidget;                          // 0x0330 (size: 0x8)
    double InputDamageMultiplier;                                                     // 0x0338 (size: 0x8)
    double CriticalRoll;                                                              // 0x0340 (size: 0x8)
    TArray<FFDamageModifier> ActiveModifiers;                                         // 0x0348 (size: 0x10)
    TEnumAsByte<EDamageValueState::Type> ValueState_AttackElement;                    // 0x0358 (size: 0x1)
    TEnumAsByte<EDamageValueState::Type> ValueState_CriticalHitRoll;                  // 0x0359 (size: 0x1)
    bool FinalLock;                                                                   // 0x035A (size: 0x1)
    bool IsAbsorbedByShield;                                                          // 0x035B (size: 0x1)
    double ExtraCriticalHitChance;                                                    // 0x0360 (size: 0x8)
    double ExtraCriticalHitDamageMultiplier;                                          // 0x0368 (size: 0x8)
    double BreakBarDamageMultiplier;                                                  // 0x0370 (size: 0x8)
    class UBP_BattleDamageBuilder_C* SourceDamageBuilder;                             // 0x0378 (size: 0x8)
    TEnumAsByte<EMissReason::Type> MissReason;                                        // 0x0380 (size: 0x1)
    double FinalDamageLimit;                                                          // 0x0388 (size: 0x8)

    double GetInputFinalDamageMultiplier();
    void NewFunction();
    void SetFinalDamageLimit(double DamageLimit, FString DebugReason);
    TEnumAsByte<EMissReason::Type> GetMissReason();
    void SetMissReason(TEnumAsByte<EMissReason::Type> MissReason);
    bool IsDeathtouch();
    void CheckEditableValue:Modify(TEnumAsByte<EDamageValueState::Type> Selection, FString ValueName, FString ChangeReason, bool& Allowed);
    void AddCriticalHitExtraChance(double Chance: 0.0-1.0, FString DebugReason);
    void CheckEditableValue_GetFinalValue(TEnumAsByte<EDamageValueState::Type> Selection, bool& Allowed);
    void GetAffinityType(TEnumAsByte<EElementalAffinity::Type>& BaseTypeAffinity);
    void GetDamageSourceObject(TScriptInterface<class IIBattleDamageSource_C>& SourceObject);
    void SetIgnoreShields();
    void SetIgnoreMarkedRemoval();
    bool GetIgnoreMarkedRemoval();
    class USoundBase* GetHitSoundOverride();
    void GetFeedbackReason(bool& HasFeedback, FText& FeedbackReasonText, FLinearColor& FeedbackReasonColor);
    void ApplyDeathtouch();
    void OverrideWithEffectiveDamage(double FinalDamage);
    void ApplyCommonDamageMultipliers();
    int64 GetFinalBreakBarDamageAmount();
    double GetBreakBarDamageMultiplier();
    void AddBreakBarDamageMultiplier(double Multiplier, FString Reason);
    bool TryRollEnemyDodgeFromStats();
    void LoadFromBuilder(class UBP_BattleDamageBuilder_C* Builder);
    void SetAbsorbedByShield();
    void ApplyCriticalHitModifiers(bool& IsCriticalHit);
    void ApplyAffinitiesModifiers();
    void TryAddLog(const FText& Reason, double PreviousValue, double NewValue, const TArray<FText>& TargetArray);
    void AddModifierInternal(const FFDamageModifier& Modifier);
    void AddDamageModifier(const FFDamageModifier& Modifier);
    double CalculateDefense(double AttackPower, double Defense);
    void CheckValidReason(FText Reason, FString Context);
    double GetInputDamageMultiplier();
    void ModifyFloatRef(double& TargetVariable, double NewValue, FString VarName, FText Reason);
    void NotifyListeners();
    void LogModifier(FText Text);
    void GetInputBaseElement(TEnumAsByte<EAttackType::Type>& InputAttackType);
    void ApplyActiveModifiers();
    void ComputeDamageModifiers(TArray<FFDamageModifier>& Modifiers, double InputBase, double& base, TArray<FText>& DamageLogs);
    void AddAttackPowerModifier(const FFDamageModifier& Modifier);
    void GetCriticalRollToBeat(double& Value);
    void ModifyBaseDamageElement(TEnumAsByte<EAttackType::Type> NewAttackType, FText Reason);
    void GetIsResistant(bool& IsResistant);
    void GetIsWeakness(bool& IsWeakness);
    void GetIsCriticalHit(bool& IsCritical);
    void SetIsCriticalHit(bool IsCritical, FString DebugReason);
    void GetTargetCharacter(class UAC_jRPG_CharacterBattleStats_C*& NewParam);
    void GetFinalBaseElement(TEnumAsByte<EAttackType::Type>& AttackElement);
    void GetSourceCharacter(class UAC_jRPG_CharacterBattleStats_C*& SourceCharacter);
    void GetInputDamages_Base(double& RawDamages);
    void GetInputDamages(double& RawDamages);
    void GetIgnoreTargetDefense(bool& IgnoreTargetDefense);
    void GetFinalDamages_Base(double& FinalDamages);
    void Set Ignore Target Defense(bool Ignore);
    void PrintMessage(FText Message);
    void PrintError(FText Message);
    void GetFinalDamages(double& FinalDamages);
    void Finish();
    void Cancel(TEnumAsByte<EMissReason::Type> MissReason, FString DebugReason);
    void ApplyTargetClampAndRounding();
    void ApplyDebugOverrides();
    void ApplyStraightDamages(double StraightDamage);
    void ApplyClamp();
    void InitFinalDamages();
    void ApplyDefense();
    void InitAffinities();
    void SetAffinities(TEnumAsByte<EElementalAffinity::Type> BaseTypeAffinity);
    void ProcessBaseElement();
    void RollCriticalHit(bool& IsCriticalHit);
    void Init();
}; // Size: 0x390

#endif
