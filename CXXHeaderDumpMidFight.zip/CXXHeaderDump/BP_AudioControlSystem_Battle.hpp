#ifndef UE4SS_SDK_BP_AudioControlSystem_Battle_HPP
#define UE4SS_SDK_BP_AudioControlSystem_Battle_HPP

class UBP_AudioControlSystem_Battle_C : public UExtendedObject
{
    TEnumAsByte<ECharacterTeamSelector::Type> LastTurnStartTeam;                      // 0x0028 (size: 0x1)
    FSoundEventDataTableRowHandle SoundEvent_TurnStart_Ally;                          // 0x0030 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_TurnStart_Enemy;                         // 0x0040 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_BattleStart;                             // 0x0050 (size: 0x10)
    bool PlayerIsInBattle;                                                            // 0x0060 (size: 0x1)
    TArray<USoundClass*> SC_SharedAssets;                                             // 0x0068 (size: 0x10)

    void OnCounterAttackEnd();
    void OnCounterAttackStart();
    void OnBattleEnd();
    void OnBattleStart();
    void OnCharacterActionEnd(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterActionStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
}; // Size: 0x78

#endif
