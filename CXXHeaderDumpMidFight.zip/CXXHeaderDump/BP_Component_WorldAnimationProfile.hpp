#ifndef UE4SS_SDK_BP_Component_WorldAnimationProfile_HPP
#define UE4SS_SDK_BP_Component_WorldAnimationProfile_HPP

class UBP_Component_WorldAnimationProfile_C : public UActorComponent
{
    FS_AnimationProfile_Skins AnimationProfile;                                       // 0x00A0 (size: 0x90)

    void SetAnimationProfileAndUpdateFromSkeletalMeshComponent(FS_AnimationProfile_Skins AnimationProfile, class USkeletalMeshComponent* SkeletalMeshComponent);
    void SetAnimationProfileAndUpdate(FS_AnimationProfile_Skins AnimationProfile);
}; // Size: 0x130

#endif
