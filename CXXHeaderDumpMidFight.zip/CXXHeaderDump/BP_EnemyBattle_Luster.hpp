#ifndef UE4SS_SDK_BP_EnemyBattle_Luster_HPP
#define UE4SS_SDK_BP_EnemyBattle_Luster_HPP

class ABP_EnemyBattle_Luster_C : public ABP_jRPG_Enemy_Battle_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x1638 (size: 0x8)
    class UBoxComponent* FreeAimTargetBox_FootL;                                      // 0x1640 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart_FootL;                        // 0x1648 (size: 0x8)
    class UBoxComponent* FreeAimTargetBox_FootR;                                      // 0x1650 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart_FootR;                        // 0x1658 (size: 0x8)
    class UBoxComponent* FreeAimTargetBox_ArmL;                                       // 0x1660 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart_armL;                         // 0x1668 (size: 0x8)
    class UBoxComponent* FreeAimTargetBox_ArmR;                                       // 0x1670 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart_armR;                         // 0x1678 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x1680 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart_head;                         // 0x1688 (size: 0x8)
    class UNiagaraComponent* Trail_Head;                                              // 0x1690 (size: 0x8)
    class UNiagaraComponent* Trail_Arm_R;                                             // 0x1698 (size: 0x8)
    class UNiagaraComponent* Trail_Foot_L;                                            // 0x16A0 (size: 0x8)
    class UNiagaraComponent* Trail_Foot_R;                                            // 0x16A8 (size: 0x8)
    class UNiagaraComponent* Trail_Arm_L1;                                            // 0x16B0 (size: 0x8)
    class UNiagaraComponent* Trail_Arm_L;                                             // 0x16B8 (size: 0x8)
    class UNiagaraComponent* Trail_Arm_R1;                                            // 0x16C0 (size: 0x8)
    class UCapsuleComponent* Capsule1;                                                // 0x16C8 (size: 0x8)
    float Timeline_freeAimHitLegsArms_GlowTrack_1A13DA93478AA31AD17301B1A9777AC5;     // 0x16D0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_freeAimHitLegsArms__Direction_1A13DA93478AA31AD17301B1A9777AC5; // 0x16D4 (size: 0x1)
    class UTimelineComponent* Timeline_freeAimHitLegsArms;                            // 0x16D8 (size: 0x8)
    float GlowTimeline_GlowTrack_F8C4416A4B8BE6FDA5D48FB4F66084BB;                    // 0x16E0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> GlowTimeline__Direction_F8C4416A4B8BE6FDA5D48FB4F66084BB; // 0x16E4 (size: 0x1)
    class UTimelineComponent* GlowTimeline;                                           // 0x16E8 (size: 0x8)
    TEnumAsByte<E_LusterCombatMode::Type> CurrentMode;                                // 0x16F0 (size: 0x1)
    class UAnimMontage* AM_ChangingCombatMode;                                        // 0x16F8 (size: 0x8)
    FFElementalTypes MortalModeAffinity;                                              // 0x1700 (size: 0x20)
    FFElementalTypes FuryModeAffinity;                                                // 0x1720 (size: 0x20)
    FFElementalTypes DefenseModeAffinity;                                             // 0x1740 (size: 0x20)
    FFElementalTypes NoModeAffinity;                                                  // 0x1760 (size: 0x20)
    int32 DefenseModeCounter;                                                         // 0x1780 (size: 0x4)
    int32 MortalModeCounter;                                                          // 0x1784 (size: 0x4)
    int32 FuryModeCounter;                                                            // 0x1788 (size: 0x4)
    int32 EnterFury/MortalModeValue;                                                  // 0x178C (size: 0x4)
    int32 EnterDefenseModeValue;                                                      // 0x1790 (size: 0x4)
    FVector StartLocCache;                                                            // 0x1798 (size: 0x18)
    FVector FuryLocationBeforeDash;                                                   // 0x17B0 (size: 0x18)
    class UAnimMontage* HitReac;                                                      // 0x17C8 (size: 0x8)
    TMap<TEnumAsByte<E_LusterCombatMode::Type>, UMaterialInstance*> Current_Material_Top; // 0x17D0 (size: 0x50)
    TMap<TEnumAsByte<E_LusterCombatMode::Type>, UMaterialInstance*> Current_Material_Bottom; // 0x1820 (size: 0x50)
    class UMaterialInstance* Previous_Material_Top;                                   // 0x1870 (size: 0x8)
    class UMaterialInstance* Previous_Material_Bottom;                                // 0x1878 (size: 0x8)
    bool IsEnraged;                                                                   // 0x1880 (size: 0x1)
    class ABP_EpicBattleSequenceActor_C* Epic Sequence;                               // 0x1888 (size: 0x8)
    class UMaterialInstanceDynamic* Material;                                         // 0x1890 (size: 0x8)
    FLinearColor GlowColorCache;                                                      // 0x1898 (size: 0x10)
    FLinearColor GlowColorHitSign;                                                    // 0x18A8 (size: 0x10)
    FLinearColor GlowColorBase;                                                       // 0x18B8 (size: 0x10)
    FLinearColor GlowColorEnraged;                                                    // 0x18C8 (size: 0x10)
    FVector MoveTo_Preview_Start;                                                     // 0x18D8 (size: 0x18)
    FVector MoveTo_Preview_End;                                                       // 0x18F0 (size: 0x18)
    class UAnimMontage* DashOut;                                                      // 0x1908 (size: 0x8)
    FFSoundEvent SD_Luster_DashOut;                                                   // 0x1910 (size: 0x8)
    class ABP_EpicBattleSequenceActor_C* CurrentBattleSequence;                       // 0x1918 (size: 0x8)
    bool ApplyBurn;                                                                   // 0x1920 (size: 0x1)
    bool 4HitCombo;                                                                   // 0x1921 (size: 0x1)
    int32 Target Index;                                                               // 0x1924 (size: 0x4)
    double TrailGlow;                                                                 // 0x1928 (size: 0x8)
    double UnleashFuryGlowValue;                                                      // 0x1930 (size: 0x8)
    FFRoutedEventHandle Skill Handle_3HitCombo;                                       // 0x1938 (size: 0x20)
    FFRoutedEventHandle Skill Handle_UnleashFury;                                     // 0x1958 (size: 0x20)
    class ULevelSequence* MeleeComboSequence_Standard;                                // 0x1978 (size: 0x8)
    class ULevelSequence* MeleeComboSequence_Alpha;                                   // 0x1980 (size: 0x8)
    double MeleeComboMoveToDistance_Standard;                                         // 0x1988 (size: 0x8)
    bool IsAlpha;                                                                     // 0x1990 (size: 0x1)
    double MeleeComboMoveToDistance_Alpha;                                            // 0x1998 (size: 0x8)
    FFRoutedEventHandle Skill Handle_Growl;                                           // 0x19A0 (size: 0x20)
    FFRoutedEventHandle Skill Handle_DashAOE;                                         // 0x19C0 (size: 0x20)
    int32 BurnStackTeamCount;                                                         // 0x19E0 (size: 0x4)
    bool UseComboLongSequence;                                                        // 0x19E4 (size: 0x1)
    bool ActivateFreeAimWeakspotOnLegsAndArmes;                                       // 0x19E5 (size: 0x1)

    FVector ThirdTarget();
    FVector FirstTarget();
    FVector SecondTarget();
    void UserConstructionScript();
    void GlowTimeline__FinishedFunc();
    void GlowTimeline__UpdateFunc();
    void Timeline_freeAimHitLegsArms__FinishedFunc();
    void Timeline_freeAimHitLegsArms__UpdateFunc();
    void TriggerHiddenSkills(class ABP_jRPG_Enemy_Battle_Base_C* Source, bool Enable);
    void PerformActionByAI();
    void UnleashFurry();
    void ReceiveBeginPlay();
    void GlowEvent(double GlowValue);
    void 3HitCombo();
    void Luster_Melee_HitEvent_Counter();
    void Luster_Melee_HitEvent();
    void ActivateTrail();
    void DeactivateTrail();
    void OnDeath(bool DeathByCounter);
    void DeclareCharacterSkillEvents();
    void Skill_Alpha_DashAoe();
    void Skill_Alpha_Growl();
    void GrowlActionEffect(int32 ActionEffectIndex);
    void DashAoeEffect(int32 ActionEffectIndex);
    void BndEvt__BP_EnemyBattle_Luster_BP_FreeAimTargetPart_armR_K2Node_ComponentBoundEvent_0_OnFreeAimHit__DelegateSignature(TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, class ABP_FreeAimProjectile_Base_C* Projectile);
    void BndEvt__BP_EnemyBattle_Luster_BP_FreeAimTargetPart_armL_K2Node_ComponentBoundEvent_1_OnFreeAimHit__DelegateSignature(TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, class ABP_FreeAimProjectile_Base_C* Projectile);
    void BndEvt__BP_EnemyBattle_Luster_BP_FreeAimTargetPart_FootR_K2Node_ComponentBoundEvent_2_OnFreeAimHit__DelegateSignature(TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, class ABP_FreeAimProjectile_Base_C* Projectile);
    void BndEvt__BP_EnemyBattle_Luster_BP_FreeAimTargetPart_FootL_K2Node_ComponentBoundEvent_3_OnFreeAimHit__DelegateSignature(TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, class ABP_FreeAimProjectile_Base_C* Projectile);
    void ExecuteUbergraph_BP_EnemyBattle_Luster(int32 EntryPoint);
}; // Size: 0x19E6

#endif
