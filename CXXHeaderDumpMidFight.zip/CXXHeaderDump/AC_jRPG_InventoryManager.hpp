#ifndef UE4SS_SDK_AC_jRPG_InventoryManager_HPP
#define UE4SS_SDK_AC_jRPG_InventoryManager_HPP

class UAC_jRPG_InventoryManager_C : public UExtendedActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    int32 InventorySlotsAmount;                                                       // 0x00A8 (size: 0x4)
    bool MultipleStacksAllowed?;                                                      // 0x00AC (size: 0x1)
    int32 SelectedItemSlot;                                                           // 0x00B0 (size: 0x4)
    class UBP_jRPG_GI_Custom_C* GameInstanceReference;                                // 0x00B8 (size: 0x8)
    FName ItemToUse;                                                                  // 0x00C0 (size: 0x8)
    FAC_jRPG_InventoryManager_COnAnyItemAdded OnAnyItemAdded;                         // 0x00C8 (size: 0x10)
    void OnAnyItemAdded();
    FAC_jRPG_InventoryManager_COnAnyItemRemoved OnAnyItemRemoved;                     // 0x00D8 (size: 0x10)
    void OnAnyItemRemoved();
    FAC_jRPG_InventoryManager_COnItemAdded OnItemAdded;                               // 0x00E8 (size: 0x10)
    void OnItemAdded(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, FS_LootContext LootContext);
    bool ItemInstances;                                                               // 0x00F8 (size: 0x1)
    bool ShouldDispatchModifications;                                                 // 0x00F9 (size: 0x1)
    class UDataTable* InventoryItemTypeMetadataTable;                                 // 0x0100 (size: 0x8)

    void GetItemTypeMetadata(TEnumAsByte<E_jRPG_ItemType::Type> ItemType, bool& Found, FS_InventoryItemTypeMetadata& ItemTypeMetadata);
    FGameplayTag GetNotificationPoolTagFromItemType(TEnumAsByte<E_jRPG_ItemType::Type> Index);
    void IsThereNotifiedCustomizationForCharacter(class UBP_CharacterData_C* CharacterData, bool& IsNotified);
    void IsThereNotifiedWeaponForCharacter(class UBP_CharacterData_C* CharacterData, bool& IsNotified);
    void ShouldItemBeNotified(FS_jRPG_Item_StaticData ItemData, bool& IsNotified);
    void MarkItemAsRead(FS_jRPG_Item_StaticData ItemData, class UUserWidget* Mark Caller);
    void NotifyItem(FS_jRPG_Item_StaticData ItemData);
    void ShowLootNotificationInDialogue(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, const FS_jRPG_Item_StaticData& ItemData);
    void SetShouldDispatchModifications(bool ShouldDispatch);
    void AddMissingItemsFromCharacterSave(const FS_jRPG_CharacterSaveState& CharacterSaveState);
    void ResetInventoryForNewGamePlus();
    void ResetInventory();
    void RemoveAllItemsOfType(TEnumAsByte<E_jRPG_ItemType::Type> ItemType);
    void OnItemRemovedFromInventory(FS_jRPG_Item_StaticData& ItemStaticData, int32 Amount);
    void GetPartyHealShard(FName& Row Name);
    bool CanAutoEquipConsumableShard();
    TArray<UBP_CharacterData_C*> GetCharactersForWeapon(FS_jRPG_Item_StaticData ItemStatic);
    void FindItemCountFromInventory(FName ItemHardcodedName, int32& Quantity);
    void FindItemDynamicFromInventory(FName ItemHardcodedName, bool& Found, FS_jRPG_Item_DynamicData& ItemStruct);
    bool CanAffordItemCosts(TArray<FS_ItemQuantity>& RequiredItem);
    void GetWeaponsForCharacter(class UBP_CharacterData_C* CharacterData, TArray<FS_jRPG_Item_DynamicData>& WeaponsDynamicData);
    void GetPartyHealConsumable(FName& Row Name);
    bool ShouldRefillConsumableShard(const FName& ItemToFind);
    FS_jRPG_Item_StaticData GetItemDefinitionFromID(FName ItemId, bool& Found);
    void DEBUG_ShowDebugText();
    int32 GetItemStackMaxCount(const FS_jRPG_Item_StaticData& ItemStaticData);
    void GetStacksLeftForItem(FName ItemId, bool& HasExistingStack, int32& ItemIndex, int32& StackLeft, int32& StackCount);
    void OnVendorItemSold(FName VendorID, FName ItemId, int32 Quantity);
    void GetItemDynamicFromInventory(FName ItemHardcodedName, FS_jRPG_Item_DynamicData& ItemStruct);
    void RefillConsumables();
    void GetConsumablesShards(TArray<FS_jRPG_Item_DynamicData>& FilteredArray);
    void GetConsumables(TArray<FS_jRPG_Item_DynamicData>& FilteredArray);
    void GetCharactersWithItemEquipped(FName ItemId, TArray<FFCharacterAssignedEquipment>& AssignedEquipment);
    void ShowItemsToSell(int32 SlotToFocus);
    void BuyItem(FName ItemHardcodedName, bool& Success);
    void CheckIfItemCanBeBought(FName ItemId, bool& CanBeBought);
    void CheckAmountOfItemTypeInInventory(TEnumAsByte<E_jRPG_ItemType::Type> ItemType, TEnumAsByte<E_jRPG_ItemSubtype::Type> ItemSubtype, int32& TotalAmountInInventory);
    void RefreshVendorItemDetails(bool ShowItemFromInventory);
    void GetProperVendorSlot(int32 Index);
    void ShowItemsToBuy(int32 SlotToFocus);
    void CreateReferenceToVendorWindow();
    void UnequipItem(TEnumAsByte<E_jRPG_ItemType::Type> ItemType);
    void UseItemOnCharacter(FName ItemToUse, FName CharacterHardcodedName);
    void SelectItemToUse();
    void GetProperUseItemOnCharacterSlotWidget(int32 SlotIndex);
    void RefreshUseItemOnCharacterSlots();
    void RefreshInventorySlotAfterDiscarding(int32 SlotIndex);
    void CheckAmountOfItemInInventory(FName ItemHardcodedName, int32& TotalAmountInInventory);
    void ShowDiscardWindow();
    void TrySpendGold(int32 GoldAmount, FString Reason, bool& Success);
    void ReceiveGold(int32 GoldAmount, FString Reason);
    void RefreshGoldAmount();
    void CalculateStatsComparisonOnEquip(FName ItemHardcodedName);
    void GetItemStructFromInventory(FName ItemHardcodedName, FS_jRPG_Item_StaticData& ItemStruct);
    void CheckIfCanUnequipItemToInventory(FName ItemHardcodedName, bool& Success?);
    void EquipItem_DEPRECATED(FName ItemHardcodedName);
    void EquipItem(FName ItemHardcodedName, FName CharacterName);
    void GetProperEquipmentChangeSlot(int32 SlotIndex);
    void ShowAllEquipableItems(TEnumAsByte<E_jRPG_ItemType::Type> ItemType);
    void GetAllEquipableItems(TEnumAsByte<E_jRPG_ItemType::Type> ItemType, TSet<TEnumAsByte<E_jRPG_ItemSubtype::Type>> AvailableSubtypes, TArray<FS_jRPG_Item_DynamicData>& EquipableItems);
    void RefreshItemDetails();
    void ReleaseInventorySlot(int32 InventorySlot);
    void CheckIfThereIsAmountOfItemInInventory(FName ItemHardcodedName, int32 Amount, bool& Success?);
    void RemoveItemFromInventory(FName ItemHardcodedName, int32 Amount, bool KeepEmptyStack);
    void AddItemInstanceToInventory(class UBP_ItemInstance_Base_C* ItemInstance, int32 Amount, FS_LootContext LootContext);
    void RefreshInventorySlot(int32 SlotIndex);
    void GetProperInventorySlotWidget(int32 ItemIndex);
    void RefreshAllInventorySlots();
    void CheckIfThereIsItemInInventory(FName ItemHardcodedName, bool& Success?, bool& IsItemFullyStacked?, int32& ItemIndex);
    void CheckIfThereIsFreeSlotInInventory(bool& Success?);
    void CheckIfThereIsNotFullyStackedItemInInventory(FName ItemHardcodedName, bool& Success?, int32& ItemIndex);
    void AddItemToInventory(FName ItemHardcodedName, int32 Amount, FS_LootContext LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItem);
    void GetOwnedItemsByType(TEnumAsByte<E_jRPG_ItemType::Type> ItemType, TEnumAsByte<E_jRPG_ItemSubtype::Type> ItemSubtype, bool IncludeHidden, TArray<FS_jRPG_Item_DynamicData>& FilteredArray);
    void CreateReferenceToInventoryWindow();
    void ReceiveTick(float DeltaSeconds);
    void OnInitializeComponent();
    void ExecuteUbergraph_AC_jRPG_InventoryManager(int32 EntryPoint);
    void OnItemAdded__DelegateSignature(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, FS_LootContext LootContext);
    void OnAnyItemRemoved__DelegateSignature();
    void OnAnyItemAdded__DelegateSignature();
}; // Size: 0x108

#endif
