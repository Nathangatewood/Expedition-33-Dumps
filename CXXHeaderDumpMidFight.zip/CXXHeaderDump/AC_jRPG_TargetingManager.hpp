#ifndef UE4SS_SDK_AC_jRPG_TargetingManager_HPP
#define UE4SS_SDK_AC_jRPG_TargetingManager_HPP

class UAC_jRPG_TargetingManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool TargetingEnabled?;                                                           // 0x00A8 (size: 0x1)
    bool CanTargetSelf?;                                                              // 0x00A9 (size: 0x1)
    TEnumAsByte<E_jRPG_TargetingType::Type> SelectedTargetingType;                    // 0x00AA (size: 0x1)
    TArray<ABP_jRPG_Character_Battle_Base_C*> TargetedCharacters;                     // 0x00B0 (size: 0x10)
    class UBP_jRPG_GI_Custom_C* GameInstanceReference;                                // 0x00C0 (size: 0x8)
    int32 SelectedTargetIndexWithGamepad;                                             // 0x00C8 (size: 0x4)
    bool MustSelectEnemyAfterAlly;                                                    // 0x00CC (size: 0x1)
    int32 multiTargetingPhase;                                                        // 0x00D0 (size: 0x4)
    TArray<UBP_TargetingGroup_C*> TargetGroups;                                       // 0x00D8 (size: 0x10)
    TArray<ABP_jRPG_Character_Battle_Base_C*> PreviousTargetedCharacters;             // 0x00E8 (size: 0x10)
    bool IsPretargeting;                                                              // 0x00F8 (size: 0x1)
    class ABP_jRPG_Character_Battle_Base_C* LastTarget;                               // 0x0100 (size: 0x8)
    class ABP_jRPG_Character_Battle_Base_C* PreferedNextInitialTarget;                // 0x0108 (size: 0x8)
    bool LastIsAlly;                                                                  // 0x0110 (size: 0x1)
    bool AreTargetsDirty;                                                             // 0x0111 (size: 0x1)
    class UBP_TargetingGroup_C* FocusedTargetingGroup;                                // 0x0118 (size: 0x8)
    int32 LastXNavigation;                                                            // 0x0120 (size: 0x4)
    FTimerHandle XInputCooldownTimer;                                                 // 0x0128 (size: 0x8)
    FAC_jRPG_TargetingManager_COnTargetConfirmed OnTargetConfirmed;                   // 0x0130 (size: 0x10)
    void OnTargetConfirmed();

    void SetFocusedTargetingGroup(class UBP_TargetingGroup_C* TargetingGroup);
    void ShiftTargetingGroup(int32 Offset);
    void ValidateTargetCandidates(TArray<UAC_jRPG_CharacterBattleStats_C*>& TargetCharacterStats, bool& Validated, FS_BlockedActionFeedback& BlockedReason);
    void ResetTargetingSystem();
    void NotifyTargetChange();
    bool IsCurrentlyTargetingEnemies();
    bool IsCurrentlyTargetingAllies();
    void OnTargetChanged();
    void DEPRECATED_GetTargetsWithGamepad(TEnumAsByte<E_jRPG_TargetingType::Type> TargetingType, int32 SelectedTargetIndex, bool SelectDescendingForSingleAllyType?, TArray<ABP_jRPG_Character_Battle_Base_C*>& Targets, int32& SelectedTargetIndexOutput);
    void DEPRECATED_ShowTargets(class ABP_jRPG_Character_Battle_Base_C* IndicatedCharacter);
    void ComputeTargetGroups(TEnumAsByte<E_jRPG_TargetingType::Type> TargetingType, bool BypassChecks, bool& IsAlly, TArray<UBP_TargetingGroup_C*>& TargetGroups, class ABP_jRPG_Character_Battle_Base_C*& PreferedNextInitialTarget);
    void TryUnfocusTargetGroup(class UBP_TargetingGroup_C* TargetGroup);
    void TryFocusTargetGroup(class UBP_TargetingGroup_C* TargetGroup);
    void GetTargetingGroupForCharacter(class ABP_jRPG_Character_Battle_Base_C* Character, class UBP_TargetingGroup_C*& Array Element);
    void ConfirmTarget();
    void RegisterTargetingGroupsInUINavigation(class ABP_jRPG_Character_Battle_Base_C* PreferedInitialTarget);
    void AddTargetingGroup(TArray<ABP_jRPG_Character_Battle_Base_C*>& Characters, const TArray<UBP_TargetingGroup_C*>& TargetGroups, class UBP_TargetingGroup_C*& TargetingGroup);
    void AddSingleCharacterTargetingGroup(class ABP_jRPG_Character_Battle_Base_C* Character, const TArray<UBP_TargetingGroup_C*>& TargetGroups, class UBP_TargetingGroup_C*& TargetingGroup);
    void UpdateTargetGroups(TEnumAsByte<E_jRPG_TargetingType::Type> TargetingType, bool& IsAlly);
    class UAC_jRPG_BattleManager_C* GetBattleManager();
    void HideTargets();
    void CancelTargeting();
    void DisableTargeting();
    void EnableTargetingInternal(TEnumAsByte<E_jRPG_TargetingType::Type> TargetingType, bool StartPreTargeting);
    void EnableTargeting(TEnumAsByte<E_jRPG_TargetingType::Type> TargetingType);
    void EnablePreTargeting();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_AC_jRPG_TargetingManager(int32 EntryPoint);
    void OnTargetConfirmed__DelegateSignature();
}; // Size: 0x140

#endif
