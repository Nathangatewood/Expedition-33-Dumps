#ifndef UE4SS_SDK_BP_FreeAimTargetPart_HPP
#define UE4SS_SDK_BP_FreeAimTargetPart_HPP

class UBP_FreeAimTargetPart_C : public USceneComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0230 (size: 0x8)
    FBP_FreeAimTargetPart_COnFreeAimHit OnFreeAimHit;                                 // 0x0238 (size: 0x10)
    void OnFreeAimHit(TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, class ABP_FreeAimProjectile_Base_C* Projectile);
    TEnumAsByte<EFreeAimBodyPartType::Type> BodyPartType;                             // 0x0248 (size: 0x1)
    bool Debug Enabled;                                                               // 0x0249 (size: 0x1)
    bool NewVar_0;                                                                    // 0x024A (size: 0x1)
    FLinearColor DebugColor;                                                          // 0x024C (size: 0x10)
    class UPrimitiveComponent* LastHitComponentRef;                                   // 0x0260 (size: 0x8)
    FLinearColor DebugColorHighlight;                                                 // 0x0268 (size: 0x10)
    TArray<UShapeComponent*> ValidChildren;                                           // 0x0278 (size: 0x10)
    class ABP_jRPG_Character_Battle_Base_C* CharacterOwnerOverride;                   // 0x0288 (size: 0x8)
    double BaseDamage;                                                                // 0x0290 (size: 0x8)
    double DamageMultiplier;                                                          // 0x0298 (size: 0x8)

    void DisablePartsCollisions();
    double GetFinalDamageMultiplier();
    void GetCharacterOwner(class ABP_jRPG_Character_Battle_Base_C*& CharacterBattleBase);
    void DEBUG_GetColor(class UShapeComponent* ShapeComponent, FLinearColor& Color);
    void DrawDebug();
    void ReceiveBeginPlay();
    void OnComponentBeginOverlap_Event_0(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void SetDebugVisible(bool DebugEnabled);
    void ReceiveTick(float DeltaSeconds);
    void OnPartHit(class UPrimitiveComponent* LastHitComponentRef, class ABP_FreeAimProjectile_Base_C* Projectile);
    void ExecuteUbergraph_BP_FreeAimTargetPart(int32 EntryPoint);
    void OnFreeAimHit__DelegateSignature(TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, class ABP_FreeAimProjectile_Base_C* Projectile);
}; // Size: 0x2A0

#endif
