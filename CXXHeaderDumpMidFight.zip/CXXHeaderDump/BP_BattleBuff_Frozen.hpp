#ifndef UE4SS_SDK_BP_BattleBuff_Frozen_HPP
#define UE4SS_SDK_BP_BattleBuff_Frozen_HPP

class UBP_BattleBuff_Frozen_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UNiagaraComponent* Niagara System;                                          // 0x0160 (size: 0x8)
    class UBP_DependencyRefCounter_C* Turn Start Dependencies;                        // 0x0168 (size: 0x8)

    void DeactivateBuff();
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_Frozen(int32 EntryPoint);
}; // Size: 0x170

#endif
