#ifndef UE4SS_SDK_BP_DataAsset_Item_HPP
#define UE4SS_SDK_BP_DataAsset_Item_HPP

class UBP_DataAsset_Item_C : public UPrimaryDataAsset
{

    TSubclassOf<class UBP_ItemInstance_Base_C> GetItemInstanceClass();
    void OnRemovedFromInventory(class UBP_jRPG_GI_Custom_C* GameInstance, class UAC_jRPG_InventoryManager_C* InventoryManager, FName ItemId);
    void OnAddedToInventory(class UAC_jRPG_InventoryManager_C* InventoryManager, FName ItemId, FS_LootContext& LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItem);
}; // Size: 0x30

#endif
