#ifndef UE4SS_SDK_BP_Battle_SkillScript_Sciel_TwilightDance_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_Sciel_TwilightDance_HPP

class ABP_Battle_SkillScript_Sciel_TwilightDance_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    bool HasHitAtLeastOnce;                                                           // 0x0310 (size: 0x1)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript_Sciel_TwilightDance(int32 EntryPoint);
}; // Size: 0x311

#endif
