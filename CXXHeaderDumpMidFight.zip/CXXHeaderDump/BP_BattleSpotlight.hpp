#ifndef UE4SS_SDK_BP_BattleSpotlight_HPP
#define UE4SS_SDK_BP_BattleSpotlight_HPP

class ABP_BattleSpotlight_C : public AActor
{
    class USpotLightComponent* SpotLight;                                             // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)

}; // Size: 0x2A0

#endif
