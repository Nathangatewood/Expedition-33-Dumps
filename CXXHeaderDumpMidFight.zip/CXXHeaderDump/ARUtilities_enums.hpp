enum class EARLiveLinkSourceType {
    None = 0,
    ARKitPoseTracking = 1,
    EARLiveLinkSourceType_MAX = 2,
};

