#ifndef UE4SS_SDK_BP_ConditionChecker_AtLeastAmountOfItemTypeInInventory_HPP
#define UE4SS_SDK_BP_ConditionChecker_AtLeastAmountOfItemTypeInInventory_HPP

class UBP_ConditionChecker_AtLeastAmountOfItemTypeInInventory_C : public UBP_ConditionChecker_C
{
    int32 Amount;                                                                     // 0x0060 (size: 0x4)
    TEnumAsByte<E_jRPG_ItemType::Type> ItemType;                                      // 0x0064 (size: 0x1)
    TEnumAsByte<E_jRPG_ItemSubtype::Type> ItemSubtype;                                // 0x0065 (size: 0x1)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
}; // Size: 0x66

#endif
