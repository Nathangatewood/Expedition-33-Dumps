#ifndef UE4SS_SDK_BP_DataAsset_Item_Pictos_HPP
#define UE4SS_SDK_BP_DataAsset_Item_Pictos_HPP

class UBP_DataAsset_Item_Pictos_C : public UBP_DataAsset_Item_C
{
    TArray<TSubclassOf<class UBP_BattleBuffInstance_C>> BattleBuffs;                  // 0x0030 (size: 0x10)
    TArray<FFPassiveEffectDataTableRow> PassiveEffects;                               // 0x0040 (size: 0x10)
    TSoftObjectPtr<class UTexture2D> PictosTexture;                                   // 0x0050 (size: 0x28)

    void OnRemovedFromInventory(class UBP_jRPG_GI_Custom_C* GameInstance, class UAC_jRPG_InventoryManager_C* InventoryManager, FName ItemId);
    TSubclassOf<class UBP_ItemInstance_Base_C> GetItemInstanceClass();
    void InitGear(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void GetUnlockedPassiveEffects(TArray<FName>& PassiveEffects);
}; // Size: 0x78

#endif
