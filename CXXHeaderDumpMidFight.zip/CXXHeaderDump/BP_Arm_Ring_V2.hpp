#ifndef UE4SS_SDK_BP_Arm_Ring_V2_HPP
#define UE4SS_SDK_BP_Arm_Ring_V2_HPP

class ABP_Arm_Ring_V2_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UNiagaraComponent* Fx;                                                      // 0x0298 (size: 0x8)
    class UChildActorComponent* BP_Shard_ArmRing2;                                    // 0x02A0 (size: 0x8)
    class UChildActorComponent* BP_Shard_ArmRing1;                                    // 0x02A8 (size: 0x8)
    class UChildActorComponent* BP_Shard_ArmRing;                                     // 0x02B0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B8 (size: 0x8)
    float ColorChange_Alpha_01BEE889490F163290F792A3A9480299;                         // 0x02C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> ColorChange__Direction_01BEE889490F163290F792A3A9480299; // 0x02C4 (size: 0x1)
    class UTimelineComponent* ColorChange;                                            // 0x02C8 (size: 0x8)
    float Active_Alpha_3563992B48317360C10B1298314EEB92;                              // 0x02D0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Active__Direction_3563992B48317360C10B1298314EEB92; // 0x02D4 (size: 0x1)
    class UTimelineComponent* Active;                                                 // 0x02D8 (size: 0x8)
    bool Activated;                                                                   // 0x02E0 (size: 0x1)
    bool Enviro;                                                                      // 0x02E1 (size: 0x1)
    bool Enemy;                                                                       // 0x02E2 (size: 0x1)
    bool TP;                                                                          // 0x02E3 (size: 0x1)
    FLinearColor PreviousColor;                                                       // 0x02E4 (size: 0x10)
    FLinearColor Color;                                                               // 0x02F4 (size: 0x10)
    FRotator GlobalRotation;                                                          // 0x0308 (size: 0x18)
    FLinearColor LiveColor;                                                           // 0x0320 (size: 0x10)
    class ABP_Shard_ArmRing_C* As BP Shard Arm Ring;                                  // 0x0330 (size: 0x8)
    class ABP_Shard_ArmRing_C* As BP Shard Arm Ring_1;                                // 0x0338 (size: 0x8)
    class ABP_Shard_ArmRing_C* As BP Shard Arm Ring_2;                                // 0x0340 (size: 0x8)

    void FlashOnShard(class AActor* Shard);
    void ColorChange__FinishedFunc();
    void ColorChange__UpdateFunc();
    void Active__FinishedFunc();
    void Active__UpdateFunc();
    void ArmRing_Enviro(bool HittingTarget);
    void ArmRing_Enemy(bool HittingTarget);
    void ArmRing_TP(bool HittingTarget);
    void Deactivate();
    void ReceiveBeginPlay();
    void GlowOnShot();
    void Activate();
    void Reset();
    void ExecuteUbergraph_BP_Arm_Ring_V2(int32 EntryPoint);
}; // Size: 0x348

#endif
