#ifndef UE4SS_SDK_BP_Dialog_AlphaCanvas_CleasTower_Dualliste_HPP
#define UE4SS_SDK_BP_Dialog_AlphaCanvas_CleasTower_Dualliste_HPP

class ABP_Dialog_AlphaCanvas_CleasTower_Dualliste_C : public ABP_Dialog_AlphaCanvas_CleasTower_C
{
}; // Size: 0x348

#endif
