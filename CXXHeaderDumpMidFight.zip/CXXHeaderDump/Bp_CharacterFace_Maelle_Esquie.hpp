#ifndef UE4SS_SDK_Bp_CharacterFace_Maelle_Esquie_HPP
#define UE4SS_SDK_Bp_CharacterFace_Maelle_Esquie_HPP

class ABp_CharacterFace_Maelle_Esquie_C : public ABP_CharacterFaceBase_Maelle_C
{
}; // Size: 0x2E0

#endif
