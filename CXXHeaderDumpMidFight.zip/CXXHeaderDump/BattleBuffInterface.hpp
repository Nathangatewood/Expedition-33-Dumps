#ifndef UE4SS_SDK_BattleBuffInterface_HPP
#define UE4SS_SDK_BattleBuffInterface_HPP

class IBattleBuffInterface_C : public IInterface
{

    void ApplyOnTurnEnd();
    void DeactivateBuff();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
}; // Size: 0x28

#endif
