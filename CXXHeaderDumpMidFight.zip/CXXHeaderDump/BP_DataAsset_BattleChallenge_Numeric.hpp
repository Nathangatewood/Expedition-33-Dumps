#ifndef UE4SS_SDK_BP_DataAsset_BattleChallenge_Numeric_HPP
#define UE4SS_SDK_BP_DataAsset_BattleChallenge_Numeric_HPP

class UBP_DataAsset_BattleChallenge_Numeric_C : public UBP_DataAsset_BattleChallenge_C
{
    TMap<FName, double> AvailableValues;                                              // 0x00A8 (size: 0x50)
    bool ShowAsPercent;                                                               // 0x00F8 (size: 0x1)
    bool MultiplierPrefix;                                                            // 0x00F9 (size: 0x1)

    void GetOptionNumericValue(const FName& OptionID, bool& Found, double& Value);
    TMap<FName, FText> GetValidOptionDisplayNames();
}; // Size: 0xFA

#endif
