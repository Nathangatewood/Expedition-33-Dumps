#ifndef UE4SS_SDK_BP_FreeAimCamera_HPP
#define UE4SS_SDK_BP_FreeAimCamera_HPP

class ABP_FreeAimCamera_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCameraComponent* FreeAimCamera;                                            // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    float Timeline_0_Alpha_D8D5930744498794AD9D0E88635DC5EA;                          // 0x02A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_D8D5930744498794AD9D0E88635DC5EA; // 0x02AC (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x02B0 (size: 0x8)
    float _TO1_Alpha_D873B6904FA48C1BD2534ABDAB7973FA;                                // 0x02B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> _TO1__Direction_D873B6904FA48C1BD2534ABDAB7973FA; // 0x02BC (size: 0x1)
    class UTimelineComponent* 0to1;                                                   // 0x02C0 (size: 0x8)

    void 0TO1__FinishedFunc();
    void 0TO1__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void TPinAim();
    void TPShot();
    void TPNotInAim();
    void ExecuteUbergraph_BP_FreeAimCamera(int32 EntryPoint);
}; // Size: 0x2C8

#endif
