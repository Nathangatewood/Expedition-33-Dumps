#ifndef UE4SS_SDK_BP_DependencyRefCounter_HPP
#define UE4SS_SDK_BP_DependencyRefCounter_HPP

class UBP_DependencyRefCounter_C : public UObject
{
    FBP_DependencyRefCounter_COnAllDependenciesSolved OnAllDependenciesSolved;        // 0x0028 (size: 0x10)
    void OnAllDependenciesSolved();
    TArray<UObject*> Dependencies;                                                    // 0x0038 (size: 0x10)
    TArray<UObject*> SolvedDependencies;                                              // 0x0048 (size: 0x10)
    bool IsListening;                                                                 // 0x0058 (size: 0x1)
    bool HasDependency;                                                               // 0x0059 (size: 0x1)
    bool HasTriggered;                                                                // 0x005A (size: 0x1)

    bool HasObjectAsDependency(const class UObject*& Object);
    bool HasNoPendingDependency();
    void ResetAllDependencies();
    void GetDebugText(FText& Result);
    void Reset();
    void CheckDependencies();
    void StartListenToDependencies();
    void AreAllDependenciesSolved(bool& AllSolved);
    void Register Dependency(class UObject* Dependency);
    void SolveDependency(class UObject* Dependency);
    void OnAllDependenciesSolved__DelegateSignature();
}; // Size: 0x5B

#endif
