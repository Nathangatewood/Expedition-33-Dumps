#ifndef UE4SS_SDK_ABP_Rope_HPP
#define UE4SS_SDK_ABP_Rope_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_258;                                                         // 0x0004 (size: 0x8)
    float __FloatProperty_259;                                                        // 0x000C (size: 0x4)
    class UAnimSequenceBase* __AnimSequenceBase_260;                                  // 0x0010 (size: 0x8)
    FName __NameProperty_261;                                                         // 0x0018 (size: 0x8)
    FName __NameProperty_262;                                                         // 0x0020 (size: 0x8)
    TEnumAsByte<ESequenceEvalReinit::Type> __ByteProperty_263;                        // 0x0028 (size: 0x1)
    int32 __IntProperty_264;                                                          // 0x002C (size: 0x4)
    float __FloatProperty_265;                                                        // 0x0030 (size: 0x4)
    class UAnimSequenceBase* __AnimSequenceBase_266;                                  // 0x0038 (size: 0x8)
    FName __NameProperty_267;                                                         // 0x0040 (size: 0x8)
    int32 __IntProperty_268;                                                          // 0x0048 (size: 0x4)
    FName __NameProperty_269;                                                         // 0x004C (size: 0x8)
    int32 __IntProperty_270;                                                          // 0x0054 (size: 0x4)
    bool __BoolProperty_271;                                                          // 0x0058 (size: 0x1)
    FName __NameProperty_272;                                                         // 0x005C (size: 0x8)
    int32 __IntProperty_273;                                                          // 0x0064 (size: 0x4)
    float __FloatProperty_274;                                                        // 0x0068 (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_275;                               // 0x006C (size: 0x2C)
    float __FloatProperty_276;                                                        // 0x0098 (size: 0x4)
    bool __BoolProperty_277;                                                          // 0x009C (size: 0x1)
    EAnimSyncMethod __EnumProperty_278;                                               // 0x009D (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_279;                             // 0x009E (size: 0x1)
    FName __NameProperty_280;                                                         // 0x00A0 (size: 0x8)
    FName __NameProperty_281;                                                         // 0x00A8 (size: 0x8)
    FName __NameProperty_282;                                                         // 0x00B0 (size: 0x8)
    FName __NameProperty_283;                                                         // 0x00B8 (size: 0x8)
    int32 __IntProperty_284;                                                          // 0x00C0 (size: 0x4)
    FAnimNodeFunctionRef __StructProperty_285;                                        // 0x00C8 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00E8 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0168 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0180 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_13;    // 0x01B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_12;    // 0x01E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_11;    // 0x0210 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_10;    // 0x0240 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_9;     // 0x0270 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_8;     // 0x02A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_7;     // 0x02D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_6;     // 0x0300 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator_1;    // 0x0330 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_10;         // 0x0360 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_6;       // 0x0390 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_9;          // 0x03C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_5;       // 0x03F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_8;          // 0x0420 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_4;       // 0x0450 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_7;          // 0x0480 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_2;         // 0x04B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_6;          // 0x04E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_5;     // 0x0510 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_4;     // 0x0540 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_3;     // 0x0570 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_2;     // 0x05A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x05D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3;       // 0x0600 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_5;          // 0x0630 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator;      // 0x0660 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_4;          // 0x0690 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2;       // 0x06C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_3;          // 0x06F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0720 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2;          // 0x0750 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x0780 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x07B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_1;         // 0x07E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0810 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x0840 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0870 (size: 0x30)

}; // Size: 0x8A0

class UABP_Rope_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13;                     // 0x03A8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12;                     // 0x03D0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;                     // 0x03F8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;                     // 0x0420 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;                      // 0x0448 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;                      // 0x0470 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;                      // 0x0498 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;                      // 0x04C0 (size: 0x28)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_1;                    // 0x04E8 (size: 0x40)
    FAnimNode_StateResult AnimGraphNode_StateResult_10;                               // 0x0528 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;                          // 0x0548 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_9;                                // 0x0590 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;                          // 0x05B0 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_8;                                // 0x05F8 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;                          // 0x0618 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_7;                                // 0x0660 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_2;                              // 0x0680 (size: 0xC8)
    FAnimNode_StateResult AnimGraphNode_StateResult_6;                                // 0x0748 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;                      // 0x0768 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;                      // 0x0790 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;                      // 0x07B8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;                      // 0x07E0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x0808 (size: 0x28)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;                          // 0x0830 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_5;                                // 0x0878 (size: 0x20)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;                      // 0x0898 (size: 0x40)
    FAnimNode_StateResult AnimGraphNode_StateResult_4;                                // 0x08D8 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;                          // 0x08F8 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_3;                                // 0x0940 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x0960 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_2;                                // 0x09A8 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x09C8 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x0A10 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_1;                              // 0x0A30 (size: 0xC8)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0AF8 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0B18 (size: 0x28)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0B40 (size: 0xC8)
    class UBP_ExplorationCapacityComponent_Rope_C* ExplorationCapacityRopeComponent;  // 0x0C08 (size: 0x8)
    TEnumAsByte<E_RopeMovementDirection::Type> RopeMovementDirection;                 // 0x0C10 (size: 0x1)
    TEnumAsByte<E_RopeMovementStep::Type> RopeMovementStep;                           // 0x0C11 (size: 0x1)
    bool HasLanded;                                                                   // 0x0C12 (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_B96B6FF540DF3C056832AA922A0F73A6();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_CEACDCBD4F661DF2D6EB7387612A223B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_88755CC6450A726295F05EB2C145DE90();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_E5F3437042D85EBEB665C7B0C48E40EE();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_8648A757463964D86BE651BD638DB8BC();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_336557F147CF37075D2C6883ABC61387();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_3280FAEB48C4608D18B224A0350A9C05();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_198199DE48F98A3CC9354CA2B8FF8984();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_4DF3BF6748F21C92B578C0908CFDCF52();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_182DCC714738FA3BDC7D38A42ADACFA9();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_9779FC5B4672710E8934ABADFD7A0658();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_DA41C38B4190978C79141D92B105B16A();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Rope_AnimGraphNode_TransitionResult_9D17ABFE4A1D8F7A556A089D8B381BF3();
    void AnimNotify_OnEnterTransitionDone();
    void AnimNotify_OnFinal();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_ABP_Rope(int32 EntryPoint);
}; // Size: 0xC13

#endif
