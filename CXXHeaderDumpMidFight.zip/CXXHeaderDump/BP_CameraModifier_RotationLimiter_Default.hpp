#ifndef UE4SS_SDK_BP_CameraModifier_RotationLimiter_Default_HPP
#define UE4SS_SDK_BP_CameraModifier_RotationLimiter_Default_HPP

class UBP_CameraModifier_RotationLimiter_Default_C : public UCameraModifier_RotationLimiter
{
}; // Size: 0x60

#endif
