#ifndef UE4SS_SDK_BP_BS_Item_HealingTintStrong_HPP
#define UE4SS_SDK_BP_BS_Item_HealingTintStrong_HPP

class ABP_BS_Item_HealingTintStrong_C : public ABP_BS_Item_HealingTintParent_C
{
}; // Size: 0x328

#endif
