#ifndef UE4SS_SDK_BP_BattleBuff_CheckHealthToTriggerBuff_HPP
#define UE4SS_SDK_BP_BattleBuff_CheckHealthToTriggerBuff_HPP

class UBP_BattleBuff_CheckHealthToTriggerBuff_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UNiagaraComponent* Niagara System;                                          // 0x0160 (size: 0x8)
    class UBP_DependencyRefCounter_C* Turn Start Dependencies;                        // 0x0168 (size: 0x8)
    TEnumAsByte<ERuntimeBattleStatType::Type> RuntimeStat;                            // 0x0171 (size: 0x1)
    double HealthMultiplierComparing;                                                 // 0x0178 (size: 0x8)
    TSubclassOf<class UBP_BattleBuffInstance_C> BuffToApply;                          // 0x0180 (size: 0x8)
    bool BuffIsApplied;                                                               // 0x0188 (size: 0x1)
    class UBP_BattleBuffInstance_C* AppliedBuff;                                      // 0x0190 (size: 0x8)
    bool IsDirty;                                                                     // 0x0198 (size: 0x1)

    void ProcessReceivedRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    bool Stats Compare();
    void ProcessHeal(class UBP_BattleHeal_C* Heal, bool& DummyOut);
    void ProcessReceivedFinalDamages(class UBP_BattleDamages_C*& BattleDamages, int32 CurrentTurnHitCount, bool& Out);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_CheckHealthToTriggerBuff(int32 EntryPoint);
}; // Size: 0x199

#endif
