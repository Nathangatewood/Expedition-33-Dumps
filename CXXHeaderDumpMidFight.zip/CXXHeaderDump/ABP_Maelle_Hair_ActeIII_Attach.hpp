#ifndef UE4SS_SDK_ABP_Maelle_Hair_ActeIII_Attach_HPP
#define UE4SS_SDK_ABP_Maelle_Hair_ActeIII_Attach_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FAnimNodeFunctionRef __StructProperty_4;                                          // 0x0008 (size: 0x20)
    FName __NameProperty_5;                                                           // 0x0028 (size: 0x8)
    FName __NameProperty_6;                                                           // 0x0030 (size: 0x8)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyPoseFromMesh;       // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0100 (size: 0x30)

}; // Size: 0x130

class UABP_Maelle_Hair_ActeIII_Attach_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_CopyPoseFromMesh AnimGraphNode_CopyPoseFromMesh;                        // 0x0388 (size: 0x158)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x04E0 (size: 0x20)

    void AnimGraph(FPoseLink& AnimGraph);
    void ExecuteUbergraph_ABP_Maelle_Hair_ActeIII_Attach(int32 EntryPoint);
}; // Size: 0x500

#endif
