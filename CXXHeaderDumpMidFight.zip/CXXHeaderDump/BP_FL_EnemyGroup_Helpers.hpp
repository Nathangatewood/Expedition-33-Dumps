#ifndef UE4SS_SDK_BP_FL_EnemyGroup_Helpers_HPP
#define UE4SS_SDK_BP_FL_EnemyGroup_Helpers_HPP

class UBP_FL_EnemyGroup_Helpers_C : public UBlueprintFunctionLibrary
{

    void LinkEnemyWorldToGroup(class ABP_EnemyGroup_C* Group, class ABP_jRPG_Enemy_World_Base_Seamless_C* EnemyWorld, class UObject* __WorldContext);
    void UnlinkEnemyWorldToGroup(class ABP_EnemyGroup_C* Group, class ABP_jRPG_Enemy_World_Base_Seamless_C* EnemyWorld, class UObject* __WorldContext);
}; // Size: 0x28

#endif
