#ifndef UE4SS_SDK_BP_CharacterSkin_LuneOutfit_Civil_HPP
#define UE4SS_SDK_BP_CharacterSkin_LuneOutfit_Civil_HPP

class ABP_CharacterSkin_LuneOutfit_Civil_C : public ABP_CharacterSkinBase_Lune_C
{
}; // Size: 0x3A1

#endif
