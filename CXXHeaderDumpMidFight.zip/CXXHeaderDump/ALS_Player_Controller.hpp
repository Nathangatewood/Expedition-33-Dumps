#ifndef UE4SS_SDK_ALS_Player_Controller_HPP
#define UE4SS_SDK_ALS_Player_Controller_HPP

class AALS_Player_Controller_C : public AALSPlayerController
{

    void SetGlobalTimeDilationLocal(double Dilation);
}; // Size: 0x878

#endif
