#ifndef UE4SS_SDK_BP_ConditionChecker_HPP
#define UE4SS_SDK_BP_ConditionChecker_HPP

class UBP_ConditionChecker_C : public UConditionChecker
{
    FBP_ConditionChecker_COnConditionChanged OnConditionChanged;                      // 0x0050 (size: 0x10)
    void OnConditionChanged();

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    FString AppendPropertyPath(FString& CurrentPath, FString PropertyName);
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
    void ReportValidationError(TArray<FText>& ErrorMesssages, FString PropertyPath, FString Message);
    void OnConditionChanged__DelegateSignature();
}; // Size: 0x60

#endif
