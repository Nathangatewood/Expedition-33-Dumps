#ifndef UE4SS_SDK_BP_Battle_SkillScript_Sciel_Intervention_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_Sciel_Intervention_HPP

class ABP_Battle_SkillScript_Sciel_Intervention_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)

    void ValidateSkillTargets(TArray<UAC_jRPG_CharacterBattleStats_C*>& TargetCharacterStats, bool& ValidTargets, FS_BlockedActionFeedback& BlockedReason);
    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript_Sciel_Intervention(int32 EntryPoint);
}; // Size: 0x310

#endif
