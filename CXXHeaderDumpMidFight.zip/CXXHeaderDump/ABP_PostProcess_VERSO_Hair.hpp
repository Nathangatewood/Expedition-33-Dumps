#ifndef UE4SS_SDK_ABP_PostProcess_VERSO_Hair_HPP
#define UE4SS_SDK_ABP_PostProcess_VERSO_Hair_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_37;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_38;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_39;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_8;        // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_7;        // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_6;        // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_5;        // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_4;        // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x0310 (size: 0x30)

}; // Size: 0x340

class UABP_PostProcess_VERSO_Hair_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x03A8 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x03C8 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_8;                            // 0x03F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7;                            // 0x0B90 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6;                            // 0x1330 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5;                            // 0x1AD0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4;                            // 0x2270 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0x2A10 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0x31B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0x3950 (size: 0x7A0)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x40F0 (size: 0xB8)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0x41B0 (size: 0x7A0)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_A6DDE9E44ED453642D19B69E76C7F4C4();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_420B1C4F4090918948FCF0A44C2C7852();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_B55B03164666377ADCCB60AB58171E4E();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_8F20F02642D33F79CB09A980D53A7297();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_18F3051E408DCF0E97E3D29D7E3AEE6D();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_4B64C883474B45BCE6FDEC8DD719B8E7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_11F73CA247F8B0572C0145B32FF57275();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_075B461041C490DAEF58ECBFAE3047F9();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_VERSO_Hair_AnimGraphNode_KawaiiPhysics_4C47E1634B0BE52B50AE098CA172F804();
    void ExecuteUbergraph_ABP_PostProcess_VERSO_Hair(int32 EntryPoint);
}; // Size: 0x4950

#endif
