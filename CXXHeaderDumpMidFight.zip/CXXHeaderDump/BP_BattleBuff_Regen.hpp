#ifndef UE4SS_SDK_BP_BattleBuff_Regen_HPP
#define UE4SS_SDK_BP_BattleBuff_Regen_HPP

class UBP_BattleBuff_Regen_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    double RecoverPercentage;                                                         // 0x0160 (size: 0x8)
    class UNiagaraComponent* Niagara System;                                          // 0x0168 (size: 0x8)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Regen(int32 EntryPoint);
}; // Size: 0x170

#endif
