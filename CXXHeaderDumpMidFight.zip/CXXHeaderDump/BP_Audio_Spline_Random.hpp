#ifndef UE4SS_SDK_BP_Audio_Spline_Random_HPP
#define UE4SS_SDK_BP_Audio_Spline_Random_HPP

class ABP_Audio_Spline_Random_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USplineComponent* Spline;                                                   // 0x0298 (size: 0x8)
    TArray<UBP_DataAsset_SoundWithDelay_C*> SoundData;                                // 0x02A0 (size: 0x10)
    int32  NumberOfPointsToSearch;                                                    // 0x02B0 (size: 0x4)
    bool DEBUG_DrawPlayedSoundEnable;                                                 // 0x02B4 (size: 0x1)
    TArray<FS_RuntimeSoundDataWithDelay> RuntimeSoundData;                            // 0x02B8 (size: 0x10)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void DEBUG_DrawMinMaxPositions();
    void DEBUG_DrawPlayedSound(class USoundBase* Sound, FVector position);
    void GetSplinePointForSound(class USoundBase* Sound, FVector& position, bool& Found);
    void PlayRandomSoundAtRandomPosition(FS_RuntimeSoundDataWithDelay& RandomSoundData);
    void GetRandomSplinePointInRange(FVector position, double Range, TArray<FVector>& Points, FVector& Point, bool& Found);
    void GetRandomSplinePointsInDistanceRange(double MinDistance, double MaxDistance, int32 NumberOfPoints, TArray<FVector>& Points);
    void GetMinMaxDistanceFromLocationInRange(FVector Location, double Range, bool& Found, double& MinDistance, double& MaxDistance);
    void OnTimerElapsed();
    void StartTimerForSoundData(FS_RuntimeSoundDataWithDelay& SoundData);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_BP_Audio_Spline_Random(int32 EntryPoint);
}; // Size: 0x2C8

#endif
