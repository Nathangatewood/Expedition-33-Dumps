#ifndef UE4SS_SDK_ARUtilities_HPP
#define UE4SS_SDK_ARUtilities_HPP

#include "ARUtilities_enums.hpp"

struct FARKitPoseTrackingConfig
{
    FVector HumanForward;                                                             // 0x0000 (size: 0x18)
    FVector MeshForward;                                                              // 0x0018 (size: 0x18)

}; // Size: 0x30

class AARPassthroughManager : public AActor
{
    TArray<TSubclassOf<class UARComponent>> ARComponentClasses;                       // 0x0290 (size: 0x10)
    class UPassthroughMaterialUpdateComponent* PassthroughUpdateComponent;            // 0x02A0 (size: 0x8)

    class UPassthroughMaterialUpdateComponent* GetPassthroughMaterialUpdateComponent();
}; // Size: 0x2A8

class UARLiveLinkRetargetAsset : public ULiveLinkRetargetAsset
{
    EARLiveLinkSourceType SourceType;                                                 // 0x0028 (size: 0x1)
    TMap<FName, FName> BoneMap;                                                       // 0x0030 (size: 0x50)
    FARKitPoseTrackingConfig ARKitPoseTrackingConfig;                                 // 0x0080 (size: 0x30)

}; // Size: 0xB0

class UARUtilitiesFunctionLibrary : public UBlueprintFunctionLibrary
{

    void UpdateWorldToMeterScale(class UMaterialInstanceDynamic* MaterialInstance, float WorldToMeterScale);
    void UpdateSceneDepthTexture(class UMaterialInstanceDynamic* MaterialInstance, class UTexture* SceneDepthTexture, float DepthToMeterScale);
    void UpdateCameraTextureParam(class UMaterialInstanceDynamic* MaterialInstance, class UTexture* CameraTexture, float ColorScale);
}; // Size: 0x28

class UPassthroughMaterialUpdateComponent : public UActorComponent
{
    EARTextureType TextureType;                                                       // 0x00A0 (size: 0x1)
    class UMaterialInterface* PassthroughMaterial;                                    // 0x00A8 (size: 0x8)
    class UMaterialInterface* PassthroughMaterialExternalTexture;                     // 0x00B0 (size: 0x8)
    FLinearColor PassthroughDebugColor;                                               // 0x00B8 (size: 0x10)
    TArray<UPrimitiveComponent*> AffectedComponents;                                  // 0x00C8 (size: 0x10)
    TArray<UPrimitiveComponent*> PendingComponents;                                   // 0x00D8 (size: 0x10)

    void SetPassthroughDebugColor(FLinearColor NewDebugColor);
    void RemoveAffectedComponent(class UPrimitiveComponent* InComponent);
    void AddAffectedComponent(class UPrimitiveComponent* InComponent);
}; // Size: 0xE8

#endif
