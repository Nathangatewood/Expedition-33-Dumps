#ifndef UE4SS_SDK_BP_BS_Item_ReviveTint_Strong_HPP
#define UE4SS_SDK_BP_BS_Item_ReviveTint_Strong_HPP

class ABP_BS_Item_ReviveTint_Strong_C : public ABP_BS_Item_ReviveTint_Parent_C
{
}; // Size: 0x328

#endif
