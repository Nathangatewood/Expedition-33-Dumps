#ifndef UE4SS_SDK_BP_CharacterSkin_Monoco_Osquio_HPP
#define UE4SS_SDK_BP_CharacterSkin_Monoco_Osquio_HPP

class ABP_CharacterSkin_Monoco_Osquio_C : public ABP_CharacterSkinBase_Monoco_C
{
}; // Size: 0x3A0

#endif
