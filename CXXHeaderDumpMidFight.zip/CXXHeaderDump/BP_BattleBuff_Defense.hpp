#ifndef UE4SS_SDK_BP_BattleBuff_Defense_HPP
#define UE4SS_SDK_BP_BattleBuff_Defense_HPP

class UBP_BattleBuff_Defense_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class USoundBase* BuffActivateSound;                                              // 0x0160 (size: 0x8)
    double DamageReceivedMultiplier;                                                  // 0x0168 (size: 0x8)

    void ProcessReceivedFinalDamages(class UBP_BattleDamages_C*& BattleDamages, int32 CurrentTurnHitCount, bool& Out);
    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_Defense(int32 EntryPoint);
}; // Size: 0x170

#endif
