#ifndef UE4SS_SDK_BP_Battle_SkillScript_Sciel_New7_DarkAbsorption_HPP
#define UE4SS_SDK_BP_Battle_SkillScript_Sciel_New7_DarkAbsorption_HPP

class ABP_Battle_SkillScript_Sciel_New7_DarkAbsorption_C : public ABP_Battle_SkillScript_StandardSkill_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    bool HasHit;                                                                      // 0x0310 (size: 0x1)
    int32 ForetellToConsume;                                                          // 0x0314 (size: 0x4)

    void OnActionEffect();
    void OnExecuteSkill();
    void ExecuteUbergraph_BP_Battle_SkillScript_Sciel_New7_DarkAbsorption(int32 EntryPoint);
}; // Size: 0x318

#endif
