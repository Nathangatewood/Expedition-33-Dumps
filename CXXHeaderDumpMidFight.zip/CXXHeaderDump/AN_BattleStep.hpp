#ifndef UE4SS_SDK_AN_BattleStep_HPP
#define UE4SS_SDK_AN_BattleStep_HPP

class UAN_BattleStep_C : public UAnimNotify
{
    bool RightFoot;                                                                   // 0x0038 (size: 0x1)
    TSubclassOf<class ULegacyCameraShake> ShakeClass;                                 // 0x0040 (size: 0x8)
    double RadiusMaxCameraShake;                                                      // 0x0048 (size: 0x8)
    TEnumAsByte<EFootstepsType::Type> FootstepsType;                                  // 0x0050 (size: 0x1)

    void GetFloorType(FVector Location, class AActor* Owner, TEnumAsByte<EPhysicalSurface>& Surface Type);
    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x51

#endif
