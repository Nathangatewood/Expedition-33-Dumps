#ifndef UE4SS_SDK_BP_BattleListener_HPP
#define UE4SS_SDK_BP_BattleListener_HPP

class UBP_BattleListener_C : public UObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)

    void IsTurnStartInProgress(bool& InProgress);
    void OnCharacterDealtDamages(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, double Damages, double& ProcessedDamages);
    void OnBattleStop();
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void OnCharacterKilled(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterResurrected();
    void ProcessAddBuffAction(const class UAction_AddBuff_C*& BuffAddAction);
    void OnSuccessfulParry();
    void OnSuccessfulDodge();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void BPI_OnAnyCharacterDamaged(class UBP_BattleDamages_C* BattleDamage);
    void BPI_OnAnyCharacterAP_Changed(class UBP_BattleEvent_APChange_C* AP_Change);
    void BPI_OnBattleStart();
    void BPI_OnReserveTeamSent();
    void ExecuteUbergraph_BP_BattleListener(int32 EntryPoint);
}; // Size: 0x30

#endif
