#ifndef UE4SS_SDK_BP_AchievementManager_HPP
#define UE4SS_SDK_BP_AchievementManager_HPP

class UBP_AchievementManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UDataTable* AchievementsDataTable;                                          // 0x00A8 (size: 0x8)
    FBP_AchievementManager_COnAchievementUnlocked OnAchievementUnlocked;              // 0x00B0 (size: 0x10)
    void OnAchievementUnlocked(FName AchievementID);

    void OnAchievementTriggered(const FAchievementsMap AchievementsMap, const bool bSuccess);
    void OnAchievementValidatorPassed(FName AchievementID);
    void UnlockAchievement(FName AchievementID);
    void GetAchievementSpecificPlatformID(FName AchievementID, FName& PlatformId);
    void GetAllAchievementsIDs(TArray<FName>& AchievementIDs);
    void GetAchievementRuntimeData(FName AchievementID, FS_AchievementRuntimeData& Data);
    bool IsAchievementUnlocked(FName AchievementID);
    void ProcessValidatedAchievementsOnInitialize(TArray<UBP_AchievementValidator_C*>& ValidatedAchievements);
    void InitializeOnSaveLoaded(bool Success);
    void Initialize();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_AchievementManager(int32 EntryPoint);
    void OnAchievementUnlocked__DelegateSignature(FName AchievementID);
}; // Size: 0xC0

#endif
