#ifndef UE4SS_SDK_BP_CharacterFaceBase_Lune_HPP
#define UE4SS_SDK_BP_CharacterFaceBase_Lune_HPP

class ABP_CharacterFaceBase_Lune_C : public ABP_CharacterFaceBase_C
{
}; // Size: 0x2E0

#endif
