#ifndef UE4SS_SDK_BP_ConditionChecker_ItemInInventory_HPP
#define UE4SS_SDK_BP_ConditionChecker_ItemInInventory_HPP

class UBP_ConditionChecker_ItemInInventory_C : public UBP_ConditionChecker_C
{
    FItemDataTableRowHandle Item;                                                     // 0x0060 (size: 0x10)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void GetItemStaticData(FS_jRPG_Item_StaticData& ItemData);
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x70

#endif
