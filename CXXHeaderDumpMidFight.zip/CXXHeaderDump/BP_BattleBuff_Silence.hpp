#ifndef UE4SS_SDK_BP_BattleBuff_Silence_HPP
#define UE4SS_SDK_BP_BattleBuff_Silence_HPP

class UBP_BattleBuff_Silence_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    FSF_ReferenceCounterHandle SilenceRefHandle;                                      // 0x0160 (size: 0x20)

    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Silence(int32 EntryPoint);
}; // Size: 0x180

#endif
