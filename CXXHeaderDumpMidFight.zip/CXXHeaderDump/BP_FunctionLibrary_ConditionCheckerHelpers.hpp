#ifndef UE4SS_SDK_BP_FunctionLibrary_ConditionCheckerHelpers_HPP
#define UE4SS_SDK_BP_FunctionLibrary_ConditionCheckerHelpers_HPP

class UBP_FunctionLibrary_ConditionCheckerHelpers_C : public UBlueprintFunctionLibrary
{

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event, FConditionChecker_Wrapper Condition, class UObject* __WorldContext);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event, FConditionChecker_Wrapper Condition, class UObject* __WorldContext);
    void ValidateCondition(FConditionChecker_Wrapper Condition, TArray<FText>& ErrorMessages, FString& PropertyPath, class UObject* __WorldContext);
    void CheckOptionalCondition(FConditionChecker_Wrapper ConditionCheckerWrapper, class UObject* __WorldContext, bool& Result);
    void CheckCondition(FConditionChecker_Wrapper ConditionCheckerWrapper, class UObject* __WorldContext, bool& Result);
    void IsConditionSet(FConditionChecker_Wrapper ConditionCheckerWrapper, class UObject* __WorldContext, bool& Result);
}; // Size: 0x28

#endif
