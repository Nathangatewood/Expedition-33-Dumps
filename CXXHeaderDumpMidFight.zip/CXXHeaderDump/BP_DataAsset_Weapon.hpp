#ifndef UE4SS_SDK_BP_DataAsset_Weapon_HPP
#define UE4SS_SDK_BP_DataAsset_Weapon_HPP

class UBP_DataAsset_Weapon_C : public UBP_DataAsset_Item_Pictos_C
{
    TMap<TEnumAsByte<ECharacterAttribute::Type>, TEnumAsByte<EAttributeScalingGrade::Type>> AttributeScalings; // 0x0078 (size: 0x50)
    double BasePhysicalPower;                                                         // 0x00C8 (size: 0x8)
    double BaseMagicalPower;                                                          // 0x00D0 (size: 0x8)
    TSoftClassPtr<ABP_WeaponSkin_C> WeaponSkin;                                       // 0x00D8 (size: 0x28)

    TSubclassOf<class UBP_ItemInstance_Base_C> GetItemInstanceClass();
    void InitGear(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void GetPowerForCharacter(class UBP_CharacterData_C* CharacterData, double& PhysicalPower, double& MagicalPower);
}; // Size: 0x100

#endif
