#ifndef UE4SS_SDK_BP_DataAsset_SoundWithDelay_HPP
#define UE4SS_SDK_BP_DataAsset_SoundWithDelay_HPP

class UBP_DataAsset_SoundWithDelay_C : public UPrimaryDataAsset
{
    double Delay;                                                                     // 0x0030 (size: 0x8)
    double RandomDeviation;                                                           // 0x0038 (size: 0x8)
    TArray<USoundBase*> Sounds;                                                       // 0x0040 (size: 0x10)
    int32 ReplaySoundThreshold;                                                       // 0x0050 (size: 0x4)

}; // Size: 0x54

#endif
