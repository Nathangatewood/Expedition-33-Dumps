#ifndef UE4SS_SDK_BP_CharacterFaceBase_Sciel_HPP
#define UE4SS_SDK_BP_CharacterFaceBase_Sciel_HPP

class ABP_CharacterFaceBase_Sciel_C : public ABP_CharacterFaceBase_C
{
}; // Size: 0x2E0

#endif
