#ifndef UE4SS_SDK_AN_ENM_Footsteps_IsBattle_HPP
#define UE4SS_SDK_AN_ENM_Footsteps_IsBattle_HPP

class UAN_ENM_Footsteps_IsBattle_C : public UAnimNotify
{
    bool RightFoot;                                                                   // 0x0038 (size: 0x1)
    TEnumAsByte<EPhysicalSurface> SurfaceType;                                        // 0x0039 (size: 0x1)
    TEnumAsByte<EFootstepsType::Type> FootstepsType;                                  // 0x003A (size: 0x1)
    TEnumAsByte<ESizeOfMonster::Type> SizeOfMonster;                                  // 0x003B (size: 0x1)
    class USoundAttenuation* AttenuationBattleOverride;                               // 0x0040 (size: 0x8)

    void PlaySoundBasedOnMonsterSize(TEnumAsByte<EPhysicalSurface> SurfaceType, FVector PlaySoundLocation, bool IsBattle?);
    void ExecutreTriggerParametersForSurfaceType(TEnumAsByte<EPhysicalSurface> Index);
    void PlayHumanoidSound(TEnumAsByte<EPhysicalSurface> SurfaceType, FVector PlaySoundLocation, bool IsBattle?);
    void PlayMediumSound(TEnumAsByte<EPhysicalSurface> SurfaceType, FVector PlaySoundLocation, bool IsBattle?);
    void PlayLargeSound(TEnumAsByte<EPhysicalSurface> SurfaceType, FVector PlaySoundLocation, bool IsBattle?);
    void PlaySmallSound(TEnumAsByte<EPhysicalSurface> SurfaceType, FVector PlaySoundLocation, bool IsBattle?);
    void PlayExtraSmallSound(TEnumAsByte<EPhysicalSurface> SurfaceType, FVector PlaySoundLocation, bool IsBattle?);
    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x48

#endif
