#ifndef UE4SS_SDK_BP_CharacterFaceBase_Verso_HPP
#define UE4SS_SDK_BP_CharacterFaceBase_Verso_HPP

class ABP_CharacterFaceBase_Verso_C : public ABP_CharacterFaceBase_C
{
}; // Size: 0x2E0

#endif
