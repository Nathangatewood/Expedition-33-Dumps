#ifndef UE4SS_SDK_BP_CharacterSkin_ScielOutfit_Chic_HPP
#define UE4SS_SDK_BP_CharacterSkin_ScielOutfit_Chic_HPP

class ABP_CharacterSkin_ScielOutfit_Chic_C : public ABP_CharacterSkinBase_Sciel_C
{
}; // Size: 0x3A9

#endif
