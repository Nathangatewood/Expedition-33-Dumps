#ifndef UE4SS_SDK_BP_BattleBuff_LowHealthDamageBoostCheck_HPP
#define UE4SS_SDK_BP_BattleBuff_LowHealthDamageBoostCheck_HPP

class UBP_BattleBuff_LowHealthDamageBoostCheck_C : public UBP_BattleBuff_CheckHealthToTriggerBuff_C
{
}; // Size: 0x199

#endif
