#ifndef UE4SS_SDK_BP_DataAsset_Item_CharacterCustomization_HPP
#define UE4SS_SDK_BP_DataAsset_Item_CharacterCustomization_HPP

class UBP_DataAsset_Item_CharacterCustomization_C : public UBP_DataAsset_Item_C
{
    TEnumAsByte<E_CustomizationItemUser::Type> User;                                  // 0x0030 (size: 0x1)

    void GetFirstCustomizationItem(class UAC_jRPG_InventoryManager_C* InventoryManager, TEnumAsByte<E_CustomizationItemType::Type> CustomizationItemType, FName& ItemName);
    void OnRemovedFromInventory(class UBP_jRPG_GI_Custom_C* GameInstance, class UAC_jRPG_InventoryManager_C* InventoryManager, FName ItemId);
    void GetCharacterHardcodedNameFromUser(FName& CharacterHardcodedName);
    void IsItemCompatibleWithCharacter(class UBP_CharacterData_C* CharacterData, bool& Compatible);
    void UpdateCharacterCustomization_Internal(class UBP_CharacterData_C* CharacterData);
    void UpdateCharacterCustomization(class UBP_CharacterData_C* CharacterData);
}; // Size: 0x31

#endif
