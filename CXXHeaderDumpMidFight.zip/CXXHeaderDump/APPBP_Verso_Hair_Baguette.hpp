#ifndef UE4SS_SDK_APPBP_Verso_Hair_Baguette_HPP
#define UE4SS_SDK_APPBP_Verso_Hair_Baguette_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FAnimNodeFunctionRef __StructProperty_70;                                         // 0x0008 (size: 0x20)
    FName __NameProperty_71;                                                          // 0x0028 (size: 0x8)
    FName __NameProperty_72;                                                          // 0x0030 (size: 0x8)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_19;       // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_18;       // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_17;       // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_16;       // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_15;       // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_14;       // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_13;       // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_12;       // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_11;       // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_10;       // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_9;        // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_8;        // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_7;        // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_6;        // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_5;        // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_4;        // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0520 (size: 0x30)

}; // Size: 0x550

class UAPPBP_Verso_Hair_Baguette_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_19;                           // 0x0390 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_18;                           // 0x0B30 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_17;                           // 0x12D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_16;                           // 0x1A70 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_15;                           // 0x2210 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_14;                           // 0x29B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_13;                           // 0x3150 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_12;                           // 0x38F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_11;                           // 0x4090 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_10;                           // 0x4830 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_9;                            // 0x4FD0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_8;                            // 0x5770 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7;                            // 0x5F10 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6;                            // 0x66B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5;                            // 0x6E50 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4;                            // 0x75F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0x7D90 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0x8530 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0x8CD0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0x9470 (size: 0x7A0)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x9C10 (size: 0xB8)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x9CC8 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x9CE8 (size: 0x20)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x9D08 (size: 0x20)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_9F85DEE24BA2397D9A2C1B8FDED67519();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_10E6C56E441DED27FA229B8577EB8854();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_5FBE5B94461FF8062776A9A54269330E();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_859CC48F485974F51F9A81BF845CC214();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_7426E44042D3C5855BACE6AE057C8F06();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_A8437E734C0676DF9E18BCAD7B4ADF85();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_419E7F87464555D89BA8CE9F95247AF1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_CC48A62A4CBE397589546A8C933D5CDF();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_43D9BE3340F910224E32EAA7CBEC28FE();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_A154F9A04B76F95882FBF8A072F2B750();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_30219AC849AE95D3F7DB32BF4D3E3373();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_505BFD944A54477229056BB185C3C9EE();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_009204AA4E69ED65CABB11A990F96D90();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_D548785149D9115D40C7ABAB1C8CE195();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_841D744F4239225461AE59BEEFE93CC3();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_5641450E4B0BAA39C980BFAA5F513604();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_63F2BFF64FC2AF57F80781851475F79F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_F7A1FCB44E1D4D9BF1934E9615DE7F65();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_22A2C7F8455E2987B4C6D99B6F2610C5();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Verso_Hair_Baguette_AnimGraphNode_KawaiiPhysics_029F976044764D6FAED3CAB25C148245();
    void ExecuteUbergraph_APPBP_Verso_Hair_Baguette(int32 EntryPoint);
}; // Size: 0x9D28

#endif
