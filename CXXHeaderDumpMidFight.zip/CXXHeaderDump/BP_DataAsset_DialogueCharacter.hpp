#ifndef UE4SS_SDK_BP_DataAsset_DialogueCharacter_HPP
#define UE4SS_SDK_BP_DataAsset_DialogueCharacter_HPP

class UBP_DataAsset_DialogueCharacter_C : public UPrimaryDataAsset
{
    FText CharacterName;                                                              // 0x0030 (size: 0x10)

}; // Size: 0x40

#endif
