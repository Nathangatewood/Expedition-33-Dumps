#ifndef UE4SS_SDK_BP_DataAsset_CharacterDebugSave_HPP
#define UE4SS_SDK_BP_DataAsset_CharacterDebugSave_HPP

class UBP_DataAsset_CharacterDebugSave_C : public UPrimaryDataAsset
{
    TEnumAsByte<E_CharacterList::Type> PlayableCharacter;                             // 0x0030 (size: 0x1)
    FS_jRPG_CharacterSaveState CharacterSaveState;                                    // 0x0038 (size: 0x1C0)

}; // Size: 0x1F8

#endif
