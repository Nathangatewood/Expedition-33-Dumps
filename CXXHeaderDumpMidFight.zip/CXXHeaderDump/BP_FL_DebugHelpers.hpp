#ifndef UE4SS_SDK_BP_FL_DebugHelpers_HPP
#define UE4SS_SDK_BP_FL_DebugHelpers_HPP

class UBP_FL_DebugHelpers_C : public UBlueprintFunctionLibrary
{

    void CreateDistanceTextComponentFromActors(class AActor* MainActor, class AActor* SecondaryActor, double ValidMinimumDistance, double ValidMaximumDistance, class UObject* __WorldContext, class UTextRenderComponent*& TextRenderComponent);
    void CreateArrowComponentFromActors(class AActor* MainActor, class AActor* SecondaryActor, double ValidMinimumDistance, double ValidMaximumDistance, class UObject* __WorldContext, class UArrowComponent*& ArrowComponent);
    void ComputeValidDistanceBetweenActors(class AActor* ActorA, class AActor* ActorB, double MinimumDistance, double MaximumDistance, class UObject* __WorldContext, double& Distance, bool& IsAtValidDistance);
}; // Size: 0x28

#endif
