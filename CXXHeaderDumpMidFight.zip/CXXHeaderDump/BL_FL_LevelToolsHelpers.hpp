#ifndef UE4SS_SDK_BL_FL_LevelToolsHelpers_HPP
#define UE4SS_SDK_BL_FL_LevelToolsHelpers_HPP

class UBL_FL_LevelToolsHelpers_C : public UBlueprintFunctionLibrary
{

    void SetStaticMeshFromGeometryCollection(class UGeometryCollection* GeometryCollection, class UStaticMeshComponent* StaticMeshComponent, class UObject* __WorldContext);
    void TryGetStaticMeshFromCollection(class UGeometryCollection* GeometryCollection, class UObject* __WorldContext, class UStaticMesh*& StaticMesh, TArray<UMaterialInterface*>& Materials);
    void ComputeTRSToSpawnWallAlongSpline(FVector LocationNextPoint, FVector LocationPoint, double Thickness, double Height, class UObject* __WorldContext, FTransform& TransformForComponent);
    void ComputePointsInClosedLoop(class USplineComponent* Spline, double Spacing Far, class UObject* __WorldContext, TArray<FVector>& LocationPointsArray, FVector& CornerPoint);
    void ComputePointsBetweenSplinePoints(class USplineComponent* Spline, int32 SplinePointIndexA, double DistancePointA, int32 SplinePointIndexB, double DistancePointB, double SpacingFar, class UObject* __WorldContext, TArray<FVector>& LocationPointsArray);
    void ComputePointsToSpawnAlongSpline(class USplineComponent* Spline, bool ClosedLoop, double SpacingFar, class UObject* __WorldContext, TArray<FVector>& LocationPointsArray, TArray<FVector>& LocationPointsCorners);
    void CopySplineComponent(class USplineComponent* FromSplineComponent, class USplineComponent* ToSplineComponent, class UObject* __WorldContext);
    void UpdateDynamicMeshFromSpline(class USplineComponent* Spline, class UDynamicMeshComponent* DynamicMesh, double Height, class UObject* __WorldContext);
}; // Size: 0x28

#endif
