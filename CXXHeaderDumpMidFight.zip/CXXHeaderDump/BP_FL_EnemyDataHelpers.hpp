#ifndef UE4SS_SDK_BP_FL_EnemyDataHelpers_HPP
#define UE4SS_SDK_BP_FL_EnemyDataHelpers_HPP

class UBP_FL_EnemyDataHelpers_C : public UBlueprintFunctionLibrary
{

    void GetSavedFleePointIndex(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class UObject* __WorldContext, TSoftObjectPtr<class ABP_FleePoint_C>& FleePoint, bool& IsValid);
    void GetSavedRoamingPointIndex(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class UObject* __WorldContext, int32& Index, bool& IsValid);
    void GetEnemyTransformBeforeBattle(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class UObject* __WorldContext, FTransform& Transform, bool& IsValid);
    void GetSavedEnemyTransform(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class UObject* __WorldContext, FTransform& Transform, bool& IsValid);
    void GetEnemyBattleState(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class UObject* __WorldContext, bool& BattleState);
    void IsDynamicallySpawnedEnemy(class ABP_jRPG_Enemy_World_Base_Seamless_C* Enemy, class UObject* __WorldContext, bool& Result);
    void GetWorldMapEnemyGlobalID(class UObject* __WorldContext, FName& ID);
}; // Size: 0x28

#endif
