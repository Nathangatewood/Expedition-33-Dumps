#ifndef UE4SS_SDK_BP_BattleBuff_Stance_Offensive_HPP
#define UE4SS_SDK_BP_BattleBuff_Stance_Offensive_HPP

class UBP_BattleBuff_Stance_Offensive_C : public UBP_BattleBuff_Stance_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0160 (size: 0x8)

    void ShouldKeepOnDeath(bool& Keep);
    void ProcessReceivedRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_Stance_Offensive(int32 EntryPoint);
}; // Size: 0x168

#endif
