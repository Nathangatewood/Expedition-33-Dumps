#ifndef UE4SS_SDK_BP_FL_AnimationHelpers_HPP
#define UE4SS_SDK_BP_FL_AnimationHelpers_HPP

class UBP_FL_AnimationHelpers_C : public UBlueprintFunctionLibrary
{

    void ShouldDisablePostProcessInAnimation(class APawn* PawnOwner, class UObject* __WorldContext, bool& ShouldDisablePostProcessAnimationBlueprint);
}; // Size: 0x28

#endif
