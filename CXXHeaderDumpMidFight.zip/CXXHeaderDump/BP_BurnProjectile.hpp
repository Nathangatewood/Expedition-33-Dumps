#ifndef UE4SS_SDK_BP_BurnProjectile_HPP
#define UE4SS_SDK_BP_BurnProjectile_HPP

class ABP_BurnProjectile_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UNiagaraComponent* Trail;                                                   // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    float CurveMoveTimeline_Curve_E253AF63432A6EA92084FF9F2098FE8F;                   // 0x02A8 (size: 0x4)
    float CurveMoveTimeline_AtoB_E253AF63432A6EA92084FF9F2098FE8F;                    // 0x02AC (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> CurveMoveTimeline__Direction_E253AF63432A6EA92084FF9F2098FE8F; // 0x02B0 (size: 0x1)
    class UTimelineComponent* CurveMoveTimeline;                                      // 0x02B8 (size: 0x8)
    double Size;                                                                      // 0x02C0 (size: 0x8)
    double CurveHeight;                                                               // 0x02C8 (size: 0x8)
    double Speed;                                                                     // 0x02D0 (size: 0x8)
    FVector TargetLocation;                                                           // 0x02D8 (size: 0x18)
    FVector InitialActorLocation;                                                     // 0x02F0 (size: 0x18)
    FBP_BurnProjectile_COnExplode OnExplode;                                          // 0x0308 (size: 0x10)
    void OnExplode();

    void UserConstructionScript();
    void CurveMoveTimeline__FinishedFunc();
    void CurveMoveTimeline__UpdateFunc();
    void FX_Explode();
    void ReceiveBeginPlay();
    void CurveMove();
    void ExecuteUbergraph_BP_BurnProjectile(int32 EntryPoint);
    void OnExplode__DelegateSignature();
}; // Size: 0x318

#endif
