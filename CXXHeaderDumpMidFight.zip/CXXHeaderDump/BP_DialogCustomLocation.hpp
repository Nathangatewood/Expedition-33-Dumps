#ifndef UE4SS_SDK_BP_DialogCustomLocation_HPP
#define UE4SS_SDK_BP_DialogCustomLocation_HPP

class ABP_DialogCustomLocation_C : public AActor
{
    class UTextRenderComponent* Text_NPCPosition;                                     // 0x0290 (size: 0x8)
    class UTextRenderComponent* Text_PlayerPosition;                                  // 0x0298 (size: 0x8)
    class UArrowComponent* Arrow1;                                                    // 0x02A0 (size: 0x8)
    class UCapsuleComponent* Capsule_Player;                                          // 0x02A8 (size: 0x8)
    class UArrowComponent* Arrow;                                                     // 0x02B0 (size: 0x8)
    class UCapsuleComponent* Capsule_NPC;                                             // 0x02B8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02C0 (size: 0x8)

}; // Size: 0x2C8

#endif
