#ifndef UE4SS_SDK_BP_ConditionChecker_AtLeastAmountOfSkillUnlocked_HPP
#define UE4SS_SDK_BP_ConditionChecker_AtLeastAmountOfSkillUnlocked_HPP

class UBP_ConditionChecker_AtLeastAmountOfSkillUnlocked_C : public UBP_ConditionChecker_C
{
    TEnumAsByte<E_CharacterList::Type> Character;                                     // 0x0060 (size: 0x1)
    int32 Amount;                                                                     // 0x0064 (size: 0x4)

    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
}; // Size: 0x68

#endif
