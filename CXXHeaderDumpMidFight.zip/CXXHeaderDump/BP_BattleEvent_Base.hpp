#ifndef UE4SS_SDK_BP_BattleEvent_Base_HPP
#define UE4SS_SDK_BP_BattleEvent_Base_HPP

class UBP_BattleEvent_Base_C : public UObject
{

    void BroadcastBattleEvent(class UAC_jRPG_BattleManager_C*& BattleManager);
}; // Size: 0x28

#endif
