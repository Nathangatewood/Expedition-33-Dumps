#ifndef UE4SS_SDK_BP_BattleBuffInstance_HPP
#define UE4SS_SDK_BP_BattleBuffInstance_HPP

class UBP_BattleBuffInstance_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    int32 TurnDuration;                                                               // 0x0030 (size: 0x4)
    class UAC_jRPG_CharacterBattleStats_C* TargetCharacterStats;                      // 0x0038 (size: 0x8)
    bool IsPermanent;                                                                 // 0x0040 (size: 0x1)
    TArray<FFStatMultiplierData> CharacterStatMultipliers;                            // 0x0048 (size: 0x10)
    FText Name;                                                                       // 0x0058 (size: 0x10)
    FText Description;                                                                // 0x0068 (size: 0x10)
    class UTexture2D* Icon;                                                           // 0x0078 (size: 0x8)
    TEnumAsByte<E_jRPG_BuffStackingType::Type> StackingType;                          // 0x0080 (size: 0x1)
    TSubclassOf<class UBP_BattleBuffInstance_C> BuffFamily;                           // 0x0088 (size: 0x8)
    TArray<UParticleSystemComponent*> ActiveParticleSystemsCascade;                   // 0x0090 (size: 0x10)
    bool IsMarkedForRemoval;                                                          // 0x00A0 (size: 0x1)
    TEnumAsByte<E_BuffAndStatusEffectTypes::Type> Type;                               // 0x00A1 (size: 0x1)
    class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStats;                      // 0x00A8 (size: 0x8)
    TArray<UNiagaraComponent*> ActiveNiagaraSystem;                                   // 0x00B0 (size: 0x10)
    FDataTableRowHandle BuffActivationSound;                                          // 0x00C0 (size: 0x10)
    int32 StackCount;                                                                 // 0x00D0 (size: 0x4)
    TArray<UWBP_jRPG_BuffSlot_C*> BuffSlotWidgets;                                    // 0x00D8 (size: 0x10)
    FDataTableRowHandle SoundActivation;                                              // 0x00E8 (size: 0x10)
    FDataTableRowHandle SoundFeedback;                                                // 0x00F8 (size: 0x10)
    FDataTableRowHandle SoundDeactivate;                                              // 0x0108 (size: 0x10)
    FDataTableRowHandle DataTableRowSoundToPlay;                                      // 0x0118 (size: 0x10)
    class UBP_BattleBuffInstance_AggregatorBase_C* AggregatorBuffInstance;            // 0x0128 (size: 0x8)
    TSubclassOf<class UBP_BattleBuffInstance_AggregatorBase_C> AggregatorBuffClass;   // 0x0130 (size: 0x8)
    FBP_BattleBuffInstance_CBuffStackCountChange BuffStackCountChange;                // 0x0138 (size: 0x10)
    void BuffStackCountChange(class UBP_BattleBuffInstance_C* BuffInstance);
    class UObject* BuffInstigator;                                                    // 0x0148 (size: 0x8)
    bool DisableInNarrativeBattles;                                                   // 0x0150 (size: 0x1)

    void GetDamageSourceCharacter(class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void GetDamageSourceType(TEnumAsByte<EDamageReason::Type>& DamageSourceType);
    void IsTurnStartInProgress(bool& InProgress);
    void OnCharacterDealtDamages(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, double Damages, double& ProcessedDamages);
    class UObject* GetInstigatorObject();
    void SetInstigatorObject(class UObject* Instigator);
    void ModifyOwnerSkillStates(TMap<UBP_DataAsset_Skill_C*, UBP_SkillState_C*> SkillStates);
    void ProcessBattleStartEvent(class UBP_DependencyRefCounter_C* DepsRefCount);
    void ProcessDealtDamageCriticalHitChance(class UBP_BattleDamages_C* Damages, bool& Out);
    void OnVisualEffectDimChange(bool IsDimmed);
    void SetTurnDuration(int32 TurnDuration);
    void OnBuffStackCountChanged(int32 NewValue);
    void ShouldKeepOnDeath(bool& Keep);
    void FeedbackBuffTriggeredOnTarget(FText Text, FLinearColor Color);
    bool IsBuffPermanent();
    void SetPermanent();
    void OnGradientGaugeChange(class UBP_GradientGaugeChangeEvent_C* GradientChangeEvent);
    FText GetBuffDisplayName();
    void OnDeathDamagePrevented();
    void GetStackCount(int32& StackCount);
    void ChangeStackCount(int32 StackCount);
    void UpdateCustomBuffWidget(class UWBP_jRPG_BuffSlot_C* BuffWidget, bool& DummyOut);
    void InitializeCustomBuffWidget(class UWBP_jRPG_BuffSlot_C* BuffWidget, bool& DummyOut);
    void RegisterBuffWidget(const class UWBP_jRPG_BuffSlot_C*& BuffSlotWidget);
    void ProcessPermeateDamage(class UBP_BattleDamages_C* Damages, bool& Out);
    void ProcessAttackElement(class UBP_BattleDamages_C* Damages, bool& Out);
    void OnStanceChange(TEnumAsByte<E_StanceType::Type> NewStance, TEnumAsByte<E_StanceType::Type> previousStance, TEnumAsByte<E_StanceType::Type>& NewStance1, TEnumAsByte<E_StanceType::Type>& PreviousStance1);
    bool IsBuffFromFamily(TSubclassOf<class UBP_BattleBuffInstance_C> TestFamily);
    void ProcessHeal(class UBP_BattleHeal_C* Heal, bool& DummyOut);
    void ProcessAPChange(int32 NewAPAmount, int32 PreviousAPAmount, TEnumAsByte<EAPChangeReason::Type> ChangeReason, bool& HasChanged, int32& ChangedValue);
    void OnPerfectionChanged(int32 NewPerfection, int32 DeltaPerfection, TEnumAsByte<E_PerfectionUpdateType::Type> PerfectionChangeType, TEnumAsByte<EPerfectionReason::Type> PerfectionChangeReason, int32& FinalPerfection);
    void GetDebugText(FText& DebugInfo);
    void MarkBuffForRemoval();
    void ProcessReceivedRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void IsBuffTarget(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, bool& IsTarget);
    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void HideAllParticleSystems();
    void ShowAllParticleSystems();
    void RemoveAllParticleSystems();
    void AddCharacterParticleSystem(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, TEnumAsByte<E_jRPG_CharacterAttachmentSlot::Type> AttachmentSlot, class UParticleSystem* ParticleSystemCascade, FRotator PartySystemRotation, class UNiagaraSystem* SystemNiagara, FVector PositionOffset, class UParticleSystemComponent*& ParticleSystemCompoCascade, class UNiagaraComponent*& NiagaraSystem);
    void IsSameBuffFamily(class UBP_BattleBuffInstance_C* BattleBuffInstance, bool& IsSame);
    void ProcessReceivedFinalDamages(class UBP_BattleDamages_C*& BattleDamages, int32 CurrentTurnHitCount, bool& Out);
    void OnLoaded_148FF7BA4C95776B122106A0489F695B(class UObject* Loaded);
    void OnBattleStop();
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void OnCharacterKilled(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterResurrected();
    void ProcessAddBuffAction(const class UAction_AddBuff_C*& BuffAddAction);
    void OnSuccessfulParry();
    void OnSuccessfulDodge();
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void BPI_OnAnyCharacterDamaged(class UBP_BattleDamages_C* BattleDamage);
    void BPI_OnAnyCharacterAP_Changed(class UBP_BattleEvent_APChange_C* AP_Change);
    void BPI_OnBattleStart();
    void BPI_OnReserveTeamSent();
    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void Event Play Sound Feedback();
    void DeactivateBuff();
    void ExecuteUbergraph_BP_BattleBuffInstance(int32 EntryPoint);
    void BuffStackCountChange__DelegateSignature(class UBP_BattleBuffInstance_C* BuffInstance);
}; // Size: 0x151

#endif
