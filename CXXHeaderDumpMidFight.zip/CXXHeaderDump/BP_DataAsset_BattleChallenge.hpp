#ifndef UE4SS_SDK_BP_DataAsset_BattleChallenge_HPP
#define UE4SS_SDK_BP_DataAsset_BattleChallenge_HPP

class UBP_DataAsset_BattleChallenge_C : public UPrimaryDataAsset
{
    FName ChallengeID;                                                                // 0x0030 (size: 0x8)
    TSoftClassPtr<UBP_BattleModifierBuff_Challenge_Base_C> BattleModifierClass;       // 0x0038 (size: 0x28)
    FText Name;                                                                       // 0x0060 (size: 0x10)
    FText Description;                                                                // 0x0070 (size: 0x10)
    TSoftObjectPtr<class UTexture2D> Icon;                                            // 0x0080 (size: 0x28)

    TSoftClassPtr<UBP_BattleModifierBuff_Challenge_Base_C> GetBattleModifierBuffClass();
    FText GetChallengeDisplayName();
    FName GetChallengeID();
    void GetChallengeBattleDataAtIndex(int32 NewParam);
    TMap<FName, FText> GetValidOptionDisplayNames();
}; // Size: 0xA8

#endif
