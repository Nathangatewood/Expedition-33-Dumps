#ifndef UE4SS_SDK_BP_BattleBuff_PerfectionManager_HPP
#define UE4SS_SDK_BP_BattleBuff_PerfectionManager_HPP

class UBP_BattleBuff_PerfectionManager_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    TMap<TEnumAsByte<EDamageReason::Type>, TEnumAsByte<EPerfectionReason::Type>> DamageReasonToPerfectionReason; // 0x0160 (size: 0x50)
    bool HasLostRankThisTurn;                                                         // 0x01B0 (size: 0x1)

    void ShouldKeepOnDeath(bool& Keep);
    void ProcessHeal(class UBP_BattleHeal_C* Heal, bool& DummyOut);
    void ProcessReceivedFinalDamages(class UBP_BattleDamages_C*& BattleDamages, int32 CurrentTurnHitCount, bool& Out);
    class UBP_PerfectionMechanicComponent_C* GetPerfectionComponent();
    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_PerfectionManager(int32 EntryPoint);
}; // Size: 0x1B1

#endif
