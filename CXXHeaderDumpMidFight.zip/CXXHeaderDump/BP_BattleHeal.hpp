#ifndef UE4SS_SDK_BP_BattleHeal_HPP
#define UE4SS_SDK_BP_BattleHeal_HPP

class UBP_BattleHeal_C : public UExtendedObject
{
    bool IsPrevented;                                                                 // 0x0028 (size: 0x1)
    double Amount;                                                                    // 0x0030 (size: 0x8)
    class UAC_jRPG_CharacterBattleStats_C* SourceCharacter;                           // 0x0038 (size: 0x8)
    class UAC_jRPG_CharacterBattleStats_C* TargetCharacter;                           // 0x0040 (size: 0x8)
    TEnumAsByte<EHealReason::Type> Reason;                                            // 0x0048 (size: 0x1)
    FString DebugReason;                                                              // 0x0050 (size: 0x10)
    TArray<FString> DebugModifierLogs;                                                // 0x0060 (size: 0x10)

    void GetDebugInfo(FString& DebugReason, TArray<FString>& DebugModifierLogs);
    void GetReason(TEnumAsByte<EHealReason::Type>& Reason);
    double GetCurrentAmount();
    void ModifyAmount(double NewAmount, FString DebugReason);
    void Init(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double Amount);
}; // Size: 0x70

#endif
