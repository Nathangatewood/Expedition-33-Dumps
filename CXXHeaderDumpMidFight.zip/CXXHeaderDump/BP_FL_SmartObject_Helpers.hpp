#ifndef UE4SS_SDK_BP_FL_SmartObject_Helpers_HPP
#define UE4SS_SDK_BP_FL_SmartObject_Helpers_HPP

class UBP_FL_SmartObject_Helpers_C : public UBlueprintFunctionLibrary
{

    void ComputeSearchBox(class APawn* Pawn, double SearchBoxExtent, class UObject* __WorldContext, FBox& Box);
}; // Size: 0x28

#endif
