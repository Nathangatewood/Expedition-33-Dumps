#ifndef UE4SS_SDK_BP_DataAsset_BattleHitSound_HPP
#define UE4SS_SDK_BP_DataAsset_BattleHitSound_HPP

class UBP_DataAsset_BattleHitSound_C : public UPrimaryDataAsset
{
    class USoundBase* BaseIntensity;                                                  // 0x0030 (size: 0x8)
    class USoundBase* HighIntensity;                                                  // 0x0038 (size: 0x8)

    void GetSoundForDamage(class UBP_BattleDamages_C* BattleDamage, class USoundBase*& Sound);
}; // Size: 0x40

#endif
