#ifndef UE4SS_SDK_BP_CharacterSkinBase_Lune_HPP
#define UE4SS_SDK_BP_CharacterSkinBase_Lune_HPP

class ABP_CharacterSkinBase_Lune_C : public ABP_CharacterSkinBase_C
{
    bool BaseSkin;                                                                    // 0x03A0 (size: 0x1)

}; // Size: 0x3A1

#endif
