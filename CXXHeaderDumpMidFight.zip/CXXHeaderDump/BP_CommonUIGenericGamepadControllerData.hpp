#ifndef UE4SS_SDK_BP_CommonUIGenericGamepadControllerData_HPP
#define UE4SS_SDK_BP_CommonUIGenericGamepadControllerData_HPP

class UBP_CommonUIGenericGamepadControllerData_C : public UCommonInputBaseControllerData
{
}; // Size: 0xF8

#endif
