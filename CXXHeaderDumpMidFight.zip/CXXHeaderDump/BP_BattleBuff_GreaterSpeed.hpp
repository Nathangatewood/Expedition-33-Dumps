#ifndef UE4SS_SDK_BP_BattleBuff_GreaterSpeed_HPP
#define UE4SS_SDK_BP_BattleBuff_GreaterSpeed_HPP

class UBP_BattleBuff_GreaterSpeed_C : public UBP_BattleBuff_Speed_C
{
}; // Size: 0x168

#endif
