#ifndef UE4SS_SDK_ABP_PostProcess_Hair_SCIEL_MessyBun_HPP
#define UE4SS_SDK_ABP_PostProcess_Hair_SCIEL_MessyBun_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_130;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_131;                                                         // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_132;                                        // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_26;       // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_25;       // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_24;       // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_23;       // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_22;       // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_21;       // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_20;       // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_19;       // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_18;       // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_17;       // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_16;       // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_15;       // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_14;       // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_13;       // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_12;       // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone;             // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_11;       // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_10;       // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_9;        // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_8;        // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_7;        // 0x0520 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_6;        // 0x0550 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_5;        // 0x0580 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_4;        // 0x05B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x05E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x0610 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_11;        // 0x0640 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x0670 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x06A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_10;        // 0x06D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_9;         // 0x0700 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_8;         // 0x0730 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_7;         // 0x0760 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_6;         // 0x0790 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_5;         // 0x07C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_4;         // 0x07F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0820 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_3;         // 0x0850 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_2;         // 0x0880 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_1;         // 0x08B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics;           // 0x08E0 (size: 0x30)

}; // Size: 0x910

class UABP_PostProcess_Hair_SCIEL_MessyBun_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0388 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_26;                           // 0x03B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_25;                           // 0x0B50 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_24;                           // 0x12F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_23;                           // 0x1A90 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_22;                           // 0x2230 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_21;                           // 0x29D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_20;                           // 0x3170 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_19;                           // 0x3910 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_18;                           // 0x40B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_17;                           // 0x4850 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_16;                           // 0x4FF0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_15;                           // 0x5790 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_14;                           // 0x5F30 (size: 0x7A0)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x66D0 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_13;                           // 0x66F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_12;                           // 0x6E90 (size: 0x7A0)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x7630 (size: 0xB8)
    FAnimNode_SpringBone AnimGraphNode_SpringBone;                                    // 0x76E8 (size: 0x168)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_11;                           // 0x7850 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_10;                           // 0x7FF0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_9;                            // 0x8790 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_8;                            // 0x8F30 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7;                            // 0x96D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6;                            // 0x9E70 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5;                            // 0xA610 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4;                            // 0xADB0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0xB550 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0xBCF0 (size: 0x7A0)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;                             // 0xC490 (size: 0x520)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0xC9B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0xD150 (size: 0x7A0)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;                             // 0xD8F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;                              // 0xDE10 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;                              // 0xE330 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;                              // 0xE850 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;                              // 0xED70 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;                              // 0xF290 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;                              // 0xF7B0 (size: 0x520)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0xFCD0 (size: 0x20)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;                              // 0xFCF0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;                              // 0x10210 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_1;                              // 0x10730 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;                                // 0x10C50 (size: 0x520)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_016080364EE9D18CC3ED279D0E871334();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_E59135FE4369FD97832F5096BC1F26E5();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_972314754FD14F86E2A399BFD4769C99();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_CA5CCEB147B0AFACE5FF1793BB198B7F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_201EE5334DF982798D1D90B6505C60B7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_A56AD06B489A2EBAF13C8BBFC04BFA46();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_16E866C349A90863FDDB508F8B0740AC();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_86B36BE6422689A72F7F52951E5E2212();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_69E2891B4B73BD596A1355A00F3B19BE();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_55505FA34AA222F847164F867F90571A();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_9F9854974D5615C4FAE7A58E231C41F6();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_C5C9E33C45357E218EF2D2A8B8216C9E();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_2D996AB246EC3D6D29A2768203D73AD1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_B07662BC4028B1F78A1811837D023E21();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_8D8D2C9F46E8A9FE778172A7A07CC36A();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_1AEE69D24D93BC3AA38078B67EBCC674();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_E9F689CA4214B1EAC18FF59CBA2D031F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_89B00D45480F8814B084C48C13FE7578();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_E3EFB6BD42F58672F336BBBE4CA0F8EA();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_D0E7CAE14A35217D710B8F8BF93589A4();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_BE4A92624DAB9E0F009AACBE74C84EB3();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_1DBAEB3941A030B6395B089A65E1F4C7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_0029AD984562DC8B4DB870A0064E6A89();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_E09056DF4F6B3F681DEE24B4E9CB9EFC();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_AE46290F418C21A928618AB762328C54();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_F90441FC47111917EE72F2A4EACDF1DA();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun_AnimGraphNode_KawaiiPhysics_1FE49D334F32BC6B1073E58DB0DAC5E9();
    void ExecuteUbergraph_ABP_PostProcess_Hair_SCIEL_MessyBun(int32 EntryPoint);
}; // Size: 0x11170

#endif
