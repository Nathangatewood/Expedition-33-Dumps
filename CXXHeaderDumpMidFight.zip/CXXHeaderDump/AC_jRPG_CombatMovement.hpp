#ifndef UE4SS_SDK_AC_jRPG_CombatMovement_HPP
#define UE4SS_SDK_AC_jRPG_CombatMovement_HPP

class UAC_jRPG_CombatMovement_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FVector InitialLocation;                                                          // 0x00A8 (size: 0x18)
    FRotator InitialRotation;                                                         // 0x00C0 (size: 0x18)
    FRotator TargetRotation;                                                          // 0x00D8 (size: 0x18)
    double RotationSpeed;                                                             // 0x00F0 (size: 0x8)
    bool RotationActive;                                                              // 0x00F8 (size: 0x1)
    FVector StartLocation;                                                            // 0x0100 (size: 0x18)
    FVector TargetLocation;                                                           // 0x0118 (size: 0x18)
    bool MovementActive;                                                              // 0x0130 (size: 0x1)
    bool DEBUG_Verbose;                                                               // 0x0131 (size: 0x1)
    class UAnimMontage* DEBUG_PreviousMontage;                                        // 0x0138 (size: 0x8)
    bool DEBUG_ShowMoveToDebug;                                                       // 0x0140 (size: 0x1)
    FDebugFloatHistory DEBUG_CurveHistory;                                            // 0x0148 (size: 0x20)
    double HACK_LinearCurveValue_5_2;                                                 // 0x0168 (size: 0x8)
    double HACK_CurveProgress_5_2;                                                    // 0x0170 (size: 0x8)
    FAC_jRPG_CombatMovement_COnMovementCompleted OnMovementCompleted;                 // 0x0178 (size: 0x10)
    void OnMovementCompleted(class UAC_jRPG_CombatMovement_C* MovementComponent);
    FTimerHandle MoveToTimeoutTimer;                                                  // 0x0188 (size: 0x8)
    bool PreviousPauseAnims;                                                          // 0x0190 (size: 0x1)
    int32 DEBUG_IncrementalArrows;                                                    // 0x0194 (size: 0x4)
    class UAnimMontage* LastPlayedMontage;                                            // 0x0198 (size: 0x8)
    class USF_BlueprintLatentAction* ActiveMovementLatentAction;                      // 0x01A0 (size: 0x8)
    FString Debug_CurrentReason;                                                      // 0x01A8 (size: 0x10)
    float LastCurveValue;                                                             // 0x01B8 (size: 0x4)

    void UpdateMovementProgression(float CurveValue);
    void CallAndResetMovementLatentAction();
    bool IsMovingTowardsInitialLocation();
    bool IsAtInitialLocation();
    bool IsAtInitialLocationOrAboutToBe();
    void StartMovementToCharacter(class ABP_jRPG_Character_Battle_Base_C* OtherCharacter, class UAnimMontage* MontageToPlay, float PlayRate, double Distance, double Angle, bool AbsoluteAngle, class USF_BlueprintLatentAction* LatentAction, FVector& TargetLocation);
    float GetCurrentCurveValue();
    void UpdateMovement();
    void QA_CheckExistingMoveToMontage(class UAnimMontage* NewMontage, FString Reason);
    void DoesLocationMatch(bool& Result);
    void DoesRotationMatch(bool& Result);
    void OnNotifyEnd_8640038743EBB9E2014362BE91EB35F9(FName NotifyName);
    void OnNotifyBegin_8640038743EBB9E2014362BE91EB35F9(FName NotifyName);
    void OnInterrupted_8640038743EBB9E2014362BE91EB35F9(FName NotifyName);
    void OnBlendOut_8640038743EBB9E2014362BE91EB35F9(FName NotifyName);
    void OnCompleted_8640038743EBB9E2014362BE91EB35F9(FName NotifyName);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void UpdateInitialTransform();
    void DEBUG_CVarChanged_ShowMoveToDebug(bool NewValue);
    void StartMovement(FVector TargetLocation, class UAnimMontage* MontageToPlay, float PlayRate, class USF_BlueprintLatentAction* LatentAction, FString DebugReason);
    void MovementCompleted();
    void OnMoveTimerExpired();
    void MoveToInitialLocation(class UAnimMontage* MontageToPlay, float PlayRate, class USF_BlueprintLatentAction* LatentAction, FString DebugReason);
    void OnMontageEnded(class UAnimMontage* Montage, bool bInterrupted);
    void ExecuteUbergraph_AC_jRPG_CombatMovement(int32 EntryPoint);
    void OnMovementCompleted__DelegateSignature(class UAC_jRPG_CombatMovement_C* MovementComponent);
}; // Size: 0x1BC

#endif
