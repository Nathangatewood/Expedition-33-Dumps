#ifndef UE4SS_SDK_BP_FL_CharacterCustomizationHelpers_HPP
#define UE4SS_SDK_BP_FL_CharacterCustomizationHelpers_HPP

class UBP_FL_CharacterCustomizationHelpers_C : public UBlueprintFunctionLibrary
{

    void GetCharacterHardcodedName(TEnumAsByte<E_CustomizationItemUser::Type> CustomizationItemUser, class UObject* __WorldContext, FName& CharacterHardcodedName);
    void NotEqual (CharacterCustomizationItemData)(FS_CharacterCustomizationItemData LeftCustomization, FS_CharacterCustomizationItemData RightCustomization, class UObject* __WorldContext, bool& Result);
    void Equal (CharacterCustomizationItemData)(FS_CharacterCustomizationItemData LeftCustomization, FS_CharacterCustomizationItemData RightCustomization, class UObject* __WorldContext, bool& Result);
    void NotEqual (CharacterCustomization)(FS_CharacterCustomization LeftCustomization, FS_CharacterCustomization RightCustomization, class UObject* __WorldContext, bool& Result);
    void Equal (CharacterCustomization)(FS_CharacterCustomization LeftCustomization, FS_CharacterCustomization RightCustomization, class UObject* __WorldContext, bool& Result);
    void IsValid (CharacterCustomizationItemData)(FS_CharacterCustomizationItemData CharacterCustomization, class UObject* __WorldContext, bool& Valid);
    void IsValid (CharacterCustomization)(FS_CharacterCustomization CharacterCustomization, class UObject* __WorldContext, bool& Valid);
}; // Size: 0x28

#endif
