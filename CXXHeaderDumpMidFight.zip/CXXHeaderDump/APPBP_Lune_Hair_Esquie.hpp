#ifndef UE4SS_SDK_APPBP_Lune_Hair_Esquie_HPP
#define UE4SS_SDK_APPBP_Lune_Hair_Esquie_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_106;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_107;                                                         // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_108;                                        // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_31;       // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_30;       // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_29;       // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_28;       // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_27;       // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_26;       // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_25;       // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_24;       // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_23;       // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_22;       // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_21;       // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_20;       // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_19;       // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_18;       // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_17;       // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_16;       // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_15;       // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose;                       // 0x0430 (size: 0x8)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0438 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_14;       // 0x0468 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_13;       // 0x0498 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_12;       // 0x04C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_11;       // 0x04F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_10;       // 0x0528 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_9;        // 0x0558 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_8;        // 0x0588 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_7;        // 0x05B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_6;        // 0x05E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0618 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_5;        // 0x0648 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_4;        // 0x0678 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x06A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x06D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x0708 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x0738 (size: 0x30)

}; // Size: 0x768

class UAPPBP_Lune_Hair_Esquie_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_31;                           // 0x0390 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_30;                           // 0x0B30 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_29;                           // 0x12D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_28;                           // 0x1A70 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_27;                           // 0x2210 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_26;                           // 0x29B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_25;                           // 0x3150 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_24;                           // 0x38F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_23;                           // 0x4090 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_22;                           // 0x4830 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_21;                           // 0x4FD0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_20;                           // 0x5770 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_19;                           // 0x5F10 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_18;                           // 0x66B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_17;                           // 0x6E50 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_16;                           // 0x75F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_15;                           // 0x7D90 (size: 0x7A0)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x8530 (size: 0x20)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x8550 (size: 0xB8)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x8608 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_14;                           // 0x8630 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_13;                           // 0x8DD0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_12;                           // 0x9570 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_11;                           // 0x9D10 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_10;                           // 0xA4B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_9;                            // 0xAC50 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_8;                            // 0xB3F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7;                            // 0xBB90 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6;                            // 0xC330 (size: 0x7A0)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0xCAD0 (size: 0x20)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5;                            // 0xCAF0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4;                            // 0xD290 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0xDA30 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0xE1D0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0xE970 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0xF110 (size: 0x7A0)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_CACCE3234DCE744E531EBF903FF98E5C();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_433E5D454D0FC0884BFBEC9665F9F91D();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_D66289824F20ED7C15121AA7CDC3C540();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_3E803B9B499DE9C7F3653E8F29B8C7A3();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_E28BCB9D48BF3C57E1660CB382F2D84F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_54DF11704A043122931AF79518C3256B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_7F2E8A764F83B8D0159138965135F01B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_1E334E7446459091A01806A8DC4B7BBA();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_5B02CA4D4A65DF5A71C707AC7B50D97B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_66E40E91441D189FCE2BDE85B2F02BA1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_154E8C14467E3129B609F5A907EB3EC2();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_EF7737A14099CC35FF4362A8A69DA4C8();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_AF4C9BBB40EC143E2771FEB900EBA3C1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_83E4C3C84F3B2901CB53E389FE03E615();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_C25ADB264C838F6F210291BC61AC0DD3();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_E43718EE4C341685FFBD92A00B88FBEA();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_962BB3EF45A28DE354A853ABE504CFA1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_1835140349F28877B5CE2FA8B425CA7A();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_F04547F841B680E28BA5FEB04CAA3F50();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_613BC6D34DF04ABB802B8F83F248BFB2();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_DBAC2245420557F8F6AC26A5B399F99B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_A72478E94A3DFA6E9032BBACA9561EC8();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_DF46076849C929919750CA979C0C502C();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_D0B08AC5482ED2F667096DADCA7E3FB0();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_93BF68FC452FA4872F8FEEA07ED8B90B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_C055453148FDB25B557D19BFAC447938();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_3EBACBBB401E861F9D06F4862ACF0B42();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_23DFB4684872BEC0585BC895B0D1FFDE();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_CF64103345AC5CA149EFF4A2EC70423E();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_98AE06C04DEFE83DAB4CFF9754015638();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_F2663D6542AB6EE3548CD389AF802EF7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_APPBP_Lune_Hair_Esquie_AnimGraphNode_KawaiiPhysics_7871303D42F6D6C39BF5EBBDB279ECE3();
    void ExecuteUbergraph_APPBP_Lune_Hair_Esquie(int32 EntryPoint);
}; // Size: 0xF8B0

#endif
