#ifndef UE4SS_SDK_BP_FreeAimProjectile_Base_HPP
#define UE4SS_SDK_BP_FreeAimProjectile_Base_HPP

class ABP_FreeAimProjectile_Base_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UArrowComponent* Arrow;                                                     // 0x0298 (size: 0x8)
    class USphereComponent* HitBox;                                                   // 0x02A0 (size: 0x8)
    FBP_FreeAimProjectile_Base_COnBattleCharacterHit OnBattleCharacterHit;            // 0x02A8 (size: 0x10)
    void OnBattleCharacterHit(class ABP_jRPG_Character_Battle_Base_C* Character, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, FHitResult HitResult, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
    class AActor* Caster;                                                             // 0x02B8 (size: 0x8)
    bool IsConsumed;                                                                  // 0x02C0 (size: 0x1)
    FVector LastLocation;                                                             // 0x02C8 (size: 0x18)
    TEnumAsByte<EDrawDebugTrace::Type> DEBUG_TraceDraw;                               // 0x02E0 (size: 0x1)
    FBP_FreeAimProjectile_Base_COnProjectileShotFinished OnProjectileShotFinished;    // 0x02E8 (size: 0x10)
    void OnProjectileShotFinished();

    void GetTargetPartFromCollidedComponent(class UPrimitiveComponent* PrimitiveComp, class UBP_FreeAimTargetPart_C*& TargetPart);
    void UserConstructionScript();
    void Consume();
    void OnCollision(class UObject* OtherActor, class UPrimitiveComponent* OtherComp, FHitResult HitResult);
    void TriggerRaycast();
    void Shoot();
    void RequestDestroy();
    void ExecuteUbergraph_BP_FreeAimProjectile_Base(int32 EntryPoint);
    void OnProjectileShotFinished__DelegateSignature();
    void OnBattleCharacterHit__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character, TEnumAsByte<EFreeAimBodyPartType::Type> BodyPart, FHitResult HitResult, class UBP_FreeAimTargetPart_C* TargetBodyPartBP);
}; // Size: 0x2F8

#endif
