#ifndef UE4SS_SDK_BP_Chest_Regular_HPP
#define UE4SS_SDK_BP_Chest_Regular_HPP

class ABP_Chest_Regular_C : public ABP_jRPG_InteractionObject_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* SM_FX_OptimizedPaintMesh;                             // 0x02F8 (size: 0x8)
    class UAudioComponent* AC_Loot;                                                   // 0x0300 (size: 0x8)
    class UAudioComponent* AC_Loot_Idle;                                              // 0x0308 (size: 0x8)
    class UStaticMeshComponent* Cube;                                                 // 0x0310 (size: 0x8)
    class UNiagaraComponent* FX_Chest;                                                // 0x0318 (size: 0x8)
    double LightIntensity;                                                            // 0x0320 (size: 0x8)
    FS_ChestFeedbackParameters DefaultChestFeedbackParameters;                        // 0x0328 (size: 0x68)
    FLinearColor ColorWhenOpening;                                                    // 0x0390 (size: 0x10)
    TSoftObjectPtr<class UForceFeedbackEffect> ForceFeedbackEffect;                   // 0x03A0 (size: 0x28)
    TMap<FName, int32> ItemsToLoot;                                                   // 0x03C8 (size: 0x50)
    FDataTableRowHandle ChestSetupHandle;                                             // 0x0418 (size: 0x10)
    TArray<FLootTableReference> LootTableReferences;                                  // 0x0428 (size: 0x10)
    double RollChanceMultiplier;                                                      // 0x0438 (size: 0x8)
    TEnumAsByte<E_LD_Annotation_Chest_LevelLocation::Type> ChestLocation;             // 0x0440 (size: 0x1)
    TEnumAsByte<E_LD_Annotation_Chest_RewardLevel::Type> ChestRewardLevel;            // 0x0441 (size: 0x1)
    FDataTableRowHandle OverrideLootParameters;                                       // 0x0448 (size: 0x10)
    bool PlayInWorldDialogueOnLoot;                                                   // 0x0458 (size: 0x1)

    void CanInteractWithMount(bool& CanInteract);
    void UpdateVisuals();
    void GetInteractionLocation(FVector& Location);
    void GetSectionsFromLootTableReferences(TArray<FLootTableReference>& LootTableReferences, TArray<FS_LootTableSection>& LootTableSections);
    void ComputeChestLootTableSections(TArray<FS_LootTableSection>& LootTableSections, double& RollChanceMultipler);
    void ComputePreviewChestItemType(TEnumAsByte<E_jRPG_ItemType::Type>& ItemType);
    void ComputeChestDominantItemType(TEnumAsByte<E_jRPG_ItemType::Type>& ItemType);
    int32 GetItemTypeScore(TEnumAsByte<E_jRPG_ItemType::Type> ItemType);
    void CompareItemTypesForFeedback(TEnumAsByte<E_jRPG_ItemType::Type> Existing, TEnumAsByte<E_jRPG_ItemType::Type> New, bool& IsBetter);
    int32 ComputeEncounterLevelOverride();
    void ComputeChestLootContext(FS_LootContext& S_LootContext);
    void RollChestItems(FS_LootContext LootContext, TMap<FName, int32>& ItemsToLoot);
    void UpdateFeedbackParameters(FS_ChestFeedbackParameters ChestFeedbackParameters);
    void GenerateObjectID();
    void UpdateFeedbackParametersFromLoot();
    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void GetInteractionPromptParams(FFPromptParams& PromptParams);
    bool FindDuplicateID();
    void AddItemsFromChestToInventory();
    void ConstructInteractionPopUpText(FText& PopUpText, FText& Item_Description1, class UTexture2D*& Item_Icon1, int32& Items_amount1);
    void UserConstructionScript();
    void OnLoaded_3A9C66874010891688933A9C2368EED3(class UObject* Loaded);
    void OnInteractionRequested(class ABP_jRPG_Character_World_C* InteractingWorldCharacter, bool Instant);
    void OnObjectInteractionStateLoaded(bool InteractionState);
    void ReceiveBeginPlay();
    void PlayForceFeedback();
    void ExecuteUbergraph_BP_Chest_Regular(int32 EntryPoint);
}; // Size: 0x459

#endif
