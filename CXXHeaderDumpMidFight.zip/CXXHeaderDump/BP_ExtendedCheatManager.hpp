#ifndef UE4SS_SDK_BP_ExtendedCheatManager_HPP
#define UE4SS_SDK_BP_ExtendedCheatManager_HPP

class UBP_ExtendedCheatManager_C : public UCheatManager
{
}; // Size: 0x88

#endif
