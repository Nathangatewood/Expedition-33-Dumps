#ifndef UE4SS_SDK_BP_DataAsset_Item_CharacterFace_HPP
#define UE4SS_SDK_BP_DataAsset_Item_CharacterFace_HPP

class UBP_DataAsset_Item_CharacterFace_C : public UBP_DataAsset_Item_CharacterCustomization_C
{
    TSoftClassPtr<ABP_CharacterFaceBase_C> CharacterFace;                             // 0x0038 (size: 0x28)

    void OnRemovedFromInventory(class UBP_jRPG_GI_Custom_C* GameInstance, class UAC_jRPG_InventoryManager_C* InventoryManager, FName ItemId);
    void UpdateCharacterCustomization_Internal(class UBP_CharacterData_C* CharacterData);
}; // Size: 0x60

#endif
