#ifndef UE4SS_SDK_BP_DataAsset_Item_MusicRecord_HPP
#define UE4SS_SDK_BP_DataAsset_Item_MusicRecord_HPP

class UBP_DataAsset_Item_MusicRecord_C : public UBP_DataAsset_Item_C
{
    FText Name;                                                                       // 0x0030 (size: 0x10)
    TSoftObjectPtr<class USoundBase> Music;                                           // 0x0040 (size: 0x28)

}; // Size: 0x68

#endif
