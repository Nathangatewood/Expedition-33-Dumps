#ifndef UE4SS_SDK_BP_DataAsset_DebugSaveGame_HPP
#define UE4SS_SDK_BP_DataAsset_DebugSaveGame_HPP

class UBP_DataAsset_DebugSaveGame_C : public UPrimaryDataAsset
{
    FFDebugSaveGame SaveData;                                                         // 0x0030 (size: 0x190)
    class UBP_DataAsset_DebugSaveGame_C* PreviousSaveInChain;                         // 0x01C0 (size: 0x8)

}; // Size: 0x1C8

#endif
