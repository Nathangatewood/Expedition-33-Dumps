#ifndef UE4SS_SDK_BP_CineCharacter_Main_HPP
#define UE4SS_SDK_BP_CineCharacter_Main_HPP

class ABP_CineCharacter_Main_C : public APawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0318 (size: 0x8)
    class USceneComponent* FocusPoint;                                                // 0x0320 (size: 0x8)
    class UBP_EyeEffectsControllerComponent_C* BP_EyeEffectsControllerComponent;      // 0x0328 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_foot_right; // 0x0330 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_foot_left; // 0x0338 (size: 0x8)
    class UStaticMeshComponent* SM_Hat;                                               // 0x0340 (size: 0x8)
    class UNiagaraComponent* FX_NPC_DustingSphere;                                    // 0x0348 (size: 0x8)
    class UNiagaraComponent* FX_Dusting;                                              // 0x0350 (size: 0x8)
    class ULiveLinkComponentController* LiveLinkComponentController;                  // 0x0358 (size: 0x8)
    class UBP_CinematicCharacterSkinComponent_C* BP_CinematicCharacterSkinComponent;  // 0x0360 (size: 0x8)
    class USpringArmComponent* SpringArmFront;                                        // 0x0368 (size: 0x8)
    class USpringArmComponent* SpringArmFace;                                         // 0x0370 (size: 0x8)
    class UStaticMeshComponent* Sphere_UsedForVelocity;                               // 0x0378 (size: 0x8)
    class USceneComponent* LookAtPosition;                                            // 0x0380 (size: 0x8)
    class USceneComponent* Attachment_Hand_L;                                         // 0x0388 (size: 0x8)
    class USceneComponent* Attachment_Hand_R;                                         // 0x0390 (size: 0x8)
    class UChildActorComponent* Weapons_Base;                                         // 0x0398 (size: 0x8)
    class UStaticMeshComponent* TargetLookAtSphere;                                   // 0x03A0 (size: 0x8)
    class ULODSyncComponent* LODSync;                                                 // 0x03A8 (size: 0x8)
    class UGroomComponent* Hair;                                                      // 0x03B0 (size: 0x8)
    class USkeletalMeshComponent* Haircut_SkeletalMesh;                               // 0x03B8 (size: 0x8)
    class UGroomComponent* Eyebrows;                                                  // 0x03C0 (size: 0x8)
    class UGroomComponent* Eyelashes;                                                 // 0x03C8 (size: 0x8)
    class UStaticMeshComponent* Haircut_StaticMesh;                                   // 0x03D0 (size: 0x8)
    class UGroomComponent* Mustache;                                                  // 0x03D8 (size: 0x8)
    class USceneComponent* Light_Pelvis_Attachment;                                   // 0x03E0 (size: 0x8)
    class UGroomComponent* Beard;                                                     // 0x03E8 (size: 0x8)
    class USkeletalMeshComponent* Face;                                               // 0x03F0 (size: 0x8)
    class UNiagaraComponent* FX_ArmRing2;                                             // 0x03F8 (size: 0x8)
    class UNiagaraComponent* FX_ArmRing1;                                             // 0x0400 (size: 0x8)
    class UNiagaraComponent* FX_ArmRing3;                                             // 0x0408 (size: 0x8)
    class USkeletalMeshComponent* Body;                                               // 0x0410 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0418 (size: 0x8)
    float SGXAlphaUp_Alpha_28DC9226460AA6CA41118B86734D803B;                          // 0x0420 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> SGXAlphaUp__Direction_28DC9226460AA6CA41118B86734D803B; // 0x0424 (size: 0x1)
    class UTimelineComponent* SGXAlphaUp;                                             // 0x0428 (size: 0x8)
    float SGXAlpha_Alpha_DD9523544B77DF0FEED64A9C66272505;                            // 0x0430 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> SGXAlpha__Direction_DD9523544B77DF0FEED64A9C66272505; // 0x0434 (size: 0x1)
    class UTimelineComponent* SGXAlpha;                                               // 0x0438 (size: 0x8)
    bool UseLookAtSphereSystem;                                                       // 0x0440 (size: 0x1)
    FTransform FaceWorldTransform;                                                    // 0x0450 (size: 0x60)
    class USoundWave* DialogSoundWave_Cache;                                          // 0x04B0 (size: 0x8)
    class AActor* ActorToLookAt;                                                      // 0x04B8 (size: 0x8)
    class USoundWave* Dialog_SoundWave;                                               // 0x04C0 (size: 0x8)
    FName HeadCenterBoneName;                                                         // 0x04C8 (size: 0x8)
    float FacialAnimationScale;                                                       // 0x04D0 (size: 0x4)
    TEnumAsByte<E_Expressions_Metahuman::Type> Expression_1;                          // 0x04D4 (size: 0x1)
    double Expression_1_Strength;                                                     // 0x04D8 (size: 0x8)
    TEnumAsByte<E_Expressions_Metahuman::Type> Expression_2;                          // 0x04E0 (size: 0x1)
    double Expression_2_Strength;                                                     // 0x04E8 (size: 0x8)
    double ManualFacialAnimAlpha;                                                     // 0x04F0 (size: 0x8)
    bool UseMocapHands;                                                               // 0x04F8 (size: 0x1)
    class ABP_WeaponSkin_C* Weapons;                                                  // 0x0500 (size: 0x8)
    FName Weapon R Socket Name;                                                       // 0x0508 (size: 0x8)
    FName Weapon L Socket Name;                                                       // 0x0510 (size: 0x8)
    TSubclassOf<class ABP_WeaponSkin_C> WeaponClass;                                  // 0x0518 (size: 0x8)
    bool Deprecated_Sequence_ShowWeapon;                                              // 0x0520 (size: 0x1)
    float EyeOcclusionOpacity;                                                        // 0x0524 (size: 0x4)
    double BreathingAlpha;                                                            // 0x0528 (size: 0x8)
    int32 TurningDirection;                                                           // 0x0530 (size: 0x4)
    bool UseAutomaticTurnInPlaceAnimations;                                           // 0x0534 (size: 0x1)
    double Speed;                                                                     // 0x0538 (size: 0x8)
    bool UseAutomaticMovementSystem;                                                  // 0x0540 (size: 0x1)
    class UBlendSpace* MovementBlendSpace;                                            // 0x0548 (size: 0x8)
    bool LookAt_OnlyMoveHead;                                                         // 0x0550 (size: 0x1)
    double LookAtInterpolationSpeed;                                                  // 0x0558 (size: 0x8)
    EAttachmentRule Location Rule;                                                    // 0x0560 (size: 0x1)
    FTransform Weapon_R_Offset;                                                       // 0x0570 (size: 0x60)
    FTransform Weapon_L_Offset;                                                       // 0x05D0 (size: 0x60)
    bool UseHandAdditive;                                                             // 0x0630 (size: 0x1)
    bool SequencerShowWeapons_New;                                                    // 0x0631 (size: 0x1)
    bool CinematicWeaponsAreSummoned;                                                 // 0x0632 (size: 0x1)
    double WeaponAppearTime;                                                          // 0x0638 (size: 0x8)
    double WeaponDisappearTime;                                                       // 0x0640 (size: 0x8)
    double DustingLevel;                                                              // 0x0648 (size: 0x8)
    double DirtLevel;                                                                 // 0x0650 (size: 0x8)
    double SweatLevel;                                                                // 0x0658 (size: 0x8)
    double TearsLevel;                                                                // 0x0660 (size: 0x8)
    double BloodLevel;                                                                // 0x0668 (size: 0x8)
    double ActivateFXThreshold;                                                       // 0x0670 (size: 0x8)
    FName BoneToAttachHaircutTo;                                                      // 0x0678 (size: 0x8)
    double TimeDilation;                                                              // 0x0680 (size: 0x8)
    TArray<UMeshComponent*> MeshesToAlter;                                            // 0x0688 (size: 0x10)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void GetGroomComponents(TArray<UGroomComponent*>& Array);
    void ResetWeaponsPosition(class ABP_WeaponSkin_C* weapon);
    void SetTimeDilation(double NewValue);
    void UpdateCharactersLODs(class UConfigurableGameUserSettings* NewParam);
    void UpdateCharacterVisualAlterationElements();
    void SetBloodLevel(double NewValue);
    void SetTearsLevel(double NewValue);
    void SetSweatLevel(double NewValue);
    void SetDirtLevel(double NewValue);
    void MakeGroomAppear();
    void MakeGroomDisappear();
    void SetDustingLevel(double NewParam);
    void GetAllElementsToDust(TArray<UMeshComponent*>& ElementsToDust);
    void SetSequence_ShowWeapon(bool NewValue);
    void SpawnWeaponAndSetSkin(bool IsVerso);
    void AttachWeaponToHands(class ABP_WeaponSkin_C* Weapons);
    void UserConstructionScript();
    void SGXAlpha__FinishedFunc();
    void SGXAlpha__UpdateFunc();
    void SGXAlphaUp__FinishedFunc();
    void SGXAlphaUp__UpdateFunc();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void PlayDialogWave();
    void BndEvt__BP_CineCharacter_Main_LiveLinkComponentController_K2Node_ComponentBoundEvent_0_LiveLinkTickDelegate__DelegateSignature(float DeltaTime);
    void ActivateFX();
    void ResetFX();
    void BndEvt__BP_CineCharacter_Main_BP_CinematicCharacterSkinComponent_K2Node_ComponentBoundEvent_1_OnCharacterCustomizationChanged__DelegateSignature(class UBP_CharacterSkinComponent_C* SkinComponent);
    void ExecuteUbergraph_BP_CineCharacter_Main(int32 EntryPoint);
}; // Size: 0x698

#endif
