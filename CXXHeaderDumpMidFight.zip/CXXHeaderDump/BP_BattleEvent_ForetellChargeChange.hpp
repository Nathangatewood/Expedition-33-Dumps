#ifndef UE4SS_SDK_BP_BattleEvent_ForetellChargeChange_HPP
#define UE4SS_SDK_BP_BattleEvent_ForetellChargeChange_HPP

class UBP_BattleEvent_ForetellChargeChange_C : public UBP_BattleEvent_Base_C
{
    TMap<TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type>, int32> InitialChargesDelta; // 0x0028 (size: 0x50)
    TMap<TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type>, int32> CurrentChargesDelta; // 0x0078 (size: 0x50)
    TEnumAsByte<EBattleContext::Type> Reason;                                         // 0x00C8 (size: 0x1)
    bool CanDoChanges;                                                                // 0x00C9 (size: 0x1)

    void EnsureCanChange();
    void ChangeChargeType(const TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type> PreviousChargeType, const TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type> NewChargeType, bool SumWithExistingCharges);
    void RemoveChargeType(const TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type> ChargeType);
    void SetChargeQuantity(const TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type> ChargeType, const int32 NewQuantity);
    void OverrideChargesDelta(TMap<TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type>, int32> NewCharges);
    TMap<TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type>, int32> GetCurrentChargesDelta();
    TEnumAsByte<EBattleContext::Type> GetChangeReason();
    void Finalize();
    void Init();
    TMap<TEnumAsByte<E_UniqueMechanic_Foretell_ChargeType::Type>, int32> GetInitialChargesDelta();
}; // Size: 0xCA

#endif
