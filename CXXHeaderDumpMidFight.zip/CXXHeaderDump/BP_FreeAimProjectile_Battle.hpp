#ifndef UE4SS_SDK_BP_FreeAimProjectile_Battle_HPP
#define UE4SS_SDK_BP_FreeAimProjectile_Battle_HPP

class ABP_FreeAimProjectile_Battle_C : public ABP_FreeAimProjectile_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02F8 (size: 0x8)
    class UNiagaraComponent* FX_Projectile;                                           // 0x0300 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0308 (size: 0x8)
    FVector LocationBuffer;                                                           // 0x0310 (size: 0x18)
    TEnumAsByte<EAttackType::Type> DesiredElementToShoot;                             // 0x0328 (size: 0x1)

    void ReceiveBeginPlay();
    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void Shoot();
    void ExecuteUbergraph_BP_FreeAimProjectile_Battle(int32 EntryPoint);
}; // Size: 0x329

#endif
