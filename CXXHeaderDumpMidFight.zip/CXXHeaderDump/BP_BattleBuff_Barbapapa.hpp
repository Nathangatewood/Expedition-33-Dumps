#ifndef UE4SS_SDK_BP_BattleBuff_Barbapapa_HPP
#define UE4SS_SDK_BP_BattleBuff_Barbapapa_HPP

class UBP_BattleBuff_Barbapapa_C : public UBP_BattleBuffInstance_C
{

    void ShouldKeepOnDeath(bool& Keep);
}; // Size: 0x151

#endif
