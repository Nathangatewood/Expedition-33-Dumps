#ifndef UE4SS_SDK_BP_FXForetellList_HPP
#define UE4SS_SDK_BP_FXForetellList_HPP

class UBP_FXForetellList_C : public UObject
{
    TArray<UNiagaraComponent*> ForetellList;                                          // 0x0028 (size: 0x10)

}; // Size: 0x38

#endif
