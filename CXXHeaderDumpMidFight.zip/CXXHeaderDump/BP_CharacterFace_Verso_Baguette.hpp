#ifndef UE4SS_SDK_BP_CharacterFace_Verso_Baguette_HPP
#define UE4SS_SDK_BP_CharacterFace_Verso_Baguette_HPP

class ABP_CharacterFace_Verso_Baguette_C : public ABP_CharacterFaceBase_Verso_C
{
    class UStaticMeshComponent* Lucien_Glasses_2;                                     // 0x02E0 (size: 0x8)

}; // Size: 0x2E8

#endif
