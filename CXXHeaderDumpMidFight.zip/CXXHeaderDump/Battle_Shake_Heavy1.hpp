#ifndef UE4SS_SDK_Battle_Shake_Heavy1_HPP
#define UE4SS_SDK_Battle_Shake_Heavy1_HPP

class UBattle_Shake_Heavy1_C : public UDefaultCameraShakeBase
{

    void NewFunction_0();
}; // Size: 0xE0

#endif
