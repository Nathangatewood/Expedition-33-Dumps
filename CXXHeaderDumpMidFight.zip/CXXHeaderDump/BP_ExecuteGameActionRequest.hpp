#ifndef UE4SS_SDK_BP_ExecuteGameActionRequest_HPP
#define UE4SS_SDK_BP_ExecuteGameActionRequest_HPP

class UBP_ExecuteGameActionRequest_C : public USF_BlueprintLatentAction
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0048 (size: 0x8)
    FGameAction_Wrapper GameActionWrapper;                                            // 0x0050 (size: 0x10)

    void OnGameActionExecuted(class UGameAction* GameAction);
    void StartOperation();
    void ExecuteUbergraph_BP_ExecuteGameActionRequest(int32 EntryPoint);
}; // Size: 0x60

#endif
