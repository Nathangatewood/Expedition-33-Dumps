#ifndef UE4SS_SDK_BP_CameraConfigBlender_HPP
#define UE4SS_SDK_BP_CameraConfigBlender_HPP

class UBP_CameraConfigBlender_C : public UExtendedObject
{
    class UCameraComponent* CameraComponent;                                          // 0x0028 (size: 0x8)
    class USpringArmComponent* SpringArmComponent;                                    // 0x0030 (size: 0x8)
    TArray<UBP_DataAsset_CameraConfig_C*> CameraConfigs;                              // 0x0038 (size: 0x10)
    FS_CameraConfig PreviousCameraConfig;                                             // 0x0048 (size: 0x88)
    double AccumulatedDeltaTime;                                                      // 0x00D0 (size: 0x8)
    FViewTargetTransitionParams CurrentBlendParameters;                               // 0x00D8 (size: 0x10)
    bool IsTransitionFinished;                                                        // 0x00E8 (size: 0x1)

    void OnCameraConfigStackChanged(FViewTargetTransitionParams TransitionParameters);
    void GetLastCameraConfig(class UBP_DataAsset_CameraConfig_C*& Output);
    void GetCurrentCameraConfigFromComponents(FS_CameraConfig& CameraConfig);
    void IsAppliedOnComponents(class UCameraComponent* CameraComponent, class USpringArmComponent* SpringArmComponent, bool& IsApplied);
    void IsTransitionDone(bool& Done);
    void ApplyCameraConfigInstant(FS_CameraConfig CameraConfig);
    void UpdateCameraConfigBlenderInternal(double DeltaSeconds);
    void ValidateCameraConfigBlender();
    void UpdateCameraConfigBlender(double DeltaSeconds);
    void RemoveCameraConfig(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void AddCameraConfig(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void SetupCameraConfig(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void DebugDrawSpringArmComponentConfig();
    void DebugDrawCameraComponent();
    void DebugDrawCameraConfigBlender();
    FString GetDebugString();
    void ComputeLerpCameraComponentConfig(double LerpValue, FS_CameraComponentConfig& CameraComponentConfig);
    FS_SpringArmComponentConfig ComputeLerpSpringArmComponentConfig(double LerpValue);
    FS_CameraConfig ComputeLerpCameraConfig();
    float ComputeLerpValue();
}; // Size: 0xE9

#endif
