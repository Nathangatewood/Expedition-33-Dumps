#ifndef UE4SS_SDK_BP_BattleBuff_GreaterSlow_HPP
#define UE4SS_SDK_BP_BattleBuff_GreaterSlow_HPP

class UBP_BattleBuff_GreaterSlow_C : public UBP_BattleBuff_Slow_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0160 (size: 0x8)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_GreaterSlow(int32 EntryPoint);
}; // Size: 0x168

#endif
