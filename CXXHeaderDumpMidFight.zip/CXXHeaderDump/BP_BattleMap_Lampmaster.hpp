#ifndef UE4SS_SDK_BP_BattleMap_Lampmaster_HPP
#define UE4SS_SDK_BP_BattleMap_Lampmaster_HPP

class ABP_BattleMap_Lampmaster_C : public ABP_BattleMap_C
{
}; // Size: 0x548

#endif
