#ifndef UE4SS_SDK_AutoLinkerPlugin_HPP
#define UE4SS_SDK_AutoLinkerPlugin_HPP

struct FALTColliderPath
{
    FVector Start;                                                                    // 0x0000 (size: 0x18)
    FVector End;                                                                      // 0x0018 (size: 0x18)
    FVector Direction;                                                                // 0x0030 (size: 0x18)
    TArray<FALTLinkReduced> linkInside;                                               // 0x0048 (size: 0x10)

}; // Size: 0x58

struct FALTLinkCapsuleMaker
{
    TArray<FVector> allPoints;                                                        // 0x0000 (size: 0x10)
    FVector _a;                                                                       // 0x0010 (size: 0x18)
    FVector _b;                                                                       // 0x0028 (size: 0x18)

}; // Size: 0x40

struct FALTLinkReduced
{
    FVector Start;                                                                    // 0x0000 (size: 0x18)
    FVector End;                                                                      // 0x0018 (size: 0x18)

}; // Size: 0x30

class AALT_AutoLinker : public AActor
{
    bool areLinkSpawned;                                                              // 0x0290 (size: 0x1)
    FALT_AutoLinkerOnLinkSpawned onLinkSpawned;                                       // 0x0298 (size: 0x10)
    void OnLinkSpawned();
    class AALT_NavLink* linker;                                                       // 0x02A8 (size: 0x8)
    class AALT_NavLink* linkerUp;                                                     // 0x02B0 (size: 0x8)
    FTimerHandle Timer;                                                               // 0x02B8 (size: 0x8)
    class UWorld* World;                                                              // 0x02C0 (size: 0x8)
    bool isDone;                                                                      // 0x02C8 (size: 0x1)
    class UNavigationSystemV1* navSystem;                                             // 0x02D0 (size: 0x8)
    int32 step;                                                                       // 0x02D8 (size: 0x4)
    int32 entityMaxHeight;                                                            // 0x02DC (size: 0x4)
    int32 entityMaxRadius;                                                            // 0x02E0 (size: 0x4)
    int32 minFallHeight;                                                              // 0x02E4 (size: 0x4)
    int32 maxFallHeight;                                                              // 0x02E8 (size: 0x4)
    int32 minJumpHeight;                                                              // 0x02EC (size: 0x4)
    int32 maxJumpHeight;                                                              // 0x02F0 (size: 0x4)
    int32 receptionPointDistFromLedge;                                                // 0x02F4 (size: 0x4)
    int32 blockingWallMinHeight;                                                      // 0x02F8 (size: 0x4)
    FVector Extent;                                                                   // 0x0300 (size: 0x18)
    TSubclassOf<class AALT_NavLink> _navLinkToSpawn;                                  // 0x0318 (size: 0x8)
    TArray<TEnumAsByte<EObjectTypeQuery>> groundLayer;                                // 0x0320 (size: 0x10)
    bool doBridges;                                                                   // 0x0330 (size: 0x1)
    int32 bridgesDeltaHeight;                                                         // 0x0334 (size: 0x4)
    int32 bridgesMaxLength;                                                           // 0x0338 (size: 0x4)
    bool canDebug;                                                                    // 0x033C (size: 0x1)
    TArray<FVector> allPoints;                                                        // 0x0340 (size: 0x10)

    void OnLinkSpawned__DelegateSignature();
    FVector GetDirection2D(const FVector& _start, const FVector& _end);
    void GenerateLinks();
    void GenerateLink();
    void ClearLink();
}; // Size: 0x350

class AALT_NavLink : public ANavLinkProxy
{
    int32 step;                                                                       // 0x02E0 (size: 0x4)
    bool canGenerateCollider;                                                         // 0x02E4 (size: 0x1)
    int32 radiusSphere;                                                               // 0x02E8 (size: 0x4)
    int32 capsuleHeightDelta;                                                         // 0x02EC (size: 0x4)
    float capsuleRefreshRate;                                                         // 0x02F0 (size: 0x4)
    float capsuleDistanceDelta;                                                       // 0x02F4 (size: 0x4)
    float capsuleNormalDelta;                                                         // 0x02F8 (size: 0x4)
    TArray<TEnumAsByte<EObjectTypeQuery>> enemyLayer;                                 // 0x0300 (size: 0x10)
    TArray<TEnumAsByte<EObjectTypeQuery>> groundLayer;                                // 0x0310 (size: 0x10)
    TArray<FALTColliderPath> allCollider;                                             // 0x0320 (size: 0x10)
    FColor DebugColor;                                                                // 0x0330 (size: 0x4)
    bool canDebug;                                                                    // 0x0334 (size: 0x1)
    FString linkName;                                                                 // 0x0338 (size: 0x10)
    FTimerHandle detectionTimer;                                                      // 0x0348 (size: 0x8)
    FALT_NavLinkOnEntityTriggerLink onEntityTriggerLink;                              // 0x0350 (size: 0x10)
    void OnEntityTriggerLink(class APawn* _hitPawn, FVector _destination);

    void OnEntityTriggerLink__DelegateSignature(class APawn* _hitPawn, FVector _destination);
    void CheckCollision();
    void BuildNav();
}; // Size: 0x360

#endif
