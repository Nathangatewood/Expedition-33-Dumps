#ifndef UE4SS_SDK_BP_DataAsset_Item_Shard_HPP
#define UE4SS_SDK_BP_DataAsset_Item_Shard_HPP

class UBP_DataAsset_Item_Shard_C : public UBP_DataAsset_Item_C
{
    FDataTableRowHandle BaseConsumableItemType;                                       // 0x0030 (size: 0x10)
    TArray<FDataTableRowHandle> ConsumableItemPerLevel;                               // 0x0040 (size: 0x10)
    FDataTableRowHandle UpgradeItemRow;                                               // 0x0050 (size: 0x10)

    void GetShardUpgradeCost(TArray<FS_ItemQuantity>& RequiredItems);
    void GetConsumablesList(TArray<FDataTableRowHandle>& ConsumableItemPerLevel);
    FDataTableRowHandle GetUpgradeLevelConsumableRow(int32 UpgradeLevel);
    void OnAddedToInventory(class UAC_jRPG_InventoryManager_C* InventoryManager, FName ItemId, FS_LootContext& LootContext, class UBP_GeneratedItemInfo_Base_C*& GeneratedItem);
}; // Size: 0x60

#endif
