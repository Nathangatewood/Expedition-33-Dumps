#ifndef UE4SS_SDK_ALS_CharacterBP_HPP
#define UE4SS_SDK_ALS_CharacterBP_HPP

class AALS_CharacterBP_C : public AALSCharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0960 (size: 0x8)
    class ULODSyncComponent* LODSync;                                                 // 0x0968 (size: 0x8)
    class UBP_FootstepVisualComponent_C* BP_FootstepVisualComponent;                  // 0x0970 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_right_foot; // 0x0978 (size: 0x8)
    class UBP_EnvironmentInteractorComponent_C* BP_EnvironmentInteractorComponent_left_foot; // 0x0980 (size: 0x8)
    class USceneComponent* Foot_R;                                                    // 0x0988 (size: 0x8)
    class USceneComponent* foot_l;                                                    // 0x0990 (size: 0x8)
    class USceneComponent* Hand_R;                                                    // 0x0998 (size: 0x8)
    class USceneComponent* Hand_L;                                                    // 0x09A0 (size: 0x8)
    class USceneComponent* Head;                                                      // 0x09A8 (size: 0x8)
    class UBP_FallDetectorComponent_C* BP_FallDetectorComponent;                      // 0x09B0 (size: 0x8)
    class UDebugComponent_C* DebugComponent;                                          // 0x09B8 (size: 0x8)
    class UMantleComponent_C* MantleComponent;                                        // 0x09C0 (size: 0x8)
    class UAnimMontage* LandRoll_Default;                                             // 0x09C8 (size: 0x8)
    class UAnimMontage* LandRoll_RH;                                                  // 0x09D0 (size: 0x8)
    class UAnimMontage* LandRoll_LH;                                                  // 0x09D8 (size: 0x8)
    class UAnimMontage* LandRoll_2H;                                                  // 0x09E0 (size: 0x8)
    class UAnimMontage* GetUpFront_Default;                                           // 0x09E8 (size: 0x8)
    class UAnimMontage* GetUpFront_LH;                                                // 0x09F0 (size: 0x8)
    class UAnimMontage* GetUpFront_2H;                                                // 0x09F8 (size: 0x8)
    class UAnimMontage* GetUpFront_RH;                                                // 0x0A00 (size: 0x8)
    class UAnimMontage* GetUpBack_Default;                                            // 0x0A08 (size: 0x8)
    class UAnimMontage* GetUpBack_LH;                                                 // 0x0A10 (size: 0x8)
    class UAnimMontage* GetUpBack_2H;                                                 // 0x0A18 (size: 0x8)
    class UAnimMontage* GetUpBack_RH;                                                 // 0x0A20 (size: 0x8)
    double RollAnimationThreshold;                                                    // 0x0A28 (size: 0x8)
    double MaxVelocityToDisablePostProcess;                                           // 0x0A30 (size: 0x8)

    double GetMaxVelocityToDisablePostProcess();
    void OnRollAnimationStopped(bool IsInterrupted);
    void OnRollAnimationStarted();
    void OnUpdateHeldObject();
    void OnUpdateHeldObjectAnimations();
    class UAnimMontage* GetRollAnimation();
    class UAnimMontage* GetGetUpAnimation(bool bRagdollFaceUpState);
    void OnNotifyEnd_C7B148F34DFE01EB080502B343933C4B(FName NotifyName);
    void OnNotifyBegin_C7B148F34DFE01EB080502B343933C4B(FName NotifyName);
    void OnInterrupted_C7B148F34DFE01EB080502B343933C4B(FName NotifyName);
    void OnBlendOut_C7B148F34DFE01EB080502B343933C4B(FName NotifyName);
    void OnCompleted_C7B148F34DFE01EB080502B343933C4B(FName NotifyName);
    void UpdateHeldObjectAnimations();
    void UpdateHeldObject();
    void AttachTorch();
    void UnattachTorch();
    void OnBreakfall();
    void PlayRollAnimation();
    void ExecuteUbergraph_ALS_CharacterBP(int32 EntryPoint);
}; // Size: 0xA38

#endif
