#ifndef UE4SS_SDK_BP_BattleFeedbackState_HPP
#define UE4SS_SDK_BP_BattleFeedbackState_HPP

class UBP_BattleFeedbackState_C : public UObject
{
    TArray<ABP_jRPG_Character_Battle_Base_C*> Heroes;                                 // 0x0028 (size: 0x10)
    TArray<ABP_jRPG_Character_Battle_Base_C*> Enemies;                                // 0x0038 (size: 0x10)
    TEnumAsByte<E_DefenseMoveType::Type> DefenseMoveType;                             // 0x0048 (size: 0x1)

    void IsSet(bool& IsSet);
    void Clear();
    void AddEntry(class ABP_jRPG_Character_Battle_Base_C* Hero, class ABP_jRPG_Character_Battle_Base_C* Enemy);
}; // Size: 0x49

#endif
