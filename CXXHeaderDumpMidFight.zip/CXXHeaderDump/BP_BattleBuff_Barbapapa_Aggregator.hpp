#ifndef UE4SS_SDK_BP_BattleBuff_Barbapapa_Aggregator_HPP
#define UE4SS_SDK_BP_BattleBuff_Barbapapa_Aggregator_HPP

class UBP_BattleBuff_Barbapapa_Aggregator_C : public UBP_BattleBuffInstance_AggregatorBase_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0178 (size: 0x8)
    TArray<UWBP_Buff_BarbapapaStackCounter_C*> FluffCounterWidgets;                   // 0x0180 (size: 0x10)
    TArray<UNiagaraComponent*> FX_Array;                                              // 0x0190 (size: 0x10)

    void ShouldKeepOnDeath(bool& Keep);
    void OnChildBuffInstanceRemoved();
    void OnChildBuffInstanceAdded();
    void OnChildBuffInstanceStackChanged(class UBP_BattleBuffInstance_C* BuffInstance);
    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void DoubleStack();
    void RefreshCounterWidget();
    void InitializeCustomBuffWidget(class UWBP_jRPG_BuffSlot_C* BuffWidget, bool& DummyOut);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void DeactivateVFX();
    void ExecuteUbergraph_BP_BattleBuff_Barbapapa_Aggregator(int32 EntryPoint);
}; // Size: 0x1A0

#endif
