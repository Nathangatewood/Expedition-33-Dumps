#ifndef UE4SS_SDK_BP_CharacterSkinBase_Monoco_HPP
#define UE4SS_SDK_BP_CharacterSkinBase_Monoco_HPP

class ABP_CharacterSkinBase_Monoco_C : public ABP_CharacterSkinBase_C
{
}; // Size: 0x3A0

#endif
