#ifndef UE4SS_SDK_BP_ExplorationPromptHintPool_HPP
#define UE4SS_SDK_BP_ExplorationPromptHintPool_HPP

class UBP_ExplorationPromptHintPool_C : public UExtendedObject
{
    TMap<UWBP_ExplorationPromptHint_C*, FVector> WidgetByWorldPosition;               // 0x0028 (size: 0x50)
    TArray<UWBP_ExplorationPromptHint_C*> AvailableWidgets;                           // 0x0078 (size: 0x10)

    void OnExplorationPromptHintDisappeared(class UWBP_ExplorationPromptHint_C* Widget);
    void AddExplorationPromptHintAtWorldLocation(const class UWBP_ExplorationPromptHint_C*& Widget, const FVector& WorldLocation);
    void DestroyAllExplorationPromptHints();
    void UpdateExplorationPromptHints();
    void ReleaseExplorationPromptHint(class UWBP_ExplorationPromptHint_C* Widget);
    void CreateExplorationPromptHint(FVector WorldPosition, class UWBP_ExplorationPromptHint_C*& Widget);
}; // Size: 0x88

#endif
