#ifndef UE4SS_SDK_BP_DataAsset_Footsteps_HPP
#define UE4SS_SDK_BP_DataAsset_Footsteps_HPP

class UBP_DataAsset_Footsteps_C : public UPrimaryDataAsset
{
    TMap<TEnumAsByte<EPhysicalSurface>, USoundBase*> Footsteps;                       // 0x0030 (size: 0x50)

}; // Size: 0x80

#endif
