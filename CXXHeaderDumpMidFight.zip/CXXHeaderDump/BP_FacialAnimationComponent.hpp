#ifndef UE4SS_SDK_BP_FacialAnimationComponent_HPP
#define UE4SS_SDK_BP_FacialAnimationComponent_HPP

class UBP_FacialAnimationComponent_C : public UActorComponent
{
    bool Talking;                                                                     // 0x00A0 (size: 0x1)
    TEnumAsByte<E_FacialExpressionsNPC::Type> FacialExpression;                       // 0x00A1 (size: 0x1)
    TEnumAsByte<E_Facial_LookAt::Type> EyesLook;                                      // 0x00A2 (size: 0x1)

}; // Size: 0xA3

#endif
