#ifndef UE4SS_SDK_BP_EnemyBattle_GaultT2_HPP
#define UE4SS_SDK_BP_EnemyBattle_GaultT2_HPP

class ABP_EnemyBattle_GaultT2_C : public ABP_EnemyBattle_Gault_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x1838 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x1840 (size: 0x8)
    class UBP_FreeAimTargetPart_C* BP_FreeAimTargetPart_Body;                         // 0x1848 (size: 0x8)

    void OnDeath(bool DeathByCounter);
    void PerformActionByAI();
    void ExecuteUbergraph_BP_EnemyBattle_GaultT2(int32 EntryPoint);
}; // Size: 0x1850

#endif
