#ifndef UE4SS_SDK_BP_DataAsset_FootstepVisualProfile_HPP
#define UE4SS_SDK_BP_DataAsset_FootstepVisualProfile_HPP

class UBP_DataAsset_FootstepVisualProfile_C : public UPrimaryDataAsset
{
    FS_FootStepVisual FootStepVisualLeft;                                             // 0x0030 (size: 0x28)
    FS_FootStepVisual FootStepVisualRight;                                            // 0x0058 (size: 0x28)

}; // Size: 0x80

#endif
