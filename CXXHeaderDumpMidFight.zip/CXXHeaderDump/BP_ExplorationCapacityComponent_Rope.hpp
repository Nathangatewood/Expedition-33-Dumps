#ifndef UE4SS_SDK_BP_ExplorationCapacityComponent_Rope_HPP
#define UE4SS_SDK_BP_ExplorationCapacityComponent_Rope_HPP

class UBP_ExplorationCapacityComponent_Rope_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class ABP_GPE_Rope_C* CurrentRope;                                                // 0x00A8 (size: 0x8)
    TEnumAsByte<E_RopeMovementDirection::Type> CurrentDirection;                      // 0x00B0 (size: 0x1)
    FBP_ExplorationCapacityComponent_Rope_COnRopeMovementBegin OnRopeMovementBegin;   // 0x00B8 (size: 0x10)
    void OnRopeMovementBegin(class ABP_GPE_Rope_C* Rope, TEnumAsByte<E_RopeMovementDirection::Type> Direction);
    FBP_ExplorationCapacityComponent_Rope_COnRopeMovementEnd OnRopeMovementEnd;       // 0x00C8 (size: 0x10)
    void OnRopeMovementEnd(class ABP_GPE_Rope_C* Rope, TEnumAsByte<E_RopeMovementDirection::Type> Direction);
    double MoveSpeedMax;                                                              // 0x00D8 (size: 0x8)
    double MoveAcceleration;                                                          // 0x00E0 (size: 0x8)
    class UCurveFloat* MoveCurve;                                                     // 0x00E8 (size: 0x8)
    class UCurveFloat* TransitionMoveCurve;                                           // 0x00F0 (size: 0x8)
    double DistanceToStartExitTransitionTopToBottom;                                  // 0x00F8 (size: 0x8)
    double AccumulatedDeltaTime;                                                      // 0x0100 (size: 0x8)
    double ComputedTimeRatio;                                                         // 0x0108 (size: 0x8)
    FVector TargetLocation;                                                           // 0x0110 (size: 0x18)
    FRotator TargetRotation;                                                          // 0x0128 (size: 0x18)
    TEnumAsByte<E_RopeMovementStep::Type> CurrentStep;                                // 0x0140 (size: 0x1)
    TSubclassOf<class UCameraShakeBase> CameraShakeWhileMoving;                       // 0x0148 (size: 0x8)
    TSubclassOf<class UCameraShakeBase> CameraShakeOnStart;                           // 0x0150 (size: 0x8)
    class UNiagaraComponent* FX_LinkToRope;                                           // 0x0158 (size: 0x8)
    class UNiagaraComponent* FX_InteractionWhileUsingRope;                            // 0x0160 (size: 0x8)
    class ABP_PP_DistortionParameterControl_C* DistortionController;                  // 0x0168 (size: 0x8)
    class UAudioComponent* AudioWhileUsingRope;                                       // 0x0170 (size: 0x8)
    FSF_ReferenceCounterHandle RopeInputLockBlockerReference;                         // 0x0178 (size: 0x20)
    FName AggroLockName;                                                              // 0x0198 (size: 0x8)
    double CurrentMoveSpeed;                                                          // 0x01A0 (size: 0x8)

    double GetAlphaForEnterTransition();
    void SetRopeMovementCurrentStep(TEnumAsByte<E_RopeMovementStep::Type> step);
    void ComputeCurrentMoveSpeed(double DeltaSeconds);
    void StopAllEffects();
    void PlayLinkToRopeFX();
    void PlayForceFeedback();
    void PlayCameraEffects();
    void ResetRuntimeVariables();
    void StopRopeMovement();
    void OnExitTransitionAnimationDone();
    bool ShouldExitMovingAlongRope();
    void UpdateMovement(double DeltaSeconds);
    void UpdateExitTransition(double DeltaSeconds);
    void GetCurrentRopeStep(TEnumAsByte<E_RopeMovementStep::Type>& CurrentStep);
    void OnEnterTransitionAnimationDone();
    void UpdateEnterTransition(double DeltaSeconds);
    void UpdateMovingAlongRope(double DeltaSeconds);
    void GetCurrentRopeDirection(TEnumAsByte<E_RopeMovementDirection::Type>& CurrentDirection);
    bool IsPerformingMovement();
    void ComputeTimeRatio();
    void AccumulateDeltaTime(float DeltaSeconds);
    void UpdateActorRotation();
    void UpdateActorLocation();
    void UpdateRopeMovement(float DeltaSeconds);
    void StartRopeMovement();
    void StartMovementWithRope(class ABP_GPE_Rope_C* Rope, TEnumAsByte<E_RopeMovementDirection::Type> Direction);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_ExplorationCapacityComponent_Rope(int32 EntryPoint);
    void OnRopeMovementEnd__DelegateSignature(class ABP_GPE_Rope_C* Rope, TEnumAsByte<E_RopeMovementDirection::Type> Direction);
    void OnRopeMovementBegin__DelegateSignature(class ABP_GPE_Rope_C* Rope, TEnumAsByte<E_RopeMovementDirection::Type> Direction);
}; // Size: 0x1A8

#endif
