#ifndef UE4SS_SDK_BP_BattleDamageBuilder_HPP
#define UE4SS_SDK_BP_BattleDamageBuilder_HPP

class UBP_BattleDamageBuilder_C : public UObject
{
    class UAC_jRPG_CharacterBattleStats_C* TargetCharacterStats;                      // 0x0028 (size: 0x8)
    double INPUT_CriticalHitDamageMultiplier;                                         // 0x0030 (size: 0x8)
    double INPUT_CriticalHitChanceModifier;                                           // 0x0038 (size: 0x8)
    FVector INPUT_HitLocationOverride;                                                // 0x0040 (size: 0x18)
    double INPUT_BreakBarMultiplier;                                                  // 0x0058 (size: 0x8)
    TEnumAsByte<EAttackType::Type> AttackElement;                                     // 0x0060 (size: 0x1)
    double AttackPowerMultiplier;                                                     // 0x0068 (size: 0x8)
    double FinalDamageMultiplier;                                                     // 0x0070 (size: 0x8)
    TScriptInterface<class IIBattleDamageSource_C> DamageSource;                      // 0x0078 (size: 0x10)
    TEnumAsByte<EDamageReason::Type> DamageReason;                                    // 0x0088 (size: 0x1)
    double INPUT_RegularHitChanceModifier;                                            // 0x0090 (size: 0x8)
    bool INPUT_UseDefenseAsAttackPower;                                               // 0x0098 (size: 0x1)
    FString DebugReason;                                                              // 0x00A0 (size: 0x10)
    double StraightDamage;                                                            // 0x00B0 (size: 0x8)
    bool INPUT_Deathtouch;                                                            // 0x00B8 (size: 0x1)
    FText FeedbackReasonText;                                                         // 0x00C0 (size: 0x10)
    FLinearColor FeedbackReasonColor;                                                 // 0x00D0 (size: 0x10)
    class USoundBase* HitSoundOverride;                                               // 0x00E0 (size: 0x8)
    bool IgnoreMarkedRemoval;                                                         // 0x00E8 (size: 0x1)
    bool IgnoreShields;                                                               // 0x00E9 (size: 0x1)
    bool ForcedCriticalHit;                                                           // 0x00EA (size: 0x1)
    bool BypassModifiers;                                                             // 0x00EB (size: 0x1)

    bool ShouldBypassModifiers();
    bool GetForcedCriticalHit();
    void SetForcedCriticalHit();
    bool GetIgnoreShields();
    void SetIgnoreShields();
    bool GetIgnoreMarkedRemoval();
    void SetIgnoreMarkedRemoval();
    class USoundBase* GetHitSoundOverride();
    void SetHitSoundOverride(class USoundBase* HitSoundOverride);
    bool HasFeedbackReason();
    void GetFeedbackReason(FText& FeedbackReasonText, FLinearColor& FeedbackReasonColor);
    void SetFeedbackReason(FText Text, FLinearColor Color);
    bool IsDeathtouch();
    void SetAsDeathtouch();
    void NullifyBaseDamage(FString Reason);
    void AddStraightDamageAsMaxHPPercent(double Percent, bool NullifyBaseDamage, bool KeepModifiersOnNullify, FString Reason);
    double GetStraightDamage();
    void AddStraightDamageFlat(double FlatValue, bool NullifyBaseDamage, bool KeepModifiersOnNullify, FString Reason);
    void AddBreakBarDamageMultiplier(double Multiplier, FString Reason);
    void GetBreakBarMultiplier(double& INPUT_BreakBarMultiplier);
    void UseDefenseAsAttackPower();
    double GetRegularHitChanceModifier();
    void DealDamages(bool& HasHit, class UBP_BattleDamages_C*& BattleDamages);
    double GetCriticalHitChanceModifier();
    double GetCriticalHitDamageMultiplier();
    void GetDamageSource(TScriptInterface<class IIBattleDamageSource_C>& DamageSource);
    void GetAttackElement(TEnumAsByte<EAttackType::Type>& AttackElement);
    void GetDamageReason(TEnumAsByte<EDamageReason::Type>& DamageReason);
    double GetFinalDamageMultiplier();
    double GetAttackPowerMultiplier();
    void AddRegularHitChanceModifier(double Multiplier, FString Reason);
    void AddCriticalHitDamageMultiplier(double Multiplier, FString Reason);
    void AddCriticalHitChanceModifier(double Modifier, FString Reason);
    void AddFinalDamageMultiplier(double Multiplier, FString Reason);
    void LoadFromData();
}; // Size: 0xEC

#endif
