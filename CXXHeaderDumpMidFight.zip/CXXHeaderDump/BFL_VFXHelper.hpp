#ifndef UE4SS_SDK_BFL_VFXHelper_HPP
#define UE4SS_SDK_BFL_VFXHelper_HPP

class UBFL_VFXHelper_C : public UBlueprintFunctionLibrary
{

    class UNiagaraComponent* SpawnSystemAttachedWithParameters(class UNiagaraSystem* SystemTemplate, class USceneComponent* AttachToComponent, FName AttachPointName, FVector Location, FRotator Rotation1, TEnumAsByte<EAttachLocation::Type> LocationType, bool bAutoDestroy, bool bAutoActivate, float  Size, FLinearColor  Color, class UObject* __WorldContext);
    void SpawnSystemAtLocationWithParameters(class UNiagaraSystem* SystemTemplate, FVector Location, FRotator Rotation, FVector Scale, bool bAutoDestroy, bool bAutoActivate, float Size, FLinearColor Color, class UObject* __WorldContext, class UNiagaraComponent*& Return Value);
}; // Size: 0x28

#endif
