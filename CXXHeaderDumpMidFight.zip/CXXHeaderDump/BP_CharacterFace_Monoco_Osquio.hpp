#ifndef UE4SS_SDK_BP_CharacterFace_Monoco_Osquio_HPP
#define UE4SS_SDK_BP_CharacterFace_Monoco_Osquio_HPP

class ABP_CharacterFace_Monoco_Osquio_C : public ABP_CharacterFaceBase_Monoco_C
{
    class UStaticMeshComponent* SM_MonoSquio_head_low;                                // 0x02E0 (size: 0x8)

}; // Size: 0x2E8

#endif
