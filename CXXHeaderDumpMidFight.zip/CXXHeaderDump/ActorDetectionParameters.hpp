#ifndef UE4SS_SDK_ActorDetectionParameters_HPP
#define UE4SS_SDK_ActorDetectionParameters_HPP

struct FActorDetectionParameters
{
    class AActor* ActorToDetect_4_E903F8294B26E7E64905BDAE30E9337B;                   // 0x0000 (size: 0x8)
    FVector DeltaVectorWithActor_10_1F3BDAA0495A1AE20FB0CEB3761A409C;                 // 0x0008 (size: 0x18)
    double DistanceToActor_9_6B5DDB644A994E4B2CE38BBB94C0FB70;                        // 0x0020 (size: 0x8)

}; // Size: 0x28

#endif
