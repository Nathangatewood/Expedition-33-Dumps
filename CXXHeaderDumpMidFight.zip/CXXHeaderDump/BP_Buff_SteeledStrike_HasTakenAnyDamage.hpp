#ifndef UE4SS_SDK_BP_Buff_SteeledStrike_HasTakenAnyDamage_HPP
#define UE4SS_SDK_BP_Buff_SteeledStrike_HasTakenAnyDamage_HPP

class UBP_Buff_SteeledStrike_HasTakenAnyDamage_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    bool HasTakenDamage;                                                              // 0x0160 (size: 0x1)

    void GetHasTakenDamage(bool& HasTakenDamage);
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, double ReceivedDamages, class UBP_BattleDamages_C* BattleDamages);
    void ExecuteUbergraph_BP_Buff_SteeledStrike_HasTakenAnyDamage(int32 EntryPoint);
}; // Size: 0x161

#endif
