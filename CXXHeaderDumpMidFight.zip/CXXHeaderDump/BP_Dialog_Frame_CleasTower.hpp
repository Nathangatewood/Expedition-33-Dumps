#ifndef UE4SS_SDK_BP_Dialog_Frame_CleasTower_HPP
#define UE4SS_SDK_BP_Dialog_Frame_CleasTower_HPP

class ABP_Dialog_Frame_CleasTower_C : public ABP_Dialogue_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0338 (size: 0x8)

    void StartDialog();
    void ExecuteUbergraph_BP_Dialog_Frame_CleasTower(int32 EntryPoint);
}; // Size: 0x340

#endif
