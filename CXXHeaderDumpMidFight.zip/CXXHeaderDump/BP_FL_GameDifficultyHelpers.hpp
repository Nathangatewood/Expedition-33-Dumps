#ifndef UE4SS_SDK_BP_FL_GameDifficultyHelpers_HPP
#define UE4SS_SDK_BP_FL_GameDifficultyHelpers_HPP

class UBP_FL_GameDifficultyHelpers_C : public UBlueprintFunctionLibrary
{

    class UDataTable* GetArchetypeScalingDataTableForBattle(class UBP_DataAsset_EnemyBattleArchetype_C* EnemyArchetype, class UAC_jRPG_BattleManager_C* BattleManager, class UObject* __WorldContext);
    TEnumAsByte<E_GameDifficulty::Type> GetGameDifficulty(class UObject* __WorldContext);
    class UBP_GameDifficultyManager_C* GetDifficultyManager(class UObject* __WorldContext);
}; // Size: 0x28

#endif
