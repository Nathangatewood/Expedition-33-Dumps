#ifndef UE4SS_SDK_BP_EntitlementDataUpdaterBase_HPP
#define UE4SS_SDK_BP_EntitlementDataUpdaterBase_HPP

class UBP_EntitlementDataUpdaterBase_C : public UPrimaryDataAsset
{

    void RemoveEntitlementData(class UGameInstance* GameInstance, class APlayerController* PlayerController);
    void ApplyEntitlementData(class UGameInstance* GameInstance, class APlayerController* PlayerController);
}; // Size: 0x30

#endif
