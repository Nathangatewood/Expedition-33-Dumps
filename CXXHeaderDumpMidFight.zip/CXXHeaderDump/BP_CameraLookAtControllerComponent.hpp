#ifndef UE4SS_SDK_BP_CameraLookAtControllerComponent_HPP
#define UE4SS_SDK_BP_CameraLookAtControllerComponent_HPP

class UBP_CameraLookAtControllerComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FBP_CameraLookAtControllerComponent_COnLookAtStarted OnLookAtStarted;             // 0x00A8 (size: 0x10)
    void OnLookAtStarted();
    FBP_CameraLookAtControllerComponent_COnLookAtFinished OnLookAtFinished;           // 0x00B8 (size: 0x10)
    void OnLookAtFinished();
    FS_CameraLookAtRequest LookAtRequest;                                             // 0x00C8 (size: 0x30)
    class AActor* ActorToLookAtReference;                                             // 0x00F8 (size: 0x8)
    class ABP_jRPG_Character_World_C* OwnerAsCharacterWorld;                          // 0x0100 (size: 0x8)
    FS_LookAtCameraParameters InitialCameraValues;                                    // 0x0108 (size: 0x28)
    FRotator InitialCameraRotation;                                                   // 0x0130 (size: 0x18)
    FRotator InitialSpringArmRotation;                                                // 0x0148 (size: 0x18)
    double AccumulatedTime;                                                           // 0x0160 (size: 0x8)
    double TransitionCurveMaxTime;                                                    // 0x0168 (size: 0x8)
    bool HasCameraInputsEnable;                                                       // 0x0170 (size: 0x1)
    TEnumAsByte<E_LookAtUpdateStep::Type> LookAtUpdateStep;                           // 0x0171 (size: 0x1)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void UpdateLookAtTransition();
    void UpdateLookAtRotation(double Alpha);
    double ComputeAlpha();
    void UpdateAccumulatedTime(double DeltaSeconds);
    void UpdateLookAtUpdateStep();
    void UpdateLookAt(double DeltaSeconds);
    void FinishLookAt();
    void SetCameraInputsEnable(bool Enable);
    void PrepareCameraForLookAtAndCacheValues();
    void PrepareForLookAt();
    bool IsPerformingLookAt();
    void IsLookAtRequestValid(FS_CameraLookAtRequest LookAtRequest, bool& IsValid);
    void OnLoaded_E108BA93448EE7FC170BF68270B157D0(class UObject* Loaded);
    void ReceiveTick(float DeltaSeconds);
    void RequestLookAt(FS_CameraLookAtRequest LookAtRequest);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_CameraLookAtControllerComponent(int32 EntryPoint);
    void OnLookAtFinished__DelegateSignature();
    void OnLookAtStarted__DelegateSignature();
}; // Size: 0x172

#endif
