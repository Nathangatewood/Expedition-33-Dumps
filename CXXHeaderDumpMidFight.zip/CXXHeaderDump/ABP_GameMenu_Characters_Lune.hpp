#ifndef UE4SS_SDK_ABP_GameMenu_Characters_Lune_HPP
#define UE4SS_SDK_ABP_GameMenu_Characters_Lune_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x1718

class UABP_GameMenu_Characters_Lune_C : public UABP_GameMenu_Characters_C
{
}; // Size: 0x1F31

#endif
