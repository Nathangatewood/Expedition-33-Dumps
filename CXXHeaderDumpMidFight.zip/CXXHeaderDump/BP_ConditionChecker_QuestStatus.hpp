#ifndef UE4SS_SDK_BP_ConditionChecker_QuestStatus_HPP
#define UE4SS_SDK_BP_ConditionChecker_QuestStatus_HPP

class UBP_ConditionChecker_QuestStatus_C : public UBP_ConditionChecker_C
{
    FQuestDataTableRowHandle Quest;                                                   // 0x0060 (size: 0x10)
    TEnumAsByte<E_QuestStatus::Type> Status;                                          // 0x0070 (size: 0x1)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x71

#endif
