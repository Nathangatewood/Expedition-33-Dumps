#ifndef UE4SS_SDK_BP_Dialogue_HPP
#define UE4SS_SDK_BP_Dialogue_HPP

class ABP_Dialogue_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UEnvelopeFollowerListener* EnvelopeFollowerListener;                        // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    bool IsComplete;                                                                  // 0x02A8 (size: 0x1)
    class AActor* InterlocutorActor;                                                  // 0x02B0 (size: 0x8)
    class ABP_jRPG_NPC_Dialog_C* NPC;                                                 // 0x02B8 (size: 0x8)
    TSoftObjectPtr<class ABP_BattleMap_C> BattleMap;                                  // 0x02C0 (size: 0x28)
    int32 ForcedDialogueStage;                                                        // 0x02E8 (size: 0x4)
    FBP_Dialogue_COnDialogueFinished OnDialogueFinished;                              // 0x02F0 (size: 0x10)
    void OnDialogueFinished();
    TArray<FS_jRPG_PartySlot> PreviousParty;                                          // 0x0300 (size: 0x10)
    FGuid DialogueGUID;                                                               // 0x0310 (size: 0x10)
    bool CanInterruptDialogue;                                                        // 0x0320 (size: 0x1)
    FS_DialogueParameters Dialogue Parameters;                                        // 0x0324 (size: 0x8)
    class USourceEffectEnvelopeFollowerPreset* EnvelopePreset;                        // 0x0330 (size: 0x8)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void GetPlayerCharacterWorld(class ABP_jRPG_Character_World_C*& AsBP J RPG Character World);
    void GetDefaultAudioTriggerForDialogue(TEnumAsByte<E_Dialogue_AudioTrigger::Type> AudioTrigger, FName& AudioTriggerName);
    void ActivateDialogue();
    void GetDialogueParameters(FS_DialogueParameters& DialogueParameters);
    void SetDialogueParameters(FS_DialogueParameters DialogueParameters);
    void ResetNPCAnim();
    void GetDialogueStage(int32& DialogueStage);
    void SetDialogueStage(int32 DialogueStage);
    void RestoreBattleParty();
    void SetBattleParty(TArray<UBP_CharacterData_C*>& CharacterData);
    void GetExternalSpeakerSlots(TArray<TSoftObjectPtr<class AActor>>& Actor Array);
    void GetSpeakerActor(class UBP_DataAsset_DialogueCharacter_C* Character, class AActor*& Actor);
    void GetInterlocutorActor(TSubclassOf<class AActor> ActorClass, class AActor*& Interlocutor);
    void Action_EndDialogue(int32 NextDialogueStage, FS_Dialogue_EndParameters Parameters);
    void ReceiveBeginPlay();
    void StartDialog();
    void OnEnvelopeFollowerUpdate_Event(float EnvelopeValue);
    void ExecuteUbergraph_BP_Dialogue(int32 EntryPoint);
    void OnDialogueFinished__DelegateSignature();
}; // Size: 0x338

#endif
