#ifndef UE4SS_SDK_BP_ConditionalDataLayersManager_HPP
#define UE4SS_SDK_BP_ConditionalDataLayersManager_HPP

class ABP_ConditionalDataLayersManager_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    TArray<FS_ConditionalDataLayers> ConditionalDataLayers;                           // 0x02A0 (size: 0x10)
    int32 ConditionIndex;                                                             // 0x02B0 (size: 0x4)
    bool ConditionValue;                                                              // 0x02B4 (size: 0x1)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void SetDataLayersRuntimeStateForEditor(TArray<UDataLayerAsset*>& DataLayers, EDataLayerRuntimeState State);
    void ForceConditionAtIndex(int32 Index, bool Value);
    void ForceCondition();
    void SetDataLayersRuntimeState(TArray<UDataLayerAsset*>& DataLayers, TArray<FName>& DataLayerNames, EDataLayerRuntimeState State);
    void OnConditionEvaluatedToFalse(FS_ConditionalDataLayers ConditionalDataLayers);
    void OnConditionEvaluatedToTrue(FS_ConditionalDataLayers ConditionalDataLayers);
    void OnGameStateChanged();
    void UnbindCondition(FS_ConditionalDataLayers ConditionalDataLayers);
    void UnbindAllConditions();
    void BindCondition(FS_ConditionalDataLayers ConditionalDataLayers);
    void BindAllConditions();
    void EvaluateCondition(FS_ConditionalDataLayers ConditionalDataLayer);
    void EvaluateAllConditions(bool IsBeginPlay);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void OnGameModePreStartPlay();
    void ExecuteUbergraph_BP_ConditionalDataLayersManager(int32 EntryPoint);
}; // Size: 0x2B5

#endif
