#ifndef UE4SS_SDK_BP_BattleBuff_PrecisionParent_HPP
#define UE4SS_SDK_BP_BattleBuff_PrecisionParent_HPP

class UBP_BattleBuff_PrecisionParent_C : public UBP_BattleBuff_Power_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0170 (size: 0x8)

    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_PrecisionParent(int32 EntryPoint);
}; // Size: 0x178

#endif
