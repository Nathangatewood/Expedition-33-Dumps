#ifndef UE4SS_SDK_BP_BattleModifierBuff_Challenge_Base_HPP
#define UE4SS_SDK_BP_BattleModifierBuff_Challenge_Base_HPP

class UBP_BattleModifierBuff_Challenge_Base_C : public UBP_BattleBuff_Modifier_Base_C
{
    double NumericValue;                                                              // 0x0158 (size: 0x8)

    void LoadChallengeAsset(class UBP_DataAsset_BattleChallenge_C* ChallengeAsset);
    void LoadNumericValue(double NumericValue);
    void LoadNumericChallengeAsset(class UBP_DataAsset_BattleChallenge_Numeric_C* Challenge);
}; // Size: 0x160

#endif
