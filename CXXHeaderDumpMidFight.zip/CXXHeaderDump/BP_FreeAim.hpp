#ifndef UE4SS_SDK_BP_FreeAim_HPP
#define UE4SS_SDK_BP_FreeAim_HPP

class UBP_FreeAim_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool IsInFreeAimMode;                                                             // 0x00A8 (size: 0x1)
    double AimReach;                                                                  // 0x00B0 (size: 0x8)
    class AActor* FreeAimTarget;                                                      // 0x00B8 (size: 0x8)
    FS_FreeAimTargetData FreeAimTargetData;                                           // 0x00C0 (size: 0x48)
    FS_FreeAimTargetData PreviousFreeAimTargetData;                                   // 0x0108 (size: 0x48)
    class UAnimMontage* FreeAimShootAnimation;                                        // 0x0150 (size: 0x8)
    TArray<ACharacter*> DetectedCharacters;                                           // 0x0158 (size: 0x10)

    void GetCrosshair(class UWBP_CrossHair_C*& Crosshair);
    void ComputeRaycastParameters(FVector& Start, FVector& End, FVector& Direction);
    void ResetFreeAimData();
    void UpdateMeshSettingsForDetectedCharacters(TEnumAsByte<EKinematicBonesUpdateToPhysics::Type> Kinematic Bones Update Type);
    void UpdateMeshSettingsForDetectedCharacter(TEnumAsByte<EKinematicBonesUpdateToPhysics::Type> KinematicBonesUpdateType, class ACharacter* Character);
    void DetectAndUpdateCharacters(const FVector Start, const FVector End);
    void PerformFreeAimRaycast(const FVector Start, const FVector End, bool& HasHit, float& HitDistance, FVector& HitLocation, class AActor*& HitActor);
    void SpawnProjectile();
    void PerformShootProjectileFeedback();
    void UpdateFreeAimCrosshair();
    void UpdateFreeAimArmRing();
    void UpdateFreeAimFeedback();
    class ABP_FreeAimCamera_C* GetFreeAimCameraActor();
    void UpdateFreeAim(double DeltaSeconds);
    bool IsInFreeAim();
    void PerformShoot();
    class ABP_jRPG_Controller_World_C* GetOwnerController();
    class ABP_jRPG_Character_World_C* GetOwnerAsCharacterWorld();
    void ToggleCamera(bool Enable);
    void ToggleFreeAim();
    void ExitFreeAim();
    void EnterFreeAim();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_FreeAim(int32 EntryPoint);
}; // Size: 0x168

#endif
