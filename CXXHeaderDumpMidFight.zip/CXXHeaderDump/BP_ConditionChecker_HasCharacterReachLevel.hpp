#ifndef UE4SS_SDK_BP_ConditionChecker_HasCharacterReachLevel_HPP
#define UE4SS_SDK_BP_ConditionChecker_HasCharacterReachLevel_HPP

class UBP_ConditionChecker_HasCharacterReachLevel_C : public UBP_ConditionChecker_C
{
    int32 Level;                                                                      // 0x0060 (size: 0x4)
    FName CharacterName;                                                              // 0x0064 (size: 0x8)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    void GetCharacterDatasToEvaluate(TArray<UBP_CharacterData_C*>& CharacterDatas);
    bool CheckInternal();
}; // Size: 0x6C

#endif
