#ifndef UE4SS_SDK_BP_DialogueSystemComponent_HPP
#define UE4SS_SDK_BP_DialogueSystemComponent_HPP

class UBP_DialogueSystemComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class ABP_Dialogue_C* ActiveDialogue;                                             // 0x00A8 (size: 0x8)
    int32 LastChoice;                                                                 // 0x00B0 (size: 0x4)
    TArray<FText> CurrentChoices;                                                     // 0x00B8 (size: 0x10)
    TArray<FFRichDialogueLine> CurrentRichDialogueLinesQueue;                         // 0x00C8 (size: 0x10)
    class UWBP_DialogueOverlay_C* DialogueUI;                                         // 0x00D8 (size: 0x8)
    bool IsWaitingForDialogInput;                                                     // 0x00E0 (size: 0x1)
    FBP_DialogueSystemComponent_COnInWorldDialogueStarted OnInWorldDialogueStarted;   // 0x00E8 (size: 0x10)
    void OnInWorldDialogueStarted();
    FBP_DialogueSystemComponent_COnInWorldDialogueFinished OnInWorldDialogueFinished; // 0x00F8 (size: 0x10)
    void OnInWorldDialogueFinished();
    bool WasLastBattleVictory;                                                        // 0x0108 (size: 0x1)
    class UBP_DataAsset_DialogueCharacter_C* CurrentSpeakerData;                      // 0x0110 (size: 0x8)
    class AActor* CurrentSpeakerActor;                                                // 0x0118 (size: 0x8)
    class UAudioComponent* CurrentAudioReactionDialogue;                              // 0x0120 (size: 0x8)
    class USoundBase* CurrentSoundBaseReactionDialogue;                               // 0x0128 (size: 0x8)
    class UWBP_DialogNotifBox_C* CurrentInWorldDialogueWidget;                        // 0x0130 (size: 0x8)
    bool CanInterruptDialogue;                                                        // 0x0138 (size: 0x1)
    class UBP_NPCAnimationComponent_C* CurrentSpeakerAnimationComponent;              // 0x0140 (size: 0x8)
    class UCameraComponent* CurrentCameraComponent;                                   // 0x0148 (size: 0x8)
    class AActor* CurrentSpeakerSlot;                                                 // 0x0150 (size: 0x8)
    TArray<AActor*> AvailableSpeakerSlots;                                            // 0x0158 (size: 0x10)
    TArray<FS_DialogueQueueElement> DialogQueue;                                      // 0x0168 (size: 0x10)
    FBP_DialogueSystemComponent_COnDialogueStarted OnDialogueStarted;                 // 0x0178 (size: 0x10)
    void OnDialogueStarted(class ABP_Dialogue_C* Dialogue);
    FBP_DialogueSystemComponent_COnDialogueFinished OnDialogueFinished;               // 0x0188 (size: 0x10)
    void OnDialogueFinished(class ABP_Dialogue_C* Dialogue);
    class UWBP_CharacterSelectorPanel_C* CharacterSelectorWindow;                     // 0x0198 (size: 0x8)
    TArray<UBP_CharacterData_C*> LastSelectedCharacterDatas;                          // 0x01A0 (size: 0x10)
    class UWBP_Merchant_Panel_C* MerchantWindow;                                      // 0x01B0 (size: 0x8)
    FTimerHandle FacialTalkingTimer;                                                  // 0x01B8 (size: 0x8)
    FCameraAnimationHandle PreviousCameraAnimation;                                   // 0x01C0 (size: 0x4)
    FCameraAnimationHandle BreathingCameraAnimation;                                  // 0x01C4 (size: 0x4)
    TEnumAsByte<EDialogueCameraType::Type> PreviousCameraType;                        // 0x01C8 (size: 0x1)
    class AActor* PreviousSpeakerActor;                                               // 0x01D0 (size: 0x8)
    TArray<AActor*> AllSpeakerActors;                                                 // 0x01D8 (size: 0x10)
    bool ForceRefreshCameraOnNextLine;                                                // 0x01E8 (size: 0x1)
    FBP_DialogueSystemComponent_COnAnyDialogueStarted OnAnyDialogueStarted;           // 0x01F0 (size: 0x10)
    void OnAnyDialogueStarted();
    FBP_DialogueSystemComponent_COnAnyDialogueFinished OnAnyDialogueFinished;         // 0x0200 (size: 0x10)
    void OnAnyDialogueFinished();
    bool ManualTransitionInProgress;                                                  // 0x0210 (size: 0x1)
    class UDataTable* LootDialoguesTable;                                             // 0x0218 (size: 0x8)
    FDataTableRowHandle SoundEventWindowOpen;                                         // 0x0220 (size: 0x10)
    class UCameraComponent* PreviousCamera;                                           // 0x0230 (size: 0x8)
    double EnvelopeValue;                                                             // 0x0238 (size: 0x8)
    bool TickUpdateEnvelopeVolumeOfComponent;                                         // 0x0240 (size: 0x1)
    FBP_DialogueSystemComponent_COnDisplayRelationshipLevelIncreasedRequested OnDisplayRelationshipLevelIncreasedRequested; // 0x0248 (size: 0x10)
    void OnDisplayRelationshipLevelIncreasedRequested(TEnumAsByte<E_CharacterList::Type> Character);
    FTimerHandle TimerToWaitToAutoSkipLines;                                          // 0x0258 (size: 0x8)
    double NumberOfCharactersToReadPerSecond;                                         // 0x0260 (size: 0x8)
    double MinimumTimeToAutoSkipLines;                                                // 0x0268 (size: 0x8)
    FBP_DialogueSystemComponent_COnDialogueBattleStarted OnDialogueBattleStarted;     // 0x0270 (size: 0x10)
    void OnDialogueBattleStarted();
    FBP_DialogueSystemComponent_COnDialogueBattleFinished OnDialogueBattleFinished;   // 0x0280 (size: 0x10)
    void OnDialogueBattleFinished();
    bool CanAutoSkipDialogueLine;                                                     // 0x0290 (size: 0x1)

    void GetTiedObject(class UObject*& Object);
    bool CanAutoSkipCurrentDialogueLine();
    void SetDialogueUI(class UWBP_DialogueOverlay_C* DialogueUI);
    void OnDialogueInterruptInput(class UWBP_GM_PromptGeneric_C* PromptWidget);
    void OnNextClicked(class UWBP_GM_PromptGeneric_C* PromptWidget);
    void OnAutoSkipSettingChanged();
    void OnTimerToSkipLinesElapsed();
    void TryStartTimerToWaitToAutoSkipLines(float Time);
    void WaitForSpeakerAudio(FFRichDialogueLine& DialogueLine);
    void InterruptCurrentSpeaker();
    void SetInWorldDialoguePaused(bool Paused);
    void OnSaveCompleted();
    void SaveAtSpawnPoint(FGameplayTag SpawnPointTag);
    bool ShouldApplyCameraAnimation(const FS_DialogueCameraParameters& Parameters);
    bool ShouldApplyCamera(TEnumAsByte<EDialogueCameraType::Type> CameraType, const FS_DialogueCameraParameters& Parameters);
    void SetEnvelopeValue(double EnvelopeValue);
    void AddGenderContextToText(FText Text, FText& EnrichedText);
    void GetActivePlayerCharacterGender(ETextGender& GenderTag);
    class UCameraAnimationSequence* GetCameraAnimationSequence(const FS_DialogueCameraParameters& CameraParameters);
    void OnInWorldDialogueFinishedOrInterrupted();
    void IsPlayingSpecificInWorldDialogue(class UBP_DA_IWD_data_C* InWorldDialogue, bool& IsPlaying);
    bool AreLootItemUsersCompatible(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, FS_LootDialogue& LootDialogue);
    bool IsLootItemSubtypeCompatible(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, FS_LootDialogue& LootDialogue);
    bool IsLootItemTypeCompatible(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, FS_LootDialogue& LootDialogue);
    bool IsLootDialogueCompatible(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, FS_LootDialogue& LootDialogue);
    void TryGetCompatibleLootDialogue(class UBP_GeneratedItemInfo_Base_C* GeneratedItemInfo, TSoftObjectPtr<class UBP_DA_IWD_data_C>& InWorldDialogue);
    void IsPlayingInWorldDialogue(bool& IsPlaying);
    void PlayInWorldDialogueOnLoot(TArray<UBP_GeneratedItemInfo_Base_C*>& Items);
    bool HasManualTransitionInProgress();
    void SetManualTransitionInProgress(bool IsInProgress);
    bool HasDialogueInQueue();
    void DisplayRelationshipLevelIncreased(TEnumAsByte<E_CharacterList::Type> Character);
    bool ShouldUseDialogCameras();
    void StopAudioForAllSpeakers();
    void ExecuteAudioTrigger(FName AudioTriggerName, class AActor* Actor);
    void StopSoundForCharacter(class AActor* Actor);
    void PlaySoundForCharacter(class USoundBase* Sound, class AActor* Actor);
    void GetCurrentCameraOfType(TEnumAsByte<EDialogueCameraType::Type> CameraType, const FS_DialogueCameraParameters& Parameters, class UCameraComponent*& CameraComponent);
    TArray<AActor*> GetAllSpeakerActors();
    void TriggerDialogueEndCameraComponentManager();
    void TriggerDialogueStartCameraComponentManager();
    void GetCurrentSpeakerActor(class AActor*& CurrentSpeakerActor);
    void PlayCameraAnimation(const FS_DialogueCameraParameters& CameraParameters);
    void SetBreathingCameraMovementEnable(bool Activate);
    void ActivateCameraComponentByType(TEnumAsByte<EDialogueCameraType::Type> CameraType, const FS_DialogueCameraParameters& Parameters);
    void DeactivatePreviousCameraComponents();
    void SetCurrentSpeakStopTalking();
    void OnMerchantWindowClosed();
    void GetLastSelectedCharacterDatas(TArray<UBP_CharacterData_C*>& CharacterData);
    void CloseCharacterSelectionWindow(TArray<UBP_CharacterData_C*>& CharacterDatas);
    void OnCharacterSelectionCanceled();
    void OnCharacterSelectionDone(TArray<UBP_CharacterData_C*>& CharacterDatas);
    void OpenCharacterSelectorWindow(int32 MaxCharacterCount, bool CanCancel);
    void OnMerchantFightRequested();
    void OpenMerchantWindow(class AActor* Merchant, bool& IsOpened);
    void QueueDialogue(TSoftObjectPtr<class ABP_jRPG_NPC_Dialog_C> DialogToQueue, FS_DialogueParameters DialogueParameters);
    void ValidateNPCDialogToEnqueue(class ABP_jRPG_NPC_Dialog_C* NPCDialog, bool& IsValid);
    void TryUnqueueDialogue();
    void UpdateAvailableSpeakers();
    void UpdateAllSpeakerActors();
    void UpdateCurrentSpeakerData();
    void GetCameraFromCurrentSpeaker(class UCameraComponent*& Camera);
    void StopRunningAnimationsForActor(class AActor* Actor);
    void StopRunningAnimationForAllSpeakers();
    void UpdateSpeakerTalkingAnimation(const FFRichDialogueLine& DialogueLine);
    void PlaySpeakerAnimation(const FFRichDialogueLine& DialogueLine);
    void PlayAnimation(class UBP_DataAsset_DialogueCharacter_C* Character, FS_Dialogue_AnimationParameters& AnimationParameters);
    void ActionPlayAnimation(class UBP_DataAsset_DialogueCharacter_C* Character, FS_Dialogue_AnimationParameters& AnimationParameters);
    FText GetCurrentSpeakerName();
    void TryFindSpeakerActorInAvailableSpeakers(class UObject* Character, class AActor*& Actor, class AActor*& Slot);
    void GetSpeaker(class UObject* Character, class AActor*& Actor, class AActor*& Slot);
    void ShowLeaveButtonIfNeeded();
    void DisableInputPrompts();
    void HandleCameraType(TEnumAsByte<EDialogueCameraType::Type> CameraType, FS_DialogueCameraParameters& Parameters);
    void UpdateCamera(const FFRichDialogueLine& DialogueLine);
    void ApplyCamera(TEnumAsByte<EDialogueCameraType::Type> CameraType, FS_DialogueCameraParameters Parameters);
    void PlayNextDialogueWave(class UDialogueWave* DialogueWave, class AActor* Actor);
    void GetRichLineText(const FFRichDialogueLine& RichDialogueLine, FText& LineText);
    bool HasActiveDialogue();
    void PlayAudioForCurrentSpeaker(const FFRichDialogueLine& DialogueLine);
    void PlayInWorldDialogue(class UBP_DA_IWD_data_C* DialogToPlay, bool& DialogueNotPlayed);
    void InterruptInWorldDialogue();
    void ActionShowVendor(FText Greeting, TSet<FName> VendorItems);
    void ActionUnpauseDialogue();
    void ActionStartBattle(FFBattleStartParams BattleStartParams);
    void ActionPauseDialogue();
    void EndDialogue(class ABP_Dialogue_C* Dialog, FS_Dialogue_EndParameters Parameters);
    void OnAllDialogLinesPlayed();
    void UpdateCanInterruptDialogue(class ABP_Dialogue_C* Dialogue, const FS_Dialogue_CustomOptions& CustomOptions);
    void PlayNextDialogueLine();
    void StartRichDialogueLines(class ABP_Dialogue_C* Dialogue, class UBP_DataAsset_DialogueCharacter_C* CharacterAsset, TArray<FFRichDialogueLine>& RichDialogueLines);
    void StartDialogLines(class ABP_Dialogue_C* Dialog, TArray<FText>& Lines, class UBP_DataAsset_DialogueCharacter_C* Character);
    void SetActiveDialogue(class ABP_Dialogue_C* Dialogue);
    void ActivateDialogue(class ABP_Dialogue_C* Dialogue);
    bool IsInDialogue();
    void NotifyCompletionToDialogue();
    void OnChoiceMade(int32 ChoiceIndex);
    void StartChoice(class ABP_Dialogue_C* Dialogue, TArray<FText>& Choices, TEnumAsByte<EDialogueCameraType::Type> CameraType, FS_Dialogue_CustomOptions CustomOptions);
    void OnLoaded_EEC4040348CBFCE11AE578A7CAAE788D(class UObject* Loaded);
    void OnUINavigationFocus(const class UBP_UINavigationFocusEvent_C* FocusEventBP);
    void OnUINavigationFocusLost();
    void OnUIAction();
    void FakeDialogue();
    void FakeChoice();
    void WaitDialogueInput();
    void WaitForBattleToFinish();
    void OnBattleFinished(bool Victory);
    void WaitForVendorToFinish();
    void OnVendorWindowClosed();
    void DelayUntilStopTalking(double Duration);
    void DelayUntilMainCharacterStopsTalking(float Duration);
    void ReceiveTick(float DeltaSeconds);
    void CurrentSpeakerStopTalking();
    void PlayInWorldDialogueFromSoftRef(TSoftObjectPtr<class UBP_DA_IWD_data_C> IWDRef);
    void ExecuteUbergraph_BP_DialogueSystemComponent(int32 EntryPoint);
    void OnDialogueBattleFinished__DelegateSignature();
    void OnDialogueBattleStarted__DelegateSignature();
    void OnDisplayRelationshipLevelIncreasedRequested__DelegateSignature(TEnumAsByte<E_CharacterList::Type> Character);
    void OnAnyDialogueFinished__DelegateSignature();
    void OnAnyDialogueStarted__DelegateSignature();
    void OnInWorldDialogueStarted__DelegateSignature();
    void OnDialogueFinished__DelegateSignature(class ABP_Dialogue_C* Dialogue);
    void OnDialogueStarted__DelegateSignature(class ABP_Dialogue_C* Dialogue);
    void OnInWorldDialogueFinished__DelegateSignature();
}; // Size: 0x291

#endif
