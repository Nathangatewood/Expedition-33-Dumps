#ifndef UE4SS_SDK_BP_DataAsset_Item_Journal_HPP
#define UE4SS_SDK_BP_DataAsset_Item_Journal_HPP

class UBP_DataAsset_Item_Journal_C : public UBP_DataAsset_Item_C
{
    FText Text;                                                                       // 0x0030 (size: 0x10)
    TSoftObjectPtr<class USoundBase> VoiceOver;                                       // 0x0040 (size: 0x28)
    FText ShortTitle;                                                                 // 0x0068 (size: 0x10)
    FName AssociatedLevel;                                                            // 0x0078 (size: 0x8)

}; // Size: 0x80

#endif
