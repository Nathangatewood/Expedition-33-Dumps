#ifndef UE4SS_SDK_AC_jRPG_BattleManager_HPP
#define UE4SS_SDK_AC_jRPG_BattleManager_HPP

class UAC_jRPG_BattleManager_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool IsBattleInitialized;                                                         // 0x00A8 (size: 0x1)
    bool ResumeBattleRequested;                                                       // 0x00A9 (size: 0x1)
    class ABP_jRPG_Character_Battle_Base_C* CurrentCharacter;                         // 0x00B0 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> PlayerCharacters;                       // 0x00B8 (size: 0x10)
    TArray<ABP_jRPG_Character_Battle_Base_C*> Enemies;                                // 0x00C8 (size: 0x10)
    double InitiativeNeededToTakeTurn;                                                // 0x00D8 (size: 0x8)
    class UWBP_HUD_GM_EndBattle_Panel_C* BattleEndScreenReference;                    // 0x00E0 (size: 0x8)
    class UBP_jRPG_GI_Custom_C* GameInstanceReference;                                // 0x00E8 (size: 0x8)
    TArray<UDEPRECATED_WBP_jRPG_BattleEndCharacterSlot_C*> BattleEndCharacterSlotsReference; // 0x00F0 (size: 0x10)
    TMap<int32, ABP_jRPG_Character_Battle_Base_C*> EnemiesBySpotIndex;                // 0x0100 (size: 0x50)
    TArray<ABP_jRPG_Character_Battle_Base_C*> DeadPlayerCharacters;                   // 0x0150 (size: 0x10)
    TArray<ABP_jRPG_Character_Battle_Base_C*> DeadEnemies;                            // 0x0160 (size: 0x10)
    TEnumAsByte<E_jRPG_ActionType::Type> SelectedAction;                              // 0x0170 (size: 0x1)
    FName SelectedSecondaryAction;                                                    // 0x0174 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> NextCharacterTurns;                     // 0x0180 (size: 0x10)
    FName EncounterName;                                                              // 0x0190 (size: 0x8)
    TArray<TScriptInterface<class IBPI_BattleListener_C>> BattleListeners;            // 0x0198 (size: 0x10)
    class USoundBase* VictorySong;                                                    // 0x01A8 (size: 0x8)
    double TeamMotivationValue;                                                       // 0x01B0 (size: 0x8)
    FFTeamMotivationData TeamMotivationData;                                          // 0x01B8 (size: 0x14)
    class APawn* OldControlledPawn;                                                   // 0x01D0 (size: 0x8)
    bool OnlySpawnHeroesAtNextBattleStart;                                            // 0x01D8 (size: 0x1)
    bool OnlySpawnEnemiesAtNextBattleStart;                                           // 0x01D9 (size: 0x1)
    FAC_jRPG_BattleManager_COnBattleFinished OnBattleFinished;                        // 0x01E0 (size: 0x10)
    void OnBattleFinished(bool Victory);
    bool HasSpawnedHeroes;                                                            // 0x01F0 (size: 0x1)
    bool HasSpawnedEnemies;                                                           // 0x01F1 (size: 0x1)
    TArray<ABP_jRPG_Character_Battle_Base_C*> DefendingHeroes;                        // 0x01F8 (size: 0x10)
    TArray<ABP_jRPG_Character_Battle_Base_C*> PreviousDefendingHeroes;                // 0x0208 (size: 0x10)
    class UBP_BattleFeedbackState_C* SuccessfulDodgeFeedback;                         // 0x0218 (size: 0x8)
    class UBP_BattleFeedbackState_C* SuccessfulParryFeedback;                         // 0x0220 (size: 0x8)
    class UBP_BattleFeedbackState_C* SuccessfulDefendFeedback;                        // 0x0228 (size: 0x8)
    FFGlobalFeedback DefendSuccessFeedback;                                           // 0x0230 (size: 0x18)
    FFGlobalFeedback DodgeSuccessFeedback;                                            // 0x0248 (size: 0x18)
    FFGlobalFeedback ParrySuccessFeedback;                                            // 0x0260 (size: 0x18)
    int32 DEBUG_ComboAutoSuccessCount;                                                // 0x0278 (size: 0x4)
    FFGlobalFeedback SkillComboQTE_SuccessFeedback;                                   // 0x0280 (size: 0x18)
    FFGlobalFeedback SkillComboQTE_FailFeedback;                                      // 0x0298 (size: 0x18)
    bool FEATURE_UseNewBattleUI;                                                      // 0x02B0 (size: 0x1)
    bool DEBUG_OverlayInfo;                                                           // 0x02B1 (size: 0x1)
    class UWBP_HUD_BattleScreen_C* BattleScreenWidget;                                // 0x02B8 (size: 0x8)
    bool WantedDefense;                                                               // 0x02C0 (size: 0x1)
    bool HasActiveCounterAttack;                                                      // 0x02C1 (size: 0x1)
    bool HasActiveTurnEndEvent;                                                       // 0x02C2 (size: 0x1)
    class ABP_jRPG_Character_Battle_Base_C* CurrentHoveredCharacter;                  // 0x02C8 (size: 0x8)
    bool FEATURE_UseBattleChecks;                                                     // 0x02D0 (size: 0x1)
    class ABP_BattleMap_C* BattleMapBP;                                               // 0x02D8 (size: 0x8)
    FFGlobalFeedback APRecoverFeedback;                                               // 0x02E0 (size: 0x18)
    FFGlobalFeedback APConsumedFeedback;                                              // 0x02F8 (size: 0x18)
    bool Play Battle Camera Intro?;                                                   // 0x0310 (size: 0x1)
    bool CanAddTurnEndEvent;                                                          // 0x0311 (size: 0x1)
    class UBP_DependencyRefCounter_C* TurnStartNotifyDependencies;                    // 0x0318 (size: 0x8)
    int32 TurnStartNextPhase;                                                         // 0x0320 (size: 0x4)
    TArray<TScriptInterface<class IBPI_BattleListener_C>> TurnStartBattleListenersToProcess; // 0x0328 (size: 0x10)
    FAC_jRPG_BattleManager_COnTurnStart OnTurnStart;                                  // 0x0338 (size: 0x10)
    void OnTurnStart(class ABP_jRPG_Character_Battle_Base_C* Character);
    FSoundEventDataTableRowHandle SoundEvent_TargetChange_Enemy;                      // 0x0348 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_TargetChange_Ally;                       // 0x0358 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_Skill_TargetEnemy_Start;                 // 0x0368 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_Skill_TargetAlly_Start;                  // 0x0378 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_Item_TargetAlly_Start;                   // 0x0388 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_Item_TargetEnemy_Start;                  // 0x0398 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_TurnStart_Ally;                          // 0x03A8 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_TurnStart_Enemy;                         // 0x03B8 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_BattleStart;                             // 0x03C8 (size: 0x10)
    int32 TurnCount;                                                                  // 0x03D8 (size: 0x4)
    FAC_jRPG_BattleManager_COnBattleReadyToStart OnBattleReadyToStart;                // 0x03E0 (size: 0x10)
    void OnBattleReadyToStart();
    class ABP_jRPG_Character_Battle_Base_C* CurrentHoveredCharacterFreeAim;           // 0x03F0 (size: 0x8)
    FVector LastMouseHitLocation;                                                     // 0x03F8 (size: 0x18)
    FAC_jRPG_BattleManager_COnBattleFlee OnBattleFlee;                                // 0x0410 (size: 0x10)
    void OnBattleFlee();
    bool BlockAllDefensiveMoves;                                                      // 0x0420 (size: 0x1)
    bool DisableCriticalHit;                                                          // 0x0421 (size: 0x1)
    FAC_jRPG_BattleManager_COnEnemyKilledEvent OnEnemyKilledEvent;                    // 0x0428 (size: 0x10)
    void OnEnemyKilledEvent(class UAC_jRPG_CharacterBattleStats_C* CharStats);
    FAC_jRPG_BattleManager_COnResurected OnResurected;                                // 0x0438 (size: 0x10)
    void OnResurected(class ABP_jRPG_Character_Battle_Base_C* CharacterResurected);
    bool UseDiegeticQTE;                                                              // 0x0448 (size: 0x1)
    FAC_jRPG_BattleManager_COnParrySuccessful OnParrySuccessful;                      // 0x0450 (size: 0x10)
    void OnParrySuccessful(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    FAC_jRPG_BattleManager_COnDodgeSuccessful OnDodgeSuccessful;                      // 0x0460 (size: 0x10)
    void OnDodgeSuccessful(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    FAC_jRPG_BattleManager_COnDefendSuccessful OnDefendSuccessful;                    // 0x0470 (size: 0x10)
    void OnDefendSuccessful(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    FSoundEventDataTableRowHandle SoundEvent_DodgeTriggered;                          // 0x0480 (size: 0x10)
    FSoundEventDataTableRowHandle SoundEvent_ParryTriggered;                          // 0x0490 (size: 0x10)
    TArray<UBP_PDT_GameAction_C*> GameActionsAfterBattle;                             // 0x04A0 (size: 0x10)
    TArray<ABP_jRPG_Character_Battle_Base_C*> AllPlayerCharactersBySpotIndex;         // 0x04B0 (size: 0x10)
    bool CurrentTurn_CanChooseAction;                                                 // 0x04C0 (size: 0x1)
    FFBattleStartParams CurrentBattleStartParams;                                     // 0x04C8 (size: 0x158)
    bool WasLastBattleLost;                                                           // 0x0620 (size: 0x1)
    FFSoundEvent SD_BattleStarts;                                                     // 0x0628 (size: 0x8)
    FFSoundEvent SD_FirstStrike;                                                      // 0x0630 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> AllEnemyCharactersBySpotIndex;          // 0x0638 (size: 0x10)
    FFSoundEvent SD_GameOverMusic;                                                    // 0x0648 (size: 0x8)
    FSoundEventDataTableRowHandle SoundEvent_GradientCounterTriggered;                // 0x0650 (size: 0x10)
    bool WasCurrentSkillInterrupted;                                                  // 0x0660 (size: 0x1)
    TArray<ABP_jRPG_Character_Battle_Base_C*> WaitingForCharactersToDashBack;         // 0x0668 (size: 0x10)
    TMap<FGuid, FFBattleCharacterStoredState> KickedCharacters;                       // 0x0678 (size: 0x50)
    FSF_ReferenceCounter BattleEndBlockerRefCount;                                    // 0x06C8 (size: 0x20)
    FAC_jRPG_BattleManager_COnCharacterKilled OnCharacterKilled;                      // 0x06E8 (size: 0x10)
    void OnCharacterKilled(class ABP_jRPG_Character_Battle_Base_C* Character);
    class ABP_jRPG_Character_Battle_Base_C* DEBUG_RandomHeroAcquireOverride;          // 0x06F8 (size: 0x8)
    class UBP_DependencyRefCounter_C* BattleStartNotifyDependencies;                  // 0x0700 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> BattleStartEvents_CharactersToProcess;  // 0x0708 (size: 0x10)
    FSF_ReferenceCounterHandle DataLayerRequestReference;                             // 0x0718 (size: 0x20)
    class UBP_LastStandSystem_C* LastStandSystem;                                     // 0x0738 (size: 0x8)
    TArray<UAC_jRPG_CharacterBattleStats_C*> CurrentCharacterStack;                   // 0x0740 (size: 0x10)
    class ABP_jRPG_Character_Battle_Base_C* CurrentTurnCharacter;                     // 0x0750 (size: 0x8)
    TMap<int32, FName> CurrentBattleEnemies;                                          // 0x0758 (size: 0x50)
    bool FleeImpossible;                                                              // 0x07A8 (size: 0x1)
    bool HasBattleStartedEndFlow;                                                     // 0x07A9 (size: 0x1)
    int32 CurrentBattleEncounterLevel;                                                // 0x07AC (size: 0x4)
    FS_BattleRewards LastReceivedBattleRewards;                                       // 0x07B0 (size: 0x18)
    class UBP_BattleSummaryStatsManager_C* BattleSummaryStatsManager;                 // 0x07C8 (size: 0x8)
    TArray<UAC_jRPG_CharacterBattleStats_C*> PendingResurrects;                       // 0x07D0 (size: 0x10)
    bool IsProcessingKilledCharacter;                                                 // 0x07E0 (size: 0x1)
    bool HasSentReserveTeam;                                                          // 0x07E1 (size: 0x1)
    bool IsWaitingForTurnEndBeforeGameOver;                                           // 0x07E2 (size: 0x1)
    class UBP_GradientGaugeSystem_C* GradientGaugeSystem;                             // 0x07E8 (size: 0x8)
    TMap<FName, int32> CurrentBattleExtraLoot;                                        // 0x07F0 (size: 0x50)
    class UBP_AudioControlSystem_Battle_C* BattleAudioControlSystem;                  // 0x0840 (size: 0x8)
    FAC_jRPG_BattleManager_COnCharacterReceivedDamage OnCharacterReceivedDamage;      // 0x0848 (size: 0x10)
    void OnCharacterReceivedDamage(class UBP_BattleDamages_C* BattleDamage);
    class UBP_BattleBuffComponent_C* BattleModifiersBuffComponent;                    // 0x0858 (size: 0x8)
    TArray<FS_jRPG_PartySlot> BattleParty;                                            // 0x0860 (size: 0x10)
    class UWBP_jRPG_GameOverScreen_C* GameOverScreenWidget;                           // 0x0870 (size: 0x8)
    class UWBP_BattleTransition_C* BattleTransitionWidget;                            // 0x0878 (size: 0x8)
    FAC_jRPG_BattleManager_COnStartedTargeting OnStartedTargeting;                    // 0x0880 (size: 0x10)
    void OnStartedTargeting();
    class ABP_LGUI_UIContainer_BattleWheelRoot_C* LGUI_Actor_BattleWheels;            // 0x0890 (size: 0x8)
    TEnumAsByte<EDamageReason::Type> LastFatalDamageReceivedReason;                   // 0x0898 (size: 0x1)
    TMap<TEnumAsByte<EDamageReason::Type>, FDataTableRowHandle> CameraFinisherMap;    // 0x08A0 (size: 0x50)
    FAC_jRPG_BattleManager_COnCharacterBreakStunned OnCharacterBreakStunned;          // 0x08F0 (size: 0x10)
    void OnCharacterBreakStunned(class UAC_jRPG_CharacterBattleStats_C* StunnedCharacterStat, class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStat);
    FSF_ModifierStackWrapper GlobalDodgeWindowModifierStack;                          // 0x0900 (size: 0x8)
    FSF_ModifierStackWrapper GlobalParryWindowModifierStack;                          // 0x0908 (size: 0x8)
    TEnumAsByte<EBattleEndResult::Type> BattleEndState;                               // 0x0910 (size: 0x1)
    bool Deactivate Battle EndCameraMovement;                                         // 0x0911 (size: 0x1)
    FAC_jRPG_BattleManager_COnEnemySpawned OnEnemySpawned;                            // 0x0918 (size: 0x10)
    void OnEnemySpawned(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    class ABP_jRPG_Character_Battle_Base_C* DummyMiddleCharacter;                     // 0x0928 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> AliveCharactersAtTurnStart;             // 0x0930 (size: 0x10)
    FDataTableRowHandle SoundEventSlowMo;                                             // 0x0940 (size: 0x10)
    TArray<UAC_jRPG_CharacterBattleStats_C*> CurrentlyCounteringCharacters;           // 0x0950 (size: 0x10)
    class ABP_jRPG_Character_Battle_Base_C* CurrentCounteredCharacter;                // 0x0960 (size: 0x8)
    FAC_jRPG_BattleManager_COnCharacterHealSuccessful OnCharacterHealSuccessful;      // 0x0968 (size: 0x10)
    void OnCharacterHealSuccessful(class UBP_BattleHeal_C* HealObject);
    FAC_jRPG_BattleManager_COnShieldPointsIncreased OnShieldPointsIncreased;          // 0x0978 (size: 0x10)
    void OnShieldPointsIncreased(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, int32 NewPoints, int32 PreviousPoints);
    FAC_jRPG_BattleManager_COnAPChanged OnAPChanged;                                  // 0x0988 (size: 0x10)
    void OnAPChanged(class UBP_BattleEvent_APChange_C* APChange);
    TEnumAsByte<E_GameDifficulty::Type> BattleDifficulty;                             // 0x0998 (size: 0x1)
    double NewVar;                                                                    // 0x09A0 (size: 0x8)
    TArray<UAC_jRPG_CharacterBattleStats_C*> ForcedNextCharactersQueue;               // 0x09A8 (size: 0x10)
    class USoundBase* LoadedBattleMusic;                                              // 0x09B8 (size: 0x8)
    bool DisableReactionBattleLines;                                                  // 0x09C0 (size: 0x1)
    bool bIsSkipImpossible;                                                           // 0x09C1 (size: 0x1)
    FAC_jRPG_BattleManager_COnSkipImpossibleChanged OnSkipImpossibleChanged;          // 0x09C8 (size: 0x10)
    void OnSkipImpossibleChanged(bool IsSkipImpossible);
    FString DebugLastFlowState;                                                       // 0x09D8 (size: 0x10)
    bool bIsNarrativeBattle;                                                          // 0x09E8 (size: 0x1)
    double Challenge_ForcedDamageLimit;                                               // 0x09F0 (size: 0x8)
    double Challenge_EnemyHealthMultiplier;                                           // 0x09F8 (size: 0x8)
    bool bIsRetryableBattle;                                                          // 0x0A00 (size: 0x1)
    TMap<FName, int32> BattleItemsCount;                                              // 0x0A08 (size: 0x50)
    TMap<FName, FS_BattleCharacterFinalState> CharacterFinalStates;                   // 0x0A58 (size: 0x50)
    bool IsFromBattleRestart;                                                         // 0x0AA8 (size: 0x1)
    FS_InteractiveMusicParameters InitialMusicParameters;                             // 0x0AB0 (size: 0x18)
    TSoftObjectPtr<class ABP_LightingScenarioReference_C> InitialLightingScenario;    // 0x0AC8 (size: 0x28)
    FS_BattleInitialState BattleInitialState;                                         // 0x0AF0 (size: 0x40)
    FS_BattleInitialState BattleRestartState;                                         // 0x0B30 (size: 0x40)
    bool AbandonRequested;                                                            // 0x0B70 (size: 0x1)
    FAC_jRPG_BattleManager_COnAllTurnStartEventsProcessed OnAllTurnStartEventsProcessed; // 0x0B78 (size: 0x10)
    void OnAllTurnStartEventsProcessed();

    bool IsPlayingFinisher();
    void TriggerAbandonBattle();
    void OnPhotoModeExited();
    void OnPhotoModeEntered();
    void UnregisterGameInstanceEvents();
    void RegisterGameInstanceEvents();
    void InitBattle();
    bool CanRetryBattle();
    bool CanAbandonBattle();
    void LoadRestartState(FS_BattleInitialState BattleInitialState);
    void ConsumeBattleItem(FName ItemHardcodedName, int32 Amount);
    void InitBattleItemCountsFromInventory();
    void FindBattleItemCount(FName ItemHardcodedName, int32& Quantity);
    void UnbindEventOnBattleFinished(const FUnbindEventOnBattleFinishedEvent& Event);
    void BindEventOnBattleFinished(const FBindEventOnBattleFinishedEvent& Event);
    void CleanUpAfterBattle();
    void RequestRestartCurrentEncounter();
    void TriggerPostBattleEvents();
    void StopBattleSystems();
    void ResumeExplorationSystems(bool BeforeRestart);
    void PrepareForEncounterRestart();
    void TryNotifyChallenges();
    void AddChallengeModifiers();
    double Challenge_GetHeroesDamageLimitOverride();
    void Challenge_SetHeroesDamageLimitOverride(double Value);
    void Challenge_SetEnemyHealthMutliplier(double Value);
    void Challenge_ApplyEnemyStatChanges(TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> InStats, TMap<TEnumAsByte<E_jRPG_StatType::Type>, double>& OutStats);
    void DeactivateAllBattleCBM();
    bool IsNarrativeBattle();
    void SetDebugFlowState(FString StateName);
    TArray<UAC_jRPG_CharacterBattleStats_C*> GetForcedNextCharacters();
    void SetIsSkipImpossible(bool IsSkipImpossible);
    void IsSkipImpossible(bool& SkipImpossible);
    bool CanPlayReactionBattleLines();
    void Internal_MakePlayerCharacterDead(const class ABP_jRPG_Character_Battle_Base_C*& Character);
    void ResumeAudioFromBattle();
    void TryRemoveQueuedForcedNextCharacter(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void TryForceUnregisterPendingResurrect(const class UAC_jRPG_CharacterBattleStats_C*& CharStats);
    void RemoveInvalidKickedCharacterStateHandles(TArray<FGuid>& KickedCharacterHandles);
    void AreAllKickedCharacterStateHandleValid(TArray<FGuid>& KickedCharacterHandle, bool& Success);
    void IsKickedCharacterStateHandleValid(FGuid& KickedCharacterHandle, bool& Success);
    void TryProcessPendingBattleEnd();
    void QueueForcedNextCharacter(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void Helper_TryAddRolledLootToMap(const TMap<FName, FS_RolledLootEntry>& RolledBattleLootEntries, FName ItemDefinitionID, int32 Quantity, int32 OffsetLootContext, FS_LootContext LootContext);
    void Helper_AddRolledLootToMap(TMap<FName, FS_RolledLootEntry>& RolledLootMap, FName ItemId, int32 Quantity, int32 GeneratedLootLevelOffset);
    void InitPlayerCharactersGear();
    void SetCurrentCharacter(class ABP_jRPG_Character_Battle_Base_C* CurrentCharacter);
    void GetActiveCharacter(class ABP_jRPG_Character_Battle_Base_C*& CurrentCharacter);
    void UnregisterBattleListener(const TScriptInterface<class IBPI_BattleListener_C>& Item);
    void GetKickedCharacterStateFromHandle(FGuid& KickedCharacterHandle, bool& Success, FFBattleCharacterStoredState& CharacterState);
    TEnumAsByte<E_GameDifficulty::Type> GetCurrentBattleDifficulty();
    void UnlockNoDamageBossAchievement();
    void SetInputMappingContextEnabled(bool bIsEnabled, const class UInputMappingContext* MappingContext, int32 Priority);
    void ReceiveBattleExperience(int32 InputPin);
    TArray<UAC_jRPG_CharacterBattleStats_C*> GetCurrentlyCounteringCharacters();
    void EndAOECounterAttack();
    void BeginAOECounterAttack();
    void Debug_PrintToCategory();
    void GetBattleItemSkills(TArray<UBP_DataAsset_Skill_C*>& ItemSkills);
    void GetBattleItemSkillsScriptClasses(TArray<TSoftClassPtr<ABP_Battle_SkillScript_C>>& ItemSkillScriptSoftClasses);
    bool Was Battle No Damage();
    void FindActiveSkillSequenceBP(class ABP_EpicBattleSequenceActor_C*& EpicSequenceBP);
    void CanCharactersCounterAttackEnemySkill(class ABP_jRPG_Character_Battle_Base_C* EnemyCharacter, TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedCharacters, bool& CanCounter);
    TArray<ABP_jRPG_Character_Battle_Base_C*> GetAliveEnemies();
    void UpdateDummyMiddleCharacterLocation();
    class ABP_jRPG_Character_Battle_Base_C* GetDummyMiddleCharacter();
    TEnumAsByte<EBattleEndResult::Type> GetBattleEndState();
    bool IsBattleEnding();
    void GetGlobalParryWindowModifier(class UModifierStack_Float*& Stack);
    void RemoveGlobalParryWindowModifier(FSF_ModifierStackEntryHandle& OutModifierHandle);
    void AddGlobalParryWindowModifier(float Multiplier, FSF_ModifierStackEntryHandle& OutModifierHandle, FString DebugName);
    void GetGlobalDodgeWindowModifier(class UModifierStack_Float*& Stack);
    void RemoveGlobalDodgeWindowModifier(FSF_ModifierStackEntryHandle& OutModifierHandle);
    void AddGlobalDodgeWindowModifier(float Multiplier, FSF_ModifierStackEntryHandle& OutModifierHandle, FString DebugName);
    void StartPlayerTurnChoice();
    void RegisterBattleListener(const TScriptInterface<class IBPI_BattleListener_C>& NewListener);
    void GetTurnCount(int32& TurnCount);
    void SetLastFatalDamageReceivedReason(TEnumAsByte<EDamageReason::Type> LastDamageReceivedReason);
    bool ShouldUpdateCharacterDataWithFinalBattleState();
    class ABP_LGUI_UIContainer_BattleWheelRoot_C* GetLGUIActor_BattleWheels();
    void GetAllActiveBattleBuffComponents(TArray<UBP_BattleBuffComponent_C*>& Array);
    void ResetGlobalTimeDilationForBattle();
    bool IsGradientChargeUnlocked();
    TArray<UAC_jRPG_CharacterBattleStats_C*> ComputeCharactersForAOECounterAttack();
    void GetCurrentlyTargetingSkillState(class UBP_SkillState_C*& SkillState);
    double GetCharacterRadiusForPlacement(class ACharacter* Character);
    void DispatchEnemiesAlongSpline();
    void AdaptSpawnedCharacterLocation(FVector BaseLocation, const TArray<AActor*>& ActorsToIgnore, FVector& GroundLocation);
    bool CanSendReserveTeam();
    void LoadParty();
    void FindBattleModifierBuffByClass(TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, TArray<UBP_BattleBuffInstanceWrapper_C*>& ActiveBuffInstanceWrappers);
    bool HasBattleModifierBuffOfClass(TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass);
    void AddBattleModifierBuff(class UBP_BattleBuffInstance_C* BuffInstance, bool ForcePermanent);
    void FindCharacterAtBattleSpot(TEnumAsByte<ECharacterTeamSelector::Type> Team, int32 SpotIndex, class ABP_jRPG_Character_Battle_Base_C*& Character);
    void On Character Has Received Damage(class UBP_BattleDamages_C* BattleDamages);
    void GetEquippedCharacterGradientAttacks(class ABP_jRPG_Character_Battle_Base_C* Character, TArray<UBP_DataAsset_Skill_C*>& EquippedSkills);
    void AddExtraLootItem(const FName ItemId, const int32 Quantity, FString Reason);
    TMap<FName, int32> GetExtraLootItems();
    void ChangeBattleMap(TSoftObjectPtr<class ABP_BattleMap_C> BattleMapActor);
    void SetupBattleMap();
    void SetBattleMapInternal(class ABP_BattleMap_C* BattleMapActor);
    void ClearBattleMap();
    void SetBattleInputEnabled(bool Enabled);
    void GetCharacterAssetDependencies(FName CharacterId, TArray<TSoftClassPtr<UObject>>& OutClasses);
    void PrepareForBackupTeam(TArray<FName>& BackupTeam, TArray<TSoftClassPtr<UObject>>& ClassesToLoad);
    void RegisterPendingResurrect(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    bool ShouldQueueRevive();
    void PerformFlee();
    void RemoveBattleScreenHUD();
    void TryGetInterceptingCharacter(class UAC_jRPG_CharacterBattleStats_C* TargetedCharacterStats, class UAC_jRPG_CharacterBattleStats_C* AttackerCharacterStats, class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void CheckBattleEnd(bool& BattleHasEnded);
    void StartPreloadingBattleDependencies();
    void SpawnBattleSequence(class ULevelSequence* LevelSequence, class ABP_jRPG_Character_Battle_Base_C* SourceCharacter, TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetCharacters, bool SnapOnTarget, bool UseTargetAsOrigin, bool UseTargetOrientation, bool LookAtTarget, bool LookAtAttacker, bool DisableSequenceSnapping, class ABP_EpicBattleSequenceActor_C*& EpicSequence, FTransform& AttackerFirstPosition);
    void ComputeFreeAim3rdPersonTargetLocation(bool DEBUG_ForShoot, bool& HasHitCharacter, class ABP_jRPG_Character_Battle_Base_C*& CharacterBattle, FVector& HitLocation, FVector& StartLocation);
    void OnBattleMapReady();
    void TryLastStand(class ABP_jRPG_Character_Battle_Base_C* CharacterBattle, TEnumAsByte<EDamageReason::Type> DeathReason, bool& HasLastStand);
    void TryStealConsumableFromPlayer(class UAC_jRPG_CharacterBattleStats_C* Thief, FDataTableRowHandle ConsumableDataRow, int32 Quantity, int32& RemovedQuantity);
    void StartFreezeFrame(TEnumAsByte<E_FreezeFrame::Type> FreezeFrameType, class USF_BlueprintLatentAction*& LatentAction);
    class ABP_jRPG_Character_Battle_Base_C* SpawnPuppetCharacter(TSubclassOf<class ABP_jRPG_Character_Battle_Base_C> CharacterBPClass, class UAC_jRPG_CharacterBattleStats_C* PuppetedBy, double Scale);
    void OnLastStandFinished();
    bool IsLastStandActive();
    void TryGradientCounterAttack(class UBP_BattleFeedbackState_C* ParryState);
    void GetAssetsToLoadForBattle(TArray<TSoftClassPtr<UObject>>& ClassesToLoad);
    void GetEquippedCharacterSkills(class ABP_jRPG_Character_Battle_Base_C* Character, TArray<UBP_DataAsset_Skill_C*>& EquippedSkills);
    void SpawnCharacterFromStoredState(FFBattleCharacterStoredState StoredState, class ABP_jRPG_Character_Battle_Base_C*& SpawnedCharacter);
    void CheckForGameOver();
    void ReintegrateCharacterToBattle(FGuid& KickedCharacterHandle, class ABP_jRPG_Character_Battle_Base_C*& RespawnedCharacter);
    void KickCharacterFromBattle_Internal(const class ABP_jRPG_Character_Battle_Base_C*& Character, FGuid& KickedCharacterHandle);
    void GetPlayerCharacterAtBattleSpot(int32 SpotIndex, class ABP_jRPG_Character_Battle_Base_C*& Character);
    void OnTurnSkipped();
    void SpawnExtraPlayerCharacter(class UBP_CharacterData_C* CharacterData);
    void Spawn Player Character(class UBP_CharacterData_C* CharacterData, int32 BattleSpotIndex, TEnumAsByte<E_jRPG_FormationType::Type> FormationType, class ABP_jRPG_Character_Battle_Base_C*& SpawnedCharacter);
    void ShowSkillTooltip(FText TooltipName, FText TooltipDesc);
    void HideBattleMenuTooltip();
    void ShowBattleMenuTooltip(FText TooltipName, FText TooltipDesc);
    void GetCharacterData(FName CharacterId, class UBP_CharacterData_C*& CharacterData);
    void SpawnEnemyOnSpot(int32 BattleSpotIndex, FName CharacterHardcodedName, bool NotifyBattleStart, class ABP_jRPG_Character_Battle_Base_C*& SpawnedEnemy, FVector& EnemySpawnedLocation);
    void IsShowingTooltip(bool& IsShowingTooltip);
    void OnPlayerTurnPreStart();
    bool IsAFullTeamDead();
    void TryGetTargetedAllies(bool& Valid, TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedHeroes);
    void CanFleeCurrentFight(bool& FleeImpossible);
    void OnTargetingUpdate();
    void UpdateFreeAimHover();
    void OnTargetChanged();
    void OnPlayerCharacterTurnStart();
    void ProcessNextTurnStartListener();
    void DEBUG_GetBattleBuffClassByName(FString _className, TSubclassOf<class UBP_BattleBuffInstance_C>& BattleBuffInstanceClass);
    void SwitchCamera(FName PathID, bool RandomStartDistance, bool Loop, bool UpdatePathLocation);
    bool DEBUG_FindPlayerCharacterByName(FString Name, class UAC_jRPG_CharacterBattleStats_C*& AC_jRPG_CharacterStats);
    void UpdateMouseTargeting();
    void OnTurnEndEventEnd();
    void OnTurnEndEventBegin(class ABP_jRPG_Character_Battle_Base_C* Character);
    void GetAllAllyCharacters_SortedBySpotIndex(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllCharacters);
    void OnCounterAttackFinished();
    void TryCounterAttack(class UBP_BattleFeedbackState_C* ParryState);
    bool CanResumeBattle();
    void OnCancelTargeting();
    void OnStopTargeting(bool WasPreTargeting);
    void OnStartTargeting();
    void OnSelectFlee();
    void OnSelectSkip();
    void OnSelectSkillMenu();
    class UBP_GameDirectorComponent_C* Get Game Director Component();
    void ResetBattle();
    void GetCharactersState(TArray<ABP_jRPG_Character_Battle_Base_C*>& Characters, TArray<double>& CharactersInitiative, TArray<bool>& CharactersEngagementBonus);
    void GetAllEnemyCharacters_SortedBySpotIndex(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllEnemies);
    void GetAllPlayerCharacters(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllCharacters);
    void GetAllAliveCharacters(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllCharacters);
    void GetAllCharacters(TArray<ABP_jRPG_Character_Battle_Base_C*>& AllCharacters);
    void SpawnOnlyRequestedTeam();
    void SpawnAllCharacters();
    void OnSkillSelectionClosed();
    void AddDefenseSuccessFeedback();
    void AddParrySuccessFeedback();
    void AddDodgeSuccessFeedback();
    void ConcatActors(TArray<AActor*>& Actors, FText& Result);
    void GetJRPGControllerWorld(class ABP_jRPG_Controller_World_C*& JRPG Controller);
    void Is Attacking Heroes(class ABP_jRPG_Enemy_Battle_Base_C* Enemy, bool& IsAttacking, TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedHeroes);
    void ActivateCharacterCamera();
    void StartCharacterTurn_Phase2();
    void GetTeamMotivationLevel(TEnumAsByte<ETeamMotivationLevelType::Type>& LevelType, double& LevelProgress);
    void IsPlayerTeamCharacterBase(class ABP_jRPG_Character_Battle_Base_C* CharacterBattle, bool& IsPlayerTeam);
    void IsPlayerTeamCharacterStats(class UAC_jRPG_CharacterBattleStats_C* CharacterBattleStats, bool& IsPlayerTeam);
    class UAC_jRPG_TargetingManager_C* GetTargetingManager();
    void ChangeTeamMotivation(double Delta, FText ReasonText);
    void UnspawnEnemies();
    void UnspawnPlayerCharacters();
    void GetQTEManager(class UBP_QTEManager_C*& QTEManager);
    void OnCharacterReceivedDamages(class UAC_jRPG_CharacterBattleStats_C* TargetCharacterStats, double Damages, class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStats, class UBP_BattleDamages_C* BattleDamages);
    void FindCharacterStatsBattleActor(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, class ABP_jRPG_Character_Battle_Base_C*& BattleCharacterActor);
    void UpdateCharacterNextTurns();
    void Debug_PrintCharacterTurns(FText& debugStr);
    void GetWorldEnemiesTransforms(TMap<FName, FTransform>& EnemiesTransforms);
    void OnPlayerCharacterResurrected(class ABP_jRPG_Character_Battle_Base_C* PlayerCharacter);
    void Disable Targeting and Input();
    void OnPlayerCharacterKilled(class ABP_jRPG_Character_Battle_Base_C* PlayerCharacter);
    void GetCharactersWithFormation(TArray<ABP_jRPG_Character_Battle_Base_C*>& CharactersArray, TEnumAsByte<E_jRPG_FormationType::Type> DesiredFormation, TArray<ABP_jRPG_Character_Battle_Base_C*>& Result);
    void End Character Turn(double UsedInitiative);
    void SelectSecondaryAction(FName SelectedSecondaryAction);
    void GetAllItemsUsableInBattle(TArray<FS_jRPG_Item_DynamicData>& UsableItem);
    void StartCharacterTurn(class ABP_jRPG_Character_Battle_Base_C* Character);
    void ReceiveBattleRewards(FS_BattleRewards& BattleRewards);
    void CheckIfAlreadyLootedItem(TArray<FS_jRPG_Item_DynamicData>& LootedItems, FName ItemHardcodedName, bool& AlreadyLooted?, int32& SlotIndex);
    void ComputeExtraLootItems();
    void RollBattleRewards(FS_BattleRewards& BattleRewards);
    void UpdateBattleEndVictoryScreen(TArray<UAC_jRPG_CharacterBattleStats_C*>& CharacterBattleStats, FS_BattleRewards& BattleRewards);
    void CreateBattleEndVictoryScreen(TArray<UBP_CharacterData_C*>& AllCharacterData);
    void ProcessVictoryEndFlow();
    void PreStopBattleSystems();
    void TryFlushBattleStateToGameState();
    void StoreAllCharacterFinalStates();
    void StoreCharacterFinalState(class ABP_jRPG_Character_Battle_Base_C* CharacterBattle);
    void ShowBattleTooltip(FText ToolTipText, bool AutoFadeout);
    void RequestActionExecution(TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedCharacters);
    void GoBackToExploration();
    void OnEnemyKilled(class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void SelectAction(TEnumAsByte<E_jRPG_ActionType::Type> ActionType);
    void CreateBattleInterface();
    void GetCharacterWithMaxInitiativeSimulate(TArray<ABP_jRPG_Character_Battle_Base_C*>& Characters, TArray<double>& CharactersInitiative, TArray<bool>& HasEngagementBonus, int32 SimulationStep, bool DEBUG_Verbose, bool& Success?, class ABP_jRPG_Character_Battle_Base_C*& Character, double& TimeToTurn);
    void GetCharacterWithMaxInitiative(bool DEBUG_Verbose, bool& Success?, class ABP_jRPG_Character_Battle_Base_C*& Character, double& TimeToTurn);
    void SpawnEnemies();
    void GetProperBattleSpawnPointTransform(bool EnemySpot?, int32 SpotIndex, TEnumAsByte<E_jRPG_FormationType::Type> FormationType, FTransform& BattleSpotTransform, TEnumAsByte<E_jRPG_FormationType::Type>& BattleSpotFormationType);
    void SpawnPlayerCharactersFromParty();
    void LoadEncounterSettings();
    void OnFinished_58BC12074BE00B90B5CACAAD978D45F2();
    void OnFinished_58BC12074BE00B90B5CACAADC430CF2B();
    void OnFinished_58BC12074BE00B90B5CACAAD8F0606F4();
    void OnRequestDone_8C2416AD4A8AC40CBFE10886B5BA038C();
    void OnFinished_6D90D4DD4291EFA19FD1D188BD270CC6();
    void OnFinished_87FC6BA24FD98A8FD85B999AF19DF012();
    void OnFinished_7574233641EBEE55E33399A458B6A201();
    void OnFinished_D23A3CB34350BC4B7F58FA81A8CA41AF();
    void OnFinished_AA7B24BA438CCF872213CCB429A957E8();
    void OnFinished_2D0A3697490DFAD752C11F89FD2218CA();
    void OnFinished_846FEEF2465960CA826606AD5416E647();
    void OnFinished_3B9680914EC52C5987B913AB52568CD9();
    void OnFinished_BACC7CD44396AB29EC64CAA6E6A2885D();
    void OnFinished_81711B71411E4D69320D38B39A03F19F();
    void OnFinished_6BC7AB0B46F32A1EE16B0AB17F7837C1();
    void OnLoaded_F58B7C71485B149C4ED04FB5D95BEB82(class UObject* Loaded);
    void OnFinished_FDED7E8741285BACE8169884161F56D8();
    void EnableFreeAimControls(TEnumAsByte<EFreeAimType::Type> FreeAimType);
    void DisableFreeAimControls();
    void StartFreeAimFromUI();
    void CancelFreeAimFromUI();
    void StartBattleNEW(FFBattleStartParams BattleStartParams);
    void TriggerBattleStartEvents(class USF_BlueprintLatentAction* LatentAction);
    void ProcessNextCharacterBattleStartEvent();
    void OnAllBattleStartEventsTriggered();
    void TriggerBattleStartEventsInstant();
    void BattleStart_ProcessNextCharacter_SkillSetup();
    void StartBattleTransition(class USF_BlueprintLatentAction* TransitionIntroLatentAction);
    void TODO_STARTBATTLE();
    void TriggerBattleStartEventsForCharacters(TArray<ABP_jRPG_Character_Battle_Base_C*>& CharactersToProcess, class USF_BlueprintLatentAction* LatentAction);
    void OnBattleDependenciesFullyLoaded();
    void OnDataLayersActivated();
    void Sandfall_KillCharacter(FString CharacterName);
    void Sandfall_KillAllEnemies();
    void Sandfall_HeroesIgnoreDamage(bool Ignore);
    void Sandfall_AddAP(FString Character, int32 Amount);
    void Sandfall_SetAllEnemiesHP(int32 NewHPValue);
    void Sandfall_ApplyBuffToAllEnemies(FString BuffBPClass);
    void Sandfall_ReproBurnDeath();
    void Sandfall_KillEnemy();
    void Sandfall_SetAllAlliesAP(int32 Amount);
    void Sandfall_SetAllAlliesHP(int32 HP);
    void Sandfall_KillAllies();
    void Sandfall_ApplyBuffToAlly(FString AllyName, FString BuffBPClass);
    void Sandfall_DamageCharacter (FString CharacterName);
    void Sandfall_ChangePerfection(FString CharacterId, int32 PerfectionChange);
    void Sandfall_ApplyShieldToEnemies(int32 ShieldAmount);
    void Sandfall_DamageEnemies(double Damages);
    void Sandfall_KillCharacterByObject(class UAC_jRPG_CharacterBattleStats_C* Target, class UAC_jRPG_CharacterBattleStats_C* Source);
    void Sandfall_TestInterception();
    void OnDefendStart();
    void OnDefendStop();
    void OnParryAction();
    void OnDodgeAction();
    void UpdateDefend(FText DebugReason);
    void UpdateDefenseControls();
    void OnComboPressed();
    void SetDefenseState(bool WantedDefense);
    void OnGradientCounterAction();
    void OnJumpAction();
    void OnJumpShot();
    void ResetInterceptions(class USF_BlueprintLatentAction* LatentAction);
    void ResumeBattle();
    void AddInitativeToAllCharacters();
    void OnBattleEndVictory();
    void OnAllHeroesKilled();
    void StartBattle(TEnumAsByte<E_jRPG_EngageTypes::Type> EngageType);
    void OnCharacterActionFinished(class ABP_jRPG_Character_Battle_Base_C* Character);
    void OnDodgeSuccess(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void OnParrySuccess(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void ProcessNextFeedback();
    void FeedbackSuccessfulDodge(class UBP_BattleFeedbackState_C* DodgeInfo);
    void FeedbackSuccessfulParry(class UBP_BattleFeedbackState_C* ParryInfo);
    void OnDefendSuccess(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void FeedbackSuccessfulDefend(class UBP_BattleFeedbackState_C* DefendInfo);
    void ResumeBattleNew();
    void StartCounterAttackInternal(class ABP_jRPG_Character_Battle_Base_C* Source, class ABP_jRPG_Character_Battle_Base_C* Target);
    void TryResumeBattle();
    void OnGameOverScreenClosed();
    void TriggerSkillCounter(class UAC_jRPG_CharacterBattleStats_C* TargetCharacterStats, class UAC_jRPG_CharacterBattleStats_C* CounteringCharacterStats, TSubclassOf<class ABP_Battle_SkillScript_C> Skill);
    void TriggerSkill(TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedCharacters, class UAC_jRPG_CharacterBattleStats_C* Source, TSubclassOf<class ABP_Battle_SkillScript_C> SkillClass);
    void OnBattleEndBlockerLifted(bool _isActive);
    void OnGradientCounterSuccess();
    void PerformLastStandFlow();
    void OnAllEnemiesKilled();
    void SpawnBackupTeam();
    void OnBackupTeamLoaded();
    void OnReserveTeamResponse(bool ShouldSendReserve);
    void ShowReserveTeamGameOver();
    void ForceBattleEnd(TEnumAsByte<EBattleEndResult::Type> BattleEndResult);
    void OnAllEnemiesKilledInternal();
    void StartBattleEndFlow(TEnumAsByte<EBattleEndResult::Type> BattleEndResult);
    void ProcessLastStandEvents(class USF_BlueprintLatentAction* LatentAction);
    void OnAllLastStandsCompleted_Internal();
    void ProcessNextCharacterTurnEnd();
    void OnCharacterDashBackComplete(class ABP_jRPG_Character_Battle_Base_C* CharacterBase);
    void OnCharacterDashBackCompleteComponent(class UAC_jRPG_CombatMovement_C* MovementComponent);
    void MoveCharactersBackToTheirSpots(class USF_BlueprintLatentAction* LatentAction, FString DebugReason);
    void ProcessAdditionalTurnEndEvent();
    void OnRetryEncounterResponse(bool ShouldRetry);
    void RegisterPauseIMC(bool Enabled);
    void ProcessNextPendingResurrect(class USF_BlueprintLatentAction* LatentAction);
    void ReceiveBeginPlay();
    void EventBattleStart();
    void ReceiveTick(float DeltaSeconds);
    void UpdateBattleTurns();
    void PlayFreezeFrameInternal(class USF_BlueprintLatentAction* LatentAction, float TimeDilation, float GameDuration);
    void OnCharacterLastStandStarted(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterLastStandEnded(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnLastStandDuringFreeAimFinishedFlow();
    void OnVictoryScreenClosedFlow();
    void DEBUG_CVarChange_BattleLine_SkipRoll(bool NewValue);
    void StartAudioForBattle(class USF_BlueprintLatentAction* LatentAction);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_AC_jRPG_BattleManager(int32 EntryPoint);
    void OnAllTurnStartEventsProcessed__DelegateSignature();
    void OnSkipImpossibleChanged__DelegateSignature(bool IsSkipImpossible);
    void OnAPChanged__DelegateSignature(class UBP_BattleEvent_APChange_C* APChange);
    void OnShieldPointsIncreased__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, int32 NewPoints, int32 PreviousPoints);
    void OnCharacterHealSuccessful__DelegateSignature(class UBP_BattleHeal_C* HealObject);
    void OnEnemySpawned__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterBreakStunned__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* StunnedCharacterStat, class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStat);
    void OnStartedTargeting__DelegateSignature();
    void OnCharacterReceivedDamage__DelegateSignature(class UBP_BattleDamages_C* BattleDamage);
    void OnCharacterKilled__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character);
    void OnDefendSuccessful__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void OnParrySuccessful__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void OnDodgeSuccessful__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void OnResurected__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* CharacterResurected);
    void OnEnemyKilledEvent__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* CharStats);
    void OnBattleFlee__DelegateSignature();
    void OnBattleReadyToStart__DelegateSignature();
    void OnTurnStart__DelegateSignature(class ABP_jRPG_Character_Battle_Base_C* Character);
    void OnBattleFinished__DelegateSignature(bool Victory);
}; // Size: 0xB88

#endif
