#ifndef UE4SS_SDK_BP_EnemyGroup_HPP
#define UE4SS_SDK_BP_EnemyGroup_HPP

class ABP_EnemyGroup_C : public AActor
{
    class UBP_Enemy_SerializableComponent_C* BP_Enemy_SerializableComponent;          // 0x0290 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    TArray<TSoftObjectPtr<class ABP_jRPG_Enemy_World_Base_Seamless_C>> EnemyWorlds;   // 0x02A8 (size: 0x10)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    bool Editor_DrawDebugShapes();
    bool Editor_GetDebugShapes(TArray<FEditorDebugShape_Arrow>& Arrows, TArray<FEditorDebugShape_Arrow>& Lines);
    void RefreshLinks();
    void GetGlobalObjectID(FName& ObjectId);
    void UserConstructionScript();
}; // Size: 0x2B8

#endif
