#ifndef UE4SS_SDK_BP_FX_AfterImage_HPP
#define UE4SS_SDK_BP_FX_AfterImage_HPP

class ABP_FX_AfterImage_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_Debug;                                             // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    class UMeshComponent* TargetToFollow;                                             // 0x02A8 (size: 0x8)
    TArray<FTransform> SnapshotTransforms;                                            // 0x02B0 (size: 0x10)
    TArray<double> SnapshotTimes;                                                     // 0x02C0 (size: 0x10)
    bool ShouldFollow;                                                                // 0x02D0 (size: 0x1)
    double TimeOffset;                                                                // 0x02D8 (size: 0x8)

    void GetClosestTimeIndex(double GameTime, int32& ArrayIndex);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void FollowTheTarget();
    void ExecuteUbergraph_BP_FX_AfterImage(int32 EntryPoint);
}; // Size: 0x2E0

#endif
