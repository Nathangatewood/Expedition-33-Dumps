#ifndef UE4SS_SDK_BP_ExplorationCapacity_TorchObject_HPP
#define UE4SS_SDK_BP_ExplorationCapacity_TorchObject_HPP

class ABP_ExplorationCapacity_TorchObject_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UPointLightComponent* Torch_Light;                                          // 0x0298 (size: 0x8)
    class UNiagaraComponent* FX_Spring_Meadows_Weak_Point;                            // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Torch_Ball;                                           // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)

    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_ExplorationCapacity_TorchObject(int32 EntryPoint);
}; // Size: 0x2B8

#endif
