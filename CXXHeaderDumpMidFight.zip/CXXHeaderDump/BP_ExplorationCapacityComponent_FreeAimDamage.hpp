#ifndef UE4SS_SDK_BP_ExplorationCapacityComponent_FreeAimDamage_HPP
#define UE4SS_SDK_BP_ExplorationCapacityComponent_FreeAimDamage_HPP

class UBP_ExplorationCapacityComponent_FreeAimDamage_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UBP_ExplorationProgressionSystem_C* ExplorationProgressionState;            // 0x00A8 (size: 0x8)

    void GetFreeAimDamageLevel(int32& FreeAimDamageLevel);
    bool CanDamageElement(int32 Level);
    void LoadStateFromGI(class UBP_jRPG_GI_Custom_C* GameInstance);
    void ExecuteUbergraph_BP_ExplorationCapacityComponent_FreeAimDamage(int32 EntryPoint);
}; // Size: 0xB0

#endif
