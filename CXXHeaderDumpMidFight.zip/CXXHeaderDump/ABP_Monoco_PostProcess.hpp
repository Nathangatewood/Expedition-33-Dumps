#ifndef UE4SS_SDK_ABP_Monoco_PostProcess_HPP
#define UE4SS_SDK_ABP_Monoco_PostProcess_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_118;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_119;                                                         // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_120;                                        // 0x0018 (size: 0x20)
    class UBlendProfile* __BlendProfile_121;                                          // 0x0038 (size: 0x8)
    class UCurveFloat* __CurveFloat_122;                                              // 0x0040 (size: 0x8)
    bool __BoolProperty_123;                                                          // 0x0048 (size: 0x1)
    EAlphaBlendOption __EnumProperty_124;                                             // 0x0049 (size: 0x1)
    EBlendListTransitionType __EnumProperty_125;                                      // 0x004A (size: 0x1)
    TArray<float> __ArrayProperty_126;                                                // 0x0050 (size: 0x10)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0060 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00E0 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0128 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0158 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose;        // 0x0188 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_3;        // 0x01B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_2;        // 0x01E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics_1;        // 0x0218 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_KawaiiPhysics;          // 0x0248 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_25;        // 0x0278 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_24;        // 0x02A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_23;        // 0x02D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_22;        // 0x0308 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_21;        // 0x0338 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_20;        // 0x0368 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_19;        // 0x0398 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_18;        // 0x03C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_17;        // 0x03F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BoneDrivenController_1; // 0x0428 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BoneDrivenController;   // 0x0458 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x0488 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_16;        // 0x04B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_15;        // 0x04E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_14;        // 0x0518 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_13;        // 0x0548 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_12;        // 0x0578 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_11;        // 0x05A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_10;        // 0x05D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_9;         // 0x0608 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_8;         // 0x0638 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_7;         // 0x0668 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_6;         // 0x0698 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_5;         // 0x06C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_4;         // 0x06F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_3;         // 0x0728 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_2;         // 0x0758 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics_1;         // 0x0788 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics;           // 0x07B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x07E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0818 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool;        // 0x0848 (size: 0x30)

}; // Size: 0x878

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    bool __BoolProperty;                                                              // 0x0001 (size: 0x1)

}; // Size: 0x2

class UABP_Monoco_PostProcess_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x2)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0380 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0388 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0390 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x03B0 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x03D0 (size: 0x20)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;                          // 0x03F0 (size: 0xB8)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3;                            // 0x04B0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2;                            // 0x0C50 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_1;                            // 0x13F0 (size: 0x7A0)
    FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics;                              // 0x1B90 (size: 0x7A0)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_25;                             // 0x2330 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_24;                             // 0x2850 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_23;                             // 0x2D70 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_22;                             // 0x3290 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_21;                             // 0x37B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_20;                             // 0x3CD0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_19;                             // 0x41F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_18;                             // 0x4710 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_17;                             // 0x4C30 (size: 0x520)
    FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_1;              // 0x5150 (size: 0x128)
    FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController;                // 0x5278 (size: 0x128)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x53A0 (size: 0x28)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_16;                             // 0x53D0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_15;                             // 0x58F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_14;                             // 0x5E10 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_13;                             // 0x6330 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12;                             // 0x6850 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;                             // 0x6D70 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;                             // 0x7290 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;                              // 0x77B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;                              // 0x7CD0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;                              // 0x81F0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;                              // 0x8710 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;                              // 0x8C30 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;                              // 0x9150 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;                              // 0x9670 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;                              // 0x9B90 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_1;                              // 0xA0B0 (size: 0x520)
    FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;                                // 0xA5D0 (size: 0x520)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0xAAF0 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0xAB70 (size: 0x28)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0xAB98 (size: 0x48)
    bool ShouldDisablePostProcess;                                                    // 0xABE0 (size: 0x1)
    double AlphaTransition;                                                           // 0xABE8 (size: 0x8)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void OnPhotoModeExited();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Monoco_PostProcess_AnimGraphNode_KawaiiPhysics_CB42337C485FB5DA3BC2F282F71F8498();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Monoco_PostProcess_AnimGraphNode_KawaiiPhysics_6FFC1B294751E0C4F677EC96B4819A13();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Monoco_PostProcess_AnimGraphNode_KawaiiPhysics_3FADAF2D4AC8E6265A0CA7BCB6E90970();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Monoco_PostProcess_AnimGraphNode_KawaiiPhysics_D4C75B7843A7D4EE51EBE79BA9148E11();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void BlueprintBeginPlay();
    void ExecuteUbergraph_ABP_Monoco_PostProcess(int32 EntryPoint);
}; // Size: 0xABF0

#endif
