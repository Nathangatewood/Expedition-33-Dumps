#ifndef UE4SS_SDK_ABP_CustomMovement_HPP
#define UE4SS_SDK_ABP_CustomMovement_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_56;                                                          // 0x0004 (size: 0x8)
    float __FloatProperty_57;                                                         // 0x000C (size: 0x4)
    TEnumAsByte<ESequenceEvalReinit::Type> __ByteProperty_58;                         // 0x0010 (size: 0x1)
    bool __BoolProperty_59;                                                           // 0x0011 (size: 0x1)
    EAnimSyncMethod __EnumProperty_60;                                                // 0x0012 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_61;                              // 0x0013 (size: 0x1)
    FName __NameProperty_62;                                                          // 0x0014 (size: 0x8)
    FName __NameProperty_63;                                                          // 0x001C (size: 0x8)
    FName __NameProperty_64;                                                          // 0x0024 (size: 0x8)
    int32 __IntProperty_65;                                                           // 0x002C (size: 0x4)
    class UBlendProfile* __BlendProfile_66;                                           // 0x0030 (size: 0x8)
    class UCurveFloat* __CurveFloat_67;                                               // 0x0038 (size: 0x8)
    bool __BoolProperty_68;                                                           // 0x0040 (size: 0x1)
    EAlphaBlendOption __EnumProperty_69;                                              // 0x0041 (size: 0x1)
    EBlendListTransitionType __EnumProperty_70;                                       // 0x0042 (size: 0x1)
    TArray<float> __ArrayProperty_71;                                                 // 0x0048 (size: 0x10)
    FAnimNodeFunctionRef __StructProperty_72;                                         // 0x0058 (size: 0x20)
    FAnimSubsystem_Tag AnimBlueprintExtension_Tag;                                    // 0x0078 (size: 0x60)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00D8 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0158 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_2;      // 0x0170 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_1;      // 0x01A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x01D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SubInput;               // 0x0200 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedAnimGraph_1;      // 0x0230 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0260 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x0290 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x02C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator;      // 0x02F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0320 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0350 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool;        // 0x0380 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedAnimGraph;        // 0x03B0 (size: 0x30)

}; // Size: 0x3E0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    TArray<float> __ArrayProperty;                                                    // 0x0008 (size: 0x10)
    bool __BoolProperty_0;                                                            // 0x0018 (size: 0x1)
    TArray<float> __ArrayProperty_1;                                                  // 0x0020 (size: 0x10)
    bool __BoolProperty_2;                                                            // 0x0030 (size: 0x1)
    float __FloatProperty_3;                                                          // 0x0034 (size: 0x4)
    class UAnimSequenceBase* __AnimSequenceBase_4;                                    // 0x0038 (size: 0x8)
    bool __BoolProperty_5;                                                            // 0x0040 (size: 0x1)

}; // Size: 0x41

class UABP_CustomMovement_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x48)
    FAnimSubsystemInstance AnimBlueprintExtension_Tag;                                // 0x03C0 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x03C8 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x03D0 (size: 0x8)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;                        // 0x03D8 (size: 0x48)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_1;                        // 0x0420 (size: 0x48)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0468 (size: 0x20)
    FAnimNode_LinkedInputPose AnimGraphNode_SubInput;                                 // 0x0488 (size: 0xB8)
    FAnimNode_LinkedAnimGraph AnimGraphNode_LinkedAnimGraph_1;                        // 0x0540 (size: 0xB8)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x05F8 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0618 (size: 0x128)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0740 (size: 0x20)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;                      // 0x0760 (size: 0x40)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x07A0 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x07C0 (size: 0xC8)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0x0888 (size: 0x48)
    FAnimNode_LinkedAnimGraph AnimGraphNode_LinkedAnimGraph;                          // 0x08D0 (size: 0xB8)
    bool IsLadder;                                                                    // 0x0988 (size: 0x1)
    double LadderPos;                                                                 // 0x0990 (size: 0x8)
    double LadderBlendTime;                                                           // 0x0998 (size: 0x8)
    class ACharacter* Owner;                                                          // 0x09A0 (size: 0x8)
    bool IsClimbing;                                                                  // 0x09A8 (size: 0x1)
    bool IsMovingNextHold;                                                            // 0x09A9 (size: 0x1)
    double MovingNextHoldTransitionAlpha;                                             // 0x09B0 (size: 0x8)
    FVector MovingNextHoldTransitionDelta;                                            // 0x09B8 (size: 0x18)
    FVector ClimbingReadyDirection;                                                   // 0x09D0 (size: 0x18)
    double ClimbingBlendTIme;                                                         // 0x09E8 (size: 0x8)
    class UBP_CustomMovementComponent_C* CustomMovement;                              // 0x09F0 (size: 0x8)
    class UAnimMontage* AM_EnteringLadderTop;                                         // 0x09F8 (size: 0x8)
    class UAnimMontage* AM_EnteringLadderBottom;                                      // 0x0A00 (size: 0x8)
    class UAnimMontage* AM_ExitingLadderTop;                                          // 0x0A08 (size: 0x8)
    class UAnimMontage* AM_ExitingLadderBottom;                                       // 0x0A10 (size: 0x8)
    class UAnimMontage* AM_EnteringClimbingTop;                                       // 0x0A18 (size: 0x8)
    class UAnimMontage* AM_ExitingClimbingTop;                                        // 0x0A20 (size: 0x8)
    class UAnimSequence* AS_Ladder_Up_Loop;                                           // 0x0A28 (size: 0x8)
    bool IsUsingRope;                                                                 // 0x0A30 (size: 0x1)
    TEnumAsByte<ECustomMovementMode::Type> CurrentCustomMovementMode;                 // 0x0A31 (size: 0x1)

    void AnimGraph(FPoseLink InPose, FPoseLink& AnimGraph);
    void ResetState();
    void UpdateAnimationAssets();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CustomMovement_AnimGraphNode_SequenceEvaluator_5A9EED8A4B8A3A3293F9AA8EAC63B9CA();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void BlueprintInitializeAnimation();
    void ExecuteUbergraph_ABP_CustomMovement(int32 EntryPoint);
}; // Size: 0xA32

#endif
