#ifndef UE4SS_SDK_BP_BattleBuff_Foretell_Charge_Sun_HPP
#define UE4SS_SDK_BP_BattleBuff_Foretell_Charge_Sun_HPP

class UBP_BattleBuff_Foretell_Charge_Sun_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void SunAPGainOnForetellConsumed(class UAC_jRPG_CharacterBattleStats_C* TargetStats, int32 PreviousForetell, int32 ForetellConsumed, TEnumAsByte<EBattleContext::Type> Reason);
    void DeactivateBuff();
    void ExecuteUbergraph_BP_BattleBuff_Foretell_Charge_Sun(int32 EntryPoint);
}; // Size: 0x160

#endif
