#ifndef UE4SS_SDK_BP_BattleMap_DuollistAlpha_HPP
#define UE4SS_SDK_BP_BattleMap_DuollistAlpha_HPP

class ABP_BattleMap_DuollistAlpha_C : public ABP_BattleMap_C
{
}; // Size: 0x548

#endif
