#ifndef UE4SS_SDK_BP_BattleLookAtComponent_HPP
#define UE4SS_SDK_BP_BattleLookAtComponent_HPP

class UBP_BattleLookAtComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FTransform LookAtTarget;                                                          // 0x00B0 (size: 0x60)
    double LookAtAlpha;                                                               // 0x0110 (size: 0x8)
    double InterpolationSpeed;                                                        // 0x0118 (size: 0x8)

    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_BattleLookAtComponent(int32 EntryPoint);
}; // Size: 0x120

#endif
