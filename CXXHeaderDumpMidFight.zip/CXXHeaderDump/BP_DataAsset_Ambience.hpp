#ifndef UE4SS_SDK_BP_DataAsset_Ambience_HPP
#define UE4SS_SDK_BP_DataAsset_Ambience_HPP

class UBP_DataAsset_Ambience_C : public UPrimaryDataAsset
{
    class USoundBase* AmbienceGlobal;                                                 // 0x0030 (size: 0x8)
    TArray<UBP_DataAsset_SoundWithDelay_C*> RFXData;                                  // 0x0038 (size: 0x10)
    double AmbienceFadeOutDuration;                                                   // 0x0048 (size: 0x8)
    double AmbienceFadeInDuration;                                                    // 0x0050 (size: 0x8)

}; // Size: 0x58

#endif
