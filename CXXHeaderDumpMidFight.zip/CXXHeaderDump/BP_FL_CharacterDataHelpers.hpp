#ifndef UE4SS_SDK_BP_FL_CharacterDataHelpers_HPP
#define UE4SS_SDK_BP_FL_CharacterDataHelpers_HPP

class UBP_FL_CharacterDataHelpers_C : public UBlueprintFunctionLibrary
{

    TArray<FS_ItemQuantity> GetCharacterResetConsumableCost(class UObject* __WorldContext);
    void GetNameFromItemSubtype(TEnumAsByte<E_jRPG_ItemSubtype::Type> ItemSubtype, class UObject* __WorldContext, FName& Name);
    void ToHardcodedName(TEnumAsByte<E_CharacterList::Type> Character, class UObject* __WorldContext, FName& HardcodedName);
}; // Size: 0x28

#endif
