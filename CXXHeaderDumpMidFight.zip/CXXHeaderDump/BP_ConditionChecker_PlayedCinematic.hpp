#ifndef UE4SS_SDK_BP_ConditionChecker_PlayedCinematic_HPP
#define UE4SS_SDK_BP_ConditionChecker_PlayedCinematic_HPP

class UBP_ConditionChecker_PlayedCinematic_C : public UBP_ConditionChecker_C
{
    FName CinematicID;                                                                // 0x0060 (size: 0x8)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x68

#endif
