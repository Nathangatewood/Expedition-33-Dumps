#ifndef UE4SS_SDK_BP_FL_GameUserSettingsHelpers_HPP
#define UE4SS_SDK_BP_FL_GameUserSettingsHelpers_HPP

class UBP_FL_GameUserSettingsHelpers_C : public UBlueprintFunctionLibrary
{

    void ShouldEnableBattleCameraMovements(class UObject* __WorldContext, bool& Enable);
    bool ShouldDoAutoQTE(class UObject* __WorldContext);
    double GetFinalCameraYawInputMultiplierForMouse(class UObject* __WorldContext);
    double GetFinalCameraPitchInputMultiplierForMouse(class UObject* __WorldContext);
    double GetFinalCameraYawInputMultiplierForController(class UObject* __WorldContext);
    double GetFinalCameraPitchInputMultiplierForController(class UObject* __WorldContext);
    void GetConfigurableGameUserSettings(class UObject* __WorldContext, class UConfigurableGameUserSettings*& GameUserSettings);
}; // Size: 0x28

#endif
