#ifndef UE4SS_SDK_BP_BattleBuffComponent_HPP
#define UE4SS_SDK_BP_BattleBuffComponent_HPP

class UBP_BattleBuffComponent_C : public UExtendedObject
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    TArray<UBP_BattleBuffInstanceWrapper_C*> ActiveBattleBuffs;                       // 0x0030 (size: 0x10)
    class UAC_jRPG_CharacterBattleStats_C* OwnerAsCharacterStat;                      // 0x0040 (size: 0x8)
    TArray<UBP_BattleBuffInstanceWrapper_C*> StandbyBattleBuffs;                      // 0x0048 (size: 0x10)
    bool Safeguard_CanAddNonPassiveBuffs;                                             // 0x0058 (size: 0x1)

    void FindActiveBuffsByInstigator(class UObject* Instigator, TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, TArray<UBP_BattleBuffInstance_C*>& BuffInstances);
    void OnReintegratedToBattle();
    void Init();
    bool IsReadyToAddBuffs();
    void ProcessBattleStartEvents(class UBP_DependencyRefCounter_C* DepsRefCount);
    void ProcessDealtDamageCriticalHitChance(class UBP_BattleDamages_C* BattleDamages);
    void OnCharacterTurnEnd();
    void ProcessAPChangeEvent(class UBP_BattleEvent_APChange_C* APChange);
    void OnGradientGaugeChange(class UBP_GradientGaugeChangeEvent_C* GradientChangeEvent);
    void OnBattleEnded();
    void OnDeathDamagePrevented();
    void GetOrCreateAggregatorBuff(TSubclassOf<class UBP_BattleBuffInstance_AggregatorBase_C> AggregatorBuffClass, class UBP_BattleBuffInstance_AggregatorBase_C*& AggregatorInstance);
    bool HasBuffOfClass(TSubclassOf<class UBP_BattleBuffInstance_C> Buff);
    void OnCharacterHealed(class UBP_BattleHeal_C* Heal);
    void TryRemoveBuffStacks(TSubclassOf<class UBP_BattleBuffInstance_C> Buff, int32 Number of stacks to remove, int32& ConsumedStacks);
    void ProcessAttackElement(class UBP_BattleDamages_C* BattleDamages);
    void ProcessPermeate(class UBP_BattleDamages_C* BattleDamages);
    void GetStatusEffectBuffInstance(TArray<UBP_BattleBuffInstance_C*>& Array);
    int32 GetActiveBuffCounts(TSubclassOf<class UBP_BattleBuffInstance_C> Buff);
    void CreateBuffStack(TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, int32 Count, int32 TurnDuration, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, TArray<UBP_BattleBuffInstance_C*>& CreatedInstances);
    void On Stance Change(TEnumAsByte<E_StanceType::Type> NewStance, TEnumAsByte<E_StanceType::Type> previousStance, TEnumAsByte<E_StanceType::Type>& NewStance1, TEnumAsByte<E_StanceType::Type>& PreviousStance1);
    void RemoveAllBuffsOfType(TEnumAsByte<E_BuffAndStatusEffectTypes::Type> BuffType);
    void RemoveAllBuffsFromFamily(TSubclassOf<class UBP_BattleBuffInstance_C> BuffFamily);
    void ProcessAPChange(int32 NewAP, int32 PreviousAP, TEnumAsByte<EAPChangeReason::Type> ChangeReason, int32& ProcessedNewAP);
    void On Perfection Changed(int32 CurrentPerfection, int32 PreviousPerfection, TEnumAsByte<E_PerfectionUpdateType::Type> PerfectionChangeType, TEnumAsByte<EPerfectionReason::Type> PerfectionChangeReason, int32& FinalPerfection);
    void OnOwnerRevived();
    void DeactivateOnOwnerKilled();
    void OnCharacterTurnStart();
    void RemoveBuffInstance(class UBP_BattleBuffInstance_C* BuffInstance);
    void RemoveBuffWrapper(class UBP_BattleBuffInstanceWrapper_C* BuffInstanceWrapper, bool& Success);
    void ProcessRemovedBuffs();
    void FindWrapper(class UBP_BattleBuffInstance_C*& Buff, class UBP_BattleBuffInstanceWrapper_C*& BuffInstanceWrappers);
    void GetBuffInstancesByTypes(TArray<TEnumAsByte<E_BuffAndStatusEffectTypes::Type>>& Type, TArray<UBP_BattleBuffInstance_C*>& Array);
    void GetBuffInstancesByType(TEnumAsByte<E_BuffAndStatusEffectTypes::Type> Type, TArray<UBP_BattleBuffInstance_C*>& Array);
    void TryConsumeBuffs(TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, int32 MinCount, int32 MaxCount, bool IgnoreMaxCount, bool& Success, int32& ConsumedBuffs);
    void ProcessReceivedRawDamages(class UBP_BattleDamages_C*& BattleDamages);
    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages);
    void RemoveBuffStacks(TSubclassOf<class UBP_BattleBuffInstance_C> Buff, int32 Number of stacks to remove);
    void GetStandbyBuffsByClass(TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, TArray<UBP_BattleBuffInstanceWrapper_C*>& StandbyBuffInstanceWrappers);
    void GetActiveBuffsByClass(TSubclassOf<class UBP_BattleBuffInstance_C> BuffClass, TArray<UBP_BattleBuffInstanceWrapper_C*>& ActiveBuffInstanceWrappers);
    void FindExistingSameBuffs(class UBP_BattleBuffInstance_C* Buff, TArray<UBP_BattleBuffInstanceWrapper_C*>& ActiveBuffInstanceWrappers);
    void AddBuff(class UBP_BattleBuffInstanceWrapper_C*& BuffInstanceWrapper, bool& Added);
    void ProcessFinalDamages(class UBP_BattleDamages_C*& BattleDamages);
    void ActivateBuff(class UBP_BattleBuffInstance_C*& BuffInstance, class UAC_jRPG_CharacterBattleStats_C*& SourceCharacter, class UBP_BattleBuffInstanceWrapper_C*& BuffInstanceWrapper, bool& Success);
    void ExecuteUbergraph_BP_BattleBuffComponent(int32 EntryPoint);
}; // Size: 0x59

#endif
