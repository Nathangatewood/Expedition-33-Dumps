#ifndef UE4SS_SDK_BP_CustomMovementComponent_HPP
#define UE4SS_SDK_BP_CustomMovementComponent_HPP

class UBP_CustomMovementComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    double LadderStepPos;                                                             // 0x00A8 (size: 0x8)
    bool IsLadderForNextAnimation;                                                    // 0x00B0 (size: 0x1)
    double LadderBlendTimeForAnimation;                                               // 0x00B8 (size: 0x8)
    double LadderMoveSpeed;                                                           // 0x00C0 (size: 0x8)
    class AActor* NextHold;                                                           // 0x00C8 (size: 0x8)
    TScriptInterface<class IBPI_CustomMoveZone_Climbing_C> NextHoldInterface;         // 0x00D0 (size: 0x10)
    bool IsMovingNextHoldForAnimation;                                                // 0x00E0 (size: 0x1)
    double MovingNextHoldTransitionAlphaForAnimation;                                 // 0x00E8 (size: 0x8)
    FVector MovingNextHoldTransitionDeltaForAnimation;                                // 0x00F0 (size: 0x18)
    TArray<AActor*> OverlappedClimbingHolds;                                          // 0x0108 (size: 0x10)
    FVector ClimbingLocation;                                                         // 0x0118 (size: 0x18)
    FRotator ClimbingRotation;                                                        // 0x0130 (size: 0x18)
    bool IsClimbingForNextAnimation;                                                  // 0x0148 (size: 0x1)
    double ClimbingBlendTimeForAnimation;                                             // 0x0150 (size: 0x8)
    bool NextHoldIsFarHold;                                                           // 0x0158 (size: 0x1)
    double MaxClimbingDistance;                                                       // 0x0160 (size: 0x8)
    FSCustomMoveZone OverlappedCustomMoveZone;                                        // 0x0168 (size: 0x10)
    FSCustomMoveZone CurrentCustomMoveZone;                                           // 0x0178 (size: 0x10)
    bool IsTransitioningCustomMoveZone;                                               // 0x0188 (size: 0x1)
    FVector EnteringTransitionBeginLocation;                                          // 0x0190 (size: 0x18)
    FVector EnteringTransitionEndLocation;                                            // 0x01A8 (size: 0x18)
    FRotator EnteringTransitionBeginRotation;                                         // 0x01C0 (size: 0x18)
    FRotator EnteringTransitionEndRotation;                                           // 0x01D8 (size: 0x18)
    double MovementDeltaTime;                                                         // 0x01F0 (size: 0x8)
    bool PrevUseControllerRotationYaw;                                                // 0x01F8 (size: 0x1)
    bool PrevOrientRotationToMovement;                                                // 0x01F9 (size: 0x1)
    class ACharacter* Character;                                                      // 0x0200 (size: 0x8)
    class UCharacterMovementComponent* CharacterMovement;                             // 0x0208 (size: 0x8)
    double EnteringLadderTopTimeline_Time;                                            // 0x0210 (size: 0x8)
    class UCurveFloat* EnteringLadderTopTimeline_Transition;                          // 0x0218 (size: 0x8)
    class UAnimMontage* AM_EnteringLadderTop;                                         // 0x0220 (size: 0x8)
    double EnteringLadderMiddleTimeline_Time;                                         // 0x0228 (size: 0x8)
    class UCurveFloat* EnteringLadderMiddleTimeline_Transition;                       // 0x0230 (size: 0x8)
    double EnteringLadderBottomTimeline_Time;                                         // 0x0238 (size: 0x8)
    class UCurveFloat* EnteringLadderBottomTimeline_Transition;                       // 0x0240 (size: 0x8)
    double EnteringClimbingTopTimeline_Time;                                          // 0x0248 (size: 0x8)
    class UCurveFloat* EnteringClimbingTopTimeline_Transition;                        // 0x0250 (size: 0x8)
    double EnteringClimbingTimeline_Time;                                             // 0x0258 (size: 0x8)
    class UCurveFloat* EnteringClimbingTimeline_Transition;                           // 0x0260 (size: 0x8)
    double MovingNextHoldTimeline_Time;                                               // 0x0268 (size: 0x8)
    double MovingNextHoldTimeline_PlayRate;                                           // 0x0270 (size: 0x8)
    class UCurveFloat* MovingNextHoldTimeline_TransitionLocation;                     // 0x0278 (size: 0x8)
    class UCurveFloat* MovingNextHoldTimeline_TransitionRotation;                     // 0x0280 (size: 0x8)
    class UAnimMontage* AM_EnteringLadderBottom;                                      // 0x0288 (size: 0x8)
    class UAnimMontage* AM_ExitingLadderTop;                                          // 0x0290 (size: 0x8)
    class UAnimMontage* AM_ExitingLadderBottom;                                       // 0x0298 (size: 0x8)
    class UAnimMontage* AM_EnteringClimbingTop;                                       // 0x02A0 (size: 0x8)
    class UAnimMontage* AM_ExitingClimbingTop;                                        // 0x02A8 (size: 0x8)
    FBP_CustomMovementComponent_CTimeline Timeline;                                   // 0x02B0 (size: 0x10)
    void Timeline(double DeltaTime);
    FBP_CustomMovementComponent_COnStartCustomMovement OnStartCustomMovement;         // 0x02C0 (size: 0x10)
    void OnStartCustomMovement();
    FBP_CustomMovementComponent_COnEndCustomMovement OnEndCustomMovement;             // 0x02D0 (size: 0x10)
    void OnEndCustomMovement();
    bool PrevUseControllerDesiredRotation;                                            // 0x02E0 (size: 0x1)
    float CooldDownBetweenMovingClimbing;                                             // 0x02E4 (size: 0x4)
    float SpringArmDistance_Climbing;                                                 // 0x02E8 (size: 0x4)
    float SpringArmDistance_CustomHold;                                               // 0x02EC (size: 0x4)
    double DistanceWithNextHold;                                                      // 0x02F0 (size: 0x8)
    float SpringArmDistance_Ladder;                                                   // 0x02F8 (size: 0x4)

    void OnEndCustomMovementInternal();
    void OnStartCustomMovementInternal();
    void Initialize(class ACharacter* Character);
    bool HasAuthority();
    bool IsCustomMovement();
    void GetLadderStepPos(double& LadderStepPos);
    void GetMovingNextHoldTransitionAlpha(double& Alpha);
    void GetCharacterNetSmoothLocation(FVector& CharacterLocation);
    void CheckClimbingNextHold();
    void UpdateClimbingMovement();
    void UpdateRootMotion();
    void CheckExitingClimbing(TScriptInterface<class IBPI_CustomMoveZone_Climbing_C> ClimbingInterface, double InputScale);
    void FindClosestClimbingHold();
    void UpdateLadderMovement();
    void CheckExitingCustomMoveZone_Ladder(TScriptInterface<class IBPI_CustomMoveZone_Ladder_C> LadderInterface, double InputScale);
    void CheckEnteringCustomMoveZone();
    void EndOverlappedCustomMoveZone(class AActor* CustomMoveZoneActor);
    bool IsLocallyControlled();
    void BeginOverlappedCustomMoveZone(FSCustomMoveZone CustomMoveZone);
    void OnNotifyEnd_0B6052B147BA631DEB594C87771CD3C0(FName NotifyName);
    void OnNotifyBegin_0B6052B147BA631DEB594C87771CD3C0(FName NotifyName);
    void OnInterrupted_0B6052B147BA631DEB594C87771CD3C0(FName NotifyName);
    void OnBlendOut_0B6052B147BA631DEB594C87771CD3C0(FName NotifyName);
    void OnCompleted_0B6052B147BA631DEB594C87771CD3C0(FName NotifyName);
    void OnNotifyEnd_7815B4404043DE25B6C892B2CE924B63(FName NotifyName);
    void OnNotifyBegin_7815B4404043DE25B6C892B2CE924B63(FName NotifyName);
    void OnInterrupted_7815B4404043DE25B6C892B2CE924B63(FName NotifyName);
    void OnBlendOut_7815B4404043DE25B6C892B2CE924B63(FName NotifyName);
    void OnCompleted_7815B4404043DE25B6C892B2CE924B63(FName NotifyName);
    void OnNotifyEnd_1E7B60B146BC1DBEED18AD8A88F50900(FName NotifyName);
    void OnNotifyBegin_1E7B60B146BC1DBEED18AD8A88F50900(FName NotifyName);
    void OnInterrupted_1E7B60B146BC1DBEED18AD8A88F50900(FName NotifyName);
    void OnBlendOut_1E7B60B146BC1DBEED18AD8A88F50900(FName NotifyName);
    void OnCompleted_1E7B60B146BC1DBEED18AD8A88F50900(FName NotifyName);
    void OnNotifyEnd_B8BEF53646A61DA7D191C7A89841AD91(FName NotifyName);
    void OnNotifyBegin_B8BEF53646A61DA7D191C7A89841AD91(FName NotifyName);
    void OnInterrupted_B8BEF53646A61DA7D191C7A89841AD91(FName NotifyName);
    void OnBlendOut_B8BEF53646A61DA7D191C7A89841AD91(FName NotifyName);
    void OnCompleted_B8BEF53646A61DA7D191C7A89841AD91(FName NotifyName);
    void OnNotifyEnd_10C99DFB4BD067287B623280FDDB977B(FName NotifyName);
    void OnNotifyBegin_10C99DFB4BD067287B623280FDDB977B(FName NotifyName);
    void OnInterrupted_10C99DFB4BD067287B623280FDDB977B(FName NotifyName);
    void OnBlendOut_10C99DFB4BD067287B623280FDDB977B(FName NotifyName);
    void OnCompleted_10C99DFB4BD067287B623280FDDB977B(FName NotifyName);
    void BroadcastExitingLadderTopRootMotion();
    void ServerExitingLadderTopRootMotion();
    void MovingNextHold(class AActor* NextHold, bool IsFarHold);
    void ServerMovingNextHold(class AActor* NextHold, bool IsFarHold);
    void BroadcastMovingNextHold(class AActor* NextHold, bool IsFarHold);
    void BroadcastExitingLadderTop();
    void UpdateEnteringLadderMiddleTimeline(double DeltaTime);
    void ServerExitingLadderTop();
    void ExitingLadderTop();
    void BroadcastExitingLadderBottomRootMotion();
    void ServerExitingLadderBottomRootMotion();
    void EnteringLadderBottom();
    void ServerEnteringLadderBottom(FSCustomMoveZone CustomMoveZone);
    void BroadcastEnteringLadderBottom(FSCustomMoveZone CustomMoveZone);
    void BroadcastExitingLadderBottom();
    void ServerExitingLadderBottom();
    void ExitingLadderBottom();
    void BroadcastExitingLadderMiddle();
    void ServerExitingLadderMiddle();
    void ExitingLadderMiddle();
    void UpdateEnteringLadderBottomTimeline(double DeltaTime);
    void ServerEnteringLadderBottomRootMotion();
    void BroadcastEnteringLadderBottomRootMotion();
    void UpdateEnteringClimbingTimeline(double DeltaTime);
    void EnteringLadderTop();
    void ServerEnteringLadderTop(FSCustomMoveZone CustomMoveZone);
    void BroadcastEnteringLadderTop(FSCustomMoveZone CustomMoveZone);
    void UpdateMovingNextHoldTimeline(double DeltaTime);
    void BroadcastEnteringClimbing(FSCustomMoveZone CustomMoveZone);
    void ServerEnteringClimbing(FSCustomMoveZone CustomMoveZone);
    void EnteringClimbing();
    void BroadcastEnteringClimbingTopRootMotion();
    void ServerEnteringClimbingTopRootMotion();
    void UpdateEnteringLadderTopTimeline(double DeltaTime);
    void ServerEnteringLadderTopRootMotion();
    void BroadcastEnteringLadderTopRootMotion();
    void ReceiveTick(float DeltaSeconds);
    void UpdateEnteringTransition(double Transition);
    void ExitCustomMovement();
    void UpdateEnteringClimbingTopTimeline(double DeltaTime);
    void UpdateCustomMovement(double DeltaTime);
    void InputAxis_LadderUp(double AxisValue);
    void BroadcastEnteringClimbingTop(FSCustomMoveZone CustomMoveZone);
    void ServerEnteringClimbingTop(FSCustomMoveZone CustomMoveZone);
    void EnteringClimbingTop();
    void InputAxis_ClimbingUp(double AxisValue);
    void InputAxis_ClimbingRight(double AxisValue);
    void EnteringLadderMiddle();
    void ReceiveBeginPlay();
    void BroadcastExitingClimbing();
    void ServerExitingClimbing();
    void ExitingClimbing();
    void ExitingClimbingBottom();
    void ServerEnteringLadderMiddle(FSCustomMoveZone CustomMoveZone);
    void BroadcastEnteringLadderMiddle(FSCustomMoveZone CustomMoveZone);
    void ForceExitCustomMovement();
    void BroadcastExitingClimbingTopRootMotion();
    void ServerExitingClimbingTopRootMotion();
    void ExitingClimbingTop();
    void ServerExitingClimbingTop();
    void BroadcastExitingClimbingTop();
    void ExecuteUbergraph_BP_CustomMovementComponent(int32 EntryPoint);
    void OnEndCustomMovement__DelegateSignature();
    void OnStartCustomMovement__DelegateSignature();
    void Timeline__DelegateSignature(double DeltaTime);
}; // Size: 0x2FC

#endif
