#ifndef UE4SS_SDK_BP_Cine_Monoco_HPP
#define UE4SS_SDK_BP_Cine_Monoco_HPP

class ABP_Cine_Monoco_C : public ABP_CineCharacter_Main_C
{
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0698 (size: 0x8)

    void UserConstructionScript();
}; // Size: 0x6A0

#endif
