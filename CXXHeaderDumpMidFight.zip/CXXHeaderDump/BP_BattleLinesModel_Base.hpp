#ifndef UE4SS_SDK_BP_BattleLinesModel_Base_HPP
#define UE4SS_SDK_BP_BattleLinesModel_Base_HPP

class UBP_BattleLinesModel_Base_C : public UExtendedObject
{
    FS_BattleLinePool TurnStart_LowLife;                                              // 0x0028 (size: 0x18)
    FS_BattleLinePool TurnStart_FullAP;                                               // 0x0040 (size: 0x18)
    FS_BattleLinePool TurnStart_Normal;                                               // 0x0058 (size: 0x18)
    FS_BattleLinePool TurnStart_FullOvercharge;                                       // 0x0070 (size: 0x18)
    FS_BattleLinePool FreeAim_Active;                                                 // 0x0088 (size: 0x18)
    FS_BattleLinePool FreeAim_HitWeakspot;                                            // 0x00A0 (size: 0x18)
    FS_BattleLinePool KillsEnemy;                                                     // 0x00B8 (size: 0x18)
    FS_BattleLinePool SelfTargetedByEnemy;                                            // 0x00D0 (size: 0x18)
    FS_BattleLineEventPerCharacter AllyTargetedByEnemy;                               // 0x00E8 (size: 0x68)
    FS_BattleLinePool EnemyPowerfullAttackIncoming;                                   // 0x0150 (size: 0x18)
    FS_BattleLinePool EnemyBlocks;                                                    // 0x0168 (size: 0x18)
    FS_BattleLinePool ReceiveBuff_Self;                                               // 0x0180 (size: 0x18)
    FS_BattleLinePool HealsSelf;                                                      // 0x0198 (size: 0x18)
    FS_BattleLineEventPerCharacter Thanks_SpecificAlly;                               // 0x01B0 (size: 0x68)
    FS_BattleLinePool UseItem;                                                        // 0x0218 (size: 0x18)
    FS_BattleLinePool InsufficientItems;                                              // 0x0230 (size: 0x18)
    FS_BattleLinePool InsufficientAP;                                                 // 0x0248 (size: 0x18)
    FS_BattleLinePool FailQTE;                                                        // 0x0260 (size: 0x18)
    FS_BattleLineEventPerCharacter HealsOtherAlly;                                    // 0x0278 (size: 0x68)
    FS_BattleLinePool RevivedByAlly;                                                  // 0x02E0 (size: 0x18)
    FS_BattleLinePool RevivingOtherAlly;                                              // 0x02F8 (size: 0x18)
    FS_BattleLineEventPerCharacter OtherAllyHealedByOther;                            // 0x0310 (size: 0x68)
    FS_BattleLineEventPerCharacter Death_OtherAlly;                                   // 0x0378 (size: 0x68)
    FS_BattleLinePool Death_AnyAlly;                                                  // 0x03E0 (size: 0x18)
    FS_BattleLinePool Dodge;                                                          // 0x03F8 (size: 0x18)
    FS_BattleLinePool Counter;                                                        // 0x0410 (size: 0x18)
    FS_BattleLinePool GradientCounter;                                                // 0x0428 (size: 0x18)
    FS_BattleLinePool BattleWon;                                                      // 0x0440 (size: 0x18)
    FS_BattleLinePool CurseWords;                                                     // 0x0458 (size: 0x18)
    class UAC_jRPG_CharacterBattleStats_C* OwnerCharacterStats;                       // 0x0470 (size: 0x8)
    TArray<FS_BattleLinePool> CurrentValidPools;                                      // 0x0478 (size: 0x10)
    bool IsGathering;                                                                 // 0x0488 (size: 0x1)
    FS_BattleLinePool CounterEnemy;                                                   // 0x0490 (size: 0x18)
    FS_BattleLinePool GradientCounterEnemy;                                           // 0x04A8 (size: 0x18)

    void Match_DeathOtherChar(class UBP_BattleLineGatherer_C* Gatherer, class UBP_BattleDamages_C* LethalDamages);
    void GetSettings(class UBP_BattleLineSettings_C*& Settings);
    void GetOwnerCharacterStats(class UAC_jRPG_CharacterBattleStats_C*& OwnerCharacterStats);
    void TryRegisterPool(class UBP_BattleLineGatherer_C* Event, FS_BattleLinePool Pool, double ChancePercent, bool& Rolled);
    void Match_TargetAcquired(class UBP_BattleLineGatherer_C* Gatherer, class UAC_jRPG_CharacterBattleStats_C* AcquiringCharacter, class UAC_jRPG_CharacterBattleStats_C* AcquiredCharacter);
    void TryRegisterEvent_OLD(FS_BattleLinePool Event, bool& Rolled);
    TArray<FS_BattleLinePool> GetGatheredPoolCandidates();
    void EndGatherPools(TArray<FS_BattleLinePoolCandidate>& PoolCandidates);
    void BeginGatherPools();
    void ModifyPoolProbability(FS_BattleLinePool InPool, double ProbabilityFactor, FS_BattleLinePool& OutPool);
    void AppendPools();
    void AddCharacterSpecificPoolToRool(FS_BattleLineEventPerCharacter BattleLinePool, class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void AddPoolToRoll(FS_BattleLinePool BattleLinePool, double ProbabilityFactor);
    void Match_HealEvent(class UBP_BattleLineGatherer_C* BattleLineGatherer, class UBP_BattleHeal_C* HealEvent);
    void Match_RevivingAlly(class UBP_BattleLineGatherer_C* Gatherer, class UAC_jRPG_CharacterBattleStats_C* RevivedCharacter);
    void Match_RevivedByAlly(class UBP_BattleLineGatherer_C* Gatherer, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter);
    void MatchDamageReceivedByAll(class UBP_BattleDamages_C* DamageObject, FS_BattleLinePool& MatchingBattleLinePool);
    void Match_TurnStartSelf_OLD();
    void Match_TurnStartSelf(class UBP_BattleLineGatherer_C* Gatherer);
}; // Size: 0x4C0

#endif
