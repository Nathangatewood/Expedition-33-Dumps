#ifndef UE4SS_SDK_BP_BattleBuff_LowHealthDamageBoostBuff_HPP
#define UE4SS_SDK_BP_BattleBuff_LowHealthDamageBoostBuff_HPP

class UBP_BattleBuff_LowHealthDamageBoostBuff_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UNiagaraComponent* Niagara System;                                          // 0x0160 (size: 0x8)

    void DeactivateBuff();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_LowHealthDamageBoostBuff(int32 EntryPoint);
}; // Size: 0x168

#endif
