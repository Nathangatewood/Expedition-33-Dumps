#ifndef UE4SS_SDK_BP_ConditionChecker_BinaryLogicOperators_HPP
#define UE4SS_SDK_BP_ConditionChecker_BinaryLogicOperators_HPP

class UBP_ConditionChecker_BinaryLogicOperators_C : public UBP_ConditionChecker_C
{
    TEnumAsByte<E_ConditionChecker_BinaryLogicOperator::Type> LogicOperator;          // 0x0060 (size: 0x1)
    TArray<FConditionChecker_Wrapper> Conditions;                                     // 0x0068 (size: 0x10)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void Check_XOR(bool& Result);
    void Check_OR(bool& Result);
    void Check_AND(bool& Result);
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x78

#endif
