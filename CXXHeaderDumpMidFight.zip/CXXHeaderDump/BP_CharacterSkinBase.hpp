#ifndef UE4SS_SDK_BP_CharacterSkinBase_HPP
#define UE4SS_SDK_BP_CharacterSkinBase_HPP

class ABP_CharacterSkinBase_C : public AActor
{
    class UNiagaraComponent* FX_ArmRing3;                                             // 0x0290 (size: 0x8)
    class UNiagaraComponent* FX_ArmRing1;                                             // 0x0298 (size: 0x8)
    class UNiagaraComponent* FX_ArmRing2;                                             // 0x02A0 (size: 0x8)
    class USkeletalMeshComponent* Haircut_SkeletalMesh;                               // 0x02A8 (size: 0x8)
    class UGroomComponent* Hair;                                                      // 0x02B0 (size: 0x8)
    class UGroomComponent* Eyebrows;                                                  // 0x02B8 (size: 0x8)
    class UGroomComponent* Eyelashes;                                                 // 0x02C0 (size: 0x8)
    class UGroomComponent* Beard;                                                     // 0x02C8 (size: 0x8)
    class UGroomComponent* Mustache;                                                  // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Haircut_StaticMesh;                                   // 0x02D8 (size: 0x8)
    class USkeletalMeshComponent* Face;                                               // 0x02E0 (size: 0x8)
    class USkeletalMeshComponent* Body;                                               // 0x02E8 (size: 0x8)
    class USceneComponent* Root;                                                      // 0x02F0 (size: 0x8)
    FS_AnimationProfile_Skins AnimationProfile;                                       // 0x02F8 (size: 0x90)
    int32 ArmRingMaterialIndex;                                                       // 0x0388 (size: 0x4)
    FName BoneToAttachHaircutTo;                                                      // 0x038C (size: 0x8)
    class UBP_DataAsset_FootstepVisualProfile_C* FootStepProfile;                     // 0x0398 (size: 0x8)

    void GetArmRingNiagaraComponents(TArray<UNiagaraComponent*>& Array, int32& ArmRingMaterialIndex);
    void UserConstructionScript();
}; // Size: 0x3A0

#endif
