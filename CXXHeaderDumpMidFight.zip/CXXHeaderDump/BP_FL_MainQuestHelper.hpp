#ifndef UE4SS_SDK_BP_FL_MainQuestHelper_HPP
#define UE4SS_SDK_BP_FL_MainQuestHelper_HPP

class UBP_FL_MainQuestHelper_C : public UBlueprintFunctionLibrary
{

    void GetCurrentQuestLevelIdentifiers(class UObject* __WorldContext, TArray<FGameplayTag>& LevelIdentifiers);
    void GetMainQuestObjectiveText(class UObject* __WorldContext, FText& Text);
    bool IsInActOrHigher(TEnumAsByte<E_CurrentAct::Type> ActToCheck, class UObject* __WorldContext);
    void GetLastMainQuestObjectiveWithStatus(TEnumAsByte<E_QuestStatus::Type> Status, class UObject* __WorldContext, FQuestObjectiveIdentifier& QuestObjective, bool& IsValid);
    void GetCurrentMainPathStatus(class UObject* __WorldContext, TEnumAsByte<E_CurrentAct::Type>& CurrentAct, TEnumAsByte<E_MainQuest_Step::Type>& CurrentStep);
}; // Size: 0x28

#endif
