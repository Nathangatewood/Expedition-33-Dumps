#ifndef UE4SS_SDK_BP_ConditionChecker_UnaryLogicOperators_HPP
#define UE4SS_SDK_BP_ConditionChecker_UnaryLogicOperators_HPP

class UBP_ConditionChecker_UnaryLogicOperators_C : public UBP_ConditionChecker_C
{
    FConditionChecker_Wrapper Condition;                                              // 0x0060 (size: 0x8)
    TEnumAsByte<E_ConditionChecker_UnaryLogicOperator::Type> LogicOperator;           // 0x0068 (size: 0x1)

    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
    void Check_NOT(bool& Result);
}; // Size: 0x69

#endif
