#ifndef UE4SS_SDK_BP_BattleBuff_Stance_Stanceless_HPP
#define UE4SS_SDK_BP_BattleBuff_Stance_Stanceless_HPP

class UBP_BattleBuff_Stance_Stanceless_C : public UBP_BattleBuff_Stance_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0160 (size: 0x8)

    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void ExecuteUbergraph_BP_BattleBuff_Stance_Stanceless(int32 EntryPoint);
}; // Size: 0x168

#endif
