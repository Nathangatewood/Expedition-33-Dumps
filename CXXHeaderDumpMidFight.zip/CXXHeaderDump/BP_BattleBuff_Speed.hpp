#ifndef UE4SS_SDK_BP_BattleBuff_Speed_HPP
#define UE4SS_SDK_BP_BattleBuff_Speed_HPP

class UBP_BattleBuff_Speed_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class USoundBase* BuffActivateSound;                                              // 0x0160 (size: 0x8)

    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void ExecuteUbergraph_BP_BattleBuff_Speed(int32 EntryPoint);
}; // Size: 0x168

#endif
