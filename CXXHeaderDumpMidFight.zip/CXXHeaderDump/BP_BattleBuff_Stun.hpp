#ifndef UE4SS_SDK_BP_BattleBuff_Stun_HPP
#define UE4SS_SDK_BP_BattleBuff_Stun_HPP

class UBP_BattleBuff_Stun_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class UParticleSystemComponent* Particle System Component;                        // 0x0160 (size: 0x8)
    FSF_ReferenceCounterHandle BreakDamageBlockerHandle;                              // 0x0168 (size: 0x20)

    void ProcessReceivedRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void DeactivateBuff();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnAllTurnSTsartEventsProcessed();
    void ExecuteUbergraph_BP_BattleBuff_Stun(int32 EntryPoint);
}; // Size: 0x188

#endif
