#ifndef UE4SS_SDK_BP_Debug_UMGDebugger_HPP
#define UE4SS_SDK_BP_Debug_UMGDebugger_HPP

class ABP_Debug_UMGDebugger_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    class UWBP_Debug_UMG_AnimationDebugger_C* UMGDebuggerInstance;                    // 0x02A0 (size: 0x8)

    void GetUMGDebuggerInstance(class UWBP_Debug_UMG_AnimationDebugger_C*& UMGDebuggerInstance);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Debug_UMGDebugger(int32 EntryPoint);
}; // Size: 0x2A8

#endif
