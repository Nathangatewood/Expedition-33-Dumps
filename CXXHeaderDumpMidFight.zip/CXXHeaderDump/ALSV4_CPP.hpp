#ifndef UE4SS_SDK_ALSV4_CPP_HPP
#define UE4SS_SDK_ALSV4_CPP_HPP

#include "ALSV4_CPP_enums.hpp"

struct FALSAnimCharacterInformation
{
    FRotator AimingRotation;                                                          // 0x0000 (size: 0x18)
    FRotator CharacterActorRotation;                                                  // 0x0018 (size: 0x18)
    FVector Velocity;                                                                 // 0x0030 (size: 0x18)
    FVector RelativeVelocityDirection;                                                // 0x0048 (size: 0x18)
    FVector Acceleration;                                                             // 0x0060 (size: 0x18)
    FVector MovementInput;                                                            // 0x0078 (size: 0x18)
    bool bIsMoving;                                                                   // 0x0090 (size: 0x1)
    bool bHasMovementInput;                                                           // 0x0091 (size: 0x1)
    float Speed;                                                                      // 0x0094 (size: 0x4)
    float MovementInputAmount;                                                        // 0x0098 (size: 0x4)
    float AimYawRate;                                                                 // 0x009C (size: 0x4)
    float ZoomAmount;                                                                 // 0x00A0 (size: 0x4)
    EALSMovementState PrevMovementState;                                              // 0x00A4 (size: 0x1)
    EALSViewMode ViewMode;                                                            // 0x00A5 (size: 0x1)

}; // Size: 0xA8

struct FALSAnimConfiguration
{
    float AnimatedWalkSpeed;                                                          // 0x0000 (size: 0x4)
    float AnimatedRunSpeed;                                                           // 0x0004 (size: 0x4)
    float AnimatedSprintSpeed;                                                        // 0x0008 (size: 0x4)
    float AnimatedCrouchSpeed;                                                        // 0x000C (size: 0x4)
    float VelocityBlendInterpSpeed;                                                   // 0x0010 (size: 0x4)
    float GroundedLeanInterpSpeed;                                                    // 0x0014 (size: 0x4)
    float InAirLeanInterpSpeed;                                                       // 0x0018 (size: 0x4)
    float SmoothedAimingRotationInterpSpeed;                                          // 0x001C (size: 0x4)
    float InputYawOffsetInterpSpeed;                                                  // 0x0020 (size: 0x4)
    float TriggerPivotSpeedLimit;                                                     // 0x0024 (size: 0x4)
    float FootHeight;                                                                 // 0x0028 (size: 0x4)
    float DynamicTransitionThreshold;                                                 // 0x002C (size: 0x4)
    float IK_TraceDistanceAboveFoot;                                                  // 0x0030 (size: 0x4)
    float IK_TraceDistanceBelowFoot;                                                  // 0x0034 (size: 0x4)

}; // Size: 0x38

struct FALSAnimGraphAimingValues
{
    FRotator SmoothedAimingRotation;                                                  // 0x0000 (size: 0x18)
    FRotator SpineRotation;                                                           // 0x0018 (size: 0x18)
    FVector2D AimingAngle;                                                            // 0x0030 (size: 0x10)
    float AimSweepTime;                                                               // 0x0040 (size: 0x4)
    float InputYawOffsetTime;                                                         // 0x0044 (size: 0x4)
    float ForwardYawTime;                                                             // 0x0048 (size: 0x4)
    float LeftYawTime;                                                                // 0x004C (size: 0x4)
    float RightYawTime;                                                               // 0x0050 (size: 0x4)

}; // Size: 0x58

struct FALSAnimGraphFootIK
{
    float FootLock_L_Alpha;                                                           // 0x0000 (size: 0x4)
    float FootLock_R_Alpha;                                                           // 0x0004 (size: 0x4)
    bool UseFootLockCurve_L;                                                          // 0x0008 (size: 0x1)
    bool UseFootLockCurve_R;                                                          // 0x0009 (size: 0x1)
    FVector FootLock_L_Location;                                                      // 0x0010 (size: 0x18)
    FVector TargetFootLock_R_Location;                                                // 0x0028 (size: 0x18)
    FVector FootLock_R_Location;                                                      // 0x0040 (size: 0x18)
    FRotator TargetFootLock_L_Rotation;                                               // 0x0058 (size: 0x18)
    FRotator FootLock_L_Rotation;                                                     // 0x0070 (size: 0x18)
    FRotator TargetFootLock_R_Rotation;                                               // 0x0088 (size: 0x18)
    FRotator FootLock_R_Rotation;                                                     // 0x00A0 (size: 0x18)
    FVector FootOffset_L_Location;                                                    // 0x00B8 (size: 0x18)
    FVector FootOffset_R_Location;                                                    // 0x00D0 (size: 0x18)
    FRotator FootOffset_L_Rotation;                                                   // 0x00E8 (size: 0x18)
    FRotator FootOffset_R_Rotation;                                                   // 0x0100 (size: 0x18)
    FVector PelvisOffset;                                                             // 0x0118 (size: 0x18)
    float PelvisAlpha;                                                                // 0x0130 (size: 0x4)

}; // Size: 0x138

struct FALSAnimGraphGrounded
{
    EALSHipsDirection TrackedHipsDirection;                                           // 0x0000 (size: 0x1)
    bool bShouldMove;                                                                 // 0x0001 (size: 0x1)
    bool bRotateL;                                                                    // 0x0002 (size: 0x1)
    bool bRotateR;                                                                    // 0x0003 (size: 0x1)
    bool bPivot;                                                                      // 0x0004 (size: 0x1)
    float RotateRate;                                                                 // 0x0008 (size: 0x4)
    float RotationScale;                                                              // 0x000C (size: 0x4)
    float DiagonalScaleAmount;                                                        // 0x0010 (size: 0x4)
    float WalkRunBlend;                                                               // 0x0014 (size: 0x4)
    float StandingPlayRate;                                                           // 0x0018 (size: 0x4)
    float CrouchingPlayRate;                                                          // 0x001C (size: 0x4)
    float StrideBlend;                                                                // 0x0020 (size: 0x4)
    float FYaw;                                                                       // 0x0024 (size: 0x4)
    float BYaw;                                                                       // 0x0028 (size: 0x4)
    float LYaw;                                                                       // 0x002C (size: 0x4)
    float RYaw;                                                                       // 0x0030 (size: 0x4)

}; // Size: 0x34

struct FALSAnimGraphInAir
{
    bool bJumped;                                                                     // 0x0000 (size: 0x1)
    float JumpPlayRate;                                                               // 0x0004 (size: 0x4)
    float FallSpeed;                                                                  // 0x0008 (size: 0x4)
    float LandPrediction;                                                             // 0x000C (size: 0x4)

}; // Size: 0x10

struct FALSAnimGraphLayerBlending
{
    int32 OverlayOverrideState;                                                       // 0x0000 (size: 0x4)
    float EnableAimOffset;                                                            // 0x0004 (size: 0x4)
    float BasePose_N;                                                                 // 0x0008 (size: 0x4)
    float BasePose_CLF;                                                               // 0x000C (size: 0x4)
    float Arm_L;                                                                      // 0x0010 (size: 0x4)
    float Arm_L_Add;                                                                  // 0x0014 (size: 0x4)
    float Arm_L_LS;                                                                   // 0x0018 (size: 0x4)
    float Arm_L_MS;                                                                   // 0x001C (size: 0x4)
    float Arm_R;                                                                      // 0x0020 (size: 0x4)
    float Arm_R_Add;                                                                  // 0x0024 (size: 0x4)
    float Arm_R_LS;                                                                   // 0x0028 (size: 0x4)
    float Arm_R_MS;                                                                   // 0x002C (size: 0x4)
    float Hand_L;                                                                     // 0x0030 (size: 0x4)
    float Hand_R;                                                                     // 0x0034 (size: 0x4)
    float Legs;                                                                       // 0x0038 (size: 0x4)
    float Legs_Add;                                                                   // 0x003C (size: 0x4)
    float Pelvis;                                                                     // 0x0040 (size: 0x4)
    float Pelvis_Add;                                                                 // 0x0044 (size: 0x4)
    float Spine;                                                                      // 0x0048 (size: 0x4)
    float Spine_Add;                                                                  // 0x004C (size: 0x4)
    float Head;                                                                       // 0x0050 (size: 0x4)
    float Head_Add;                                                                   // 0x0054 (size: 0x4)
    float EnableHandIK_L;                                                             // 0x0058 (size: 0x4)
    float EnableHandIK_R;                                                             // 0x005C (size: 0x4)

}; // Size: 0x60

struct FALSAnimRotateInPlace
{
    float RotateMinThreshold;                                                         // 0x0000 (size: 0x4)
    float RotateMaxThreshold;                                                         // 0x0004 (size: 0x4)
    float AimYawRateMinRange;                                                         // 0x0008 (size: 0x4)
    float AimYawRateMaxRange;                                                         // 0x000C (size: 0x4)
    float MinPlayRate;                                                                // 0x0010 (size: 0x4)
    float MaxPlayRate;                                                                // 0x0014 (size: 0x4)

}; // Size: 0x18

struct FALSAnimTurnInPlace
{
    float TurnCheckMinAngle;                                                          // 0x0000 (size: 0x4)
    float Turn180Threshold;                                                           // 0x0004 (size: 0x4)
    float AimYawRateLimit;                                                            // 0x0008 (size: 0x4)
    float ElapsedDelayTime;                                                           // 0x000C (size: 0x4)
    float MinAngleDelay;                                                              // 0x0010 (size: 0x4)
    float MaxAngleDelay;                                                              // 0x0014 (size: 0x4)
    FALSTurnInPlaceAsset N_TurnIP_L90;                                                // 0x0018 (size: 0x20)
    FALSTurnInPlaceAsset N_TurnIP_R90;                                                // 0x0038 (size: 0x20)
    FALSTurnInPlaceAsset N_TurnIP_L180;                                               // 0x0058 (size: 0x20)
    FALSTurnInPlaceAsset N_TurnIP_R180;                                               // 0x0078 (size: 0x20)
    FALSTurnInPlaceAsset CLF_TurnIP_L90;                                              // 0x0098 (size: 0x20)
    FALSTurnInPlaceAsset CLF_TurnIP_R90;                                              // 0x00B8 (size: 0x20)
    FALSTurnInPlaceAsset CLF_TurnIP_L180;                                             // 0x00D8 (size: 0x20)
    FALSTurnInPlaceAsset CLF_TurnIP_R180;                                             // 0x00F8 (size: 0x20)

}; // Size: 0x118

struct FALSCameraGaitSettings
{
    FALSCameraSettings Walking;                                                       // 0x0000 (size: 0x30)
    FALSCameraSettings Running;                                                       // 0x0030 (size: 0x30)
    FALSCameraSettings Sprinting;                                                     // 0x0060 (size: 0x30)
    FALSCameraSettings Crouching;                                                     // 0x0090 (size: 0x30)

}; // Size: 0xC0

struct FALSCameraSettings
{
    float TargetArmLength;                                                            // 0x0000 (size: 0x4)
    FVector SocketOffset;                                                             // 0x0008 (size: 0x18)
    float LagSpeed;                                                                   // 0x0020 (size: 0x4)
    float RotationLagSpeed;                                                           // 0x0024 (size: 0x4)
    bool bDoCollisionTest;                                                            // 0x0028 (size: 0x1)

}; // Size: 0x30

struct FALSCameraStateSettings
{
    FALSCameraGaitSettings VelocityDirection;                                         // 0x0000 (size: 0xC0)
    FALSCameraGaitSettings LookingDirection;                                          // 0x00C0 (size: 0xC0)
    FALSCameraGaitSettings Aiming;                                                    // 0x0180 (size: 0xC0)

}; // Size: 0x240

struct FALSComponentAndTransform
{
    FTransform Transform;                                                             // 0x0000 (size: 0x60)
    class UPrimitiveComponent* Component;                                             // 0x0060 (size: 0x8)

}; // Size: 0x70

struct FALSDynamicMontageParams
{
    class UAnimSequenceBase* Animation;                                               // 0x0000 (size: 0x8)
    float BlendInTime;                                                                // 0x0008 (size: 0x4)
    float BlendOutTime;                                                               // 0x000C (size: 0x4)
    float PlayRate;                                                                   // 0x0010 (size: 0x4)
    float StartTime;                                                                  // 0x0014 (size: 0x4)

}; // Size: 0x18

struct FALSGait
{
    EALSGait Gait;                                                                    // 0x0000 (size: 0x1)
    bool Walking_;                                                                    // 0x0001 (size: 0x1)
    bool Running_;                                                                    // 0x0002 (size: 0x1)
    bool Sprinting_;                                                                  // 0x0003 (size: 0x1)

}; // Size: 0x4

struct FALSGroundedEntryState
{
    EALSGroundedEntryState State;                                                     // 0x0000 (size: 0x1)
    bool None_;                                                                       // 0x0001 (size: 0x1)
    bool Roll_;                                                                       // 0x0002 (size: 0x1)

}; // Size: 0x3

struct FALSHitFX : public FTableRowBase
{
    TEnumAsByte<EPhysicalSurface> SurfaceType;                                        // 0x0008 (size: 0x1)
    TSoftObjectPtr<class USoundBase> Sound;                                           // 0x0010 (size: 0x28)
    EALSSpawnType SoundSpawnType;                                                     // 0x0038 (size: 0x1)
    TEnumAsByte<EAttachLocation::Type> SoundAttachmentType;                           // 0x0039 (size: 0x1)
    FVector SoundLocationOffset;                                                      // 0x0040 (size: 0x18)
    FRotator SoundRotationOffset;                                                     // 0x0058 (size: 0x18)
    TSoftObjectPtr<class UMaterialInterface> DecalMaterial;                           // 0x0070 (size: 0x28)
    EALSSpawnType DecalSpawnType;                                                     // 0x0098 (size: 0x1)
    TEnumAsByte<EAttachLocation::Type> DecalAttachmentType;                           // 0x0099 (size: 0x1)
    float DecalLifeSpan;                                                              // 0x009C (size: 0x4)
    FVector DecalSize;                                                                // 0x00A0 (size: 0x18)
    FVector DecalLocationOffset;                                                      // 0x00B8 (size: 0x18)
    FRotator DecalRotationOffset;                                                     // 0x00D0 (size: 0x18)
    TSoftObjectPtr<class UNiagaraSystem> NiagaraSystem;                               // 0x00E8 (size: 0x28)
    EALSSpawnType NiagaraSpawnType;                                                   // 0x0110 (size: 0x1)
    TEnumAsByte<EAttachLocation::Type> NiagaraAttachmentType;                         // 0x0111 (size: 0x1)
    FVector NiagaraLocationOffset;                                                    // 0x0118 (size: 0x18)
    FRotator NiagaraRotationOffset;                                                   // 0x0130 (size: 0x18)

}; // Size: 0x148

struct FALSLeanAmount
{
    float LR;                                                                         // 0x0000 (size: 0x4)
    float FB;                                                                         // 0x0004 (size: 0x4)

}; // Size: 0x8

struct FALSMantleAsset
{
    class UAnimMontage* AnimMontage;                                                  // 0x0000 (size: 0x8)
    class UCurveVector* PositionCorrectionCurve;                                      // 0x0008 (size: 0x8)
    FVector StartingOffset;                                                           // 0x0010 (size: 0x18)
    float LowHeight;                                                                  // 0x0028 (size: 0x4)
    float LowPlayRate;                                                                // 0x002C (size: 0x4)
    float LowStartPosition;                                                           // 0x0030 (size: 0x4)
    float HighHeight;                                                                 // 0x0034 (size: 0x4)
    float HighPlayRate;                                                               // 0x0038 (size: 0x4)
    float HighStartPosition;                                                          // 0x003C (size: 0x4)

}; // Size: 0x40

struct FALSMantleParams
{
    class UAnimMontage* AnimMontage;                                                  // 0x0000 (size: 0x8)
    class UCurveVector* PositionCorrectionCurve;                                      // 0x0008 (size: 0x8)
    float StartingPosition;                                                           // 0x0010 (size: 0x4)
    float PlayRate;                                                                   // 0x0014 (size: 0x4)
    FVector StartingOffset;                                                           // 0x0018 (size: 0x18)

}; // Size: 0x30

struct FALSMantleTraceSettings
{
    float MaxLedgeHeight;                                                             // 0x0000 (size: 0x4)
    float MinLedgeHeight;                                                             // 0x0004 (size: 0x4)
    float ReachDistance;                                                              // 0x0008 (size: 0x4)
    float ForwardTraceRadius;                                                         // 0x000C (size: 0x4)
    float DownwardTraceRadius;                                                        // 0x0010 (size: 0x4)

}; // Size: 0x14

struct FALSMovementAction
{
    EALSMovementAction Action;                                                        // 0x0000 (size: 0x1)
    bool None_;                                                                       // 0x0001 (size: 0x1)
    bool LowMantle_;                                                                  // 0x0002 (size: 0x1)
    bool HighMantle_;                                                                 // 0x0003 (size: 0x1)
    bool Rolling_;                                                                    // 0x0004 (size: 0x1)
    bool GettingUp_;                                                                  // 0x0005 (size: 0x1)

}; // Size: 0x6

struct FALSMovementDirection
{
    EALSMovementDirection MovementDirection;                                          // 0x0000 (size: 0x1)
    bool Forward_;                                                                    // 0x0001 (size: 0x1)
    bool Right_;                                                                      // 0x0002 (size: 0x1)
    bool Left_;                                                                       // 0x0003 (size: 0x1)
    bool Backward_;                                                                   // 0x0004 (size: 0x1)

}; // Size: 0x5

struct FALSMovementSettings
{
    float WalkSpeed;                                                                  // 0x0000 (size: 0x4)
    float RunSpeed;                                                                   // 0x0004 (size: 0x4)
    float SprintSpeed;                                                                // 0x0008 (size: 0x4)
    class UCurveVector* MovementCurve;                                                // 0x0010 (size: 0x8)
    class UCurveFloat* RotationRateCurve;                                             // 0x0018 (size: 0x8)

}; // Size: 0x20

struct FALSMovementStanceSettings
{
    FALSMovementSettings Standing;                                                    // 0x0000 (size: 0x20)
    FALSMovementSettings Crouching;                                                   // 0x0020 (size: 0x20)

}; // Size: 0x40

struct FALSMovementState
{
    EALSMovementState State;                                                          // 0x0000 (size: 0x1)
    bool None_;                                                                       // 0x0001 (size: 0x1)
    bool Grounded_;                                                                   // 0x0002 (size: 0x1)
    bool InAir_;                                                                      // 0x0003 (size: 0x1)
    bool Mantling_;                                                                   // 0x0004 (size: 0x1)
    bool Ragdoll_;                                                                    // 0x0005 (size: 0x1)

}; // Size: 0x6

struct FALSMovementStateSettings : public FTableRowBase
{
    FALSMovementStanceSettings VelocityDirection;                                     // 0x0008 (size: 0x40)
    FALSMovementStanceSettings LookingDirection;                                      // 0x0048 (size: 0x40)
    FALSMovementStanceSettings Aiming;                                                // 0x0088 (size: 0x40)

}; // Size: 0xC8

struct FALSOverlayState
{
    EALSOverlayState State;                                                           // 0x0000 (size: 0x1)
    bool Default_;                                                                    // 0x0001 (size: 0x1)
    bool Masculine_;                                                                  // 0x0002 (size: 0x1)
    bool Feminine_;                                                                   // 0x0003 (size: 0x1)
    bool Injured_;                                                                    // 0x0004 (size: 0x1)
    bool HandsTied_;                                                                  // 0x0005 (size: 0x1)
    bool Rifle_;                                                                      // 0x0006 (size: 0x1)
    bool PistolOneHanded_;                                                            // 0x0007 (size: 0x1)
    bool PistolTwoHanded_;                                                            // 0x0008 (size: 0x1)
    bool Bow_;                                                                        // 0x0009 (size: 0x1)
    bool Torch_;                                                                      // 0x000A (size: 0x1)
    bool Binoculars_;                                                                 // 0x000B (size: 0x1)
    bool Box_;                                                                        // 0x000C (size: 0x1)
    bool Barrel_;                                                                     // 0x000D (size: 0x1)

}; // Size: 0xE

struct FALSRotateInPlaceAsset
{
    class UAnimSequenceBase* Animation;                                               // 0x0000 (size: 0x8)
    FName SlotName;                                                                   // 0x0008 (size: 0x8)
    float SlowTurnRate;                                                               // 0x0010 (size: 0x4)
    float FastTurnRate;                                                               // 0x0014 (size: 0x4)
    float SlowPlayRate;                                                               // 0x0018 (size: 0x4)
    float FastPlayRate;                                                               // 0x001C (size: 0x4)

}; // Size: 0x20

struct FALSRotationMode
{
    EALSRotationMode RotationMode;                                                    // 0x0000 (size: 0x1)
    bool VelocityDirection_;                                                          // 0x0001 (size: 0x1)
    bool LookingDirection_;                                                           // 0x0002 (size: 0x1)
    bool Aiming_;                                                                     // 0x0003 (size: 0x1)

}; // Size: 0x4

struct FALSStance
{
    EALSStance Stance;                                                                // 0x0000 (size: 0x1)
    bool Standing_;                                                                   // 0x0001 (size: 0x1)
    bool Crouching_;                                                                  // 0x0002 (size: 0x1)

}; // Size: 0x3

struct FALSTurnInPlaceAsset
{
    class UAnimSequenceBase* Animation;                                               // 0x0000 (size: 0x8)
    float AnimatedAngle;                                                              // 0x0008 (size: 0x4)
    FName SlotName;                                                                   // 0x000C (size: 0x8)
    float PlayRate;                                                                   // 0x0014 (size: 0x4)
    bool ScaleTurnAngle;                                                              // 0x0018 (size: 0x1)

}; // Size: 0x20

struct FALSVelocityBlend
{
    float F;                                                                          // 0x0000 (size: 0x4)
    float B;                                                                          // 0x0004 (size: 0x4)
    float L;                                                                          // 0x0008 (size: 0x4)
    float R;                                                                          // 0x000C (size: 0x4)

}; // Size: 0x10

class AALSAIController : public AAIController
{
    class UBehaviorTree* Behaviour;                                                   // 0x03B8 (size: 0x8)

}; // Size: 0x3C0

class AALSBaseCharacter : public ACharacter
{
    FALSBaseCharacterJumpPressedDelegate JumpPressedDelegate;                         // 0x0668 (size: 0x10)
    void JumpPressedSignature();
    FALSBaseCharacterOnJumpedDelegate OnJumpedDelegate;                               // 0x0678 (size: 0x10)
    void OnJumpedSignature();
    FALSBaseCharacterRagdollStateChangedDelegate RagdollStateChangedDelegate;         // 0x0688 (size: 0x10)
    void RagdollStateChangedSignature(bool bRagdollState);
    FALSBaseCharacterOnGaitChangedDispatcher OnGaitChangedDispatcher;                 // 0x0698 (size: 0x10)
    void ALSBaseCharacterGaitChangedSignature(EALSGait previousGait, EALSGait nextGait);
    FALSBaseCharacterOnStanceChangedDispatcher OnStanceChangedDispatcher;             // 0x06A8 (size: 0x10)
    void ALSBaseCharacterStanceChangedSignature(EALSStance previousStance, EALSStance nextStance);
    class UALSCharacterMovementComponent* MyCharacterMovementComponent;               // 0x06B8 (size: 0x8)
    EALSRotationMode DesiredRotationMode;                                             // 0x06C0 (size: 0x1)
    EALSGait DesiredGait;                                                             // 0x06C1 (size: 0x1)
    EALSStance DesiredStance;                                                         // 0x06C2 (size: 0x1)
    float LookUpDownRate;                                                             // 0x06C4 (size: 0x4)
    float LookLeftRightRate;                                                          // 0x06C8 (size: 0x4)
    float RollDoubleTapTimeout;                                                       // 0x06CC (size: 0x4)
    bool bBreakFall;                                                                  // 0x06D0 (size: 0x1)
    bool bSprintHeld;                                                                 // 0x06D1 (size: 0x1)
    float ThirdPersonFOV;                                                             // 0x06D4 (size: 0x4)
    float FirstPersonFOV;                                                             // 0x06D8 (size: 0x4)
    bool bRightShoulder;                                                              // 0x06DC (size: 0x1)
    FDataTableRowHandle MovementModel;                                                // 0x06E0 (size: 0x10)
    FVector Acceleration;                                                             // 0x06F0 (size: 0x18)
    bool bIsMoving;                                                                   // 0x0708 (size: 0x1)
    bool bHasMovementInput;                                                           // 0x0709 (size: 0x1)
    FRotator LastVelocityRotation;                                                    // 0x0710 (size: 0x18)
    FRotator LastMovementInputRotation;                                               // 0x0728 (size: 0x18)
    float Speed;                                                                      // 0x0740 (size: 0x4)
    float MovementInputAmount;                                                        // 0x0744 (size: 0x4)
    float AimYawRate;                                                                 // 0x0748 (size: 0x4)
    float EasedMaxAcceleration;                                                       // 0x074C (size: 0x4)
    FVector ReplicatedCurrentAcceleration;                                            // 0x0750 (size: 0x18)
    FRotator ReplicatedControlRotation;                                               // 0x0768 (size: 0x18)
    class USkeletalMesh* VisibleMesh;                                                 // 0x0780 (size: 0x8)
    EALSOverlayState OverlayState;                                                    // 0x0788 (size: 0x1)
    EALSGroundedEntryState GroundedEntryState;                                        // 0x0789 (size: 0x1)
    EALSMovementState MovementState;                                                  // 0x078A (size: 0x1)
    EALSMovementState PrevMovementState;                                              // 0x078B (size: 0x1)
    EALSMovementAction MovementAction;                                                // 0x078C (size: 0x1)
    EALSRotationMode RotationMode;                                                    // 0x078D (size: 0x1)
    EALSGait Gait;                                                                    // 0x078E (size: 0x1)
    EALSStance Stance;                                                                // 0x078F (size: 0x1)
    EALSViewMode ViewMode;                                                            // 0x0790 (size: 0x1)
    int32 OverlayOverrideState;                                                       // 0x0794 (size: 0x4)
    FALSMovementStateSettings MovementData;                                           // 0x0798 (size: 0xC8)
    FRotator TargetRotation;                                                          // 0x0860 (size: 0x18)
    FRotator InAirRotation;                                                           // 0x0878 (size: 0x18)
    float YawOffset;                                                                  // 0x0890 (size: 0x4)
    bool bBreakfallOnLand;                                                            // 0x0894 (size: 0x1)
    float BreakfallOnLandVelocity;                                                    // 0x0898 (size: 0x4)
    bool bReversedPelvis;                                                             // 0x089C (size: 0x1)
    bool bRagdollOnLand;                                                              // 0x089D (size: 0x1)
    float RagdollOnLandVelocity;                                                      // 0x08A0 (size: 0x4)
    bool bRagdollOnGround;                                                            // 0x08A4 (size: 0x1)
    bool bRagdollFaceUp;                                                              // 0x08A5 (size: 0x1)
    FVector LastRagdollVelocity;                                                      // 0x08A8 (size: 0x18)
    FVector TargetRagdollLocation;                                                    // 0x08C0 (size: 0x18)
    class UALSPlayerCameraBehavior* CameraBehavior;                                   // 0x0900 (size: 0x8)
    class UALSDebugComponent* ALSDebugComponent;                                      // 0x0938 (size: 0x8)

    void WalkAction();
    void VelocityDirectionAction();
    void StanceAction();
    void SprintAction(bool bValue);
    void SetVisibleMesh(class USkeletalMesh* NewSkeletalMesh);
    void SetViewMode(EALSViewMode NewViewMode, bool bForce);
    void SetStance(EALSStance NewStance, bool bForce);
    void SetRotationMode(EALSRotationMode NewRotationMode, bool bForce);
    void SetRightShoulder(bool bNewRightShoulder);
    void SetOverlayState(EALSOverlayState NewState, bool bForce);
    void SetOverlayOverrideState(int32 NewState);
    void SetMovementState(EALSMovementState NewState, bool bForce);
    void SetMovementModel(FDataTableRowHandle Model);
    void SetMovementAction(EALSMovementAction NewAction, bool bForce);
    void SetGroundedEntryState(EALSGroundedEntryState NewState);
    void SetGait(EALSGait NewGait, bool bForce);
    void SetDesiredStance(EALSStance NewStance);
    void SetDesiredRotationMode(EALSRotationMode NewRotMode);
    void SetDesiredGait(EALSGait NewGait);
    void SetCameraBehavior(class UALSPlayerCameraBehavior* CamBeh);
    void SetActorLocationAndTargetRotation(FVector NewLocation, FRotator NewRotation);
    void Server_SetVisibleMesh(class USkeletalMesh* NewSkeletalMesh);
    void Server_SetViewMode(EALSViewMode NewViewMode, bool bForce);
    void Server_SetRotationMode(EALSRotationMode NewRotationMode, bool bForce);
    void Server_SetOverlayState(EALSOverlayState NewState, bool bForce);
    void Server_SetMeshLocationDuringRagdoll(FVector MeshLocation);
    void Server_SetDesiredStance(EALSStance NewStance);
    void Server_SetDesiredRotationMode(EALSRotationMode NewRotMode);
    void Server_SetDesiredGait(EALSGait NewGait);
    void Server_RagdollStart();
    void Server_RagdollEnd(FVector CharacterLocation);
    void Server_PlayMontage(class UAnimMontage* Montage, float PlayRate);
    void RightMovementAction(float Value);
    void ReplicatedRagdollStart();
    void ReplicatedRagdollEnd();
    void Replicated_PlayMontage(class UAnimMontage* Montage, float PlayRate);
    void RagdollStart();
    void RagdollEnd();
    void RagdollAction();
    void OnRep_VisibleMesh(class USkeletalMesh* NewVisibleMesh);
    void OnRep_ViewMode(EALSViewMode PrevViewMode);
    void OnRep_RotationMode(EALSRotationMode PrevRotMode);
    void OnRep_OverlayState(EALSOverlayState PrevOverlayState);
    void OnBreakfall();
    void Multicast_RagdollStart();
    void Multicast_RagdollEnd(FVector CharacterLocation);
    void Multicast_PlayMontage(class UAnimMontage* Montage, float PlayRate);
    void Multicast_OnLanded();
    void Multicast_OnJumped();
    void LookingDirectionAction();
    void JumpAction(bool bValue);
    bool IsRightShoulder();
    bool IsMoving();
    bool HasMovementInput();
    EALSViewMode GetViewMode();
    TEnumAsByte<ECollisionChannel> GetThirdPersonTraceParams(FVector& TraceOrigin, float& TraceRadius);
    FTransform GetThirdPersonPivotTarget();
    FALSMovementSettings GetTargetMovementSettings();
    EALSStance GetStance();
    float GetSpeed();
    EALSRotationMode GetRotationMode();
    class UAnimMontage* GetRollAnimation();
    EALSMovementState GetPrevMovementState();
    EALSOverlayState GetOverlayState();
    int32 GetOverlayOverrideState();
    class UALSCharacterMovementComponent* GetMyMovementComponent();
    EALSMovementState GetMovementState();
    float GetMovementInputAmount();
    FVector GetMovementInput();
    EALSMovementAction GetMovementAction();
    EALSGroundedEntryState GetGroundedEntryState();
    class UAnimMontage* GetGetUpAnimation(bool bRagdollFaceUpState);
    EALSGait GetGait();
    FVector GetFirstPersonCameraTarget();
    EALSStance GetDesiredStance();
    EALSRotationMode GetDesiredRotationMode();
    EALSGait GetDesiredGait();
    void GetCameraParameters(float& TPFOVOut, float& FPFOVOut, bool& bRightShoulderOut);
    float GetAnimCurveValue(FName CurveName);
    EALSGait GetAllowedGait();
    float GetAimYawRate();
    FRotator GetAimingRotation();
    EALSGait GetActualGait(EALSGait AllowedGait);
    FVector GetAcceleration();
    void ForwardMovementAction(float Value);
    void EventOnLanded();
    void EventOnJumped();
    bool CanSprint();
    void CameraUpAction(float Value);
    void CameraTapAction();
    void CameraRightAction(float Value);
    void CameraHeldAction();
    void AimAction(bool bValue);
}; // Size: 0x940

class AALSCharacter : public AALSBaseCharacter
{
    class USceneComponent* HeldObjectRoot;                                            // 0x0940 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0948 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0950 (size: 0x8)

    void UpdateHeldObjectAnimations();
    void UpdateHeldObject();
    void ClearHeldObject();
    void AttachToHand(class UStaticMesh* NewStaticMesh, class USkeletalMesh* NewSkeletalMesh, UClass* NewAnimClass, bool bLeftHand, FVector Offset);
}; // Size: 0x960

class AALSPlayerCameraManager : public APlayerCameraManager
{
    class AALSBaseCharacter* ControlledCharacter;                                     // 0x24B8 (size: 0x8)
    class USkeletalMeshComponent* CameraBehavior;                                     // 0x24C0 (size: 0x8)
    FVector RootLocation;                                                             // 0x24C8 (size: 0x18)
    FTransform SmoothedPivotTarget;                                                   // 0x24E0 (size: 0x60)
    FVector PivotLocation;                                                            // 0x2540 (size: 0x18)
    FVector TargetCameraLocation;                                                     // 0x2558 (size: 0x18)
    FRotator TargetCameraRotation;                                                    // 0x2570 (size: 0x18)
    FRotator DebugViewRotation;                                                       // 0x2588 (size: 0x18)
    FVector DebugViewOffset;                                                          // 0x25A0 (size: 0x18)
    class UALSDebugComponent* ALSDebugComponent;                                      // 0x25B8 (size: 0x8)

    void OnPossess(class AALSBaseCharacter* NewCharacter);
    float GetCameraBehaviorParam(FName CurveName);
    void DrawDebugTargets(FVector PivotTargetLocation);
    bool CustomCameraBehavior(float DeltaTime, FVector& Location, FRotator& Rotation, float& FOV);
    FVector CalculateAxisIndependentLag(FVector CurrentLocation, FVector TargetLocation, FRotator CameraRotation, FVector LagSpeeds, float DeltaTime);
}; // Size: 0x25C0

class AALSPlayerController : public APlayerController
{
    class AALSBaseCharacter* PossessedCharacter;                                      // 0x0858 (size: 0x8)
    bool bApplyDefaultInputMappingContexts;                                           // 0x0860 (size: 0x1)
    class UInputMappingContext* DefaultInputMappingContext;                           // 0x0868 (size: 0x8)
    class UInputMappingContext* DebugInputMappingContext;                             // 0x0870 (size: 0x8)

    void WalkAction(const FInputActionValue& Value);
    void VelocityDirectionAction(const FInputActionValue& Value);
    void StanceAction(const FInputActionValue& Value);
    void SprintAction(const FInputActionValue& Value);
    void RightMovementAction(const FInputActionValue& Value);
    void RagdollAction(const FInputActionValue& Value);
    void LookingDirectionAction(const FInputActionValue& Value);
    void JumpAction(const FInputActionValue& Value);
    void ForwardMovementAction(const FInputActionValue& Value);
    void DebugToggleTracesAction(const FInputActionValue& Value);
    void DebugToggleSlomoAction(const FInputActionValue& Value);
    void DebugToggleShapesAction(const FInputActionValue& Value);
    void DebugToggleMeshAction(const FInputActionValue& Value);
    void DebugToggleLayerColorsAction(const FInputActionValue& Value);
    void DebugToggleHudAction(const FInputActionValue& Value);
    void DebugToggleDebugViewAction(const FInputActionValue& Value);
    void DebugToggleCharacterInfoAction(const FInputActionValue& Value);
    void DebugOverlayMenuCycleAction(const FInputActionValue& Value);
    void DebugOpenOverlayMenuAction(const FInputActionValue& Value);
    void DebugFocusedCharacterCycleAction(const FInputActionValue& Value);
    void CameraUpAction(const FInputActionValue& Value);
    void CameraTapAction(const FInputActionValue& Value);
    void CameraRightAction(const FInputActionValue& Value);
    void CameraHeldAction(const FInputActionValue& Value);
    bool AreStreamingSourcesEnabled();
    void AimAction(const FInputActionValue& Value);
}; // Size: 0x878

class UALSAnimNotifyCameraShake : public UAnimNotify
{
    TSubclassOf<class UCameraShakeBase> ShakeClass;                                   // 0x0038 (size: 0x8)
    float Scale;                                                                      // 0x0040 (size: 0x4)

}; // Size: 0x48

class UALSAnimNotifyFootstep : public UAnimNotify
{
    class UDataTable* HitDataTable;                                                   // 0x0038 (size: 0x8)
    FName FootSocketName;                                                             // 0x0040 (size: 0x8)
    TEnumAsByte<ETraceTypeQuery> TraceChannel;                                        // 0x0048 (size: 0x1)
    TEnumAsByte<EDrawDebugTrace::Type> DrawDebugType;                                 // 0x0049 (size: 0x1)
    float TraceLength;                                                                // 0x004C (size: 0x4)
    bool bSpawnDecal;                                                                 // 0x0050 (size: 0x1)
    bool bMirrorDecalX;                                                               // 0x0051 (size: 0x1)
    bool bMirrorDecalY;                                                               // 0x0052 (size: 0x1)
    bool bMirrorDecalZ;                                                               // 0x0053 (size: 0x1)
    bool bSpawnSound;                                                                 // 0x0054 (size: 0x1)
    FName SoundParameterName;                                                         // 0x0058 (size: 0x8)
    EALSFootstepType FootstepType;                                                    // 0x0060 (size: 0x1)
    bool bOverrideMaskCurve;                                                          // 0x0061 (size: 0x1)
    float VolumeMultiplier;                                                           // 0x0064 (size: 0x4)
    float PitchMultiplier;                                                            // 0x0068 (size: 0x4)
    bool bSpawnNiagara;                                                               // 0x006C (size: 0x1)

}; // Size: 0x70

class UALSAnimNotifyGroundedEntryState : public UAnimNotify
{
    EALSGroundedEntryState GroundedEntryState;                                        // 0x0038 (size: 0x1)

}; // Size: 0x40

class UALSCharacterAnimInstance : public UAnimInstance
{
    class AALSBaseCharacter* Character;                                               // 0x0368 (size: 0x8)
    FALSAnimCharacterInformation CharacterInformation;                                // 0x0370 (size: 0xA8)
    FALSMovementState MovementState;                                                  // 0x0418 (size: 0x6)
    FALSMovementAction MovementAction;                                                // 0x041E (size: 0x6)
    FALSRotationMode RotationMode;                                                    // 0x0424 (size: 0x4)
    FALSGait Gait;                                                                    // 0x0428 (size: 0x4)
    FALSStance Stance;                                                                // 0x042C (size: 0x3)
    FALSOverlayState OverlayState;                                                    // 0x042F (size: 0xE)
    FALSAnimGraphGrounded Grounded;                                                   // 0x0440 (size: 0x34)
    FALSVelocityBlend VelocityBlend;                                                  // 0x0474 (size: 0x10)
    FALSLeanAmount LeanAmount;                                                        // 0x0484 (size: 0x8)
    FVector RelativeAccelerationAmount;                                               // 0x0490 (size: 0x18)
    FALSGroundedEntryState GroundedEntryState;                                        // 0x04A8 (size: 0x3)
    FALSMovementDirection MovementDirection;                                          // 0x04AB (size: 0x5)
    FALSAnimGraphInAir InAir;                                                         // 0x04B0 (size: 0x10)
    FALSAnimGraphAimingValues AimingValues;                                           // 0x04C0 (size: 0x58)
    FVector2D SmoothedAimingAngle;                                                    // 0x0518 (size: 0x10)
    float FlailRate;                                                                  // 0x0528 (size: 0x4)
    FALSAnimGraphLayerBlending LayerBlendingValues;                                   // 0x052C (size: 0x60)
    FALSAnimGraphFootIK FootIKValues;                                                 // 0x0590 (size: 0x138)
    FALSAnimTurnInPlace TurnInPlaceValues;                                            // 0x06C8 (size: 0x118)
    FALSAnimRotateInPlace RotateInPlace;                                              // 0x07E0 (size: 0x18)
    FALSAnimConfiguration Config;                                                     // 0x07F8 (size: 0x38)
    class UCurveFloat* DiagonalScaleAmountCurve;                                      // 0x0830 (size: 0x8)
    class UCurveFloat* StrideBlend_N_Walk;                                            // 0x0838 (size: 0x8)
    class UCurveFloat* StrideBlend_N_Run;                                             // 0x0840 (size: 0x8)
    class UCurveFloat* StrideBlend_C_Walk;                                            // 0x0848 (size: 0x8)
    class UCurveFloat* LandPredictionCurve;                                           // 0x0850 (size: 0x8)
    class UCurveFloat* LeanInAirCurve;                                                // 0x0858 (size: 0x8)
    class UCurveVector* YawOffset_FB;                                                 // 0x0860 (size: 0x8)
    class UCurveVector* YawOffset_LR;                                                 // 0x0868 (size: 0x8)
    class UAnimSequenceBase* TransitionAnim_R;                                        // 0x0870 (size: 0x8)
    class UAnimSequenceBase* TransitionAnim_L;                                        // 0x0878 (size: 0x8)
    FName IkFootL_BoneName;                                                           // 0x0880 (size: 0x8)
    FName IkFootR_BoneName;                                                           // 0x0888 (size: 0x8)
    class UALSDebugComponent* ALSDebugComponent;                                      // 0x08B0 (size: 0x8)

    bool ShouldMoveCheck();
    void SetTrackedHipsDirection(EALSHipsDirection HipsDirection);
    void SetGroundedEntryState(EALSGroundedEntryState NewState);
    void PlayTransitionChecked(const FALSDynamicMontageParams& Parameters);
    void PlayTransition(const FALSDynamicMontageParams& Parameters);
    void PlayDynamicTransition(float ReTriggerDelay, FALSDynamicMontageParams Parameters);
    void OnPivot();
    void OnJumped();
    bool CanTurnInPlace();
    bool CanRotateInPlace();
    bool CanDynamicTransition();
}; // Size: 0x8C0

class UALSCharacterMovementComponent : public UCharacterMovementComponent
{
    FName AvoidanceCapsuleComponentTag;                                               // 0x0F78 (size: 0x8)
    uint8 bRequestMovementSettingsChange;                                             // 0x0F80 (size: 0x1)
    EALSGait AllowedGait;                                                             // 0x0F81 (size: 0x1)
    FALSMovementSettings CurrentMovementSettings;                                     // 0x0F88 (size: 0x20)
    bool bUseMovementSettingsWhenFlying;                                              // 0x0FA8 (size: 0x1)
    TEnumAsByte<EMovementMode> CustomDefaultMovementMode;                             // 0x0FA9 (size: 0x1)
    FName AgentName;                                                                  // 0x0FAC (size: 0x8)
    bool bForceUseNavMeshWalking;                                                     // 0x0FB4 (size: 0x1)
    float NavMeshWalkingSearchDistance;                                               // 0x0FB8 (size: 0x4)
    float NavMeshWalkingHeightSearchScale;                                            // 0x0FBC (size: 0x4)
    float DebugDisplayNavMeshWalkingLifetime;                                         // 0x0FC0 (size: 0x4)
    bool bForcePositionOnNavMesh;                                                     // 0x0FC4 (size: 0x1)
    float DebugDisplayForcePositionOnNavMeshLifetime;                                 // 0x0FC8 (size: 0x4)

    void SetMovementSettings(FALSMovementSettings NewMovementSettings);
    void SetAllowedGait(EALSGait NewAllowedGait);
    void Server_SetAllowedGait(EALSGait NewAllowedGait);
}; // Size: 0xFD0

class UALSDebugComponent : public UActorComponent
{
    class AALSBaseCharacter* OwnerCharacter;                                          // 0x00A0 (size: 0x8)
    bool bSlomo;                                                                      // 0x00A8 (size: 0x1)
    bool bShowHUD;                                                                    // 0x00A9 (size: 0x1)
    bool bShowCharacterInfo;                                                          // 0x00AA (size: 0x1)
    class USkeletalMesh* DebugSkeletalMesh;                                           // 0x00B0 (size: 0x8)
    TArray<AALSBaseCharacter*> AvailableDebugCharacters;                              // 0x00B8 (size: 0x10)
    class AALSBaseCharacter* DebugFocusCharacter;                                     // 0x00C8 (size: 0x8)
    class USkeletalMesh* DefaultSkeletalMesh;                                         // 0x00D8 (size: 0x8)

    void UpdateColoringSystem();
    void ToggleTraces();
    void ToggleSlomo();
    void ToggleLayerColors();
    void ToggleHud();
    void ToggleGlobalTimeDilationLocal(float TimeDilation);
    void ToggleDebugView();
    void ToggleDebugShapes();
    void ToggleDebugMesh();
    void ToggleCharacterInfo();
    void SetResetColors();
    void SetDynamicMaterials();
    void OverlayMenuCycle(bool bValue);
    void OpenOverlayMenu(bool bValue);
    void OnPlayerControllerInitialized(class APlayerController* Controller);
    bool GetShowTraces();
    bool GetShowLayerColors();
    bool GetShowDebugShapes();
    bool GetDebugView();
    void FocusedDebugCharacterCycle(bool bValue);
    void DrawDebugSpheres();
}; // Size: 0xE8

class UALSMantleComponent : public UActorComponent
{
    FALSMantleComponentOnMantleStateChanged OnMantleStateChanged;                     // 0x00A0 (size: 0x10)
    void MantleStateChangedSignature(bool State);
    class UTimelineComponent* MantleTimeline;                                         // 0x00B0 (size: 0x8)
    FALSMantleTraceSettings GroundedTraceSettings;                                    // 0x00B8 (size: 0x14)
    FALSMantleTraceSettings AutomaticTraceSettings;                                   // 0x00CC (size: 0x14)
    FALSMantleTraceSettings FallingTraceSettings;                                     // 0x00E0 (size: 0x14)
    class UCurveFloat* MantleTimelineCurve;                                           // 0x00F8 (size: 0x8)
    FName MantleObjectDetectionProfile;                                               // 0x0100 (size: 0x8)
    TEnumAsByte<ECollisionChannel> WalkableSurfaceDetectionChannel;                   // 0x0108 (size: 0x1)
    FALSMantleParams MantleParams;                                                    // 0x0110 (size: 0x30)
    FALSComponentAndTransform MantleLedgeLS;                                          // 0x0140 (size: 0x70)
    FTransform MantleTarget;                                                          // 0x01B0 (size: 0x60)
    FTransform MantleActualStartOffset;                                               // 0x0210 (size: 0x60)
    FTransform MantleAnimatedStartOffset;                                             // 0x0270 (size: 0x60)
    float AcceptableVelocityWhileMantling;                                            // 0x02D0 (size: 0x4)
    class AALSBaseCharacter* OwnerCharacter;                                          // 0x02D8 (size: 0x8)
    class UALSDebugComponent* ALSDebugComponent;                                      // 0x02E0 (size: 0x8)

    void Server_MantleStart(float MantleHeight, const FALSComponentAndTransform& MantleLedgeWS, EALSMantleType MantleType);
    void PerformMantleIfPossible();
    void OnOwnerRagdollStateChanged(bool bRagdollState);
    void Multicast_MantleStart(float MantleHeight, const FALSComponentAndTransform& MantleLedgeWS, EALSMantleType MantleType);
    void MantleUpdate(float BlendIn);
    void MantleStart(float MantleHeight, const FALSComponentAndTransform& MantleLedgeWS, EALSMantleType MantleType);
    void MantleEnd();
    bool MantleCheck(const FALSMantleTraceSettings& TraceSettings, TEnumAsByte<EDrawDebugTrace::Type> DebugType);
    FALSMantleAsset GetMantleAsset(EALSMantleType MantleType, EALSOverlayState CurrentOverlayState);
}; // Size: 0x2F0

class UALSMathLibrary : public UBlueprintFunctionLibrary
{

    FTransform TransformSub(const FTransform& T1, const FTransform& T2);
    FTransform TransformAdd(const FTransform& T1, const FTransform& T2);
    FTransform MantleComponentLocalToWorld(const FALSComponentAndTransform& CompAndTransform);
    FVector GetCapsuleLocationFromBase(FVector BaseLocation, float ZOffset, class UCapsuleComponent* Capsule);
    FVector GetCapsuleBaseLocation(float ZOffset, class UCapsuleComponent* Capsule);
    bool CapsuleHasRoomCheck(class UCapsuleComponent* Capsule, FVector TargetLocation, float HeightOffset, float RadiusOffset, TEnumAsByte<EDrawDebugTrace::Type> DebugType, bool DrawDebugTrace);
    EALSMovementDirection CalculateQuadrant(EALSMovementDirection Current, float FRThreshold, float FLThreshold, float BRThreshold, float BLThreshold, float Buffer, float Angle);
    bool AngleInRange(float Angle, float MinAngle, float MaxAngle, float Buffer, bool IncreaseBuffer);
}; // Size: 0x28

class UALSNotifyStateEarlyBlendOut : public UAnimNotifyState
{
    class UAnimMontage* ThisMontage;                                                  // 0x0038 (size: 0x8)
    float BlendOutTime;                                                               // 0x0040 (size: 0x4)
    bool bCheckMovementState;                                                         // 0x0044 (size: 0x1)
    EALSMovementState MovementStateEquals;                                            // 0x0045 (size: 0x1)
    bool bCheckStance;                                                                // 0x0046 (size: 0x1)
    EALSStance StanceEquals;                                                          // 0x0047 (size: 0x1)
    bool bCheckMovementInput;                                                         // 0x0048 (size: 0x1)

}; // Size: 0x50

class UALSNotifyStateMovementAction : public UAnimNotifyState
{
    EALSMovementAction MovementAction;                                                // 0x0038 (size: 0x1)

}; // Size: 0x40

class UALSNotifyStateOverlayOverride : public UAnimNotifyState
{
    int32 OverlayOverrideState;                                                       // 0x0038 (size: 0x4)

}; // Size: 0x40

class UALSPlayerCameraBehavior : public UAnimInstance
{
    EALSMovementState MovementState;                                                  // 0x0368 (size: 0x1)
    EALSMovementAction MovementAction;                                                // 0x0369 (size: 0x1)
    bool bLookingDirection;                                                           // 0x036A (size: 0x1)
    bool bVelocityDirection;                                                          // 0x036B (size: 0x1)
    bool bAiming;                                                                     // 0x036C (size: 0x1)
    EALSGait Gait;                                                                    // 0x036D (size: 0x1)
    EALSStance Stance;                                                                // 0x036E (size: 0x1)
    EALSViewMode ViewMode;                                                            // 0x036F (size: 0x1)
    bool bRightShoulder;                                                              // 0x0370 (size: 0x1)
    bool bDebugView;                                                                  // 0x0371 (size: 0x1)

}; // Size: 0x380

class UALS_BTTask_GetRandomLocation : public UBTTask_BlackboardBase
{
    float MaxDistance;                                                                // 0x0098 (size: 0x4)
    TSubclassOf<class UNavigationQueryFilter> Filter;                                 // 0x00A0 (size: 0x8)

}; // Size: 0xA8

class UALS_BTTask_SetFocusToPlayer : public UBTTaskNode
{
}; // Size: 0x70

#endif
