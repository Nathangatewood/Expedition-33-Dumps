#ifndef UE4SS_SDK_BP_DA_CharacterStatsPerLevelScalingProfile_HPP
#define UE4SS_SDK_BP_DA_CharacterStatsPerLevelScalingProfile_HPP

class UBP_DA_CharacterStatsPerLevelScalingProfile_C : public UPrimaryDataAsset
{
    FFCharacterAttributeScalingList StatsScaling;                                     // 0x0030 (size: 0xA0)

}; // Size: 0xD0

#endif
