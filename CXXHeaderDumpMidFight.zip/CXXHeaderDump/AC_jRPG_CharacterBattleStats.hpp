#ifndef UE4SS_SDK_AC_jRPG_CharacterBattleStats_HPP
#define UE4SS_SDK_AC_jRPG_CharacterBattleStats_HPP

class UAC_jRPG_CharacterBattleStats_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FName CharacterHardcodedName;                                                     // 0x00A8 (size: 0x8)
    class UTexture2D* CharacterBattleIcon;                                            // 0x00B0 (size: 0x8)
    FText CharacterDisplayName;                                                       // 0x00B8 (size: 0x10)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> CharacterBaseStats;              // 0x00C8 (size: 0x50)
    TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> CharacterCurrentStats;           // 0x0118 (size: 0x50)
    double CurrentHP;                                                                 // 0x0168 (size: 0x8)
    int32 CurrentShieldPoints;                                                        // 0x0170 (size: 0x4)
    double CurrentAP;                                                                 // 0x0178 (size: 0x8)
    double CurrentInitiative;                                                         // 0x0180 (size: 0x8)
    bool Defending;                                                                   // 0x0188 (size: 0x1)
    class UAC_jRPG_BattleManager_C* BattleManagerReference;                           // 0x0190 (size: 0x8)
    class UBP_jRPG_GI_Custom_C* GameInstanceReference;                                // 0x0198 (size: 0x8)
    TEnumAsByte<E_jRPG_ActionType::Type> SelectedActionType;                          // 0x01A0 (size: 0x1)
    FName SelectedSecondaryActionName;                                                // 0x01A4 (size: 0x8)
    TArray<ABP_jRPG_Character_Battle_Base_C*> TargetedCharacters;                     // 0x01B0 (size: 0x10)
    double CurrentPower;                                                              // 0x01C0 (size: 0x8)
    TMap<TEnumAsByte<E_jRPG_ItemType::Type>, FS_jRPG_Item_StaticData> EquipmentLegacy; // 0x01C8 (size: 0x50)
    double BuffPower;                                                                 // 0x0218 (size: 0x8)
    double OriginalPower;                                                             // 0x0220 (size: 0x8)
    class UBP_BattleBuffComponent_C* BattleBuffComponent;                             // 0x0228 (size: 0x8)
    TMap<FGuid, FStatMultiplier> CharacterStatMultipliers;                            // 0x0230 (size: 0x50)
    TMap<FName, int32> SkillsLearnt;                                                  // 0x0280 (size: 0x50)
    double CurrentOverdrive;                                                          // 0x02D0 (size: 0x8)
    FS_jRPG_OverdriveSource OverdriveSources;                                         // 0x02D8 (size: 0x10)
    bool SimulatedDamage?;                                                            // 0x02E8 (size: 0x1)
    int32 TurnSkipRefCount;                                                           // 0x02EC (size: 0x4)
    FAC_jRPG_CharacterBattleStats_COnBuffAdded OnBuffAdded;                           // 0x02F0 (size: 0x10)
    void OnBuffAdded(class UBP_BattleBuffInstance_C* BuffInstance);
    FAC_jRPG_CharacterBattleStats_COnBuffRemoved OnBuffRemoved;                       // 0x0300 (size: 0x10)
    void OnBuffRemoved(class UBP_BattleBuffInstance_C* BuffInstance);
    FAC_jRPG_CharacterBattleStats_COnHPChanged OnHPChanged;                           // 0x0310 (size: 0x10)
    void OnHPChanged(double NewHP, double PreviousHP);
    FAC_jRPG_CharacterBattleStats_COnShieldPointsChanged OnShieldPointsChanged;       // 0x0320 (size: 0x10)
    void OnShieldPointsChanged(int32 CurrentValue, int32 PreviousValue);
    FAC_jRPG_CharacterBattleStats_COnCharacterInitialized OnCharacterInitialized;     // 0x0330 (size: 0x10)
    void OnCharacterInitialized();
    class UWBP_HUD_Battle_CharacterPortrait_C* CharacterBattleSlotWidget;             // 0x0340 (size: 0x8)
    bool HasReceivedHitDuringCurrentSkill;                                            // 0x0348 (size: 0x1)
    bool HasParriedAllHitsDuringCurrentSkill;                                         // 0x0349 (size: 0x1)
    TArray<FName> ActiveChecks;                                                       // 0x0350 (size: 0x10)
    FName Check_CanRecoverHP;                                                         // 0x0360 (size: 0x8)
    FName Check_IsAlive;                                                              // 0x0368 (size: 0x8)
    FName Check_IsMaxedHP;                                                            // 0x0370 (size: 0x8)
    FName Check_CanResurrect;                                                         // 0x0378 (size: 0x8)
    class UBP_BattleCheckContext_C* TargetingCheckContext;                            // 0x0380 (size: 0x8)
    class UBP_BattleCheckContext_C* BattleActionCheckContext;                         // 0x0388 (size: 0x8)
    FAC_jRPG_CharacterBattleStats_COnAPChanged OnAPChanged;                           // 0x0390 (size: 0x10)
    void OnAPChanged(int32 NewAP, int32 PreviousAP, class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    int32 APDefendCost;                                                               // 0x03A0 (size: 0x4)
    int32 APDodgeCost;                                                                // 0x03A4 (size: 0x4)
    int32 APParryCost;                                                                // 0x03A8 (size: 0x4)
    int32 APNewTurnGain;                                                              // 0x03AC (size: 0x4)
    int32 APGainParry;                                                                // 0x03B0 (size: 0x4)
    int32 APGainAttack;                                                               // 0x03B4 (size: 0x4)
    FFCharacterStats CharacterStats;                                                  // 0x03B8 (size: 0x30)
    int32 APTurnStartBonus;                                                           // 0x03E8 (size: 0x4)
    FAC_jRPG_CharacterBattleStats_COnAPChangedEvent OnAPChangedEvent;                 // 0x03F0 (size: 0x10)
    void OnAPChangedEvent(class UBP_BattleEvent_APChange_C* APChangeEvent);
    FAC_jRPG_CharacterBattleStats_COnDeath OnDeath;                                   // 0x0400 (size: 0x10)
    void OnDeath();
    int32 DefenseLockRefCount;                                                        // 0x0410 (size: 0x4)
    bool IsStun;                                                                      // 0x0414 (size: 0x1)
    TMap<FFEquipmentSlot, FS_jRPG_Item_StaticData> Equipment;                         // 0x0418 (size: 0x50)
    int64 StunBreakBarCurrent;                                                        // 0x0468 (size: 0x8)
    int64 StunBreakBarMax;                                                            // 0x0470 (size: 0x8)
    FSF_ReferenceCounter BreakDamageBlockerRefCount;                                  // 0x0478 (size: 0x20)
    bool HasEngagementBonus;                                                          // 0x0498 (size: 0x1)
    TMap<UBP_BattleBuffInstance_C*, FFPassiveEffect> BuffToPassiveMap;                // 0x04A0 (size: 0x50)
    TMap<UBP_BattleBuffInstance_C*, FName> BuffToPassiveIDsMap;                       // 0x04F0 (size: 0x50)
    bool IsBoss;                                                                      // 0x0540 (size: 0x1)
    FSF_ReferenceCounter PreventDeathRefCount;                                        // 0x0548 (size: 0x20)
    bool IsCurrentAttackUndodgeable;                                                  // 0x0568 (size: 0x1)
    bool IsCurrentAttackUnblockable;                                                  // 0x0569 (size: 0x1)
    bool IsCurrentAttackGradient;                                                     // 0x056A (size: 0x1)
    bool IsCurrentAttackJumpable;                                                     // 0x056B (size: 0x1)
    TSubclassOf<class ABP_Battle_SkillScript_C> AutomaticCounterSkill;                // 0x0570 (size: 0x8)
    TArray<UBP_DataAsset_Skill_C*> Skills;                                            // 0x0578 (size: 0x10)
    TMap<UBP_DataAsset_Skill_C*, UBP_SkillState_C*> SkillStates;                      // 0x0588 (size: 0x50)
    bool GradientAttackPpIsOn;                                                        // 0x05D8 (size: 0x1)
    bool IsFleeing;                                                                   // 0x05D9 (size: 0x1)
    class UAC_jRPG_CharacterBattleStats_C* PuppetedBy;                                // 0x05E0 (size: 0x8)
    TArray<UBP_SkillDataComponentScript_C*> BattleStartEvent_ToProcess_SkillDataComponent; // 0x05E8 (size: 0x10)
    class UBP_DependencyRefCounter_C* BattleStartNotifyDependencies;                  // 0x05F8 (size: 0x8)
    FSF_ReferenceCounter DodgeLock;                                                   // 0x0600 (size: 0x20)
    FAC_jRPG_CharacterBattleStats_COnDamageReceived OnDamageReceived;                 // 0x0620 (size: 0x10)
    void OnDamageReceived(class UBP_BattleDamages_C* BattleDamages);
    bool IsPerformingLastStand;                                                       // 0x0630 (size: 0x1)
    bool ShouldInterceptAllTeamAttacks;                                               // 0x0631 (size: 0x1)
    TArray<UAC_jRPG_CharacterBattleStats_C*> CharactersToProtectWithInterception;     // 0x0638 (size: 0x10)
    class UAC_jRPG_CharacterBattleStats_C* CurrentInterceptedCharacter;               // 0x0648 (size: 0x8)
    FSF_ReferenceCounter DamageLimitUnlockRefCount;                                   // 0x0650 (size: 0x20)
    TEnumAsByte<EAttackType::Type> BaseDamageType;                                    // 0x0670 (size: 0x1)
    TEnumAsByte<EAttackType::Type> FreeAimDamageType;                                 // 0x0671 (size: 0x1)
    FS_ResurrectParameters NextResurrectParameters;                                   // 0x0678 (size: 0x18)
    FAC_jRPG_CharacterBattleStats_COnBreakDamageReceived OnBreakDamageReceived;       // 0x0690 (size: 0x10)
    void OnBreakDamageReceived(class UAC_jRPG_CharacterBattleStats_C* SelfCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, int32 PreviousValue);
    FAC_jRPG_CharacterBattleStats_COnBreakBarStun OnBreakBarStun;                     // 0x06A0 (size: 0x10)
    void OnBreakBarStun(class UAC_jRPG_CharacterBattleStats_C* SelfCharacter);
    FAC_jRPG_CharacterBattleStats_COnConsumableActionEffect OnConsumableActionEffect; // 0x06B0 (size: 0x10)
    void OnConsumableActionEffect(class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStats, TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetCharacterBases, FName ShardID, FName ConsumableID);
    FAC_jRPG_CharacterBattleStats_COnDeathDamagePrevented OnDeathDamagePrevented;     // 0x06C0 (size: 0x10)
    void OnDeathDamagePrevented(class UObject* CharacterStats);
    bool IsFlying;                                                                    // 0x06D0 (size: 0x1)
    FSF_ReferenceCounter ForceAutoAttackRefCount;                                     // 0x06D8 (size: 0x20)
    FAC_jRPG_CharacterBattleStats_COnDamageAbsorbed OnDamageAbsorbed;                 // 0x06F8 (size: 0x10)
    void OnDamageAbsorbed(int64 Amount, class UBP_BattleDamages_C* BattleDamages);
    class ABP_Battle_SkillScript_C* ForcedSkillOnNextTurn;                            // 0x0708 (size: 0x8)
    FSF_ReferenceCounter ParryLock;                                                   // 0x0710 (size: 0x20)
    FAC_jRPG_CharacterBattleStats_COnSkillPreExecution OnSkillPreExecution;           // 0x0730 (size: 0x10)
    void OnSkillPreExecution(class UBP_SkillState_C* SkillState);
    FSF_ModifierStackWrapper DodgeWindowModifierStack;                                // 0x0740 (size: 0x8)
    FSF_ModifierStackWrapper ParryWindowModifierStack;                                // 0x0748 (size: 0x8)
    FAC_jRPG_CharacterBattleStats_COnPerfectDodge OnPerfectDodge;                     // 0x0750 (size: 0x10)
    void OnPerfectDodge();
    ETextGender GenderTag;                                                            // 0x0760 (size: 0x1)
    bool bIsPreparedForBattle;                                                        // 0x0761 (size: 0x1)
    bool bIsDeathQueuedForTurnEnd;                                                    // 0x0762 (size: 0x1)
    TArray<UAction_AddBuff_C*> NestedAddBuffActionStack;                              // 0x0768 (size: 0x10)
    FSF_ReferenceCounter SilenceRefCounts;                                            // 0x0778 (size: 0x20)
    FAC_jRPG_CharacterBattleStats_COnSkillStatesInitialized OnSkillStatesInitialized; // 0x0798 (size: 0x10)
    void OnSkillStatesInitialized();

    void GetDamageSourceCharacter(class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void GetDamageSourceType(TEnumAsByte<EDamageReason::Type>& DamageSourceType);
    void NotifySkillStatesAvailable();
    bool CanCounterAttackCurrentEnemySkill();
    bool IsDeathQueuedForTurnEnd();
    void ClearSkillStates();
    void SetDead_Internal();
    bool IsPreparedForBattle();
    ETextGender GetGenderTag();
    void TryDodgeHitFromCharacter(class UAC_jRPG_CharacterBattleStats_C* AttackingCharacter, bool& Successful, bool& IsPerfectDodge);
    void TryParryHitFromCharacter(class UAC_jRPG_CharacterBattleStats_C* AttackingCharacter, bool& Successful);
    void GetParryWindowModifier(class UModifierStack_Float*& Stack);
    void RemoveParryWindowModifier(FSF_ModifierStackEntryHandle& OutModifierHandle);
    void AddParryWindowModifier(double Percent, FSF_ModifierStackEntryHandle& OutModifierHandle, FString DebugName);
    void GetDodgeWindowModifier(class UModifierStack_Float*& Stack);
    void RemoveDodgeWindowModifier(FSF_ModifierStackEntryHandle& OutModifierHandle);
    void AddDodgeWindowModifier(double Percent, FSF_ModifierStackEntryHandle& OutModifierHandle, FString DebugName);
    void RemoveParryLock(FSF_ReferenceCounterHandle& LockHandle);
    void AddParryLock(FSF_ReferenceCounterHandle& LockHandle, FString DebugReason);
    bool IsParryLocked();
    class ABP_Battle_SkillScript_C* GetCurrentSkillScript();
    bool IsOfArchetype(TSoftObjectPtr<class UBP_DataAsset_EnemyBattleArchetype_C> Archetype);
    void GetArchetype(class UBP_DataAsset_EnemyBattleArchetype_C*& Archetype);
    void ResetCurrentParryFlags();
    void ResetCurrentAttackTypeFlags();
    class ABP_Battle_SkillScript_C* GetForcedSkillOnNextTurn();
    void TryProcessForcedSkill(bool& PreventPlayerChoice);
    void ForceSkillOnNextTurn(class ABP_Battle_SkillScript_C* SkillScript);
    bool IsSameCharacterStats(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void TryPerformBreakStun(class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, TEnumAsByte<E_BreakStunReason::Type> Reason, bool& Success);
    bool CanPerformBreakStun();
    void PerformBreakStun(class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, TEnumAsByte<E_BreakStunReason::Type> Reason);
    void SetIsCharacterFlying(bool IsFlying);
    bool CanPerformAction();
    bool HasForcedAutoAttack();
    void RemoveForcedAutoAttack(FSF_ReferenceCounterHandle& ReferenceHandle);
    void AddForcedAutoAttack(FSF_ReferenceCounterHandle& ReferenceHandle, FString DebugName);
    bool IsFlyingCharacter();
    bool IsDead();
    void GetCharacterData(class UBP_CharacterData_C*& CharacterData);
    bool IsInTeam(TEnumAsByte<ECharacterTeamSelector::Type> Team);
    void SetCurrentBreakBarDamage(int64 NewValue, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, FString Reason);
    TSubclassOf<class UBP_BattleBuffInstance_C> GetStunBuffClass();
    void SetBreakBarDamagePercentage(double Percentage, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, FString Reason);
    void AddBreakBarDamagePercentage(double Percentage, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, FString Reason);
    void AddBreakBarDamage(int64 DamageValue, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, FString Reason);
    double GetCurrentBreakBarPercent();
    void InitBreakBar(int32 BreakBarHPPercentage);
    void HasPendingResurrect(bool& Enabled);
    void ResurrectInternal();
    TEnumAsByte<EAttackType::Type> GetFreeAimDamageType();
    TEnumAsByte<EAttackType::Type> GetBaseDamageType();
    void StopInterceptingAttacksAgainstCharacter(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void StartInterceptingAttacksAgainstCharacter(class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    bool CanInterceptAttack(class UAC_jRPG_CharacterBattleStats_C* TargetedCharacter, class UAC_jRPG_CharacterBattleStats_C* AttackerCharacter);
    void OnBattleEnded();
    bool IsDodgeLockActive();
    void RemoveDodgeLock(FSF_ReferenceCounterHandle& LockHandle);
    void AddDodgeLock(FSF_ReferenceCounterHandle& LockHandle, FString DebugReason);
    void GetTeam(TEnumAsByte<ECharacterTeamSelector::Type>& Team);
    void ReceiveDamageFromObject(double Straight Damage (ignores calculation), class UBP_BattleDamageBuilder_C* DamageBuilder, double& DamageDealt, bool& HasHit, bool& DodgeSuccess, bool& ParrySuccess, class UBP_BattleDamages_C*& BattleDamages);
    bool IsSkillOvercharged(class UBP_DataAsset_Skill_C* Skill);
    void GetSkillScriptByTurnStartEventCriteria(TArray<UBP_SkillDataComponentScript_C*>& HasStartEvent, TArray<UBP_SkillDataComponentScript_C*>& HasNoStartEvent);
    void GetCurrentAPPercentage01(double& Percent01);
    void GetRuntimeStatValue(TEnumAsByte<ERuntimeBattleStatType::Type> StatType, double& Value);
    void Force Play Again(bool ShouldPlayTooltip, bool PreventChainedPlayAgain, bool& HasAppliedForcePlayAgain);
    void TryDisableGradientPostProcess(bool DuringCounter, FVector GradientCenterLocation);
    void RegisterSkillChecks(class UBP_DataAsset_Skill_C* Skill);
    void DrainAP(int32 Amount, class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStats);
    void Drain_AP_FromTarget(class UAC_jRPG_CharacterBattleStats_C* TargetCharacter, int32 Amount);
    void CheckForDeath(class UBP_BattleDamages_C* BattleDamages);
    void SetDead();
    void SetCharacterFleeing(bool IsFleeing);
    void GetCurrentShieldPoints(int32& ShieldPoints);
    void SetCurrentShieldPoints(int32 NewValue, FString DebugReason);
    void AddShieldPoints(int32 Amount, FString DebugReason);
    void TryConsumeShieldPoints(int32 Amount, FString DebugReason, bool& Success);
    void NotifyDeath(bool DeathCounter);
    void FindEquippedSkillByID(FName SkillID, class UBP_DataAsset_Skill_C*& Skill);
    void TriggerSkill(TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetedCharacters, TSubclassOf<class ABP_Battle_SkillScript_C> SkillClass);
    void UpdateSkillStates();
    void GetAllSkillStatesForUI(TMap<UBP_DataAsset_Skill_C*, UBP_SkillState_C*>& SkillStates);
    void GetSkillState(const class UBP_DataAsset_Skill_C* SkillData, class UBP_SkillState_C*& Value);
    double GetProbabilityToReceiveBuff(class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, TEnumAsByte<EBuffApplicationProbability::Type> StatusEffectProbability, class UBP_BattleBuffInstance_C* BuffInstance);
    void DeinitBattleGear();
    void GetDefenseAgainstElement(TEnumAsByte<EAttackType::Type> AttackElement, double& Defense);
    void PrepareForActionAsSkillCaster();
    void PrepareForActionAsSkillTarget();
    void InitSkillStates();
    bool DEBUG_Console_AutoGradientParry();
    void GetAttackPowerForType(TEnumAsByte<EAttackType::Type> AttackElement, double& Power);
    bool IsDefenseLockActive();
    void RemoveDefenseLock();
    void AddDefenseLock();
    bool IsTurnSkipActive();
    void RemoveTurnSkip();
    void AddTurnSkip();
    void GetPassiveFromBuff(const class UBP_BattleBuffInstance_C*& Key, FFPassiveEffect& PassiveEffect, FName& PassiveID, bool& Found);
    double GetCurrentSpeedSimulate(bool HasEngagementBonus);
    double GetCurrentSpeed();
    void GetCurrentHPPercentage(double& Percent01);
    void OnKilledByDamage(class UBP_BattleDamages_C* BattleDamages);
    bool CanSpendAP(int32 Amount);
    void SetAP(int32 NewAP, TEnumAsByte<EAPChangeReason::Type> ChangeReason);
    void CheckIsAlive2(bool CheckMode, class UBP_BattleCheckContext_C* NewParam, bool& Value);
    bool CheckCanResurrect(bool CheckMode);
    void CheckCanRecoverHP(bool CheckMode, bool& CanRecover, bool& BecauseDead, bool& BecauseMaxHP);
    void CheckIsMaxed(bool CheckMode, bool& Value);
    void CheckIsAlive(bool CheckMode, bool& Value);
    void InvalidateCheck(FName CheckName);
    void AddCheckStack(FName CheckConstant, bool CheckMode);
    void ResetChecks();
    void Assert Check(FName CheckConstant, FString OperationName);
    void CanRecoverHP(bool& Valid, bool& BecauseDead);
    void OnParryPerfectFail(FText Reason);
    bool DEBUG_Console_AutoDodge();
    bool DEBUG_Console_AutoParry();
    void ComputeNewInitiativeAfterTimeSimulate(double CurrentInitiative, double Time, bool HasEngagementBonus, bool DEBUG_Verbose, double& NewInitiative);
    void AdvanceInitiativeByTime(double Time, bool DEBUG_Verbose);
    void GetTimeToFullInitiativeSimulate(double CurrentInitiative, bool HasEngagementBonus, double& Time);
    void GetTimeToFullInitiative(double& Time);
    void GetMaxAP(double& MaxMP);
    void GetMaxHP(double& MaxHP);
    void InitBattleGear();
    void GetOtherElementalAffinity(class UAC_jRPG_CharacterBattleStats_C* CharacterBattleStats, TEnumAsByte<EAttackType::Type> AttackType, TEnumAsByte<EElementalAffinity::Type>& Affinity);
    void GetElementalAffinity(TEnumAsByte<EAttackType::Type> AttackType, TEnumAsByte<EElementalAffinity::Type>& Affinity);
    void GetCharacterBattleBase(class ABP_jRPG_Character_Battle_Base_C*& jRPG_CharacterBattleBase, bool& IsValid);
    void CheckHP/MaxHP();
    void SetHP(double HP Value);
    void OnOverrideFull();
    void AddOverdrive(double Amount, FText Reason);
    void OnBuffDeactivated(class UBP_BattleBuffInstanceWrapper_C* BuffInstanceWrapper);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterTurn);
    void RecalculateStats();
    void RemoveStatMultiplier(FGuid StatMultiplierUID);
    void AddStatMultiplier(TEnumAsByte<E_jRPG_StatType::Type> StatType, double Multiplier, FGuid& StatMultiplierUID);
    void ActivateBuff(class UBP_BattleBuffInstance_C* BuffInstance, TEnumAsByte<EBuffApplicationProbability::Type> StatusEffectProbability, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, bool& Success);
    void Resurrect(double HP Amount, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter);
    void ReduceAP(double Amount, TEnumAsByte<EAPChangeReason::Type> ChangeReason);
    void GainAP(int32 Amount, TEnumAsByte<EAPChangeReason::Type> ChangeReason);
    void GetCurrentAP(double& AP);
    void ReduceHP(double Amount, double& NewHPValue, double& EffectiveDamage);
    void ReduceInitiative(double Amount);
    void CalculateDefendStanceDamageReduction(double DamageInput, double& DamageOutput);
    void RemoveInitiative(double Amount);
    void ReceiveDamage(double FinalDamageMultiplier, TScriptInterface<class IIBattleDamageSource_C> DamageSourceCharacter, TEnumAsByte<EAttackType::Type> AttackType, bool Simulated Damage (No Damage will be dealt), double Straight Damage (ignores calculation), bool IsCounterDamage, TEnumAsByte<EDamageReason::Type> DamageReason, FVector DamageLocation, FString DebugReason, double& DamageDealt, bool& HasHit, bool& DodgeSuccess, bool& ParrySuccess, bool& QTESuccess?, class UBP_BattleDamages_C*& BattleDamages);
    void RecoverHP(double RecoveryAmount, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, bool PlayVFX, TEnumAsByte<EHealReason::Type> Reason, FString DebugReason);
    void AddInitiative(double Amount);
    void CreateCharacterBattleSlotUI();
    void SetCharacterDataFromHero(class UBP_CharacterData_C* HeroCharacterData);
    void SetCharacterData(FName HardcodedID, FText CharacterDisplayName, ETextGender GenderTag, TMap<TEnumAsByte<E_jRPG_StatType::Type>, double> CharacterStats, double CurrentHealth, double CurrentMana, FS_jRPG_OverdriveSource OverdriveSources, class UTexture2D* CharacterBattleIcon, FFCharacterStats& CommonCharacterStats, bool IsBoss, bool IsFlying, TMap<TEnumAsByte<EAttackType::Type>, TEnumAsByte<EElementalAffinity::Type>> ElementalAffinities);
    void ReceiveBeginPlay();
    void Internal_BeginPrepareForBattle();
    void ProcessSkillComponentStartEvents(const class USF_BlueprintLatentAction* LatentAction, bool ForceInstant);
    void BattleStart_SkillComponents_ProcessNext();
    void BattleStart_SkillComponent_OnAllProcessed();
    void Internal_FinishPrepareForBattle();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ExecuteUbergraph_AC_jRPG_CharacterBattleStats(int32 EntryPoint);
    void OnSkillStatesInitialized__DelegateSignature();
    void OnPerfectDodge__DelegateSignature();
    void OnSkillPreExecution__DelegateSignature(class UBP_SkillState_C* SkillState);
    void OnDamageAbsorbed__DelegateSignature(int64 Amount, class UBP_BattleDamages_C* BattleDamages);
    void OnDeathDamagePrevented__DelegateSignature(class UObject* CharacterStats);
    void OnAPChangedEvent__DelegateSignature(class UBP_BattleEvent_APChange_C* APChangeEvent);
    void OnConsumableActionEffect__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* SourceCharacterStats, TArray<ABP_jRPG_Character_Battle_Base_C*>& TargetCharacterBases, FName ShardID, FName ConsumableID);
    void OnBreakBarStun__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* SelfCharacter);
    void OnBreakDamageReceived__DelegateSignature(class UAC_jRPG_CharacterBattleStats_C* SelfCharacter, class UAC_jRPG_CharacterBattleStats_C* SourceCharacter, int32 PreviousValue);
    void OnDamageReceived__DelegateSignature(class UBP_BattleDamages_C* BattleDamages);
    void OnShieldPointsChanged__DelegateSignature(int32 CurrentValue, int32 PreviousValue);
    void OnDeath__DelegateSignature();
    void OnAPChanged__DelegateSignature(int32 NewAP, int32 PreviousAP, class UAC_jRPG_CharacterBattleStats_C* CharacterStats);
    void OnCharacterInitialized__DelegateSignature();
    void OnHPChanged__DelegateSignature(double NewHP, double PreviousHP);
    void OnBuffRemoved__DelegateSignature(class UBP_BattleBuffInstance_C* BuffInstance);
    void OnBuffAdded__DelegateSignature(class UBP_BattleBuffInstance_C* BuffInstance);
}; // Size: 0x7A8

#endif
