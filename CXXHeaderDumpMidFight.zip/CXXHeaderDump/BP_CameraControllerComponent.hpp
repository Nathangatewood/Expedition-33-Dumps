#ifndef UE4SS_SDK_BP_CameraControllerComponent_HPP
#define UE4SS_SDK_BP_CameraControllerComponent_HPP

class UBP_CameraControllerComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    TArray<UBP_CameraConfigBlender_C*> CameraConfigBlenders;                          // 0x00A8 (size: 0x10)
    bool ApplyCameraConfigs;                                                          // 0x00B8 (size: 0x1)
    bool IsCameraRecentering;                                                         // 0x00B9 (size: 0x1)
    FS_CameraRecenterRequest CameraRecenterRequest;                                   // 0x00C0 (size: 0x8)
    FRotator CachedControllerRotation;                                                // 0x00C8 (size: 0x18)
    double AccumulatedDeltaTime;                                                      // 0x00E0 (size: 0x8)
    bool EnableDynamicCameraFocus;                                                    // 0x00E8 (size: 0x1)
    double MaximumDynamicFocusDistance;                                               // 0x00F0 (size: 0x8)
    bool EnableCameraShakeWhenMoving;                                                 // 0x00F8 (size: 0x1)
    TArray<TEnumAsByte<E_CharacterList::Type>> CharactersToIgnoreCameraShake;         // 0x0100 (size: 0x10)
    class UCameraShakeBase* CameraShakeInPlay;                                        // 0x0110 (size: 0x8)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void StopAllCameraShakes();
    double ComputeCameraShakeScale();
    bool ShouldEnableCameraShake();
    void UpdateCameraShake(double DeltaSeconds);
    double ComputeDistanceBetweenCameraAndCharacterMesh();
    void UpdateDynamicCameraFocusDistance(double DeltaSeconds);
    void SetFocusDistance(float FocusDistance);
    void SetFocusDistanceWithComponent(class USceneComponent* ComponentToFocus);
    void SetupCameraConfigOnComponents(class UCameraComponent* CameraComponent, class USpringArmComponent* SpringArmComponent, const class UBP_DataAsset_CameraConfig_C*& CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void SetupCameraConfigOnFreeAimCamera(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void SetupCameraConfigOnMainCamera(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void DebugDrawCameraControllerComponent();
    void RemoveCameraConfigOnComponents(class UCameraComponent* CameraComponent, class USpringArmComponent* SpringArmComponent, const class UBP_DataAsset_CameraConfig_C*& CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void RemoveCameraConfigOnFreeAimCamera(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void RemoveCameraConfigOnMainCamera(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void GetOwnerAsCharacterWorld(class ABP_jRPG_Character_World_C*& CharacterWorld);
    void UpdateCameraRecenter(double DeltaSeconds);
    bool IsPerformingCameraRecenter();
    bool CanPerformCameraRecenter();
    void CancelCameraRecenter();
    void RequestCameraRecenter(FS_CameraRecenterRequest& CameraRecenterRequest);
    void UpdateCameraConfigBlenders(float DeltaSeconds);
    void AddNewCameraConfigOnComponents(class UCameraComponent* CameraComponent, class USpringArmComponent* SpringArmComponent, const class UBP_DataAsset_CameraConfig_C*& CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void FindOrCreateCameraConfigBlender(class UCameraComponent* CameraComponent, class USpringArmComponent* SpringArmComponent, class UBP_CameraConfigBlender_C*& CameraConfigBlender);
    void GetCameraConfig(int32 Index, FS_CameraConfig& CameraConfig);
    void AddCameraConfigOnFreeAimCamera(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void AddCameraConfigOnMainCamera(class UBP_DataAsset_CameraConfig_C* CameraConfig, FViewTargetTransitionParams TransitionParameters);
    void SetupCameraConfigs(class UBP_DataAsset_CameraConfig_C* CameraConfig, class UBP_DataAsset_CameraConfig_C* FreeAimCameraConfig, FViewTargetTransitionParams TransitionParameters);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void SetGameplayPaused(bool Paused);
    void ExecuteUbergraph_BP_CameraControllerComponent(int32 EntryPoint);
}; // Size: 0x118

#endif
