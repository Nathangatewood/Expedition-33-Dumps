#ifndef UE4SS_SDK_BP_BattleBuff_BurnAggregator_HPP
#define UE4SS_SDK_BP_BattleBuff_BurnAggregator_HPP

class UBP_BattleBuff_BurnAggregator_C : public UBP_BattleBuffInstance_AggregatorBase_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0178 (size: 0x8)
    double BurnDamageMultiplier;                                                      // 0x0180 (size: 0x8)
    TArray<UWBP_Buff_Burn_StackCounter_C*> BurnCounterWidgets;                        // 0x0188 (size: 0x10)
    class UAudioComponent* Sound Fire loop;                                           // 0x0198 (size: 0x8)
    class UNiagaraComponent* Niagara System;                                          // 0x01A0 (size: 0x8)

    void OnChildBuffInstanceStackChanged(class UBP_BattleBuffInstance_C* BuffInstance);
    void RefreshBurnCounterWidget();
    void OnChildBuffInstanceRemoved();
    void OnChildBuffInstanceAdded();
    void InitializeCustomBuffWidget(class UWBP_jRPG_BuffSlot_C* BuffWidget, bool& DummyOut);
    void Compute Burn Damage Total(double& TotalDamage);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnCharacterTurnStart(class UAC_jRPG_CharacterBattleStats_C* CharacterStats, const class UBP_DependencyRefCounter_C*& TurnStartDependencies);
    void DeactivateBuff();
    void Event Play Sound Feedback();
    void OnVisualEffectDimChange(bool IsDimmed);
    void ExecuteUbergraph_BP_BattleBuff_BurnAggregator(int32 EntryPoint);
}; // Size: 0x1A8

#endif
