#ifndef UE4SS_SDK_BP_BS_Item_EnergyMedium_HPP
#define UE4SS_SDK_BP_BS_Item_EnergyMedium_HPP

class ABP_BS_Item_EnergyMedium_C : public ABP_BS_Item_EnergyTint_Parent_C
{
}; // Size: 0x328

#endif
