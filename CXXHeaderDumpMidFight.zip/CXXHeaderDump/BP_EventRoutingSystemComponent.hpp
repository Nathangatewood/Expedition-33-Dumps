#ifndef UE4SS_SDK_BP_EventRoutingSystemComponent_HPP
#define UE4SS_SDK_BP_EventRoutingSystemComponent_HPP

class UBP_EventRoutingSystemComponent_C : public UActorComponent
{
    TMap<FFRoutedEventHandle, UBP_RoutedEventInstance_C*> SkillInstances;             // 0x00A0 (size: 0x50)
    FFRoutedEventHandle LastExecutedEventHandle;                                      // 0x00F0 (size: 0x20)

    void ClearLastExecutedEventHandle();
    FFRoutedEventHandle GetLastExecutedEventHandle();
    void ExecuteEventFromHandle(FFRoutedEventHandle& EventHandle);
    void DeclareEvent(FFRoutedEventHandle& SkillHandle, const FDeclareEventEvent& Event, FString DebugName);
}; // Size: 0x110

#endif
