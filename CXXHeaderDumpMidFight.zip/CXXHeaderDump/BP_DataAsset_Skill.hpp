#ifndef UE4SS_SDK_BP_DataAsset_Skill_HPP
#define UE4SS_SDK_BP_DataAsset_Skill_HPP

class UBP_DataAsset_Skill_C : public USkillDataAsset
{
    FName NameID;                                                                     // 0x0060 (size: 0x8)
    FDataTableRowHandle ActionRow;                                                    // 0x0068 (size: 0x10)
    TEnumAsByte<ESkillType::Type> SkillType;                                          // 0x0078 (size: 0x1)
    int32 APCost;                                                                     // 0x007C (size: 0x4)
    FText Name;                                                                       // 0x0080 (size: 0x10)
    FText Description;                                                                // 0x0090 (size: 0x10)
    FText ShortDescription;                                                           // 0x00A0 (size: 0x10)
    TEnumAsByte<E_jRPG_TargetingType::Type> TargetingType;                            // 0x00B0 (size: 0x1)
    TArray<FSkillDataComponent_Wrapper> SkillComponents;                              // 0x00B8 (size: 0x10)
    TArray<UBP_BattleAction_DataAsset_C*> ActionData;                                 // 0x00C8 (size: 0x10)
    TEnumAsByte<EAttackType::Type> BaseElementalType;                                 // 0x00D8 (size: 0x1)
    TEnumAsByte<ESkillElementOverride::Type> DynamicElementOverride;                  // 0x00D9 (size: 0x1)
    TSoftClassPtr<ABP_Battle_SkillScript_C> SkillScript;                              // 0x00E0 (size: 0x28)
    TEnumAsByte<E_jRPG_SpeedModifier::Type> TimelinePreview_TargetSpeedModifier;      // 0x0108 (size: 0x1)
    int32 TimelinePreview_TargetSpeedModifierDuration;                                // 0x010C (size: 0x4)
    int32 TimelinePreview_StunTurnDuration;                                           // 0x0110 (size: 0x4)
    FSkillDataComponent_Wrapper SkillDataComponent;                                   // 0x0118 (size: 0x8)

    void BPI_GetDependencies(TArray<TSoftClassPtr<UObject>>& Classes, TArray<TSoftObjectPtr<class UObject>>& Assets, TArray<TScriptInterface<class IBPI_LoadingDependenciesSource_C>>& ExternalDependencies);
    int32 GetSkillBaseCost();
    int32 GetSkillCost(class UBP_SkillState_C* SkillState);
    void FindSkillComponentsByClass(TSubclassOf<class UBP_SkillDataComponent_Base_C> SkillComponentClass, TArray<UBP_SkillDataComponent_Base_C*>& Array);
    void GetSkillComponentsAsBP(TArray<UBP_SkillDataComponent_Base_C*>& Array);
}; // Size: 0x120

#endif
