#ifndef UE4SS_SDK_BP_ConditionChecker_HasCharacterInCollection_HPP
#define UE4SS_SDK_BP_ConditionChecker_HasCharacterInCollection_HPP

class UBP_ConditionChecker_HasCharacterInCollection_C : public UBP_ConditionChecker_C
{
    TEnumAsByte<E_CharacterList::Type> Character;                                     // 0x0060 (size: 0x1)
    bool CheckExcludedCharacters;                                                     // 0x0061 (size: 0x1)

    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    bool CheckInternal();
}; // Size: 0x62

#endif
