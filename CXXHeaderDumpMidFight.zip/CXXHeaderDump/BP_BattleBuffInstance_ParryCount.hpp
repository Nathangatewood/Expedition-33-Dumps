#ifndef UE4SS_SDK_BP_BattleBuffInstance_ParryCount_HPP
#define UE4SS_SDK_BP_BattleBuffInstance_ParryCount_HPP

class UBP_BattleBuffInstance_ParryCount_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 ParryCountFromBattleStart;                                                  // 0x0160 (size: 0x4)
    int32 ParryCountFromLastTurn;                                                     // 0x0164 (size: 0x4)

    void ApplyOnTurnEnd();
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void OnParrySuccess(class ABP_jRPG_Character_Battle_Base_C* Character, class ABP_jRPG_Character_Battle_Base_C* Enemy);
    void ExecuteUbergraph_BP_BattleBuffInstance_ParryCount(int32 EntryPoint);
}; // Size: 0x168

#endif
