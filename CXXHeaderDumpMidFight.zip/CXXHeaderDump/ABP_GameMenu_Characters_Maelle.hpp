#ifndef UE4SS_SDK_ABP_GameMenu_Characters_Maelle_HPP
#define UE4SS_SDK_ABP_GameMenu_Characters_Maelle_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
}; // Size: 0x1718

class UABP_GameMenu_Characters_Maelle_C : public UABP_GameMenu_Characters_C
{
}; // Size: 0x1F31

#endif
