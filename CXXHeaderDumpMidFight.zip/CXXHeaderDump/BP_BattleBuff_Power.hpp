#ifndef UE4SS_SDK_BP_BattleBuff_Power_HPP
#define UE4SS_SDK_BP_BattleBuff_Power_HPP

class UBP_BattleBuff_Power_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    class USoundBase* BuffActivateSound;                                              // 0x0160 (size: 0x8)
    double DamageMultiplier;                                                          // 0x0168 (size: 0x8)

    void ProcessDealtRawDamages(class UBP_BattleDamages_C*& BattleDamages, bool& Out);
    void ActivateBuff(const class UAC_jRPG_CharacterBattleStats_C*& CharacterStats);
    void DeactivateBuff();
    void ExecuteUbergraph_BP_BattleBuff_Power(int32 EntryPoint);
}; // Size: 0x170

#endif
