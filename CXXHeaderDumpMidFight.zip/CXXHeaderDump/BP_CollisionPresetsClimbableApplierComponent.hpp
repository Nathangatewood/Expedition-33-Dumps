#ifndef UE4SS_SDK_BP_CollisionPresetsClimbableApplierComponent_HPP
#define UE4SS_SDK_BP_CollisionPresetsClimbableApplierComponent_HPP

class UBP_CollisionPresetsClimbableApplierComponent_C : public UBP_CollisionPresetsApplierComponent_C
{
}; // Size: 0xC0

#endif
