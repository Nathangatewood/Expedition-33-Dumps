#ifndef UE4SS_SDK_BP_CollisionPresetsApplierComponent_HPP
#define UE4SS_SDK_BP_CollisionPresetsApplierComponent_HPP

class UBP_CollisionPresetsApplierComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FName CollisionPresetsName;                                                       // 0x00A8 (size: 0x8)
    TArray<FFDebugMeshComponentToMaterialArray> Debug_MaterialArray;                  // 0x00B0 (size: 0x10)

    bool CheckForErrors(TArray<FText>& ErrorMessages);
    void DebugDisplay(bool Enabled);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_CollisionPresetsApplierComponent(int32 EntryPoint);
}; // Size: 0xC0

#endif
