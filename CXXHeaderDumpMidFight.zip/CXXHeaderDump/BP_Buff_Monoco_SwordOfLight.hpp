#ifndef UE4SS_SDK_BP_Buff_Monoco_SwordOfLight_HPP
#define UE4SS_SDK_BP_Buff_Monoco_SwordOfLight_HPP

class UBP_Buff_Monoco_SwordOfLight_C : public UBP_BattleBuffInstance_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0158 (size: 0x8)
    int32 SwordOfLightCastCount;                                                      // 0x0160 (size: 0x4)

    int32 GetCastCount();
    void IncreaseCastCount();
    void ExecuteUbergraph_BP_Buff_Monoco_SwordOfLight(int32 EntryPoint);
}; // Size: 0x164

#endif
