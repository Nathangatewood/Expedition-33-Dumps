#ifndef UE4SS_SDK_BP_BattleLineGatherer_HPP
#define UE4SS_SDK_BP_BattleLineGatherer_HPP

class UBP_BattleLineGatherer_C : public UExtendedObject
{
    TArray<FS_BattleLinePoolCandidate> CandidatePools;                                // 0x0028 (size: 0x10)
    TArray<FS_BattleLine> Lines;                                                      // 0x0038 (size: 0x10)
    TArray<FS_BattleLineCandidate> LineCandidates;                                    // 0x0048 (size: 0x10)

    void RollChancePercent(double ChancePercent, bool& Rolled);
    void SelectBattleLineCandidate(bool& Valid, FS_BattleLineCandidate& ChosenLine);
    void Roll();
    void RollFromPool(const FS_BattleLinePool& BattleLinePool, FS_BattleLine& BattleLine);
    void TryRegisterPool(FS_BattleLinePool Pool, double ChancePercent, class UBP_BattleLinesModel_Base_C* SourceModel, FString DebugReason, bool& Rolled);
    void RegisterPool(FS_BattleLinePool Pool, class UBP_BattleLinesModel_Base_C* SourceModel, FString DebugReason);
    void TryRegisterPerCharacterPool(FS_BattleLineEventPerCharacter PerCharacterLines, double ChancePercent, class UAC_jRPG_CharacterBattleStats_C* RelevantCharacter, class UBP_BattleLinesModel_Base_C* SourceModel, FString DebugReason, bool& Rolled);
    void RegisterPerCharacterPool(FS_BattleLineEventPerCharacter PerCharacterLines, class UAC_jRPG_CharacterBattleStats_C* RelevantCharacter, class UBP_BattleLinesModel_Base_C* SourceModel, FString DebugReason);
    void RegisterCandidateLine(const FS_BattleLine& NewLine, class UBP_BattleLinesModel_Base_C* SourceModel, FString DebugReason);
}; // Size: 0x58

#endif
