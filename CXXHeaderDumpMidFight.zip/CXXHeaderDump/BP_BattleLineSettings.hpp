#ifndef UE4SS_SDK_BP_BattleLineSettings_HPP
#define UE4SS_SDK_BP_BattleLineSettings_HPP

class UBP_BattleLineSettings_C : public UPrimaryDataAsset
{
    double GlobalChanceMultiplier;                                                    // 0x0030 (size: 0x8)
    double TurnStart_LowHP_Chance;                                                    // 0x0038 (size: 0x8)
    double TurnStart_FullAP_Chance;                                                   // 0x0040 (size: 0x8)
    double TurnStart_Normal_Chance;                                                   // 0x0048 (size: 0x8)
    double HealsSelf_Chance;                                                          // 0x0050 (size: 0x8)
    double HealsAlly_Chance;                                                          // 0x0058 (size: 0x8)
    double RevivedByAlly_Chance;                                                      // 0x0060 (size: 0x8)
    double RevivingOtherAlly_Chance;                                                  // 0x0068 (size: 0x8)
    double OtherAllyHealedByOther_Chance;                                             // 0x0070 (size: 0x8)
    double EnemyKilled_Chance;                                                        // 0x0078 (size: 0x8)
    double DeathOtherAlly_Chance;                                                     // 0x0080 (size: 0x8)
    double SelfTargetedByEnemy_Chance;                                                // 0x0088 (size: 0x8)
    double AllyTargetedByEnemy_Chance;                                                // 0x0090 (size: 0x8)

    bool RollChanceValue(double Percent);
}; // Size: 0x98

#endif
