#ifndef UE4SS_SDK_BP_ConditionChecker_HasAtLeastRelationshipLevel_HPP
#define UE4SS_SDK_BP_ConditionChecker_HasAtLeastRelationshipLevel_HPP

class UBP_ConditionChecker_HasAtLeastRelationshipLevel_C : public UBP_ConditionChecker_C
{
    TEnumAsByte<E_CharacterList::Type> Character;                                     // 0x0060 (size: 0x1)
    int32 Level;                                                                      // 0x0064 (size: 0x4)

    bool CheckInternal();
    void UnbindEventOnGameStateChanged(const FUnbindEventOnGameStateChangedEvent& Event);
    void BindEventOnGameStateChanged(const FBindEventOnGameStateChangedEvent& Event);
    void ValidateConditionChecker(TArray<FText>& ErrorMessages, FString& PropertyPath);
}; // Size: 0x68

#endif
