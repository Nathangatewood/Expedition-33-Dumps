#ifndef UE4SS_SDK_BP_FL_TutorialHelpers_HPP
#define UE4SS_SDK_BP_FL_TutorialHelpers_HPP

class UBP_FL_TutorialHelpers_C : public UBlueprintFunctionLibrary
{

    void SetTutorialCompletedByID(bool Completed, const FName& TutorialID, class UObject* __WorldContext);
    void SetTutorialCompletedByDataTableRow(bool Completed, FDataTableRowHandle TutorialCardRow, class UObject* __WorldContext);
    void SetSkipTurnPrevented(bool Prevented, class UObject* __WorldContext);
    void OneTimeDisplayTutorialCard(FName& TutorialID, class UObject* __WorldContext);
    void HighlightTutorialWidget(class UWidget* TargetWidget, FVector2D AdditionalHalfSize, class UObject* __WorldContext, class UWBP_Tuto_BlurIndicator_C*& AreaHighlightWidget);
    void GetWBP_BattleWheelAction(class UObject* __WorldContext, class UWBP_BattleWheel_C*& WBP_BattleWheel_Action);
    void DisableUI_InputsBlock(class UWBP_CommonUI_InvisibleModalInputBlocker_C*& WBPInputBlocker, class UObject* __WorldContext);
    class UWBP_CommonUI_InvisibleModalInputBlocker_C* EnableUI_InputsBlock(class UObject* __WorldContext);
    void DisplayTutorialHint(const FS_TutorialHintParameters& TutorialHintParameters, class UObject* __WorldContext);
    void DisplayTutorialCard(FS_TutorialCardParameters TutorialCardParameters, const FDisplayTutorialCardEvent& Event, class UObject* __WorldContext);
    bool AreTutorialsEnabled(class UObject* __WorldContext);
    class UBP_TutorialSystemComponent_C* GetTutorialSystemComponent(class UObject* __WorldContext);
}; // Size: 0x28

#endif
